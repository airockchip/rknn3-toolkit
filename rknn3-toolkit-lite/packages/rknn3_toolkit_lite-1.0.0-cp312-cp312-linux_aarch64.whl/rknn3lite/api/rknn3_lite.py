# -*- coding:utf-8 -*-

import os
import copy
import traceback
import platform
from .rknn3_runtime import RKNN3Runtime, RKNN3CoreMask, RKNN3Config
from .rknn3_log import set_log_level_and_file_path
from .rknn3_lite_llm import RKNN3Lite_LLM


class RKNN3Lite:
    RKNN3CoreMask = RKNN3CoreMask
    """
    Rockchip NN Kit
    """
    def __init__(self, llm_mode=False, verbose=False, verbose_file=None):
        self.verbose = verbose
        if verbose_file is not None:
            if os.path.dirname(verbose_file) != "" and not os.path.exists(os.path.dirname(verbose_file)):
                verbose_file = None
        self.rknn_log = set_log_level_and_file_path(verbose, verbose_file)

        # get rknn3-toolkit-lite version
        try:
            import importlib.metadata
            self.rknn_log.w('rknn3-toolkit-lite version: ' +
                            importlib.metadata.version("rknn3-toolkit-lite"))
        except Exception:
            pass

        if verbose:
            if verbose_file is None:
                self.rknn_log.w('Verbose file path is invalid, debug info will not dump to file.')
            else:
                self.rknn_log.d('Save log info to: {}'.format(verbose_file))

        self.rknn_runtime = None
        self.llm = None
        self.rknn_config = RKNN3Config()
        self.model_data = None
        self.weight_data = None
        self.llm_mode = llm_mode


    def load_rknn(self, model_path, weight_path):
        """
        Load RKNN model
        :param model_path: RKNN model file path
        :param weight_path: RKNN weight file path
        :return: success: 0, failure: -1
        """
        if not os.path.exists(weight_path) or not os.path.exists(model_path):
            self.rknn_log.e('Invalid RKNN weight path or model path: {} or {}'.format("None" if (weight_path is None or weight_path == "") else weight_path, 
                                                                                      "None" if (model_path is None or model_path == "") else model_path),
                            False)
            return -1
        try:
            # Read RKNN model file data
            with open(weight_path, 'rb') as f1:
                self.weight_data = f1.read()
            with open(model_path, 'rb') as f2:
                self.model_data = f2.read()
        except:
            self.rknn_log.e('Catch exception when loading RKNN model [{}, {}]!'.format(weight_path, model_path), False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1

        if self.weight_data is None or self.model_data is None:
            return -1

        return 0

    def init_runtime(self, target, core_mask, llm_args=None, llm_callback=None, llm_embed_path=None, device_id=None):
        """
        Init run time environment. Needed by called before inference or eval performance.
        :param target:Specifies the coprocessor; currently, rk1820/rk1828 are supported.
        :param core_mask: NPU core mask. The co-processor contains 8 NPU cores, and this parameter specifies the enabled cores using a bitmask. For example, 0x0f (binary 0b00001111) indicates the use of the first 4 NPU cores. Note that this parameter must be consistent with the core_mask used when converting the RKNN model; otherwise, an error will occur.
        :param llm_args: A dictionary of configuration parameters for the LLM model.
        :param llm_callback: A callback function for the LLM model, which can be used for streaming inference.
        :param llm_embed_path:The embedding vocabulary path, required to initialize the LLMGetEmbedCallback.
        :return: success: 0, failure: -1
        """
        self.rknn_log.d('target set by user is: {}'.format(target))

        if target is None and platform.machine() != 'aarch64' and platform.machine() != 'armv7l':
            support_target = 'rk1820 / rk1828'
            self.rknn_log.e("RKNN Toolkit Lite3 does not support simulator, please specify the target: {}", False).\
                format(support_target)
            return -1

        if self.weight_data is None or self.model_data is None:
            self.rknn_log.e("Model is not loaded yet, this interface should be called after load_rknn!", False)
            return -1

        # if rknn_runtime is not None, release it first
        if self.rknn_runtime is not None:
            self.rknn_runtime.destroy()
            self.rknn_runtime = None
        try:
            self.rknn_runtime = RKNN3Runtime(target=target)
        except:
            self.rknn_log.e('Catch exception when load library!', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1

        # rknn_init
        try:
            self.rknn_runtime.rknn_init(device_id=device_id)
        except:
            self.rknn_log.e('Catch exception when init runtime!', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        
        # load rknn model
        try:
            self.rknn_runtime.load_model_from_data(self.model_data, self.weight_data)
        except:
            self.rknn_log.e('Catch exception when load model data!', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        
        # model init
        self.rknn_config.run_core_mask = core_mask
        try:
            ret = self.rknn_runtime.model_init(self.rknn_config)
        except:
            self.rknn_log.e('Catch exception when set npu core mode.', False)
            return -1
        
        # session_init
        if self.llm_mode:
            try:
                self.llm = RKNN3Lite_LLM(self.rknn_runtime.lib, self.rknn_runtime.context, self.rknn_log, llm_args, llm_callback, llm_embed_path)
            except:
                self.rknn_log.e('Catch exception when init llm session!', False)
                self.rknn_log.e(traceback.format_exc(), False)
                return -1
        
        # set tensor
        if not self.llm_mode:
            try:
                self.rknn_runtime.creat_tensor()
            except:
                self.rknn_log.e('Catch exception when creat tensor.', False)
                self.rknn_log.e(traceback.format_exc(), False)
                return None

        return ret
    

    def inference(self, inputs=None, data_format=None):
        """
        Run model inference
        :param inputs: Input data List (ndarray list)
        :param data_format: Input format list (str list). Data format (str), current support: 'undefined' 'nhwc' and 'nchw', default is None.
        :return: Output data (ndarray list)
        """
        if self.llm is not None:
             self.rknn_log.e('This interface is only for RKNN model inference, please use session_run for LLM model inference!', False)
             return None

        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
            return None
        
        if inputs is None:
            self.rknn_log.e('inputs is None, the model requires input', False)
            return None
        
        if data_format is not None and len(data_format) != len(inputs):
            self.rknn_log.e('data_format length is not equal to inputs length', False)
            return None

        # set inputs
        try:
            self.rknn_runtime.set_input_tensor(inputs, data_format)
        except:
            self.rknn_log.e('Catch exception when setting inputs.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return None

        # run
        try:
            ret = self.rknn_runtime.run()
        except:
            self.rknn_log.e('Catch exception when running RKNN model.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return None

        try:
            outputs = self.rknn_runtime.get_outputs()
        except:
            self.rknn_log.e('Catch exception when getting outputs.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return None

        return outputs

    
    def session_run(self, inputs=None, prompt=None, embeds=None):
        """
        Run model inference
        :param inputs: Input data list for multimodal models. Type is list, elements can be RKNN3Image, RKNN3Audio, RKNN3Video, or RKNN3AuxTensor.
        :param prompt: Text prompt input for LLM models, used in multimodal or auxiliary input scenarios.
        :param embeds: Input embedding vectors for LLM models. The type is ndarray.
        :return: ret (0 for success, -1 for failure), and performance stats list [n_decode_tokens, n_prefill_tokens, llm_start_time, llm_end_time]
        """

        if self.llm is None:
            self.rknn_log.e('RKNN model inference, please use inference interface!', False)
            return -1, []
        
        try:
            ret, [n_decode_tokens, n_prefill_tokens, llm_start_time, llm_end_time] = self.llm.inference(prompt=prompt, embeds=embeds, inputs=inputs)
        except:
            self.rknn_log.e('Catch exception when running LLM model.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1, []
        return ret, [n_decode_tokens, n_prefill_tokens, llm_start_time, llm_end_time]

    def get_sdk_version(self):
        """
        Get SDK version
        :return: sdk_version
        """
        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
            return None

        try:
            sdk_version, _, _ = self.rknn_runtime.get_sdk_version()
        except:
            self.rknn_log.e('Catch exception when get sdk version', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return None

        return sdk_version
    
    def set_chat_template(self, system_prompt, prompt_prefix, prompt_postfix):
        """
        Set chat template for LLM model
        :param system_prompt: System prompt
        :param prompt_prefix: Prompt prefix
        :param prompt_postfix: Prompt postfix
        :return: success: 0, failure: -1
        """
        if self.llm is None:
            self.rknn_log.e('LLM runtime environment is not inited, please call init_runtime and set llm_init first!', False)
            return -1

        try:
            ret = self.llm.set_chat_template(system_prompt, prompt_prefix, prompt_postfix)
        except:
            self.rknn_log.e('Catch exception when setting chat template.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1

        return ret

    def get_devices_id(self):
        """
        Get devices id
        :return: id
        """
        rknn_runtime = RKNN3Runtime(target="rk1820")
        list_devices = rknn_runtime.list_devices()
        devices = []
        if list_devices.n_devices > 0:
            for i in range(list_devices.n_devices):
                devices.append(list_devices.devices[i].id)
        rknn_runtime.release()
        return devices
    
    def get_inputs_tensor_attr(self):
        """
        Get input tensor attribute
        :return: inputs tensor attribute
        """
        if self.llm is not None:
            input_attr =  self.llm.rknn_session.get_inputs_tensor_attr()
        else:
            if self.rknn_runtime is None:
                self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
                return None

            try:
                input_attr = self.rknn_runtime.get_inputs_tensor_attr()
            except:
                self.rknn_log.e('Catch exception when getting input tensor attribute.', False)
                self.rknn_log.e(traceback.format_exc(), False)
                return None
            
        if input_attr is None:
            self.rknn_log.e('Please check if the model is initialized correctly.')

        return input_attr
    
    def get_outputs_tensor_attr(self):
        """
        Get output tensor attribute
        :return: outputs tensor attribute
        """
        if self.llm is not None:
            return self.llm.rknn_session.get_outputs_tensor_attr()

        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
            return None

        try:
            output_attr = self.rknn_runtime.get_outputs_tensor_attr()
        except:
            self.rknn_log.e('Catch exception when getting output tensor attribute.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return None

        if output_attr is None:
            self.rknn_log.e('Please check if the model is initialized correctly.')  

        return output_attr

    def release(self):
        """
        Release RKNN resource
        :return: None
        """
        # release rknn session
        if self.llm is not None:
            self.llm.release()
            self.llm = None
        # release rknn runtime
        if self.rknn_runtime is not None:
            self.rknn_runtime.release()
            self.rknn_runtime = None
