"""
RKNN3 Types and Structures Definition
This file contains all the type definitions, structures, enumerations, and constants
used by RKNN3 Toolkit Lite, similar to a C header file.
"""

import platform
import numpy as np
from ctypes import *
from enum import IntEnum, auto


# ============================================= Constants =============================================

# RKNN3 Maximum Values
RKNN3_MAX_DIMS = 16
RKNN3_MAX_STRIDE_DIMS = RKNN3_MAX_DIMS + 1
RKNN3_MAX_NAME_LEN = 256
RKNN3_MAX_DYNAMIC_SHAPE_NUM = 512
RKNN3_MAX_LORA_NUM = 32
RKNN3_MAX_DEVS = 64
RKNN3_MAX_DEV_LEN = 64
RKNN3_MAX_NPU_NODE_NUM = 128
RKNN3_MAX_KVCACHE_LEN_GROUPS = 16
RKNN3_MAX_ATTENTION_TYPE_NUM = 3

# LLM Special Token Limits
RKNN3_MAX_SPECIAL_BOS_ID_NUM = 64  # maximum number of special Begin-Of-Sequence (BOS) token
RKNN3_MAX_SPECIAL_EOS_ID_NUM = 64  # maximum number of special End-Of-Sequence (EOS) token

# Library Path
LIBRKNN3RT_PATHS = ['/usr/lib/librknn3_api.so', '/usr/lib/librknn3_api_rkcp.so', '/usr/lib/librknn3_api_native.so']

# Context Types
if platform.architecture()[0] == '32bit':
    rknn3_context = c_uint32
else:
    rknn3_context = c_uint64

rknn3_session = c_void_p

# API Return Codes
rknn3_runtime_api_ret_code = {
    "0"  : "RKNN3_SUCCESS",
    "-1" : "RKNN3_ERR_FAIL",
    "-2" : "RKNN3_ERR_ARGUMENT_INVALID",
    "-3" : "RKNN3_ERR_MODEL_INVALID",
    "-4" : "RKNN3_ERR_CTX_INVALID",
    "-5" : "RKNN3_ERR_RUN_TASK_FAILED",
    "-6" : "RKNN3_ERR_OUT_OF_MEMORY",
    "-7" : "RKNN3_ERR_TIMEOUT",
    "-8" : "RKNN3_ERR_INPUT_INVALID",
    "-9" : "RKNN3_ERR_OUTPUT_INVALID",
    "-10": "RKNN3_ERR_DEVICE_UNAVAILABLE",
    "-11": "RKNN3_ERR_DEVICE_UNMATCH",
    "-12": "RKNN3_ERR_TARGET_PLATFORM_UNMATCH",
    "-13": "RKNN3_ERR_COMMUNICATION",
    "-14": "RKNN3_ERR_MEM_SYNC_FAILED",
    "-15": "RKNN3_ERR_KEY_INVALID",
    "-16": "RKNN3_ERR_DECRYPT_FAILED",
    "-17": "RKNN3_ERR_WEIGHT_LOAD_NOT_PREPARED",
    "-18": "RKNN3_ERR_INCOMPATIBLE_VERSION",
    "-100": "RKNN3_WARN_NPU_CORE_UNUSED",
}


# ============================================= Enumerations =============================================

class RKNN3QueryCmd(IntEnum):
    """Query command types for RKNN3"""
    RKNN3_QUERY_IN_OUT_NUM = 0                  # query the number of input & output tensor.
    RKNN3_QUERY_INPUT_ATTR = 1                  # query the attribute of input tensor.
    RKNN3_QUERY_OUTPUT_ATTR = 2                 # query the attribute of output tensor.

    # Deprecated by the current public header but kept as aliases for older SO compatibility.
    RKNN3_QUERY_PERF_DETAIL = 3
    RKNN3_QUERY_PERF_RUN = 4

    RKNN3_QUERY_SDK_VERSION = 5                 # query the sdk & driver version
    RKNN3_QUERY_CORE_MEM_SIZE = 6               # query the weight & internal memory size of each core
    RKNN3_QUERY_CUSTOM_STRING = 7               # query the custom string

    # New names in rknn3_api.h
    RKNN3_QUERY_ORIGIN_INPUT_ATTR = 8           # query the attribute of origin input tensor.
    RKNN3_QUERY_ORIGIN_OUTPUT_ATTR = 9          # query the attribute of origin output tensor.

    # Backward-compatible aliases used by older Python code.
    RKNN3_QUERY_NATIVE_INPUT_ATTR = RKNN3_QUERY_ORIGIN_INPUT_ATTR
    RKNN3_QUERY_NATIVE_OUTPUT_ATTR = RKNN3_QUERY_ORIGIN_OUTPUT_ATTR
    RKNN3_QUERY_NATIVE_NC1HWC2_INPUT_ATTR = RKNN3_QUERY_ORIGIN_INPUT_ATTR
    RKNN3_QUERY_NATIVE_NC1HWC2_OUTPUT_ATTR = RKNN3_QUERY_ORIGIN_OUTPUT_ATTR
    RKNN3_QUERY_NATIVE_NHWC_INPUT_ATTR = 10
    RKNN3_QUERY_NATIVE_NHWC_OUTPUT_ATTR = 11

    RKNN3_QUERY_DEVICE_MEM_INFO = 12            # query the attribute of rknn3 memory information.
    RKNN3_QUERY_CORE_NUMBER = 13                # query the core number
    RKNN3_QUERY_ALLOCATION_INFO = 14            # query the allocation info
    RKNN3_QUERY_DYNAMIC_SHAPE_CONFIG = 15       # query the complete dynamic shape config
    RKNN3_QUERY_DYNAMIC_SHAPE_INFO = 16         # query all supported shape combinations
    RKNN3_QUERY_LLM_CONFIG = 17                 # query the LLM config
    RKNN3_QUERY_POSTPROCESS_IN_OUT_NUM = 18     # query the number of postprocess input and output, only valid when postprocess is enabled
    RKNN3_QUERY_POSTPROCESS_OUTPUT_ATTR = 19    # query the attribute of postprocess output tensor, only valid when postprocess is enabled
    RKNN3_QUERY_POSTPROCESS_DYNAMIC_SHAPE_INFO = 20  # query the dynamic shape info of postprocess, only valid when postprocess is enabled
    RKNN3_QUERY_LORA_NUM = 21                   # query the number of LoRA adapters
    RKNN3_QUERY_LORA_INFO = 22                  # query the LoRA information
    RKNN3_QUERY_KVCACHE_LEN_GROUP_INFO = 23     # query the kvcache length group info (group count, per-group per-core kvcache sizes)

    RKNN3_QUERY_CMD_MAX = 24


class RKNN3TensorType(IntEnum):
    """Tensor data types supported by RKNN3"""
    RKNN3_TENSOR_FLOAT32 = 0      # data type is float32.
    RKNN3_TENSOR_FLOAT16 = 1      # data type is float16.
    RKNN3_TENSOR_INT8 = 2         # data type is int8.
    RKNN3_TENSOR_UINT8 = 3        # data type is uint8.
    RKNN3_TENSOR_INT16 = 4        # data type is int16.
    RKNN3_TENSOR_UINT16 = 5       # data type is uint16.
    RKNN3_TENSOR_INT32 = 6        # data type is int32.
    RKNN3_TENSOR_UINT32 = 7       # data type is uint32.
    RKNN3_TENSOR_INT64 = 8        # data type is int64.
    RKNN3_TENSOR_UINT64 = 9       # data type is uint64.
    RKNN3_TENSOR_BOOL = 10        # data type is boolean.
    RKNN3_TENSOR_INT4 = 11        # data type is int4.
    RKNN3_TENSOR_FLOAT8E4M3FN = 12  # data type is float8e4m3fn.
    RKNN3_TENSOR_BFLOAT16 = 13    # data type is bfloat16.
    RKNN3_TENSOR_FLOAT8E8M0 = 14   # data type is float8e8m0.
    RKNN3_TENSOR_FLOAT4E2M1 = 15   # data type is float4e2m1 (fp4).

    RKNN3_TENSOR_TYPE_MAX = 16


class RKNN3TensorQntType(IntEnum):
    """Tensor quantization types"""
    RKNN3_TENSOR_QNT_NONE = 0                    # none.
    RKNN3_TENSOR_PER_LAYER_SYMMETRIC = 1         # per layer symmetric.
    RKNN3_TENSOR_PER_LAYER_ASYMMETRIC = 2        # per layer asymmetric.
    RKNN3_TENSOR_PER_CHANNEL_SYMMETRIC = 3       # per channel symmetric.
    RKNN3_TENSOR_PER_CHANNEL_ASYMMETRIC = 4      # per channel asymmetric.
    RKNN3_TENSOR_PER_GROUP_SYMMETRIC = 5         # per group symmetric.
    RKNN3_TENSOR_PER_GROUP_ASYMMETRIC = 6        # per group asymmetric.

    RKNN3_TENSOR_QNT_MAX = auto()


class RKNN3TensorLayout(IntEnum):
    """Tensor layout formats"""
    RKNN3_TENSOR_UNDEFINED = 0
    RKNN3_TENSOR_NCHW = 1
    RKNN3_TENSOR_NHWC = 2
    RKNN3_TENSOR_NC1HWC2 = 3
    RKNN3_TENSOR_CHWN = 4
    RKNN3_TENSOR_HWIO = 5
    RKNN3_TENSOR_OIHW = 6
    RKNN3_TENSOR_O1I1HWI2O2 = 7

    RKNN3_TENSOR_LAYOUT_MAX = auto()


class RKNN3MemAllocFlags(IntEnum):
    """Memory allocation flags for creating RKNN3 tensor memory"""
    RKNN3_FLAG_MEMORY_FLAGS_DEFAULT = 0 << 0     # Same with RKNN3_FLAG_MEMORY_CACHEABLE
    RKNN3_FLAG_MEMORY_CACHEABLE = 1 << 0         # Create Cacheable memory.
    RKNN3_FLAG_MEMORY_NON_CACHEABLE = 1 << 1     # Create NON-Cacheable memory.


class RKNN3MemSyncMode(IntEnum):
    """Memory synchronization modes for rknn3_mem_sync function"""
    # the mode used for consistency of device access after CPU accesses data.
    RKNN3_MEMORY_SYNC_TO_DEVICE = 0x1
    # the mode used for consistency of CPU access after device accesses data.
    RKNN3_MEMORY_SYNC_FROM_DEVICE = 0x2
    # the mode used for consistency of data access between device and CPU in both directions.
    RKNN3_MEMORY_SYNC_BIDIRECTIONAL = RKNN3_MEMORY_SYNC_TO_DEVICE | RKNN3_MEMORY_SYNC_FROM_DEVICE


class RKNN3CoreMask(IntEnum):
    """The mode of running on target NPU core."""
    RKNN3_NPU_CORE_AUTO = 0          # default, run on NPU core randomly.
    RKNN3_NPU_CORE_0 = 1 << 0        # run on NPU core 0.
    RKNN3_NPU_CORE_1 = 1 << 1        # run on NPU core 1.
    RKNN3_NPU_CORE_2 = 1 << 2        # run on NPU core 2.
    RKNN3_NPU_CORE_3 = 1 << 3        # run on NPU core 3.
    RKNN3_NPU_CORE_4 = 1 << 4        # run on NPU core 4.
    RKNN3_NPU_CORE_5 = 1 << 5        # run on NPU core 5.
    RKNN3_NPU_CORE_6 = 1 << 6        # run on NPU core 6.
    RKNN3_NPU_CORE_7 = 1 << 7        # run on NPU core 7.
    RKNN3_NPU_CORE_ALL = 0xFFFFFFFF  # auto choice, run on NPU cores depending on platform


class RKNN3MemType(IntEnum):
    """Memory type for creating RKNN tensor memory"""
    RKNN3_MEMORY_TYPE_NPU_DRAM = 0 << 0     # NPU DRAM memory.
    RKNN3_MEMORY_TYPE_EXT_DDR = 1 << 0      # External DDR memory.


class RKNN3KVCacheDtype(IntEnum):
    """KV Cache data type"""
    RKNN3_KVCACHE_DTYPE_UNDEFINED = 0    # Undefined.
    RKNN3_KVCACHE_DTYPE_INT4_TO_F16 = 1  # Int4 to F16.
    RKNN3_KVCACHE_DTYPE_INT4_TO_F8 = 2   # Int4 to F8.
    RKNN3_KVCACHE_DTYPE_INT8_TO_F16 = 3  # Int8 to F16.
    RKNN3_KVCACHE_DTYPE_FLOAT4_TO_F16 = 4  # Float4 to F16.
    RKNN3_KVCACHE_DTYPE_FLOAT4_TO_F8 = 5   # Float4 to F8.
    RKNN3_KVCACHE_DTYPE_FLOAT8_TO_F16 = 6  # Float8 to F16.
    RKNN3_KVCACHE_DTYPE_FLOAT8_TO_F8 = 7   # Float8 to F8.
    RKNN3_KVCACHE_DTYPE_FLOAT16 = 8       # Float16.


class RKNN3KVCacheStoreMethod(IntEnum):
    """KV Cache store method"""
    RKNN3_KVCACHE_STORE_METHOD_UNDEFINED = 0  # Undefined.
    RKNN3_KVCACHE_STORE_METHOD_NORMAL = 1     # Normal.
    RKNN3_KVCACHE_STORE_METHOD_GROUP_QUANT = 2  # GroupQuant.


class RKNN3AttentionType(IntEnum):
    """Attention type for LLM attention configs."""
    RKNN3_ATTENTION_TYPE_FULL_ATTENTION = 0
    RKNN3_ATTENTION_TYPE_SLIDING_ATTENTION = 1
    RKNN3_ATTENTION_TYPE_LINEAR_ATTENTION = 2


class RKNN3KVCachePolicy(IntEnum):
    """The policy of KV cache."""
    RKNN3_KVCACHE_POLICY_DEFAULT = 0          # Default cache policy is RKNN3_KVCACHE_POLICY_RECURRENT
    RKNN3_KVCACHE_POLICY_RECURRENT = 1        # Use recurrent cache policy.
    RKNN3_KVCACHE_POLICY_NORMAL = 2           # Use normal cache policy. Only use KV cache with max_context_len

    RKNN3_KVCACHE_POLICY_SAVE_CHECKPOINT = 0x100  # Use checkpoint cache policy.


class RKNN3KVCacheClearPolicy(IntEnum):
    """Policies for clearing KV cache.

    Enumerates the different policies for clearing the key-value cache:
    - RKNN3_KVCACHE_CLEAR_ALL: Completely clears all KV cache entries
    - RKNN3_KVCACHE_KEEP_SYSTEM_PROMPT: Clears KV cache while preserving system prompt entries
    """
    RKNN3_KVCACHE_CLEAR_ALL = 0           # Clear all KV cache entries
    RKNN3_KVCACHE_KEEP_SYSTEM_PROMPT = auto()  # Clear KV cache but keep system prompt entries


class RKNN3LLMInputType(IntEnum):
    """Defines the types of inputs that can be fed into the LLM."""
    RKNN3_LLM_INPUT_PROMPT = 0       # Input is a text prompt.
    RKNN3_LLM_INPUT_TOKEN = 1        # Input is a sequence of tokens.
    RKNN3_LLM_INPUT_EMBED = 2        # Input is an embedding vector.
    RKNN3_LLM_INPUT_MULTIMODAL = 3   # Multimodal input
    RKNN3_LLM_INPUT_AUX = 4          # AUX input

    RKNN3_LLM_INPUT_MAX = auto()     # Maximum value for input type enumeration.


class LLMCallState(IntEnum):
    """Describes the possible states of an LLM call."""
    RKLLM_RUN_NORMAL = 0                # The LLM call is in a normal running state.
    RKLLM_RUN_WAITING = 1               # The LLM call is waiting for complete UTF-8 encoded character.
    RKLLM_RUN_FINISH = 2                # The LLM call has finished execution.
    RKLLM_RUN_STOP = 3                  # The LLM call is stopped by user.
    RKLLM_RUN_MAX_NEW_TOKEN_REACHED = 4 # The LLM call has reached the maximum number of new tokens.
    RKLLM_RUN_ERROR = 5                 # An error occurred during the LLM call.
    RKLLM_RUN_PAUSE = 6                 # The LLM call is paused.
    RKLLM_RUN_RESUME = 7               # The LLM call is resumed from pause.


class LLMOutputCallbackState(IntEnum):
    """Describes the possible states of the output callback."""
    RKLLM_OUTPUT_CALLBACK_PREFILL_PROCESSING = 0  # output_callback is processing in prefill stage.
    RKLLM_OUTPUT_CALLBACK_PREFILL_FINISHED = 1    # output_callback is finished in prefill stage.
    RKLLM_OUTPUT_CALLBACK_DECODE_PROCESSING = 2   # output_callback is processing in decode stage.
    RKLLM_OUTPUT_CALLBACK_DECODE_FINISHED = 3     # output_callback is finished in decode stage.


class RKNN3LLMTaskType(IntEnum):
    """The Large Language Model task type."""
    RKNN3_LLM_TASK_GENERATE = 0    # The generation task.
    RKNN3_LLM_TASK_EMBEDDING = 1   # The embedding task.
    RKNN3_LLM_TASK_RERANKER = 2    # The reranker task.


class RKNN3ImFmt(IntEnum):
    """Image format enumeration"""
    RKNN3_IM_FMT_RGB888 = 0          # General image processing, display rendering
    RKNN3_IM_FMT_BGR888 = 1          # OpenCV image processing
    RKNN3_IM_FMT_GRAY8 = 2           # Black and white images, OCR
    RKNN3_IM_FMT_YCbCr_420_SP = 3    # Video codec (H.264/H.265)
    RKNN3_IM_FMT_YCrCb_420_SP = 4    # Video codec (H.264/H.265)
    RKNN3_IM_FMT_YCbCr_422_SP = 5    # Video codec (H.264/H.265)
    RKNN3_IM_FMT_YCrCb_422_SP = 6    # Video codec (H.264/H.265)
    RKNN3_IM_FMT_UNKNOWN = 0xFFFF    # Unknown image format


class RKNN3ImProcFlag(IntEnum):
    """Image processing flags enumeration"""
    RKNN3_IM_PROC_FLAG_NONE = 0
    RKNN3_IM_PROC_FLAG_CROP = 1 << 0
    RKNN3_IM_PROC_FLAG_RESIZE = 1 << 1
    RKNN3_IM_PROC_FLAG_FILL = 1 << 5
    RKNN3_IM_PROC_FLAG_COLOR_SPACE_CONVERT = 1 << 6
    RKNN3_IM_PROC_FLAG_DECODE = 1 << 7
    RKNN3_IM_PROC_FLAG_ENCODE = 1 << 8


class RKNN3OpTargetType(IntEnum):
    """Backend execution device for custom operator."""
    RKNN3_OP_TARGET_TYPE_CPU = 1  # Backend device is CPU
    RKNN3_OP_TARGET_TYPE_MAX = auto()


class RKNN3OpPluginType(IntEnum):
    """Custom operator plugin type enumeration"""
    RKNN3_OP_PLUGIN_TYPE_POSTPROCESS = 0  # Postprocess plugin
    RKNN3_OP_PLUGIN_TYPE_CUSTOM_OP = 1    # Custom op plugin, currently not supported
    RKNN3_OP_PLUGIN_TYPE_MAX = auto()


# ============================================= Basic Structures =============================================

class RKNN3InputOutputNum(Structure):
    """The information for RKNN3_QUERY_IN_OUT_NUM."""
    _fields_ = [
        ("n_input", c_uint32),   # the number of input.
        ("n_output", c_uint32)   # the number of output.
    ]


class RKNN3QuantInfo(Structure):
    """Quantization information structure"""
    _fields_ = [
        ("scale", c_float),      # the pointer of scale data
        ("zero_point", c_int32)  # the pointer of zero point data
    ]


class RKNN3TensorAttr(Structure):
    """The information for RKNN3_QUERY_INPUT_ATTR / RKNN3_QUERY_OUTPUT_ATTR."""
    _fields_ = [
        ("index", c_uint32),                         # input parameter, the index of input/output tensor, need set before call rknn3_query.
        ("name", c_char * RKNN3_MAX_NAME_LEN),       # the name of tensor.
        ("n_dims", c_uint32),                        # the number of dimensions.
        ("shape", c_uint32 * RKNN3_MAX_DIMS),        # the valid dimensions array.
        ("aligned_size", c_uint64),                  # the size of tensor with aligned shape in bytes.
        ("n_stride", c_uint32),                      # the number of stride.
        ("stride", c_uint64 * RKNN3_MAX_STRIDE_DIMS), # the stride of tensor.
        ("n_elems", c_uint32),                       # the number of elements of tensor.
        ("dtype", c_int),                            # the data type of tensor.
        ("layout", c_int),                           # the data layout of tensor.
        ("qnt_type", c_int),                         # the quantization type of tensor.
        ("qnt_info", RKNN3QuantInfo),                # the quantization information of tensor.
        ("n_orig_dims", c_uint32),                   # the number of original dimensions.
        ("orig_shape", c_uint32 * RKNN3_MAX_DIMS),   # the valid original dimensions array.
        ("orig_layout", c_int),                      # the layout of original tensors
        ("core_id", c_int32)                         # the core id of tensor buffer.
    ]


class RKNN3PerfDetail(Structure):
    """Performance detail information"""
    _fields_ = [
        ("perf_data", c_char_p),
        ("data_len", c_uint64)
    ]


class RKNN3PerfRun(Structure):
    """Performance run information"""
    _fields_ = [
        ("run_duration", c_int64)
    ]


class RKNN3SDKVersion(Structure):
    """The information for RKNN3_QUERY_SDK_VERSION."""
    _fields_ = [
        ("api_version", c_char * 256),   # the version of rknn3 api.
        ("drv_version", c_char * 256)    # the version of rknn3 driver.
    ]


class RKNN3CoreMemSize(Structure):
    """The information for RKNN3_QUERY_CORE_MEM_SIZE."""
    _fields_ = [
        ("core_id", c_int32),       # the core id of memory.
        ("weight_size", c_uint64),  # the weight memory size
        ("internal_size", c_uint64), # the internal memory size
        ("reserved", c_uint8 * 32), # reserved
    ]


class RKNN3MemSize(Structure):
    """Memory size information"""
    _fields_ = [
        ("total_const_size", c_uint64), 
        ("total_internal_size", c_uint64),
        ("total_dma_allocated_size", c_uint64),
        ("total_sram_size", c_uint64),
        ("free_sram_size", c_uint64),
    ]


class RKNN3CustomString(Structure):
    """The information for RKNN3_QUERY_CUSTOM_STRING."""
    _fields_ = [
        ("string", c_char * 1024)   # the string of custom, lengths max to 1024 bytes
    ]


class RKNN3TensorMemory(Structure):
    """Tensor memory information structure"""
    _fields_ = [
        ("virt_addr", c_void_p),    # the virtual address of tensor buffer.
        ("phys_addr", c_uint64),    # the physical address of tensor buffer.
        ("fd", c_int32),            # the fd of tensor buffer.
        ("buffer_id", c_uint64),    # the buffer id of tensor buffer, used for memory management.
        ("offset", c_uint64),       # indicates the offset of the memory.
        ("size", c_uint64),         # the size of tensor buffer.
        ("flags", c_uint64),        # the flags of tensor buffer, reserved
        ("core_id", c_int32),       # the id of npu core
        ("priv_data", c_void_p),    # the private data of tensor buffer.
        ("mem_type", c_int),        # the memory type of tensor buffer.
    ]


class RKNN3Config(Structure):
    """The control parameters for model loading."""
    _fields_ = [
        ("priority", c_int32),          # the priority of run
        ("run_timeout", c_uint32),      # the timeout of run in ms, 0 means no timeout
        ("run_core_mask", c_uint32),    # the core mask of model execution
        ("user_mem_weight", c_uint8),   # whether the weight memory is allocated by user
        ("user_mem_internal", c_uint8), # whether the internal memory is allocated by user
        ("user_sram", c_uint8),         # whether the sram memory is allocated by user
        ("reserved", c_uint8 * 128),    # reserved
    ]


class RKNN3Tensor(Structure):
    """Structure representing a RKNN3 tensor containing memory and attribute information."""
    _fields_ = [
        ("mem", POINTER(RKNN3TensorMemory)),   # the memory information of tensor
        ("attr", POINTER(RKNN3TensorAttr))     # the attribute of tensor
    ]


class RKNN3AllocationInfo(Structure):
    """Structure containing memory allocation information for RKNN3 model."""
    _fields_ = [
        ("core_id", c_int32),               # the physical id of npu core
        ("command_mem", RKNN3TensorMemory),  # the memory information of command memory.
        ("weight_mem", RKNN3TensorMemory),   # the memory information of weight memory.
        ("internal_mem", RKNN3TensorMemory), # the memory information of internal memory.
        ("kvcache_mem", RKNN3TensorMemory),  # the memory information of kv cache memory.
        ("reserved", c_uint8 * 128),        # reserved
    ]


class RKNN3ShapeInfo(Structure):
    """Structure containing shape information for RKNN3 model tensors"""
    _fields_ = [
        ("shape_id", c_int32),                      # the unique ID of this shape combination
        ("n_inputs", c_uint32),                     # the number of input tensors
        ("input_attrs", POINTER(RKNN3TensorAttr)),  # array of input tensor attributes
        ("n_outputs", c_uint32),                    # the number of output tensors
        ("output_attrs", POINTER(RKNN3TensorAttr)), # array of output tensor attributes
        ("is_default", c_uint8),                    # whether this is the default shape
        ("reserved", c_uint8 * 31),                 # reserved
    ]


class RKNN3ShapeConfig(Structure):
    """Configuration structure for dynamic shape settings"""
    _fields_ = [
        # Number of shape combinations available
        ("n_shapes", c_uint32),
        # ID of the currently active shape configuration. A value of -1 indicates no active shape
        ("current_shape_id", c_int32)
    ]


class RKNN3InitExtend(Structure):
    """Structure containing device-specific initialization information"""
    _fields_ = [
        # input parameter, indicate which device selected. if only one device connected, can set nullptr.
        ("device_id", c_char_p),
        ("reserved", c_uint8 * 128)  # reserved
    ]


class RKNN3NodeMemInfo(Structure):
    """Structure containing memory information for RKNN3 device nodes"""
    _fields_ = [
        ("total", c_uint64),  # the total memory available for this node, unit Bytes
        ("free", c_uint64)    # the free memory available for this node, unit Bytes
    ]


class RKNN3DevMemInfo(Structure):
    """Structure containing memory information for RKNN3 device nodes"""
    _fields_ = [
        ("node_num", c_uint32),                                  # the number of nodes in the device
        ("sys_total", c_uint64),                                 # the total system memory of the device, unit Bytes
        ("sys_free", c_uint64),                                  # the free system memory of the device, unit Bytes
        ("node_mem_info", RKNN3NodeMemInfo * RKNN3_MAX_NPU_NODE_NUM)  # the memory information of each node
    ]


class RKNN3Device(Structure):
    """Structure representing a RKNN3 device"""
    _fields_ = [
        ("id", c_char * RKNN3_MAX_DEV_LEN),    # the device ID.
        ("type", c_char * RKNN3_MAX_DEV_LEN),  # the device type.
        ("mem_info", RKNN3DevMemInfo)           # the memory information of device.
    ]


class RKNN3Devices(Structure):
    """Structure containing information about RKNN3 devices"""
    _fields_ = [
        ("n_devices", c_uint32),                     # the number of devices.
        ("devices", RKNN3Device * RKNN3_MAX_DEVS)    # the devices information.
    ]


# ============================================= LLM Structures =============================================

class Float16(Structure):
    """Float16 representation"""
    _pack_ = 1
    _fields_ = [
        ("frac", c_uint16, 10),
        ("exp", c_uint16, 5),
        ("sign", c_uint16, 1),
    ]


class RKNN3VocabInfo(Structure):
    """Structure containing vocabulary information for RKNN3 models"""
    _fields_ = [
        ("vocab_size", c_int),                                       # Size of the vocabulary
        # ID of the special Begin-Of-Sequence (BOS) token
        ("special_bos_id", c_int * RKNN3_MAX_SPECIAL_BOS_ID_NUM),
        # ID of the special End-Of-Sequence (EOS) token
        ("special_eos_id", c_int * RKNN3_MAX_SPECIAL_EOS_ID_NUM),
        ("n_special_bos_id", c_int),                                 # Number of special Begin-Of-Sequence (BOS) token
        ("n_special_eos_id", c_int),                                 # Number of special End-Of-Sequence (EOS) token
        ("linefeed_id", c_int),                                      # ID of the linefeed token
        ("skip_special_token", c_bool),                              # Whether to skip special tokens during generation.
        ("ignore_eos_token", c_bool),                                # Whether to ignore EOS token during generation.
        ("reserved", c_uint8 * 64),
    ]


class RKNN3SamplingParams(Structure):
    """Sampling parameters for LLM generation"""
    _fields_ = [
        ('top_k', c_int32),              # Top-K sampling parameter for token generation.
        ('top_p', c_float),              # Top-P (nucleus) sampling parameter.
        ('temperature', c_float),        # Sampling temperature, affecting the randomness of token selection.
        ('repeat_penalty', c_float),     # Penalty for repeating tokens in generation.
        ('frequency_penalty', c_float),  # Penalizes frequent tokens during generation.
        ('presence_penalty', c_float),   # Penalizes tokens based on their presence in the input.
    ]


class RECURRENT(Structure):
    """Recurrent KV cache parameters.

    If the model contains a system prompt, the length of the system prompt is automatically used,
    and the parameters n_keep and n_keep_aligned are ignored.
    Otherwise, n_keep and n_keep_aligned are used to specify the number of cache to keep.
    """
    _fields_ = [
        ("n_keep", c_int64),         # Number of caches to keep when recurrent.
        ("n_keep_aligned", c_int64)  # Aligned number of caches to keep when recurrent, aligned to kvcache_group_size.
    ]


class SAVE_CHECKPOINT(Structure):
    """Parameters for saving checkpoints.

    Only takes effect for models with linear attention or sliding attention
    (e.g., Qwen3.5 and Gemma4 series models); has no effect on other models.
    """
    _fields_ = [
        # The position at which to begin saving checkpoints, e.g., position 0.
        # The value should be aligned to 128. If not aligned, it will be forcibly adjusted to an aligned value.
        ("checkpoint_start_pos", c_int64),
        # Token interval for saving checkpoints, e.g., save every 128 tokens.
        # The value should be aligned to 128. If not aligned, it will be forcibly adjusted to an aligned value.
        ("checkpoint_interval", c_int64),
        # Maximum number of checkpoints to save from checkpoint_start_pos.
        # The value should be less than (max_context_len - checkpoint_start_pos) / checkpoint_interval.
        # If not less, it will be forcibly adjusted to the maximum value.
        ("max_checkpoint_count", c_int64),
        # When set to true, the tail/last checkpoint slot is used as a overwrite slot.
        # (max_checkpoint_count - 1) checkpoints are saved at their corresponding, fixed positions.
        # Once the token position exceeds (checkpoint_start_pos + max_checkpoint_count * checkpoint_interval),
        # all subsequent checkpoints will overwrite the tail/last slot.
        # Example: max_checkpoint_count=5 means 4 fixed checkpoints + 1 rolling checkpoint tail.
        ("checkpoint_tail_overwrite", c_bool)
    ]


class RKNN3KVCachePolicyParam(Structure):
    """Defines parameters for the KV cache policy."""
    _fields_ = [
        ("recurrent", RECURRENT),          # Parameters for recurrent cache policy.
        ("save_checkpoint", SAVE_CHECKPOINT),  # Parameters for saving checkpoints.
        ("reserved", c_uint8 * 64)         # reserved
    ]


class RKNN3Lora(Structure):
    """Defines parameters for a Lora used in model fine-tuning."""
    _fields_ = [
        ("lora_name", c_char * RKNN3_MAX_NAME_LEN),  # Name of the Lora.
        ("scale", c_float)                           # Scaling factor for applying the Lora.
    ]


class RKNN3LLMTensor(Structure):
    """Structure representing a tensor for large language model operations."""
    _fields_ = [
        ("name", c_char_p),            # Name of this tensor.
        ("prompt", c_char_p),          # Text prompt input if input_type is RKLLM_INPUT_PROMPT.
        ("embed", POINTER(Float16)),   # Pointer to the embedding vector (of size n_tokens * hidden_size) if input_type is RKNN3_LLM_INPUT_EMBED.
        ("tokens", POINTER(c_int32)),  # Array of token IDs if input_type is RKNN3_LLM_INPUT_TOKEN.
        ("n_tokens", c_uint64),        # Number of tokens represented in the embedding.
        ("enable_thinking", c_bool)    # Controls whether "thinking mode" is enabled.
    ]


# Auxiliary tensor type (alias)
RKNN3AuxTensor = RKNN3Tensor


class RKNN3Image(Structure):
    """Image input for multimodal LLM"""
    _fields_ = [
        # Embedding of the image (size: n_image * n_image_tokens * embedding_dim * sizeof(float16)).
        ("image_embed", POINTER(Float16)),
        ("n_image_tokens", c_uint64),  # Number of image tokens.
        ("n_image", c_uint64),         # Number of images.
        ("image_start", c_char_p),     # Start tag for image in multimodal input.
        ("image_end", c_char_p),       # End tag for image in multimodal input.
        ("image_content", c_char_p),   # Content tag for image in multimodal input.
        ("image_width", c_uint64),     # Width of image.
        ("image_height", c_uint64),    # Height of image.
    ]


class RKNN3Audio(Structure):
    """Audio input for multimodal LLM"""
    _fields_ = [
        # Embedding of the audio (size: n_audio * n_audio_tokens * embedding_dim * sizeof(float16)).
        ("audio_embed", POINTER(Float16)),
        ("n_audio_tokens", c_uint64),  # Number of audio tokens.
        ("n_audio", c_uint64),         # Number of audio.
        ("audio_start", c_char_p),     # Start tag for audio in multimodal input.
        ("audio_end", c_char_p),       # End tag for audio in multimodal input.
        ("audio_content", c_char_p),   # Content tag for audio in multimodal input.
    ]


class RKNN3Video(Structure):
    """Video input for multimodal LLM"""
    _fields_ = [
        # Embedding of the video (size: n_video * n_frame_per_video * n_frame_tokens * embedding_dim * sizeof(float16)).
        ("video_embed", POINTER(Float16)),
        ("n_frame_tokens", c_uint64),      # Number of frame tokens.
        ("n_frame_per_video", c_uint64),   # Number of frames per video.
        ("n_video", c_uint64),             # Number of video.
        ("video_start", c_char_p),         # Start tag for video in multimodal input.
        ("video_end", c_char_p),           # End tag for video in multimodal input.
        ("video_content", c_char_p),       # Content tag for video in multimodal input.
        ("frame_width", c_uint64),         # Width of frame.
        ("frame_height", c_uint64),        # Height of frame.
    ]


class RKNN3LLMMultiModelTensor(Structure):
    """Represents multimodal input (e.g., text, image, audio, and video)."""
    _fields_ = [
        ("name", c_char_p),            # Name of this tensor.
        ("prompt", c_char_p),          # Text prompt input.
        ("tokens", POINTER(c_int32)),  # Array of token IDs.
        ("n_tokens", c_uint64),        # Number of token IDs.
        ("enable_thinking", c_bool),   # Controls whether "thinking mode" is enabled.
        ("image", RKNN3Image),         # Image-related data
        ("audio", RKNN3Audio),         # Audio-related data
        ("video", RKNN3Video),         # Video-related data
    ]


class RKNN3LLMInputUnion(Union):
    """Union for different LLM input types"""
    _fields_ = [
        ("llm_input", RKNN3LLMTensor),
        ("multimodal_input", RKNN3LLMMultiModelTensor),
        ("aux_input", RKNN3AuxTensor)
    ]


class RKNN3LLMInput(Structure):
    """Represents different types of input to the LLM via a union."""
    _fields_ = [
        # Message role: "user" (user input), "tool" (function result)
        ("role", c_char_p),
        # Specifies the type of input provided (e.g., token, embed, aux).
        ("input_type", c_int),
        ("input_union", RKNN3LLMInputUnion)
    ]


class RKNN3LLMExtendParam(Structure):
    """Extended LLM parameters"""
    _fields_ = [
        ("reserved", c_uint8 * 128)
    ]


class RKNN3LLMParam(Structure):
    """Defines the parameters for configuring an LLM instance."""
    _fields_ = [
        # Name of output logits. Required only when model has multiple outputs, otherwise can be NULL.
        ("logits_name", c_char_p),
        ("max_context_len", c_int32),             # Maximum number of tokens in the context.
        ("sampling_param", RKNN3SamplingParams),  # Sampling parameters for token generation.
        ("vocab_info", RKNN3VocabInfo),           # Vocabulary information.
        ("extend_param", RKNN3LLMExtendParam)     # Extend parameters.
    ]


class RKNN3LLMInferParam(Structure):
    """Structure for defining parameters during inference."""
    _fields_ = [
        ("keep_history", c_int),      # Flag to determine history retention (1: keep history, 0: discard history).
        ("max_new_tokens", c_int32),  # Maximum number of new tokens to generate.
        ("prefill_only", c_bool),     # Flag to prefill only. It means the model will only do prefill, and skip decode stage.
                                      # But still will do sampling for prefill output tokens. Default is false.
        ("disable_sampling", c_bool), # Flag to disable sampling. It means the model will not do sampling. Default is false.
                                      # Suitable for prefill-only scenario and do not want to get prefill output tokens.
                                      # Usually, when prefill_only is set to true, disable_sampling is also set to true
                                      # (Setting disable_sampling alone has no effect).
                                      # Such as for embedding and reranker models only want get embeddings without sampling.
        ("reserved", c_uint8 * 128),  # Reserved bytes for future use.
    ]


class RKLLMResult(Structure):
    """Structure to represent the result of LLM inference."""
    _fields_ = [
        ("token_ids", POINTER(c_int)),  # Pointer to the tokens generated by the LLM.
        ("num_tokens", c_int),          # Number of tokens generated.
    ]


class RKLLMRunState(Structure):
    """Structure to hold the state of the LLM run."""
    _fields_ = [
        ("n_total_tokens", c_uint64),    # Total number of tokens processed currently.
        ("n_reuse_tokens", c_uint64),    # Total number of tokens reused from KV cache (for the current input).
        ("n_max_tokens", c_uint64),      # Maximum number of tokens can be processed.
        ("n_prefill_tokens", c_uint64),  # Number of tokens processed during the prefill stage.
        ("n_decode_tokens", c_uint64),   # Number of tokens generated during the decode stage.
        ("n_input_tokens", c_uint64),    # Number of tokens input to the model (same as n_prefill_tokens).
        ("n_output_tokens", c_uint64),   # Number of tokens output from the model (n_output_tokens = n_decode_tokens + 1).
        ("input_tokens", POINTER(c_int32)),  # Pointer to the array of tokens input to the model. Should not be freed by the user.
        ("output_tokens", POINTER(c_int32)), # Pointer to the array of tokens output from the model. Should not be freed by the user.
        ("kvcache_policy", c_int),       # KV cache policy.
        ("n_loras_enabled", c_int32),    # Number of Lora enabled.
        ("loras_enabled", POINTER(RKNN3Lora)),  # Lora enabled.
    ]


class RKLLMResultLastHiddenLayer(Structure):
    """Last hidden layer result"""
    _fields_ = [
        ("hidden_states", POINTER(c_float)),  # Pointer to the hidden states.
        ("embd_size", c_int),                 # Embedding size.
        ("num_tokens", c_int)                 # Number of tokens.
    ]


class RKNN3AttentionKvCacheLens(Structure):
    """KV cache buffer length config for one attention type."""
    _fields_ = [
        ("attention_type", c_int),                                         # attention type
        ("n_kvcache_buffer_lens", c_uint32),                               # number of valid kvcache buffer lens
        ("kvcache_buffer_lens", c_int32 * RKNN3_MAX_KVCACHE_LEN_GROUPS),  # kvcache buffer lens
    ]


class RKNN3KvCacheLenGroupInfo(Structure):
    """Per-core kvcache length group information for RKNN3_QUERY_KVCACHE_LEN_GROUP_INFO.

    Usage: query RKNN3_QUERY_CORE_NUMBER to get core_number, then allocate
    RKNN3KvCacheLenGroupInfo info[core_number] and query with
    sizeof(RKNN3KvCacheLenGroupInfo) * core_number.
    """
    _fields_ = [
        ("core_id", c_int32),                                   # the physical id of npu core
        ("n_groups", c_uint32),                                 # number of kvcache length groups (0 = single-group legacy mode)
        ("active_group_id", c_int32),                           # currently active group_id (default 0)
        ("kvcache_sizes", c_uint64 * RKNN3_MAX_KVCACHE_LEN_GROUPS),  # kvcache_sizes[group_id] -> kvcache size for that group on this core
    ]


class RKNN3LLMConfig(Structure):
    """Configuration structure for LLM (Language Learning Model)"""
    _fields_ = [
        ("chat_template", c_char_p),                          # chat template
        ("vocab_size", c_uint32),                              # vocab size
        ("embedding_dim", c_uint32),                           # embedding dim
        ("max_ctx_len", c_uint32),                             # max context length
        ("max_position_embeddings", c_uint32),                # max position embeddings
        ("kvcache_store_method", c_int),                       # kvcache store method
        ("kvcache_dtype", c_int),                              # kvcache dtype
        ("kvcache_group_size", c_uint32),                      # kvcache group size
        ("kvcache_residual_depth", c_uint32),                  # kvcache residual depth
        ("model_type", c_char_p),                              # model type
        ("task_type", c_int),                                  # task type
        ("rope_cache_host_storage", c_uint8),                  # rope cache host storage
        ("n_attention_kvcache_lens", c_uint32),                # number of valid attention kvcache lens configs
        ("attention_kvcache_lens", RKNN3AttentionKvCacheLens * RKNN3_MAX_ATTENTION_TYPE_NUM),  # kvcache lens configs for attention types
        ("reserved", c_uint8 * 127),                           # reserved
    ]


class RKNN3ImRect(Structure):
    """Image rectangle structure"""
    _fields_ = [
        ("x", c_int),       # upper-left x.
        ("y", c_int),       # upper-left y.
        ("width", c_int),   # the width of rect.
        ("height", c_int),  # the height of rect.
    ]


class RKNN3ImMetadata(Structure):
    """Image metadata structure"""
    _fields_ = [
        ("peer_im_mem_addr", c_uint64),  # address of the image memory object on the peer side.
    ]


class RKNN3ImMem(Structure):
    """Image memory information structure"""
    _fields_ = [
        ("width", c_int),                       # the width of image buffer.
        ("height", c_int),                      # the height of image buffer.
        ("stride", c_int),                      # the stride of image buffer.
        ("format", c_int),                      # the format of image buffer.
        ("sync_to_host", c_bool),               # whether sync image data to host, default false.
        ("data_mem", POINTER(RKNN3TensorMemory)),  # the memory information of image buffer.
        ("metadata", RKNN3ImMetadata),          # extra bookkeeping shared between host and device.
    ]




# ============================================= Custom Operator Structures =============================================

class RKNN3CustomOpContext(Structure):
    """Custom operator context structure"""
    _fields_ = [
        ("rknn_ctx", rknn3_context),   # RKNN3 context handle, managed by framework
        ("priv_data", c_void_p),       # Private data managed by framework
        ("user_data", c_void_p),       # User data managed by user
    ]


RKNN3CustomOpInitCallback = CFUNCTYPE(c_int, POINTER(RKNN3CustomOpContext))
RKNN3CustomOpPrepareCallback = CFUNCTYPE(
    c_int, POINTER(RKNN3CustomOpContext), POINTER(RKNN3Tensor), c_uint32, POINTER(RKNN3Tensor), c_uint32
)
RKNN3CustomOpComputeCallback = CFUNCTYPE(
    c_int, POINTER(RKNN3CustomOpContext), POINTER(RKNN3Tensor), c_uint32, POINTER(RKNN3Tensor), c_uint32
)
RKNN3CustomOpDeinitCallback = CFUNCTYPE(c_int, POINTER(RKNN3CustomOpContext))
RKNN3CustomOpGetOutputNumCallback = CFUNCTYPE(c_int, POINTER(RKNN3CustomOpContext))
RKNN3CustomOpGetAttrsCallback = CFUNCTYPE(
    c_int, POINTER(RKNN3CustomOpContext), POINTER(RKNN3TensorAttr), c_uint32, POINTER(RKNN3TensorAttr), c_uint32
)


class RKNN3CustomOp(Structure):
    """RKNN3 Custom Operator structure definition"""
    _fields_ = [
        ("op_type", c_char_p),                   # Custom operator type name
        ("plugin_type", c_int),                   # Custom operator plugin type
        ("target", c_int),                        # Custom operator backend target
        ("version", c_uint32),                    # Custom operator version number
        ("author", c_char_p),                     # Custom operator author information
        ("description", c_char_p),                # Custom operator description
        ("init", RKNN3CustomOpInitCallback),      # [optional] Custom operator kernel initialization fallback function
        ("prepare", RKNN3CustomOpPrepareCallback),  # [optional] Custom operator kernel preparation fallback function
        ("compute", RKNN3CustomOpComputeCallback),  # [required] Custom operator kernel computation fallback function
        ("deinit", RKNN3CustomOpDeinitCallback),    # [optional] Custom operator kernel deinitialization fallback function
        ("get_output_num", RKNN3CustomOpGetOutputNumCallback),  # [optional] Get custom operator output number fallback function
        ("get_attrs", RKNN3CustomOpGetAttrsCallback),  # [optional] Get custom operator input and output tensor attributes fallback function
    ]


RKNN3RegisterCustomOpFunc = CFUNCTYPE(POINTER(RKNN3CustomOp), c_int)

# ============================================= Callback Types =============================================

# LLM Callback function types

# Callback function to handle LLM results.
#   userdata: Pointer to user data for the callback.
#   result: Pointer to the LLM result.
#   state: State of the LLM call (e.g., finished, error).
#   return: 0 on success, non-zero on error.
LLMResultCallback = CFUNCTYPE(c_int, c_void_p, POINTER(RKLLMResult), c_int)

# Callback function to handle sampling logits.
#   userdata: Pointer to user data for the callback.
#   logits: Pointer to the logits array.
#   logits_name: Name of the logits.
#   return: Return selected token id (>=0) on success, negative value on error.
LLMSamplingCallback = CFUNCTYPE(c_int, c_void_p, POINTER(Float16), c_char_p)

# Callback function to get LLM embeddings.
#   userdata: Pointer to user-defined data.
#   tokens: Array of token IDs.
#   num_tokens: Number of tokens in the tokens array.
#   embed: Pointer to buffer that will store the embedding output.
#   len: Length of the embedding buffer in bytes.
#   return: Returns 0 on success, non-zero value on failure.
LLMGetEmbedCallback = CFUNCTYPE(c_int, c_void_p, POINTER(c_int32), c_uint64, c_void_p, c_uint64)

# Callback function to handle tokenization.
#   userdata: Pointer to user data for the callback.
#   text: Pointer to the input prompt string.
#   text_len: Length of the input text.
#   tokens: Pointer to the array of token IDs.
#   n_tokens_max: Max tokens to generated.
#   return: Return tokens number (>=0) on success, negative value on error.
LLMTokenizerCallback = CFUNCTYPE(c_int, c_void_p, c_char_p, c_int32, POINTER(c_int32), c_int32)

# Callback function to retrieve the output tensors.
#   userdata: Pointer to user data for the callback.
#   output_tensors: Pointer to the output tensors for the callback.
#   n_output_tensors: Number of output tensors.
#   state: Output callback state.
#   return: 0 on success, non-zero on error.
LLMOutputCallback = CFUNCTYPE(c_int, c_void_p, POINTER(RKNN3Tensor), c_uint32, c_int)


class LLMInputCallbackParam(Structure):
    """Parameters for LLMInputCallback."""
    _fields_ = [
        ("tokens", POINTER(c_int32)),        # Pointer to the current input token array.
        ("num_tokens", c_int32),             # Number of tokens.
        ("shape_id", c_int32),               # Shape ID of the current input_tensors.
        ("pos", c_int32),                    # Position of the current input in the whole context.
        ("reserved", c_uint8 * 128),         # Reserved for future extension.
    ]


# Callback function to provide custom input tensors (e.g., for per_layer_inputs like gemma4).
#   userdata: Pointer to user data for the callback.
#   input_tensors: Pointer to the input tensors for the callback.
#   n_input_tensors: Number of input tensors.
#   param: Additional parameters for the input callback, such as token information.
#   return: 0 on success, non-zero on error.
LLMInputCallback = CFUNCTYPE(c_int, c_void_p, POINTER(RKNN3Tensor), c_uint32, LLMInputCallbackParam)


class RKLLMCallback(Structure):
    """Structure to hold callback functions for LLM operations."""
    _fields_ = [
        ("result_callback", LLMResultCallback),      # callback for results returned by the LLM
        ("result_userdata", c_void_p),               # userdata for LLMResultCallback

        ("sampling_callback", LLMSamplingCallback),  # Optional: Only required when custom sampling is needed
        ("sampling_userdata", c_void_p),             # userdata for LLMSamplingCallback

        ("tokenizer_callback", LLMTokenizerCallback),  # Optional: Only required when custom tokenizer is needed
        ("tokenizer_userdata", c_void_p),             # userdata for LLMTokenizerCallback

        ("embed_callback", LLMGetEmbedCallback),     # Optional: Only required when custom embedding retrieval is needed
        ("embed_userdata", c_void_p),                # userdata for LLMGetEmbedCallback

        ("output_callback", LLMOutputCallback),      # Optional: Only required when get output is needed
        ("output_userdata", c_void_p),               # userdata for LLMOutputCallback
        ("output_tensors", POINTER(RKNN3Tensor)),    # output tensors to be returned by the LLM
        ("n_output_tensors", c_uint32),              # number of output tensors

        ("input_callback", LLMInputCallback),        # Optional: Only required when provide custom input tensors
        ("input_userdata", c_void_p),                # userdata for LLMInputCallback
        ("input_tensors_index", POINTER(c_int32)),   # index of input tensors
        ("n_input_tensors", c_uint32),               # number of input tensors
    ]


# ============================================= Wrapper Classes =============================================

class RKNN3AuxTensorWrapper:
    """Wrapper class for auxiliary tensor"""
    def __init__(self, aux_data=None, index=0, align_size=0):
        self.aux_data = aux_data          # Store numpy array directly
        self.index = index
        self.align_size = align_size


# ============================================= Utility Functions =============================================

def rknn_dtype_to_numpy_dtype(dtype_enum):
    """Convert RKNN3 tensor type to numpy dtype"""
    mapping = {
        RKNN3TensorType.RKNN3_TENSOR_FLOAT32: np.float32,
        RKNN3TensorType.RKNN3_TENSOR_FLOAT16: np.float16,
        RKNN3TensorType.RKNN3_TENSOR_INT8: np.int8,
        RKNN3TensorType.RKNN3_TENSOR_UINT8: np.uint8,
        RKNN3TensorType.RKNN3_TENSOR_INT16: np.int16,
        RKNN3TensorType.RKNN3_TENSOR_UINT16: np.uint16,
        RKNN3TensorType.RKNN3_TENSOR_INT32: np.int32,
        RKNN3TensorType.RKNN3_TENSOR_UINT32: np.uint32,
        RKNN3TensorType.RKNN3_TENSOR_INT64: np.int64,
        RKNN3TensorType.RKNN3_TENSOR_UINT64: np.uint64,
        RKNN3TensorType.RKNN3_TENSOR_BOOL: np.bool_,
        # NumPy has no stable builtin dtype for these packed formats here; expose raw storage.
        RKNN3TensorType.RKNN3_TENSOR_INT4: np.int8,
        RKNN3TensorType.RKNN3_TENSOR_FLOAT8E4M3FN: np.uint8,
        RKNN3TensorType.RKNN3_TENSOR_BFLOAT16: np.uint16,
        RKNN3TensorType.RKNN3_TENSOR_FLOAT8E8M0: np.uint8,
        RKNN3TensorType.RKNN3_TENSOR_FLOAT4E2M1: np.uint8,
    }
    return mapping.get(dtype_enum, np.float32)


def rknn3_get_layout_string(layout):
    """Get layout string from layout enum"""
    try:
        layout_enum = RKNN3TensorLayout(layout)
        layout_map = {
            RKNN3TensorLayout.RKNN3_TENSOR_UNDEFINED: "UNDEFINED",
            RKNN3TensorLayout.RKNN3_TENSOR_NCHW: "NCHW",
            RKNN3TensorLayout.RKNN3_TENSOR_NHWC: "NHWC",
            RKNN3TensorLayout.RKNN3_TENSOR_NC1HWC2: "NC1HWC2",
            RKNN3TensorLayout.RKNN3_TENSOR_CHWN: "CHWN",
            RKNN3TensorLayout.RKNN3_TENSOR_HWIO: "HWIO",
            RKNN3TensorLayout.RKNN3_TENSOR_OIHW: "OIHW",
            RKNN3TensorLayout.RKNN3_TENSOR_O1I1HWI2O2: "O1I1HWI2O2"
        }
        return layout_map.get(layout_enum, "UNKNOWN")
    except ValueError:
        return "UNKNOWN"


def rknn3_get_type_string(dtype):
    """Get data type string from dtype enum"""
    try:
        type_enum = RKNN3TensorType(dtype)
        type_map = {
            RKNN3TensorType.RKNN3_TENSOR_FLOAT32: "FP32",
            RKNN3TensorType.RKNN3_TENSOR_FLOAT16: "FP16",
            RKNN3TensorType.RKNN3_TENSOR_INT8: "INT8",
            RKNN3TensorType.RKNN3_TENSOR_UINT8: "UINT8",
            RKNN3TensorType.RKNN3_TENSOR_INT16: "INT16",
            RKNN3TensorType.RKNN3_TENSOR_UINT16: "UINT16",
            RKNN3TensorType.RKNN3_TENSOR_INT32: "INT32",
            RKNN3TensorType.RKNN3_TENSOR_UINT32: "UINT32",
            RKNN3TensorType.RKNN3_TENSOR_INT64: "INT64",
            RKNN3TensorType.RKNN3_TENSOR_BOOL: "BOOL",
            RKNN3TensorType.RKNN3_TENSOR_INT4: "INT4",
            RKNN3TensorType.RKNN3_TENSOR_FLOAT8E4M3FN: "FLOAT8E4M3FN",
            RKNN3TensorType.RKNN3_TENSOR_BFLOAT16: "BFLOAT16",
            RKNN3TensorType.RKNN3_TENSOR_FLOAT8E8M0: "FLOAT8E8M0",
            RKNN3TensorType.RKNN3_TENSOR_FLOAT4E2M1: "FLOAT4E2M1",
        }
        return type_map.get(type_enum, "UNKNOWN")
    except ValueError:
        return "UNKNOWN"


def rknn3_get_qnt_type_string(qnt_type):
    """Get quantization type string from qnt_type enum"""
    try:
        qnt_enum = RKNN3TensorQntType(qnt_type)
        qnt_map = {
            RKNN3TensorQntType.RKNN3_TENSOR_QNT_NONE: "NONE",
            RKNN3TensorQntType.RKNN3_TENSOR_PER_LAYER_SYMMETRIC: "PER_LAYER_SYMMETRIC",
            RKNN3TensorQntType.RKNN3_TENSOR_PER_LAYER_ASYMMETRIC: "PER_LAYER_ASYMMETRIC",
            RKNN3TensorQntType.RKNN3_TENSOR_PER_CHANNEL_SYMMETRIC: "PER_CHANNEL_SYMMETRIC",
            RKNN3TensorQntType.RKNN3_TENSOR_PER_CHANNEL_ASYMMETRIC: "PER_CHANNEL_ASYMMETRIC",
            RKNN3TensorQntType.RKNN3_TENSOR_PER_GROUP_SYMMETRIC: "PER_GROUP_SYMMETRIC",
            RKNN3TensorQntType.RKNN3_TENSOR_PER_GROUP_ASYMMETRIC: "PER_GROUP_ASYMMETRIC",
        }
        return qnt_map.get(qnt_enum, "UNKNOWN")
    except ValueError:
        return "UNKNOWN"


def dump_tensor_attr(attr, prefix="tensor"):
    """Print tensor attribute information"""
    shape_list = [attr.shape[i] for i in range(attr.n_dims)]
    stride_list = [attr.stride[i] for i in range(attr.n_stride)]
    
    layout_str = rknn3_get_layout_string(attr.layout)
    dtype_str = rknn3_get_type_string(attr.dtype)
    qnt_type_str = rknn3_get_qnt_type_string(attr.qnt_type)

    try:
        scale_val = attr.qnt_info.scale
        zero_point_val = attr.qnt_info.zero_point
    except AttributeError:
        scale_val = 1.0
        zero_point_val = 0
    
    print(f"{prefix}_{attr.index}: name={attr.name.decode('utf-8', errors='ignore')}, "
          f"n_dims={attr.n_dims}, shape={shape_list}, stride={stride_list}, "
          f"aligned_size={attr.aligned_size}, layout={layout_str}, dtype={dtype_str}, "
          f"qnt_type={qnt_type_str}, scale={scale_val:.5f}, zero_point={zero_point_val}")

    # Print original shape info if available (skip silently on older SO versions)
    try:
        n_orig_dims = int(attr.n_orig_dims)
        if 0 < n_orig_dims <= RKNN3_MAX_DIMS:
            orig_shape_list = [int(attr.orig_shape[i]) for i in range(n_orig_dims)]
            orig_layout_str = rknn3_get_layout_string(attr.orig_layout)
            print(f"  orig: n_dims={n_orig_dims}, shape={orig_shape_list}, layout={orig_layout_str}")
    except (AttributeError, TypeError, IndexError, ValueError):
        pass


def get_os_platform():
    """Get OS platform string"""
    if platform.architecture()[0] == '64bit':
        return platform.system() + '_' + 'x64'
    else:
        return platform.system() + '_' + 'x32'
