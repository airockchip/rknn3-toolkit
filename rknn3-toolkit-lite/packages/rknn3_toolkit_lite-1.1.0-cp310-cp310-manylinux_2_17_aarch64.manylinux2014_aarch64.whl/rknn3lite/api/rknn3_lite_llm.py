from .rknn3_session import RKNN3Session

import traceback


class RKNN3Lite_LLM():
    def __init__(self, lib, context, rknn_log):
        self.context = context
        self.rknn_log = rknn_log
        self.rknn_session = RKNN3Session(lib, context)

    def init_session(self, session_index=0, args=None, callback=None):
        """Initialize an extra LLM session.

        This is a generic multi-session API. It is intentionally separated
        from LoRA. For LoRA usage, create another session first, then call
        init_lora/load_lora/enable_lora explicitly.
        """

        if self.rknn_session is None:
            self.rknn_log.e('LLM runtime environment is not inited, please call init_runtime and set llm_init first!', False)
            return -1

        self.args = args
        self.callback = callback

        if args is not None:
            try:
                self.rknn_session.set_llm_param(args)
            except:
                self.rknn_log.e('Catch exception when set llm param for session[{}]!'.format(session_index), False)
                self.rknn_log.e(traceback.format_exc(), False)
                return -1

        try:
            ret = self.rknn_session.init(session_index=session_index)
            if ret != 0:
                return ret
        except:
            self.rknn_log.e('Catch exception when init session[{}]!'.format(session_index), False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1

        try:
            return self.rknn_session.set_callback(callback, session_index=session_index)
        except:
            self.rknn_log.e('Catch exception when set callback for session[{}]!'.format(session_index), False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1

    def set_chat_template(self, system_prompt, prompt_prefix, prompt_postfix, session_index=0):  
        return self.rknn_session.set_chat_template(system_prompt, prompt_prefix, prompt_postfix, session_index=session_index)

    def inference(self, prompt, embeds, tokens, inputs, keep_history=None, max_new_tokens=None, prefill_only=None, disable_sampling=None, enable_thinking=False, session_index=0):
        """Run LLM inference synchronously.

        :param prompt: Text prompt string. The runtime tokenizes it internally.
        :param embeds: Pre-computed embedding vectors (2-D numpy float16 array).
        :param tokens: 1-D array of token IDs (ndarray or list). Will be
            converted to int32 automatically. Use this when you have already
            tokenized the input and want to feed raw token IDs.
        :param inputs: Multimodal input list (RKNN3Image / RKNN3Audio /
            RKNN3Video / RKNN3AuxTensorWrapper).
        :param keep_history: Whether to keep history context. None uses default.
        :param max_new_tokens: Max tokens to generate. None uses default.
        :param prefill_only: If set, overrides infer_param.prefill_only.
        :param disable_sampling: If set, overrides infer_param.disable_sampling.
        :param enable_thinking: Enable thinking mode. Default False.
        :param session_index: LLM session index. Default 0.
        :return: (ret, [n_decode_tokens, n_prefill_tokens, llm_start_time, llm_end_time])
        """
        if self.rknn_session is None:
            self.rknn_log.e('LLM runtime environment is not inited, please call init_runtime and set llm_init first!', False)
            return None

        if (embeds is not None) + (prompt is not None) + (tokens is not None) > 1:
            self.rknn_log.e("RKLLM Input prompt or embeds or tokens only support one.") 
            return None

        # set inputs
        try:
            self.rknn_session.set_llm_inputs(prompt, embeds, tokens, inputs, enable_thinking=enable_thinking)
        except:
            self.rknn_log.e('Catch exception when setting inputs.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return None

        # run
        try:
            ret, [n_decode_tokens, n_prefill_tokens, llm_start_time, llm_end_time] = self.rknn_session.run(keep_history, max_new_tokens, prefill_only, disable_sampling, session_index=session_index)
        except:
            self.rknn_log.e('Catch exception when running RKNN model on session[{}].'.format(session_index), False)
            self.rknn_log.e(traceback.format_exc(), False)
            return None

        return ret, [n_decode_tokens, n_prefill_tokens, llm_start_time, llm_end_time]

    def inference_async(self, prompt, embeds, tokens, inputs, keep_history=None, max_new_tokens=None, prefill_only=None, disable_sampling=None, enable_thinking=False, session_index=0):
        """Run LLM inference asynchronously.

        :param prompt: Text prompt string. The runtime tokenizes it internally.
        :param embeds: Pre-computed embedding vectors (2-D numpy float16 array).
        :param tokens: 1-D array of token IDs (ndarray or list). Will be
            converted to int32 automatically. Use this when you have already
            tokenized the input and want to feed raw token IDs.
        :param inputs: Multimodal input list (RKNN3Image / RKNN3Audio /
            RKNN3Video / RKNN3AuxTensorWrapper).
        :param keep_history: Whether to keep history, overrides infer_param if not None.
        :param max_new_tokens: Maximum number of new tokens, overrides infer_param if not None.
        :param prefill_only: If set, overrides infer_param.prefill_only.
        :param disable_sampling: If set, overrides infer_param.disable_sampling.
        :param enable_thinking: Whether to enable thinking mode for this request.
        :param session_index: LLM session index. Default 0.
        :return: (ret, [n_decode_tokens, n_prefill_tokens, llm_start_time, llm_end_time])
        """
        if self.rknn_session is None:
            self.rknn_log.e('LLM runtime environment is not inited, please call init_runtime and set llm_init first!', False)
            return None

        if (embeds is not None) + (prompt is not None) + (tokens is not None) > 1:
            self.rknn_log.e("RKLLM Input prompt or embeds or tokens only support one.")
            return None

        # set inputs
        try:
            self.rknn_session.set_llm_inputs(prompt, embeds, tokens, inputs, enable_thinking=enable_thinking)
        except:
            self.rknn_log.e('Catch exception when setting inputs.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return None

        # run async
        try:
            ret, [n_decode_tokens, n_prefill_tokens, llm_start_time, llm_end_time] = self.rknn_session.run_async(keep_history, max_new_tokens, prefill_only, disable_sampling, session_index=session_index)
        except:
            self.rknn_log.e('Catch exception when running RKNN model async on session[{}].'.format(session_index), False)
            self.rknn_log.e(traceback.format_exc(), False)
            return None

        return ret, [n_decode_tokens, n_prefill_tokens, llm_start_time, llm_end_time]

    # LoRA
    def init_lora(self, lora_weight_path=None, weight_data=None, weight_size=None, session_index=0):
        """Initialize LoRA from file path or memory buffer."""
        return self.rknn_session.init_lora(lora_weight_path, weight_data, weight_size, session_index=session_index)

    def load_lora(self, lora, session_index=0):
        return self.rknn_session.load_lora(lora, session_index=session_index)

    def unload_lora(self, lora, session_index=0):
        return self.rknn_session.unload_lora(lora, session_index=session_index)

    def enable_lora(self, lora, session_index=0):
        return self.rknn_session.enable_lora(lora, session_index=session_index)

    def disable_lora(self, lora, session_index=0):
        return self.rknn_session.disable_lora(lora, session_index=session_index)

    def query_lora(self, session_index=0):
        return self.rknn_session.query_lora(session_index=session_index)

    # KV Cache
    def set_kvcache_policy(self, policy, param=None, session_index=0):
        return self.rknn_session.set_kvcache_policy(policy, param, session_index=session_index)

    def load_kvcache(self, kvcache_path=None, kvcache_data=None, size=0, session_index=0):
        return self.rknn_session.load_kvcache(kvcache_path, kvcache_data, size, session_index=session_index)

    def save_kvcache(self, kvcache_path, session_index=0):
        return self.rknn_session.save_kvcache(kvcache_path, session_index=session_index)

    def clear_kvcache(self, clear_policy=None, session_index=0):
        if clear_policy is not None:
            return self.rknn_session.clear_kvcache(clear_policy, session_index=session_index)
        return self.rknn_session.clear_kvcache(session_index=session_index)

    # Session control
    def stop(self, session_index=0):
        return self.rknn_session.stop(session_index=session_index)

    def pause(self, session_index=0):
        return self.rknn_session.pause(session_index=session_index)

    def resume(self, session_index=0):
        return self.rknn_session.resume(session_index=session_index)

    def query_state(self, session_index=0):
        return self.rknn_session.query_state(session_index=session_index)

    def get_session_count(self):
        return self.rknn_session.get_session_count()
    
    # Function tools
    def set_function_tools(self, tools, session_index=0):
        return self.rknn_session.set_function_tools(tools, session_index=session_index)

    # LLM param
    def set_session_llm_param(self, params, n_params=1, session_index=0):
        return self.rknn_session.set_session_llm_param(params, n_params, session_index=session_index)

    def release(self, session_index=None):
        if self.rknn_session is not None:
            self.rknn_session.destroy(session_index=session_index)
            if session_index is None:
                self.rknn_session = None