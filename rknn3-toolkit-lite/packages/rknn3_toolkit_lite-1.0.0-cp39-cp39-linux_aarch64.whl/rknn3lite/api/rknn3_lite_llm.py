from .rknn3_session import RKNN3Session

import traceback


class RKNN3Lite_LLM():
    def __init__(self, lib, context, rknn_log, args, callback, embed_path):
        self.context = context
        self.rknn_log = rknn_log
        self.rknn_session = RKNN3Session(lib, context)

        try:
            self.rknn_session.set_llm_param(args)
        except:
            self.rknn_log.e('Catch exception when set llm param!', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1

        try:
            self.rknn_session.init()
        except:
            self.rknn_log.e('Catch exception when init session!', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        
        try:
            self.rknn_session.set_callback(callback, embed_path)
        except:
            self.rknn_log.e('Catch exception when set callback!', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        pass

    def set_chat_template(self, system_prompt, prompt_prefix, prompt_postfix):  
        return self.rknn_session.set_chat_template(system_prompt, prompt_prefix, prompt_postfix)

    def inference(self, prompt, embeds, inputs):

        if self.rknn_session is None:
            self.rknn_log.e('LLM runtime environment is not inited, please call init_runtime and set llm_init first!', False)
            return None

        if (embeds is not None) + (prompt is not None) > 1:
            self.rknn_log.e("RKLLM Input prompt or embeds only support one.")

        # set inputs
        try:
            self.rknn_session.set_llm_inputs(prompt, embeds, inputs)
        except:
            self.rknn_log.e('Catch exception when setting inputs.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return None

        # run
        try:
            ret, [n_decode_tokens, n_prefill_tokens, llm_start_time, llm_end_time] = self.rknn_session.run()
        except:
            self.rknn_log.e('Catch exception when running RKNN model.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return None

        return ret, [n_decode_tokens, n_prefill_tokens, llm_start_time, llm_end_time]

    def release(self):
        if self.rknn_session is not None:
            self.rknn_session.destroy()
            self.rknn_session = None