# -*- coding:utf-8 -*-

import os
import copy
import traceback
import platform
from typing import Any, Optional
from .rknn3_runtime import RKNN3Runtime, RKNN3CoreMask, RKNN3Config
from .rknn3_log import set_log_level_and_file_path
from .rknn3_lite_llm import RKNN3Lite_LLM
from .rknn3_types import (
    RKNN3Lora,
    RKNN3KVCachePolicy,
    RKNN3KVCacheClearPolicy,
    RKNN3KVCachePolicyParam,
    RKNN3KVCacheClearPolicyParam,
    RKNN3LLMParam,
    RKNN3MemAllocFlags,
    RKNN3ImFmt,
    RKNN3ImMem,
    RKNN3TensorMemory,
    RKNN3QueryCmd,
    RKNN3InputOutputNum,
    RKNN3TensorAttr,
    RKNN3SDKVersion,
    RKNN3CoreMemSize,
    RKNN3MemSize,
    RKNN3CustomString,
    RKNN3PerfDetail,
    RKNN3PerfRun,
    RKNN3DevMemInfo,
    RKNN3AllocationInfo,
    RKNN3ShapeConfig,
    RKNN3ShapeInfo,
    RKNN3LLMConfig,
    RKNN3AttentionConfig,
    RKNN3KvCachePageInfo,
    RKNN3Tensor,
)


class RKNN3Lite:
    RKNN3CoreMask = RKNN3CoreMask
    """
    Rockchip NN Kit
    """
    def __init__(self, llm_mode=False, verbose=False, verbose_file=None):
        self.verbose = verbose
        if verbose_file is not None:
            if os.path.dirname(verbose_file) != "" and not os.path.exists(os.path.dirname(verbose_file)):
                verbose_file = None
        self.rknn_log = set_log_level_and_file_path(verbose, verbose_file)

        # get rknn3-toolkit-lite version
        try:
            import importlib.metadata
            self.rknn_log.w('rknn3-toolkit-lite version: ' +
                            importlib.metadata.version("rknn3-toolkit-lite"))
        except Exception:
            pass

        if verbose:
            if verbose_file is None:
                self.rknn_log.w('Verbose file path is invalid, debug info will not dump to file.')
            else:
                self.rknn_log.d('Save log info to: {}'.format(verbose_file))

        self.rknn_runtime = None
        self.llm = None
        self.rknn_config = RKNN3Config()
        self.model_data = None
        self.weight_data = None
        self.model_source = None
        self.llm_mode = llm_mode


    def load_rknn(self, model_path, weight_path=None, source="path"):
        """
        Load RKNN model.

        :param model_path: Model source. Meaning depends on ``source``:
                           - "path":   host-side file path of the .rknn model file.
                           - "data":   in-memory model data (bytes/bytearray/memoryview).
                           - "device": model file path on the device-side filesystem (emmc).
        :param weight_path: Weight source. Meaning depends on ``source``:
                            - "path":   host-side file path of the .weight file.
                            - "data":   in-memory weight data (bytes/bytearray/memoryview).
                            - "device": weight file path on the device-side filesystem.
                                        Pass None for streaming weight loading mode.
        :param source: Where the model/weight come from. One of:
                       - "path" (default): load from host-side file paths via
                         rknn3_load_model_from_path.
                       - "data": load from in-memory data via rknn3_load_model_from_data.
                       - "device": load from device-side file paths via
                         rknn3_load_model_from_device.
        :return: success: 0, failure: -1
        """
        if source not in ("path", "data", "device"):
            self.rknn_log.e('Invalid source "{}", must be one of: "path", "data", "device".'.format(source), False)
            return -1

        if model_path is None:
            self.rknn_log.e('Invalid model: it must not be None.', False)
            return -1

        if source == "path":
            if weight_path is None or not os.path.exists(weight_path) or not os.path.exists(model_path):
                self.rknn_log.e('Invalid RKNN weight path or model path: {} or {}'.format(
                    "None" if (weight_path is None or weight_path == "") else weight_path,
                    "None" if (model_path is None or model_path == "") else model_path), False)
                return -1
        elif source == "data":
            if weight_path is None:
                self.rknn_log.e('Invalid weight data: it must not be None.', False)
                return -1
            for name, data in (("model", model_path), ("weight", weight_path)):
                if not isinstance(data, (bytes, bytearray, memoryview)):
                    self.rknn_log.e('Invalid {} data: expected bytes/bytearray/memoryview, got {}.'.format(
                        name, type(data).__name__), False)
                    return -1
            # Keep the original objects (bytes/bytearray/memoryview) as-is.
            # No bytes() copy is made here: converting a large bytearray /
            # memoryview to bytes would double peak memory usage. A
            # zero-copy pointer is taken at C-API call time in
            # RKNN3Runtime.load_model_from_data(), and the original objects
            # are kept alive on self.model_data / self.weight_data.
        else:  # source == "device"
            if not isinstance(model_path, (str, bytes)) or len(model_path) == 0:
                self.rknn_log.e('Invalid device-side model path: it must be a non-empty path string.', False)
                return -1
            if weight_path is not None and (not isinstance(weight_path, (str, bytes)) or len(weight_path) == 0):
                self.rknn_log.e('Invalid device-side weight path: it must be a non-empty path string or None '
                                '(None enables streaming weight loading mode).', False)
                return -1

        # Plain attribute assignment; no exception is expected here (all
        # inputs were validated above). A bare try/except would swallow
        # SystemExit / KeyboardInterrupt, so keep it exception-transparent.
        self.model_data = model_path
        self.weight_data = weight_path
        self.model_source = source

        if self.model_data is None:
            return -1
        # For "device" source, weight_path=None is valid (streaming weight
        # loading mode); for the other sources the weight is mandatory.
        if source != "device" and self.weight_data is None:
            return -1

        return 0

    def init_runtime(self, target, core_mask, llm_args=None, llm_callback=None, device_id=None, decrypt_key_path=None, decrypt_key_data=None, postprocess_plugin_path=None):
        """
        Init run time environment. Needed by called before inference or eval performance.
        :param target:Specifies the coprocessor; currently, rk1820/rk1828 are supported.
        :param core_mask: NPU core mask. The co-processor contains 8 NPU cores, and this parameter specifies the enabled cores using a bitmask. For example, 0x0f (binary 0b00001111) indicates the use of the first 4 NPU cores. Note that this parameter must be consistent with the core_mask used when converting the RKNN model; otherwise, an error will occur.
        :param llm_args: A dictionary of configuration parameters for the LLM model.
        :param llm_callback: A callback function for the LLM model, which can be used for streaming inference.
        :param device_id: Specifies the target device ID when multiple devices are connected.
        :param decrypt_key_path: The file path to the encryption key/license. Used for decrypting and loading encrypted RKNN models securely on the NPU runtime.
        :param decrypt_key_data: The raw decryption key data / byte stream. (Mutually exclusive with decrypt_key_path; choose one of the two).
        :param postprocess_plugin_path: Path to the postprocess plugin shared library (.so). When provided, the plugin is registered after model_init and before tensor creation, matching the C++ flow. This causes subsequent queries (IO num, output attrs, dynamic shapes) to use RKNN3_QUERY_POSTPROCESS_* variants.
        :return: success: 0, failure: -1
        """
        ret = 0
        if self.model_data is None:
            self.rknn_log.e("Model is not loaded yet, this interface should be called after load_rknn!", False)
            return -1
        if self.model_source is None:
            # Backward compatibility: model_data was set directly (e.g. by
            # older scripts) instead of through load_rknn().
            self.model_source = "path"

        # if rknn_runtime is not None, release it first
        if self.rknn_runtime is not None:
            self.rknn_runtime.release()
            self.rknn_runtime = None
        try:
            self.rknn_runtime = RKNN3Runtime(target=target)
        except:
            self.rknn_log.e('Catch exception when load library!', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1

        # rknn_init
        try:
            self.rknn_runtime.rknn_init(device_id=device_id)
        except:
            self.rknn_log.e('Catch exception when init runtime!', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1

        if decrypt_key_path is not None:
            try:
                self.rknn_runtime.set_decrypt_key_from_path(key_path=decrypt_key_path)
            except:
                self.rknn_log.e('Catch exception when set_decrypt_key_from_path!', False)
                self.rknn_log.e(traceback.format_exc(), False)
                return -1
        elif decrypt_key_data is not None:
            try:
                self.rknn_runtime.set_decrypt_key_from_data(key_data=decrypt_key_data)
            except:
                self.rknn_log.e('Catch exception when set_decrypt_key_from_data!', False)
                self.rknn_log.e(traceback.format_exc(), False)
                return -1

        # load rknn model
        try:
            if self.model_source == "data":
                ret = self.rknn_runtime.load_model_from_data(self.model_data, self.weight_data)
            elif self.model_source == "device":
                ret = self.rknn_runtime.load_model_from_device(self.model_data, self.weight_data)
            else:
                ret = self.rknn_runtime.load_model_from_path(self.model_data, self.weight_data)
            if ret != 0:
                return -1
        except:
            self.rknn_log.e('Catch exception when load model data!', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        
        # model init
        self.rknn_config.run_core_mask = core_mask
        try:
            ret = self.rknn_runtime.model_init(self.rknn_config)
        except:
            self.rknn_log.e('Catch exception when set npu core mode.', False)
            return -1

        # Register postprocess plugin (must be after model_init and before
        # create_tensor, matching the C++ demo flow). When a plugin is registered,
        # the runtime sets use_postprocess_plugin=True so that all subsequent
        # queries (IO num, output attrs, dynamic shapes) use the POSTPROCESS_*
        # command variants.
        if postprocess_plugin_path is not None:
            if self.llm_mode:
                self.rknn_log.e('postprocess_plugin_path is not supported in LLM mode!', False)
                return -1
            try:
                ret = self.rknn_runtime.register_custom_ops_plugins(postprocess_plugin_path)
            except:
                self.rknn_log.e('Catch exception when registering postprocess plugin.', False)
                self.rknn_log.e(traceback.format_exc(), False)
                return -1
            if ret != 0:
                self.rknn_log.e('register_custom_ops_plugins failed! ret={}'.format(ret), False)
                return -1
        
        # session_init
        if self.llm_mode:
            try:
                self.llm = RKNN3Lite_LLM(self.rknn_runtime.lib, self.rknn_runtime.context, self.rknn_log)
                if llm_args is not None and llm_callback is not None:
                    ret = self.llm.init_session(0, llm_args, llm_callback)
            except:
                self.rknn_log.e('Catch exception when init llm session!', False)
                self.rknn_log.e(traceback.format_exc(), False)
                return -1
        
        # set tensor
        if not self.llm_mode:
            try:
                self.rknn_runtime.create_tensor()
            except:
                self.rknn_log.e('Catch exception when creat tensor.', False)
                self.rknn_log.e(traceback.format_exc(), False)
                self.rknn_runtime.release()
                self.rknn_runtime = None
                return -1

        return ret
    

    def inference(self, inputs=None, data_format=None):
        """
        Run model inference
        :param inputs: Input data List (ndarray list)
        :param data_format: Input format list (str list). Data format (str), current support: 'undefined' 'nhwc' and 'nchw', default is None.
        :return: Output data (ndarray list)
        """
        if self.llm is not None:
             self.rknn_log.e('This interface is only for RKNN model inference, please use session_run for LLM model inference!', False)
             return None

        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
            return None
        
        if inputs is None:
            self.rknn_log.e('inputs is None, the model requires input', False)
            return None

        if not isinstance(inputs, list) or len(inputs) == 0:
            self.rknn_log.e('inputs must be a non-empty list', False)
            return None

        if data_format is not None:
            if not isinstance(data_format, list) or len(data_format) == 0:
                self.rknn_log.e('data_format must be a non-empty list', False)
                return None
            if len(data_format) != len(inputs):
                self.rknn_log.e('data_format length is not equal to inputs length', False)
                return None        

        # set inputs
        try:
            self.rknn_runtime.set_input_tensor(inputs, data_format)
        except:
            self.rknn_log.e('Catch exception when setting inputs.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return None

        # run
        try:
            ret = self.rknn_runtime.run()
        except:
            self.rknn_log.e('Catch exception when running RKNN model.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return None

        try:
            outputs = self.rknn_runtime.get_outputs()
        except:
            self.rknn_log.e('Catch exception when getting outputs.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return None

        return outputs

    
    def session_run(self, inputs: Optional[list] = None, prompt: Optional[str] = None, embeds: Optional[Any] = None, tokens: Optional[Any] = None, keep_history: Optional[bool] = None, max_new_tokens: Optional[int] = None, prefill_only: Optional[bool] = None, disable_sampling: Optional[bool] = None, keep_grammar: Optional[bool] = None, enable_thinking: bool = False, session_index: int = 0):
        """
        Run model inference
        :param inputs: Input data list for multimodal models. Type is list, elements can be RKNN3Image, RKNN3Audio, RKNN3Video, or RKNN3AuxTensor.
        :param prompt: Text prompt input for LLM models, used in multimodal or auxiliary input scenarios.
        :param embeds: Input embedding vectors for LLM models. The type is ndarray.
        :param tokens: 1-D array of token IDs (ndarray or list). Will be converted to int32 automatically. Use this when you have already tokenized the input and want to feed raw token IDs instead of a text prompt.
        :param keep_history: Whether to keep the history context during inference, which may affect the performance. The type is bool, and the default value is None, which means using the default setting of the model.
        :param max_new_tokens: The maximum number of tokens to be generated during inference, which may affect the performance. The type is int, and the default value is None, which means using the default setting of the model.
        :param prefill_only: If true, only execute a single prefill step. The type is bool, and the default value is None, which means using the default setting of the model.
        :param disable_sampling: If true, disable token sampling after the single prefill step. The type is bool, and the default value is None, which means using the default setting of the model.
        :param keep_grammar: If true, keep the grammar matcher state across runs so the grammar state is retained for continuous generation across multiple runs. The type is bool, and the default value is None, which means using the default setting of the model (false).
        :param enable_thinking: Whether to enable thinking mode during inference, which may affect the performance. The type is bool, and the default value is False, which means not using thinking mode.
        :param session_index: LLM session index. Default is 0.
        :return: ret (0 for success, -1 for failure), and performance stats list [n_decode_tokens, n_prefill_tokens, llm_start_time, llm_end_time]
        """

        if self.llm is None:
            self.rknn_log.e('RKNN session_run init failed, please call init_runtime or init_llm_session first!', False)
            return -1, []

        try:
            ret, [n_decode_tokens, n_prefill_tokens, llm_start_time, llm_end_time] = self.llm.inference(prompt=prompt, embeds=embeds, tokens=tokens, inputs=inputs, keep_history=keep_history, max_new_tokens=max_new_tokens, prefill_only=prefill_only, disable_sampling=disable_sampling, keep_grammar=keep_grammar, enable_thinking=enable_thinking, session_index=session_index)
        except:
            self.rknn_log.e('Catch exception when running LLM model.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1, []
        return ret, [n_decode_tokens, n_prefill_tokens, llm_start_time, llm_end_time]

    def get_sdk_version(self):
        """
        Get SDK version
        :return: sdk_version
        """
        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
            return None

        try:
            sdk_version, _, _ = self.rknn_runtime.get_sdk_version()
        except:
            self.rknn_log.e('Catch exception when get sdk version', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return None

        return sdk_version
    
    def set_chat_template(self, system_prompt, prompt_prefix, prompt_postfix, session_index=0):
        """
        Set chat template for LLM model
        :param system_prompt: System prompt
        :param prompt_prefix: Prompt prefix
        :param prompt_postfix: Prompt postfix
        :param session_index: LLM session index. Default is 0.
        :return: success: 0, failure: -1
        """
        if self.llm is None:
            self.rknn_log.e('LLM runtime environment is not inited, please call init_runtime and set llm_init first!', False)
            return -1

        try:
            ret = self.llm.set_chat_template(system_prompt, prompt_prefix, prompt_postfix, session_index=session_index)
        except:
            self.rknn_log.e('Catch exception when setting chat template.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1

        return ret

    # ============================================= Structured Output Grammar =============================================

    def init_grammar(self, config=None, *, token_pieces=None, stop_tokens=None):
        """Initialize the shared host-side grammar engine for this RKNN context.

        Call once after :meth:`init_runtime` and before :meth:`set_grammar`.
        ``token_pieces`` must be ordered by token ID; it is the convenient
        Python alternative to building ``RKNN3GrammarConfig`` manually.
        """
        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime first!', False)
            return -1
        try:
            return self.rknn_runtime.init_grammar(
                config=config, token_pieces=token_pieces, stop_tokens=stop_tokens
            )
        except:
            self.rknn_log.e('Catch exception when init grammar.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1

    def set_grammar(self, grammar_str=None, grammar_type=None, options=None, session_index=0):
        """Apply a structured-output grammar to an initialized LLM session."""
        if self.llm is None:
            self.rknn_log.e('LLM runtime environment is not inited, please call init_runtime and init_llm_session first!', False)
            return -1
        try:
            return self.llm.set_grammar(
                grammar_str, grammar_type, options, session_index=session_index
            )
        except:
            self.rknn_log.e('Catch exception when setting grammar.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1

    def clear_grammar(self, session_index=0):
        """Clear the structured-output grammar from an initialized LLM session."""
        if self.llm is None:
            self.rknn_log.e('LLM runtime environment is not inited, please call init_runtime and init_llm_session first!', False)
            return -1
        try:
            return self.llm.clear_grammar(session_index=session_index)
        except:
            self.rknn_log.e('Catch exception when clearing grammar.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1

    def get_devices_id(self, target="rk1820"):
        """
        Get devices id
        :param target:Specifies the coprocessor; currently, rk1820/rk1828 are supported.
        :return: id
        """
        rknn_runtime = RKNN3Runtime(target=target)
        list_devices = rknn_runtime.list_devices()
        devices = []
        if list_devices.n_devices > 0:
            for i in range(list_devices.n_devices):
                devices.append(list_devices.devices[i].id)
        rknn_runtime.release()
        return devices
    
    def get_inputs_tensor_attr(self):
        """
        Get input tensor attribute
        :return: inputs tensor attribute
        """
        if self.llm is not None:
            input_attr =  self.llm.rknn_session.get_inputs_tensor_attr()
        else:
            if self.rknn_runtime is None:
                self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
                return None

            try:
                input_attr = self.rknn_runtime.get_inputs_tensor_attr()
            except:
                self.rknn_log.e('Catch exception when getting input tensor attribute.', False)
                self.rknn_log.e(traceback.format_exc(), False)
                return None
            
        if input_attr is None:
            self.rknn_log.e('Please check if the model is initialized correctly.')

        return input_attr
    
    def get_dynamic_shape_infos(self):
        """
        Get all supported dynamic-shape combinations.
        The query is completed during init_runtime by following the C API order:
        RKNN3_QUERY_DYNAMIC_SHAPE_CONFIG first, then one bulk
        RKNN3_QUERY_DYNAMIC_SHAPE_INFO query with preallocated input/output attr arrays.
        Returned 4-D image shapes use the public logical NCHW convention and do
        not expose internal NC1HWC2 packing.
        :return: Dynamic shape information list. Static-shape models return an empty list.
        """
        if self.llm is not None:
            self.rknn_log.e('This interface is only for RKNN model dynamic shape query!', False)
            return None

        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
            return None

        try:
            return self.rknn_runtime.get_dynamic_shape_infos()
        except:
            self.rknn_log.e('Catch exception when getting dynamic shape information.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return None

    def get_outputs_tensor_attr(self):
        """
        Get output tensor attribute
        :return: outputs tensor attribute
        """
        if self.llm is not None:
            return self.llm.rknn_session.get_outputs_tensor_attr()

        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
            return None

        try:
            output_attr = self.rknn_runtime.get_outputs_tensor_attr()
        except:
            self.rknn_log.e('Catch exception when getting output tensor attribute.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return None

        if output_attr is None:
            self.rknn_log.e('Please check if the model is initialized correctly.')  

        return output_attr

    # ============================================= LoRA =============================================

    def init_lora(self, lora_weight_path=None, weight_data=None, weight_size=None, session_index=0):
        """
        Initialize LoRA support by loading LoRA weight data.
        May be called repeatedly to register multiple weight files/buffers;
        adapter names must be unique across all registered files, and each
        in-memory buffer must remain valid until the context is released.
        :param lora_weight_path: Path to the LoRA weight file or directory.
        :param weight_data: Optional in-memory LoRA weight data. Supports bytes/bytearray/memoryview, numpy ndarray, or raw pointer.
        :param weight_size: Size of weight_data in bytes, required when weight_data is a raw pointer.
        :param session_index: LLM session index. Default is 0.
        :return: success: 0, failure: -1
        """
        if self.llm is None:
            self.rknn_log.e('LLM runtime environment is not inited, please call init_runtime with llm_mode=True first!', False)
            return -1

        try:
            ret = self.llm.init_lora(lora_weight_path, weight_data, weight_size, session_index=session_index)
        except:
            self.rknn_log.e('Catch exception when init lora.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return ret

    def load_lora(self, lora, session_index=0):
        """
        Load a LoRA adapter.
        :param lora: RKNN3Lora structure with lora_name and scale.
        :param session_index: LLM session index. Default is 0.
        :return: success: 0, failure: -1
        """
        if self.llm is None:
            self.rknn_log.e('LLM runtime environment is not inited, please call init_runtime with llm_mode=True first!', False)
            return -1

        try:
            ret = self.llm.load_lora(lora, session_index=session_index)
        except:
            self.rknn_log.e('Catch exception when load lora.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return ret

    def unload_lora(self, lora, session_index=0):
        """
        Unload a previously loaded LoRA adapter.
        :param lora: RKNN3Lora structure with lora_name and scale.
        :return: success: 0, failure: -1
        """
        if self.llm is None:
            self.rknn_log.e('LLM runtime environment is not inited, please call init_runtime with llm_mode=True first!', False)
            return -1

        try:
            ret = self.llm.unload_lora(lora, session_index=session_index)
        except:
            self.rknn_log.e('Catch exception when unload lora.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return ret

    def enable_lora(self, lora, session_index=0):
        """
        Enable a LoRA adapter for inference.
        Note: different adapters mapped to the same pattern slot cannot be
        enabled together in one session. Different sessions may reuse that
        slot; the runtime reapplies each session's LoRA binding before
        inference.
        :param lora: RKNN3Lora structure with lora_name and scale.
        :return: success: 0, failure: -1
        """
        if self.llm is None:
            self.rknn_log.e('LLM runtime environment is not inited, please call init_runtime with llm_mode=True first!', False)
            return -1

        try:
            ret = self.llm.enable_lora(lora, session_index=session_index)
        except:
            self.rknn_log.e('Catch exception when enable lora.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return ret

    def disable_lora(self, lora, session_index=0):
        """
        Disable a LoRA adapter.
        :param lora: RKNN3Lora structure with lora_name and scale.
        :return: success: 0, failure: -1
        """
        if self.llm is None:
            self.rknn_log.e('LLM runtime environment is not inited, please call init_runtime with llm_mode=True first!', False)
            return -1

        try:
            ret = self.llm.disable_lora(lora, session_index=session_index)
        except:
            self.rknn_log.e('Catch exception when disable lora.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return ret

    def query_lora(self, session_index=0):
        """
        Query loaded LoRA information.
        :return: Tuple of (lora_list, n_lora) on success, or (None, 0) on failure.
        """
        if self.llm is None:
            self.rknn_log.e('LLM runtime environment is not inited, please call init_runtime with llm_mode=True first!', False)
            return None, 0

        try:
            lora_list, n_lora = self.llm.query_lora(session_index=session_index)
        except:
            self.rknn_log.e('Catch exception when query lora.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return None, 0
        return lora_list, n_lora

    # ============================================= KV Cache =============================================

    def set_kvcache_policy(self, policy, param=None, session_index=0):
        """
        Set the KV cache policy for the LLM session.
        :param policy: RKNN3KVCachePolicy enum value.
        :param param: RKNN3KVCachePolicyParam structure, or None for default.
        :param session_index: LLM session index. Default is 0.
        :return: success: 0, failure: -1
        """
        if self.llm is None:
            self.rknn_log.e('LLM runtime environment is not inited, please call init_runtime with llm_mode=True first!', False)
            return -1

        try:
            ret = self.llm.set_kvcache_policy(policy, param, session_index=session_index)
        except:
            self.rknn_log.e('Catch exception when set kvcache policy.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return ret

    def load_kvcache(self, kvcache_path=None, kvcache_data=None, size=0, session_index=0):
        """
        Load KV cache from a file path or from data.
        :param kvcache_path: Path to the KV cache file.
        :param kvcache_data: Pointer to the KV cache data in memory.
        :param size: Size of the KV cache data in bytes (required when loading from data).
        :param session_index: LLM session index. Default is 0.
        :return: success: 0, failure: -1
        """
        if self.llm is None:
            self.rknn_log.e('LLM runtime environment is not inited, please call init_runtime with llm_mode=True first!', False)
            return -1

        try:
            ret = self.llm.load_kvcache(kvcache_path, kvcache_data, size, session_index=session_index)
        except:
            self.rknn_log.e('Catch exception when load kvcache.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return ret

    def save_kvcache(self, kvcache_path, session_index=0):
        """
        Save KV cache to a file.
        :param kvcache_path: Path where the KV cache will be saved.
        :param session_index: LLM session index. Default is 0.
        :return: success: 0, failure: -1
        """
        if self.llm is None:
            self.rknn_log.e('LLM runtime environment is not inited, please call init_runtime with llm_mode=True first!', False)
            return -1

        try:
            ret = self.llm.save_kvcache(kvcache_path, session_index=session_index)
        except:
            self.rknn_log.e('Catch exception when save kvcache.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return ret

    def clear_kvcache(self, clear_policy=None, param=None, session_index=0):
        """
        Clear KV cache.
        :param clear_policy: RKNN3KVCacheClearPolicy enum value, or None for RKNN3_KVCACHE_CLEAR_ALL.
        :param param: RKNN3KVCacheClearPolicyParam structure. Required when clear_policy is
                      RKNN3_KVCACHE_KEEP_N_TOKENS.
        :param session_index: LLM session index. Default is 0.
        :return: success: 0, failure: -1
        """
        if self.llm is None:
            self.rknn_log.e('LLM runtime environment is not inited, please call init_runtime with llm_mode=True first!', False)
            return -1

        try:
            ret = self.llm.clear_kvcache(clear_policy, param, session_index=session_index)
        except Exception:
            self.rknn_log.e('Catch exception when clear kvcache.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return ret

    def get_session_count(self):
        """
        Get current LLM session count.
        :return: session count on success, or -1 on failure.
        """
        if self.llm is None:
            self.rknn_log.e('LLM runtime environment is not inited, please call init_runtime or init_llm_session first!', False)
            return -1

        try:
            return self.llm.get_session_count()
        except:
            self.rknn_log.e('Catch exception when get session count.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1

    # ============================================= Session Control =============================================

    def session_run_async(self, inputs: Optional[list] = None, prompt: Optional[str] = None, embeds: Optional[Any] = None, tokens: Optional[Any] = None, keep_history: Optional[bool] = None, max_new_tokens: Optional[int] = None, prefill_only: Optional[bool] = None, disable_sampling: Optional[bool] = None, keep_grammar: Optional[bool] = None, enable_thinking: bool = False, session_index: int = 0):
        """
        Run LLM model inference asynchronously.
        :param inputs: Input data list for multimodal models. Type is list, elements can be RKNN3Image, RKNN3Audio, RKNN3Video, or RKNN3AuxTensor.
        :param prompt: Text prompt input for LLM models.
        :param embeds: Input embedding vectors for LLM models. The type is ndarray.
        :param tokens: 1-D array of token IDs (ndarray or list). Will be converted to int32 automatically. Use this when you have already tokenized the input and want to feed raw token IDs instead of a text prompt.
        :param keep_history: Whether to keep the history context during inference.
        :param max_new_tokens: The maximum number of tokens to be generated during inference.
        :param prefill_only: If true, only execute a single prefill step. Default is None.
        :param disable_sampling: If true, disable token sampling after the single prefill step. Default is None.
        :param keep_grammar: If true, keep the grammar matcher state across runs so the grammar state is retained for continuous generation across multiple runs. Default is None (false).
        :param enable_thinking: Whether to enable thinking mode during inference.
        :param session_index: LLM session index. Default is 0.
        :return: ret (0 for success, -1 for failure), and performance stats list [n_decode_tokens, n_prefill_tokens, llm_start_time, llm_end_time]
        """
        if self.llm is None:
            self.rknn_log.e('LLM runtime environment is not inited, please call init_runtime with llm_mode=True first!', False)
            return -1, []

        try:
            ret, [n_decode_tokens, n_prefill_tokens, llm_start_time, llm_end_time] = self.llm.inference_async(
                prompt=prompt, embeds=embeds, tokens=tokens, inputs=inputs,
                keep_history=keep_history, max_new_tokens=max_new_tokens,
                prefill_only=prefill_only, disable_sampling=disable_sampling,
                keep_grammar=keep_grammar,
                enable_thinking=enable_thinking,
                session_index=session_index
            )
        except:
            self.rknn_log.e('Catch exception when running LLM model async.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1, []
        return ret, [n_decode_tokens, n_prefill_tokens, llm_start_time, llm_end_time]

    def session_stop(self, session_index=0):
        """
        Stop the running LLM session.
        :return: success: 0, failure: -1
        """
        if self.llm is None:
            self.rknn_log.e('LLM runtime environment is not inited, please call init_runtime with llm_mode=True first!', False)
            return -1

        try:
            ret = self.llm.stop(session_index=session_index)
        except:
            self.rknn_log.e('Catch exception when stop session.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return ret

    def session_pause(self, session_index=0):
        """
        Pause the running LLM session.
        :return: success: 0, failure: -1
        """
        if self.llm is None:
            self.rknn_log.e('LLM runtime environment is not inited, please call init_runtime with llm_mode=True first!', False)
            return -1

        try:
            ret = self.llm.pause(session_index=session_index)
        except:
            self.rknn_log.e('Catch exception when pause session.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return ret

    def session_resume(self, session_index=0):
        """
        Resume a paused LLM session.
        :return: success: 0, failure: -1
        """
        if self.llm is None:
            self.rknn_log.e('LLM runtime environment is not inited, please call init_runtime with llm_mode=True first!', False)
            return -1

        try:
            ret = self.llm.resume(session_index=session_index)
        except:
            self.rknn_log.e('Catch exception when resume session.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return ret

    def session_query_state(self, session_index=0):
        """
        Query the current state of the LLM session.
        :return: RKLLMRunState on success, or None on failure.
        """
        if self.llm is None:
            self.rknn_log.e('LLM runtime environment is not inited, please call init_runtime with llm_mode=True first!', False)
            return None

        try:
            state = self.llm.query_state(session_index=session_index)
        except:
            self.rknn_log.e('Catch exception when query session state.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return None
        return state

    # ============================================= Function Tools =============================================

    def set_function_tools(self, tools, session_index=0):
        """
        Set function tools for the LLM session (function calling).
        :param tools: Function tools string (JSON format).
        :param session_index: LLM session index. Default is 0.
        :return: success: 0, failure: -1
        """
        if self.llm is None:
            self.rknn_log.e('LLM runtime environment is not inited, please call init_runtime with llm_mode=True first!', False)
            return -1

        try:
            ret = self.llm.set_function_tools(tools, session_index=session_index)
        except:
            self.rknn_log.e('Catch exception when set function tools.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return ret

    # ============================================= LLM Param =============================================

    def set_llm_param(self, params, n_params=1, session_index=0):
        """
        Set the LLM parameters for an already initialized session.
        :param params: RKNN3LLMParam structure or pointer.
        :param n_params: Number of LLM parameters.
        :param session_index: LLM session index. Default is 0.
        :return: success: 0, failure: -1
        """
        if self.llm is None:
            self.rknn_log.e('LLM runtime environment is not inited, please call init_runtime with llm_mode=True first!', False)
            return -1

        try:
            ret = self.llm.set_session_llm_param(params, n_params, session_index=session_index)
        except:
            self.rknn_log.e('Catch exception when set llm param.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return ret

    # ============================================= Context =============================================

    def dup_context(self):
        """
        Duplicate the current RKNN3 context using the legacy API.
        Newer SO versions may not provide this API and will return (-1, None).
        :return: Tuple of (ret, new_context). ret is 0 on success, -1 on failure.
        """
        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
            return -1, None

        try:
            ret, new_context = self.rknn_runtime.dup_context()
        except:
            self.rknn_log.e('Catch exception when dup context.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1, None
        return ret, new_context

    # ============================================= Async Inference =============================================

    def inference_async(self, inputs=None, data_format=None):
        """
        Run model inference asynchronously (non-LLM, legacy API).
        Newer SO versions may not provide rknn3_run_async/rknn3_wait.
        Must call wait() to get the results after this call when supported.
        :param inputs: Input data List (ndarray list)
        :param data_format: Input format list (str list). Data format (str), current support: 'undefined' 'nhwc' and 'nchw', default is None.
        :return: success: 0, failure: -1
        """
        if self.llm is not None:
            self.rknn_log.e('This interface is only for RKNN model async inference, please use session_run_async for LLM model!', False)
            return -1

        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
            return -1

        if inputs is None:
            self.rknn_log.e('inputs is None, the model requires input', False)
            return -1

        if not isinstance(inputs, list) or len(inputs) == 0:
            self.rknn_log.e('inputs must be a non-empty list', False)
            return -1

        if data_format is not None:
            if not isinstance(data_format, list) or len(data_format) == 0:
                self.rknn_log.e('data_format must be a non-empty list', False)
                return -1
            if len(data_format) != len(inputs):
                self.rknn_log.e('data_format length is not equal to inputs length', False)
                return -1

        # set inputs
        try:
            self.rknn_runtime.set_input_tensor(inputs, data_format)
        except:
            self.rknn_log.e('Catch exception when setting inputs.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1

        # run async
        try:
            ret = self.rknn_runtime.run_async()
        except:
            self.rknn_log.e('Catch exception when running RKNN model async.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1

        return ret

    def wait(self):
        """
        Wait for completion of legacy async inference (non-LLM).
        Newer SO versions may not provide rknn3_wait.
        Call get_outputs() after this to retrieve results when supported.
        :return: success: 0, failure: -1
        """
        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
            return -1

        try:
            ret = self.rknn_runtime.wait()
        except:
            self.rknn_log.e('Catch exception when waiting for async inference.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return ret

    def get_outputs(self):
        """
        Get model inference outputs (non-LLM). Call after run() or wait().
        :return: Output data (ndarray list), or None on failure.
        """
        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
            return None

        try:
            outputs = self.rknn_runtime.get_outputs()
        except:
            self.rknn_log.e('Catch exception when getting outputs.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return None
        return outputs

    # ============================================= Memory =============================================

    def create_mem(self, attr=None, tensor=None, size=None, core_id=None,
                   flags=RKNN3MemAllocFlags.RKNN3_FLAG_MEMORY_CACHEABLE):
        """
        Allocate device memory, optionally binding it to a tensor.

        This single entry point covers both allocation styles:

        * **Tensor-attribute style** (the classic form): pass ``attr`` as an
          ``RKNN3TensorAttr`` obtained from ``rknn3_query``. ``size`` and
          ``core_id`` are taken from ``attr.aligned_size`` / ``attr.core_id``.
        * **Raw-byte style**: pass ``size`` in bytes plus ``core_id``. Used for
          allocations that are not bound to a model tensor, such as individual
          paged KV cache pages.

        :param attr: RKNN3TensorAttr from rknn3_query (tensor-attribute style).
        :param tensor: Optional RKNN3Tensor; when given, its ``attr`` and ``mem``
                       fields are filled in so it can be passed to the runtime.
        :param size: Byte size for a raw allocation (raw-byte style). May also be
                     a numpy array / bytes-like object, whose ``nbytes`` is used.
        :param core_id: Target NPU core ID for a raw allocation. Defaults to 0.
        :param flags: Memory allocation flags.
        :return: POINTER(RKNN3TensorMemory), or None on failure.
        """
        import ctypes
        import numbers

        def _as_byte_size(value):
            """Return ``value`` as an int byte size, or None if it is not size-like."""
            if isinstance(value, bool):
                return None
            if isinstance(value, numbers.Integral):
                return int(value)
            # numpy arrays / memoryview expose ``nbytes``; numpy scalars do not.
            nbytes = getattr(value, 'nbytes', None)
            if isinstance(nbytes, numbers.Integral):
                return int(nbytes)
            # bytes / bytearray expose only ``len()``.
            if isinstance(value, (bytes, bytearray)):
                return len(value)
            return None

        # Backward compatibility: ``flags`` used to be the 3rd positional
        # parameter, so legacy code may call create_mem(attr, tensor, flags).
        # RKNN3MemAllocFlags is an IntEnum and therefore looks size-like, so
        # without this shift the flag value would be silently used as a byte
        # count. A genuine size is never an RKNN3MemAllocFlags instance.
        if isinstance(size, RKNN3MemAllocFlags):
            flags = size
            size = None

        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited!', False)
            return None

        try:
            # ---- 1. Resolve (size, core_id) from either call style ----
            resolved_core = 0 if core_id is None else int(core_id)

            if size is not None:
                # Raw-byte style: size (+ core_id) fully specify the allocation.
                resolved_size = _as_byte_size(size)
            elif isinstance(attr, RKNN3TensorAttr):
                resolved_size = attr.aligned_size
                resolved_core = attr.core_id
            elif attr is not None:
                # Tolerate duck-typed attributes, and treat a bare size as raw bytes.
                if hasattr(attr, 'aligned_size') and hasattr(attr, 'core_id'):
                    resolved_size = attr.aligned_size
                    resolved_core = attr.core_id
                else:
                    resolved_size = _as_byte_size(attr)
            else:
                self.rknn_log.e('create_mem requires either attr or size.', False)
                return None

            if resolved_size is None or resolved_size <= 0:
                self.rknn_log.e('Invalid memory size: {}.'.format(resolved_size), False)
                return None

            # ---- 2. Allocate ----
            mem = self.rknn_runtime.create_mem(resolved_size, resolved_core, flags)
            if mem is None:
                return None

            # ---- 3. Optionally bind to a tensor ----
            if tensor is not None:
                if not isinstance(tensor, RKNN3Tensor):
                    self.rknn_log.e('Invalid RKNN3Tensor instance.', False)
                    self.destroy_mem(mem)
                    return None
                if not isinstance(attr, RKNN3TensorAttr):
                    self.rknn_log.e('Binding a tensor requires attr to be an RKNN3TensorAttr.', False)
                    self.destroy_mem(mem)
                    return None

                # 自动处理 ctypes 指针和内存拷贝
                attr_ptr = ctypes.pointer(RKNN3TensorAttr())
                ctypes.memmove(attr_ptr, ctypes.addressof(attr), ctypes.sizeof(RKNN3TensorAttr))

                # 自动赋值
                tensor.attr = attr_ptr
                tensor.mem = mem

            return mem
        except Exception:
            self.rknn_log.e(f'Catch exception when creating memory: {traceback.format_exc()}', False)
            return None

    def set_kvcache_pages(self, bindings):
        """
        Replace the listed KV cache page bindings for the current context.

        Context-level operation (not session-scoped): bound pages are shared by
        all sessions under this context and must stay alive until unbound. Call
        only while the context is idle. See RKNN3Runtime.set_kvcache_pages for
        the full contract.
        :param bindings: Iterable of RKNN3KvCachePageBinding structures.
        :return: success: 0, failure: -1
        """
        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
            return -1

        try:
            ret = self.rknn_runtime.set_kvcache_pages(bindings)
        except:
            self.rknn_log.e('Catch exception when setting kvcache pages.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return ret

    def create_mem_from_phys(self, phys_addr, virt_addr, size):
        """
        Create tensor memory from physical address using the legacy API.
        Newer SO versions may not provide rknn3_create_mem_from_phys; prefer create_mem_from_fd.
        :param phys_addr: Physical address of the memory.
        :param virt_addr: Virtual address of the memory.
        :param size: Size of the memory in bytes.
        :return: Pointer to RKNN3TensorMemory, or None on failure.
        """
        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
            return None

        try:
            mem = self.rknn_runtime.create_mem_from_phys(phys_addr, virt_addr, size)
        except:
            self.rknn_log.e('Catch exception when creating memory from physical address.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return None
        return mem

    def create_mem_from_fd(self, fd, virt_addr, size, offset=0):
        """
        Create tensor memory from file descriptor.
        :param fd: File descriptor for the memory.
        :param virt_addr: Virtual address of the memory.
        :param size: Size of the memory in bytes.
        :param offset: Offset from the start of the memory.
        :return: Pointer to RKNN3TensorMemory, or None on failure.
        """
        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
            return None

        try:
            mem = self.rknn_runtime.create_mem_from_fd(fd, virt_addr, size, offset)
        except:
            self.rknn_log.e('Catch exception when creating memory from fd.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return None
        return mem

    def destroy_mem(self, mem):
        """
        Destroy tensor memory.
        :param mem: Pointer to RKNN3TensorMemory to destroy.
        :return: success: 0, failure: -1
        """
        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
            return -1

        try:
            ret = self.rknn_runtime.destroy_mem(mem)
        except:
            self.rknn_log.e('Catch exception when destroying memory.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return ret

    def mem_sync(self, mem, sync_mode):
        """
        Synchronize tensor memory between CPU and device.
        :param mem: Pointer to RKNN3TensorMemory.
        :param sync_mode: RKNN3MemSyncMode enum value.
        :return: success: 0, failure: -1
        """
        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
            return -1

        try:
            ret = self.rknn_runtime.mem_sync(mem, sync_mode)
        except:
            self.rknn_log.e('Catch exception when syncing memory.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return ret

    def mem_sync_range(self, mem, sync_mode, offset, length):
        """
        Synchronize a range of tensor memory between CPU and device.
        :param mem: Pointer to RKNN3TensorMemory.
        :param sync_mode: RKNN3MemSyncMode enum value.
        :param offset: Byte offset within mem->virt_addr to start syncing from.
        :param length: Number of bytes to sync (offset+length must not exceed mem->size).
        :return: success: 0, failure: -1
        """
        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
            return -1

        try:
            ret = self.rknn_runtime.mem_sync_range(mem, sync_mode, offset, length)
        except:
            self.rknn_log.e('Catch exception when syncing memory range.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return ret

    # ============================================= Dynamic Shape =============================================

    def set_shape(self, shape_id):
        """
        Set the model shape for dynamic input.
        :param shape_id: The ID of the shape to be set.
        :return: success: 0, failure: -1
        """
        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
            return -1

        try:
            ret = self.rknn_runtime.set_shape(shape_id)
        except:
            self.rknn_log.e('Catch exception when setting shape.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return ret

    # ============================================= User Memory =============================================

    def set_kvcache_mem(self, mem_list, npu_core_indices):
        """
        Set KV-Cache memory for specified NPU cores.
        :param mem_list: List of POINTER(RKNN3TensorMemory) for each core.
        :param npu_core_indices: List of NPU core indices.
        :return: success: 0, failure: -1
        """
        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
            return -1

        try:
            ret = self.rknn_runtime.set_kvcache_mem(mem_list, npu_core_indices)
        except:
            self.rknn_log.e('Catch exception when setting kvcache memory.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return ret

    def set_internal_mem(self, mem_list):
        """
        Set user-allocated internal memory for multiple cores.
        :param mem_list: List of POINTER(RKNN3TensorMemory), each mem's core_id specifies the target core.
        :return: success: 0, failure: -1
        """
        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
            return -1

        try:
            ret = self.rknn_runtime.set_internal_mem(mem_list)
        except:
            self.rknn_log.e('Catch exception when setting internal memory.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return ret

    def set_weight_mem(self, mem_list):
        """
        Set multiple core's user-allocated weight memory. Note: Current version only supports RK3572.
        :param mem_list: List of POINTER(RKNN3TensorMemory), each mem's core_id field specifies the target core.
        :return: success: 0, failure: -1
        """
        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
            return -1

        try:
            ret = self.rknn_runtime.set_weight_mem(mem_list)
        except:
            self.rknn_log.e('Catch exception when setting weight memory.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return ret

    def set_input_name_alias(self, src_input_name, dst_input_name):
        """
        Set alias between model input name and runtime/session expected input name.
        :param src_input_name: The actual input name used in the model (e.g., "input_embedding").
        :param dst_input_name: The expected input name used in the session (e.g., "input_embeds").
        :return: success: 0, failure: -1
        """
        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
            return -1

        try:
            ret = self.rknn_runtime.set_input_name_alias(src_input_name, dst_input_name)
        except:
            self.rknn_log.e('Catch exception when setting input name alias.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return ret

    def set_kvcache_group(self, group_id):
        """
        Set active KV cache group for current context.
        :param group_id: The group ID to activate (must be in [0, n_groups)).
        :return: success: 0, failure: -1
        """
        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
            return -1

        try:
            ret = self.rknn_runtime.set_kvcache_group(group_id)
        except:
            self.rknn_log.e('Catch exception when setting kvcache group.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return ret

    # ============================================= Debug & Profile =============================================

    def dump_features(self, dump_dir):
        """
        Dump layer-by-layer features of the model to .npy files.
        :param dump_dir: Directory where dumped features will be saved.
        :return: success: 0, failure: -1
        """
        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
            return -1

        try:
            ret = self.rknn_runtime.dump_features(dump_dir)
        except:
            self.rknn_log.e('Catch exception when dumping features.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return ret

    def profile_ops(self, log_level=0):
        """
        Print layer-by-layer operator profile information.
        :param log_level: Log verbosity level:
                          0 - Only print OpType summary table
                          1 - Print per-Op details table + summary table
                          2 - Print per-Op details (time/cycles/bandwidth) + summary table
        :return: success: 0, failure: -1
        """
        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
            return -1

        try:
            ret = self.rknn_runtime.profile_ops(log_level)
        except:
            self.rknn_log.e('Catch exception when profiling ops.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return ret

    def profile_mem(self):
        """
        Print memory usage information for each NPU core.
        :return: success: 0, failure: -1
        """
        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
            return -1

        try:
            ret = self.rknn_runtime.profile_mem()
        except:
            self.rknn_log.e('Catch exception when profiling memory.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return ret

    # ============================================= Image Processing =============================================

    def im_mem_create(self, width, height, fmt, size=0, core_id=0,
                      flags=RKNN3MemAllocFlags.RKNN3_FLAG_MEMORY_CACHEABLE):
        """
        Create image memory.
        :param width: Width of the image.
        :param height: Height of the image.
        :param fmt: Image format (RKNN3ImFmt enum value).
        :param size: Size in bytes. If 0, calculated from width/height/format.
        :param core_id: Target NPU core ID.
        :param flags: Memory allocation flags.
        :return: Tuple of (ret, RKNN3ImMem). ret is 0 on success, -1 on failure.
        """
        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
            return -1, None

        try:
            ret, im_mem = self.rknn_runtime.im_mem_create(width, height, fmt, size, core_id, flags)
        except:
            self.rknn_log.e('Catch exception when creating image memory.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1, None
        return ret, im_mem

    def im_mem_destroy(self, im_mem):
        """
        Destroy image memory.
        :param im_mem: RKNN3ImMem object to destroy.
        :return: success: 0, failure: -1
        """
        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
            return -1

        try:
            ret = self.rknn_runtime.im_mem_destroy(im_mem)
        except:
            self.rknn_log.e('Catch exception when destroying image memory.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return ret

    def im_cvt_color(self, src_im_mem, dst_im_mem):
        """
        Convert image color space.
        :param src_im_mem: Source RKNN3ImMem object.
        :param dst_im_mem: Destination RKNN3ImMem object.
        :return: success: 0, failure: -1
        """
        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
            return -1

        try:
            ret = self.rknn_runtime.im_cvt_color(src_im_mem, dst_im_mem)
        except:
            self.rknn_log.e('Catch exception when converting image color.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return ret

    # ============================================= Output Tensors =============================================

    def create_output_tensors(self, output_indices=None):
        """
        Create output tensors with allocated memory for LLM output callback.
        Mirrors the C++ pattern:
            for each output index:
                rknn3_query(RKNN3_QUERY_OUTPUT_ATTR) -> get attr
                rknn3_create_mem(aligned_size, core_id, CACHEABLE) -> allocate mem
                build RKNN3Tensor with attr + mem

        :param output_indices: List of output tensor indices. If None, uses all outputs (0..n_output-1).
        :return: Tuple of (output_tensor_array, n_output_tensors) on success, or (None, 0) on failure.
                 output_tensor_array is a ctypes array of RKNN3Tensor.
        """
        from ctypes import pointer, memmove, sizeof, cast, POINTER

        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
            return None, 0

        try:
            # If no indices specified, query IO num and use all outputs
            if output_indices is None:
                io_num = self.rknn3_query(RKNN3QueryCmd.RKNN3_QUERY_IN_OUT_NUM)
                if io_num is None:
                    self.rknn_log.e('Failed to query IO number.', False)
                    return None, 0
                output_indices = list(range(io_num.n_output))

            n_output_tensors = len(output_indices)
            if n_output_tensors == 0:
                self.rknn_log.e('No output tensor indices specified.', False)
                return None, 0

            # Allocate ctypes array of RKNN3Tensor
            OutputTensorArray = RKNN3Tensor * n_output_tensors
            output_tensors = OutputTensorArray()

            for i, idx in enumerate(output_indices):
                attr = self.rknn3_query(RKNN3QueryCmd.RKNN3_QUERY_OUTPUT_ATTR, index=idx)
                if attr is None:
                    self.rknn_log.e('rknn3_query output attr failed for index {}'.format(idx), False)
                    # Clean up any tensors already allocated before this failure
                    for j in range(i):
                        if output_tensors[j].mem is not None:
                            self.destroy_mem(output_tensors[j].mem)
                            output_tensors[j].mem = None
                        if output_tensors[j].attr is not None:
                            output_tensors[j].attr = None
                    return None, 0

                attr_ptr = pointer(RKNN3TensorAttr())
                memmove(attr_ptr, pointer(attr), sizeof(RKNN3TensorAttr))
                output_tensors[i].attr = attr_ptr

                # Create memory directly from attr (aligned_size + core_id extracted inside create_mem)
                mem = self.create_mem(attr)
                if mem is None:
                    self.rknn_log.e('Failed to create memory for output tensor {}'.format(i), False)
                    # Clean up any tensors already allocated before this failure
                    for j in range(i):
                        if output_tensors[j].mem is not None:
                            self.destroy_mem(output_tensors[j].mem)
                            output_tensors[j].mem = None
                        if output_tensors[j].attr is not None:
                            output_tensors[j].attr = None
                    if output_tensors[i].attr is not None:
                        output_tensors[i].attr = None
                    return None, 0
                output_tensors[i].mem = mem

            return output_tensors, n_output_tensors

        except:
            self.rknn_log.e('Catch exception when creating output tensors.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return None, 0

    def release(self, session_index=None):
        """
        Release RKNN resource.
        :param session_index: If None, release all LLM sessions and RKNN runtime.
                              Otherwise release only the specified LLM session and keep RKNN runtime.
        :return: success: 0, failure: -1
        """
        # If a specific LLM session is requested, only destroy that session.
        # The RKNN runtime/context is shared by sessions and must be kept alive.
        if session_index is not None:
            if self.llm is None:
                self.rknn_log.e('LLM runtime environment is not inited, please call init_runtime or init_llm_session first!', False)
                return -1
            try:
                self.llm.release(session_index=session_index)
            except:
                self.rknn_log.e('Catch exception when release llm session[{}].'.format(session_index), False)
                self.rknn_log.e(traceback.format_exc(), False)
                return -1
            return 0

        # Default behavior: release all LLM sessions and the RKNN runtime.
        try:
            if self.llm is not None:
                self.llm.release(session_index=None)
                self.llm = None
                self.llm_mode = False

            if self.rknn_runtime is not None:
                self.rknn_runtime.release()
                self.rknn_runtime = None
        except:
            self.rknn_log.e('Catch exception when release RKNN resource.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1
        return 0

    # ============================================= Query =============================================

    def rknn3_query(self, cmd, index=0):
        """
        General-purpose query interface, similar to the C API rknn3_query.
        Allows querying model information after init_runtime (model_init) but before
        init_llm_session, enabling a query-then-configure workflow like the C++ API.

        Supported commands:
            RKNN3_QUERY_IN_OUT_NUM          -> RKNN3InputOutputNum
            RKNN3_QUERY_INPUT_ATTR          -> RKNN3TensorAttr (use index param)
            RKNN3_QUERY_OUTPUT_ATTR         -> RKNN3TensorAttr (use index param)
            RKNN3_QUERY_NATIVE_INPUT_ATTR   -> RKNN3TensorAttr (use index param)
            RKNN3_QUERY_NATIVE_OUTPUT_ATTR  -> RKNN3TensorAttr (use index param)
            RKNN3_QUERY_NATIVE_NHWC_INPUT_ATTR  -> RKNN3TensorAttr (use index param)
            RKNN3_QUERY_NATIVE_NHWC_OUTPUT_ATTR -> RKNN3TensorAttr (use index param)
            RKNN3_QUERY_SDK_VERSION         -> RKNN3SDKVersion
            RKNN3_QUERY_CORE_NUMBER         -> c_uint32 (core_number.value)
            RKNN3_QUERY_CORE_MEM_SIZE       -> RKNN3CoreMemSize (use index to specify core_id)
            RKNN3_QUERY_DEVICE_MEM_INFO     -> RKNN3DevMemInfo
            RKNN3_QUERY_CUSTOM_STRING       -> RKNN3CustomString
            RKNN3_QUERY_PERF_DETAIL         -> RKNN3PerfDetail
            RKNN3_QUERY_PERF_RUN            -> RKNN3PerfRun
            RKNN3_QUERY_DYNAMIC_SHAPE_CONFIG -> RKNN3ShapeConfig
            RKNN3_QUERY_DYNAMIC_SHAPE_INFO  -> RKNN3ShapeInfo (use index param for shape_id)
            RKNN3_QUERY_LLM_CONFIG          -> RKNN3LLMConfig
            RKNN3_QUERY_POSTPROCESS_IN_OUT_NUM -> RKNN3InputOutputNum
            RKNN3_QUERY_POSTPROCESS_OUTPUT_ATTR -> RKNN3TensorAttr (use index param)
            RKNN3_QUERY_POSTPROCESS_DYNAMIC_SHAPE_INFO -> RKNN3ShapeInfo (use index param)
            RKNN3_QUERY_KVCACHE_LEN_GROUP_INFO -> list[RKNN3KvCacheLenGroupInfo] (one per core)
            RKNN3_QUERY_ALLOCATION_INFO     -> list[RKNN3AllocationInfo] (one per core)
            RKNN3_QUERY_KVCACHE_PAGE_INFO   -> RKNN3KvCachePageInfo (use index for core_id)
            RKNN3_QUERY_ATTENTION_CONFIG    -> list[RKNN3AttentionConfig]

        :param cmd: RKNN3QueryCmd enum value.
        :param index: Index for tensor attribute queries (input/output index) or core_id for core queries.
        :return: Query result structure on success, or None on failure.
        """
        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime to init it first!', False)
            return None

        from ctypes import pointer, cast, c_void_p, sizeof, c_uint32

        try:
            cmd_val = int(cmd)

            # RKNN3_QUERY_IN_OUT_NUM / RKNN3_QUERY_POSTPROCESS_IN_OUT_NUM
            if cmd_val in (RKNN3QueryCmd.RKNN3_QUERY_IN_OUT_NUM,
                           RKNN3QueryCmd.RKNN3_QUERY_POSTPROCESS_IN_OUT_NUM):
                info = RKNN3InputOutputNum()

            # Tensor attribute queries (input/output)
            elif cmd_val in (RKNN3QueryCmd.RKNN3_QUERY_INPUT_ATTR,
                             RKNN3QueryCmd.RKNN3_QUERY_OUTPUT_ATTR,
                             RKNN3QueryCmd.RKNN3_QUERY_NATIVE_INPUT_ATTR,
                             RKNN3QueryCmd.RKNN3_QUERY_NATIVE_OUTPUT_ATTR,
                             RKNN3QueryCmd.RKNN3_QUERY_NATIVE_NHWC_INPUT_ATTR,
                             RKNN3QueryCmd.RKNN3_QUERY_NATIVE_NHWC_OUTPUT_ATTR,
                             RKNN3QueryCmd.RKNN3_QUERY_POSTPROCESS_OUTPUT_ATTR):
                info = RKNN3TensorAttr()
                info.index = index

            # SDK version
            elif cmd_val == RKNN3QueryCmd.RKNN3_QUERY_SDK_VERSION:
                info = RKNN3SDKVersion()

            # Core number
            elif cmd_val == RKNN3QueryCmd.RKNN3_QUERY_CORE_NUMBER:
                info = c_uint32(0)
                ret = self.rknn_runtime.lib.rknn3_query(
                    self.rknn_runtime.context, cmd_val,
                    cast(pointer(info), c_void_p), sizeof(info))
                if ret < 0:
                    self.rknn_log.e('RKNN3 query CORE_NUMBER failed. error code: {}'.format(ret), False)
                    return None
                return info.value

            # Core memory size
            elif cmd_val == RKNN3QueryCmd.RKNN3_QUERY_CORE_MEM_SIZE:
                info = RKNN3CoreMemSize()
                info.core_id = index

            # Device memory info
            elif cmd_val == RKNN3QueryCmd.RKNN3_QUERY_DEVICE_MEM_INFO:
                info = RKNN3DevMemInfo()

            # Custom string
            elif cmd_val == RKNN3QueryCmd.RKNN3_QUERY_CUSTOM_STRING:
                info = RKNN3CustomString()

            # Performance detail
            elif cmd_val == RKNN3QueryCmd.RKNN3_QUERY_PERF_DETAIL:
                info = RKNN3PerfDetail()

            # Performance run
            elif cmd_val == RKNN3QueryCmd.RKNN3_QUERY_PERF_RUN:
                info = RKNN3PerfRun()

            # Dynamic shape config
            elif cmd_val == RKNN3QueryCmd.RKNN3_QUERY_DYNAMIC_SHAPE_CONFIG:
                info = RKNN3ShapeConfig()

            # Dynamic shape info / Postprocess dynamic shape info
            elif cmd_val in (RKNN3QueryCmd.RKNN3_QUERY_DYNAMIC_SHAPE_INFO,
                             RKNN3QueryCmd.RKNN3_QUERY_POSTPROCESS_DYNAMIC_SHAPE_INFO):
                info = RKNN3ShapeInfo()
                info.shape_id = index

            # LLM config
            elif cmd_val == RKNN3QueryCmd.RKNN3_QUERY_LLM_CONFIG:
                info = RKNN3LLMConfig()

            # LoRA number
            elif cmd_val == RKNN3QueryCmd.RKNN3_QUERY_LORA_NUM:
                info = c_uint32(0)
                ret = self.rknn_runtime.lib.rknn3_query(
                    self.rknn_runtime.context, cmd_val,
                    cast(pointer(info), c_void_p), sizeof(info))
                if ret < 0:
                    self.rknn_log.e('RKNN3 query LORA_NUM failed. error code: {}'.format(ret), False)
                    return None
                return info.value

            # LoRA information
            elif cmd_val == RKNN3QueryCmd.RKNN3_QUERY_LORA_INFO:
                n_lora = self.rknn3_query(RKNN3QueryCmd.RKNN3_QUERY_LORA_NUM)
                if n_lora is None:
                    self.rknn_log.e('Failed to query LoRA number.', False)
                    return None
                if n_lora == 0:
                    return []
                info = (RKNN3Lora * n_lora)()
                ret = self.rknn_runtime.lib.rknn3_query(
                    self.rknn_runtime.context, cmd_val,
                    cast(info, c_void_p), sizeof(info))
                if ret < 0:
                    self.rknn_log.e('RKNN3 query LORA_INFO failed. error code: {}'.format(ret), False)
                    return None
                return list(info)

            # KV cache length group info
            elif cmd_val == RKNN3QueryCmd.RKNN3_QUERY_KVCACHE_LEN_GROUP_INFO:
                core_num = self.rknn3_query(RKNN3QueryCmd.RKNN3_QUERY_CORE_NUMBER)
                if core_num is None or core_num <= 0:
                    self.rknn_log.e('Failed to query core number for KVCACHE_LEN_GROUP_INFO.', False)
                    return None
                from .rknn3_types import RKNN3KvCacheLenGroupInfo
                info = (RKNN3KvCacheLenGroupInfo * core_num)()
                ret = self.rknn_runtime.lib.rknn3_query(
                    self.rknn_runtime.context, cmd_val,
                    cast(info, c_void_p), sizeof(info))
                if ret < 0:
                    self.rknn_log.e('RKNN3 query KVCACHE_LEN_GROUP_INFO failed. error code: {}'.format(ret), False)
                    return None
                return list(info)

            # KV cache page info (one core per call, core_id comes from index)
            elif cmd_val == RKNN3QueryCmd.RKNN3_QUERY_KVCACHE_PAGE_INFO:
                info = RKNN3KvCachePageInfo()
                info.core_id = index

            # Allocation info (one entry per core; needed to enumerate core ids)
            elif cmd_val == RKNN3QueryCmd.RKNN3_QUERY_ALLOCATION_INFO:
                core_num = self.rknn3_query(RKNN3QueryCmd.RKNN3_QUERY_CORE_NUMBER)
                if core_num is None or core_num <= 0:
                    self.rknn_log.e('Failed to query core number for ALLOCATION_INFO.', False)
                    return None
                info = (RKNN3AllocationInfo * core_num)()
                ret = self.rknn_runtime.lib.rknn3_query(
                    self.rknn_runtime.context, cmd_val,
                    cast(info, c_void_p), sizeof(info))
                if ret < 0:
                    self.rknn_log.e('RKNN3 query ALLOCATION_INFO failed. error code: {}'.format(ret), False)
                    return None
                return list(info)

            # Attention config (array sized by RKNN3_QUERY_LLM_CONFIG.n_attention_configs)
            elif cmd_val == RKNN3QueryCmd.RKNN3_QUERY_ATTENTION_CONFIG:
                from .rknn3_types import RKNN3_MAX_ATTENTION_CONFIG_NUM
                llm_config = self.rknn3_query(RKNN3QueryCmd.RKNN3_QUERY_LLM_CONFIG)
                n_attn = int(llm_config.n_attention_configs) if llm_config is not None else 0
                if n_attn <= 0:
                    self.rknn_log.e('Failed to query n_attention_configs for ATTENTION_CONFIG.', False)
                    return None
                n_attn = min(n_attn, RKNN3_MAX_ATTENTION_CONFIG_NUM)
                info = (RKNN3AttentionConfig * n_attn)()
                ret = self.rknn_runtime.lib.rknn3_query(
                    self.rknn_runtime.context, cmd_val,
                    cast(info, c_void_p), sizeof(info))
                if ret < 0:
                    self.rknn_log.e('RKNN3 query ATTENTION_CONFIG failed. error code: {}'.format(ret), False)
                    return None
                return list(info)

            else:
                self.rknn_log.e('Unsupported query command: {}'.format(cmd), False)
                return None

            result = self.rknn_runtime.rknn3_query(cmd_val, info)
            return result

        except:
            self.rknn_log.e('Catch exception when querying.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return None

    # ============================================= Separated Init Flow =============================================

    def init_llm_session(self, llm_args, llm_callback, session_index=0):
        """
        Initialize the LLM session separately from init_runtime.
        This allows a query-then-configure workflow similar to the C++ API:
            1. load_rknn(model_path, weight_path)
            2. init_runtime(target, core_mask)          # rknn3_init + load + model_init only
            3. rknn3_query(...)                          # query model info (IO, core num, mem size, etc.)
            4. init_llm_session(llm_args, callback)      # rknn3_session_init + set_callback
            5. set_internal_mem(...) / other config       # configure shared memory, etc.
            6. session_run(...)                           # inference

        :param llm_args: A dictionary (or list of dict) of configuration parameters for the LLM model.
        :param llm_callback: A callback function (dict or RKLLMCallback structure) for the LLM model.
        :param session_index: LLM session index. Default is 0. If the LLM wrapper already exists, non-zero values initialize extra sessions.
        :return: success: 0, failure: -1
        """
        ret = 0

        if session_index < 0:
            self.rknn_log.e('The session_index of init_llm_session must be greater than or equal to 0!', False)
            return -1

        if self.rknn_runtime is None:
            self.rknn_log.e('Runtime environment is not inited, please call init_runtime first!', False)
            return -1

        if self.llm is None:
            self.rknn_log.e('LLM runtime environment is not inited, please call init_runtime and set llm_init first!', False)
            return -1

        if llm_args is None or llm_callback is None:
            self.rknn_log.e('The LLM session must pass two parameters: llm_callback and llm_args.', False)
            return -1

        # check duplicate init_session
        try:
            session_count = self.llm.get_session_count()
        except:
            self.rknn_log.e('Catch exception when get llm session count!', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1

        if session_index < session_count:
            self.rknn_log.e(
                'LLM session[{}] is already initialized, current session_count is {}. '
                'Please release it first or use session_index={}.'.format(
                    session_index, session_count, session_count
                ),
                False
            )
            return -1

        # optional: avoid skipping session index, keep sessions continuous
        if session_index > session_count:
            self.rknn_log.e(
                'Invalid session_index {}, current session_count is {}. '
                'Please initialize session_index={} first.'.format(
                    session_index, session_count, session_count
                ),
                False
            )
            return -1

        try:
            ret = self.llm.init_session(
                session_index=session_index,
                args=llm_args,
                callback=llm_callback
            )
        except:
            self.rknn_log.e('Catch exception when init llm init_session!', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1

        return ret
