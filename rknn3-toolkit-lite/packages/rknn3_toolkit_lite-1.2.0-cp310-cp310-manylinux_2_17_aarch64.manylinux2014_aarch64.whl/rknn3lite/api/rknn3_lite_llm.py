from typing import Any, Optional

from .rknn3_session import RKNN3Session
from .rknn3_types import RKNN3GrammarType

import traceback


class RKNN3Lite_LLM():
    def __init__(self, lib, context, rknn_log):
        self.context = context
        self.rknn_log = rknn_log
        self.rknn_session = RKNN3Session(lib, context)

    def init_session(self, session_index=0, args=None, callback=None):
        """Initialize an extra LLM session.

        This is a generic multi-session API. It is intentionally separated
        from LoRA. For LoRA usage, create another session first, then call
        init_lora/load_lora/enable_lora explicitly.
        """

        if self.rknn_session is None:
            self.rknn_log.e('LLM runtime environment is not inited, please call init_runtime and set llm_init first!', False)
            return -1

        self.args = args
        self.callback = callback

        if args is not None:
            try:
                self.rknn_session.set_llm_param(args)
            except:
                self.rknn_log.e('Catch exception when set llm param for session[{}]!'.format(session_index), False)
                self.rknn_log.e(traceback.format_exc(), False)
                return -1

        try:
            ret = self.rknn_session.init(session_index=session_index)
            if ret != 0:
                return ret
        except:
            self.rknn_log.e('Catch exception when init session[{}]!'.format(session_index), False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1

        try:
            return self.rknn_session.set_callback(callback, session_index=session_index)
        except:
            self.rknn_log.e('Catch exception when set callback for session[{}]!'.format(session_index), False)
            self.rknn_log.e(traceback.format_exc(), False)
            return -1

    def set_chat_template(self, system_prompt, prompt_prefix, prompt_postfix, session_index=0):  
        return self.rknn_session.set_chat_template(system_prompt, prompt_prefix, prompt_postfix, session_index=session_index)

    # Structured output grammar
    def set_grammar(self, grammar_str=None, grammar_type=None, options=None, session_index=0):
        """Apply a structured-output grammar to an LLM session.

        When ``grammar_type`` is omitted it is equivalent to
        ``RKNN3_GRAMMAR_BUILTIN_JSON``, which takes no rule text. Passing a
        non-empty ``grammar_str`` without an explicit ``grammar_type`` is
        therefore rejected instead of being silently treated as builtin JSON.
        """
        if grammar_type is None:
            if grammar_str is not None and grammar_str != b"" and grammar_str != "":
                raise ValueError(
                    "grammar_type must be specified when grammar_str is provided"
                )
            grammar_type = RKNN3GrammarType.RKNN3_GRAMMAR_BUILTIN_JSON
        return self.rknn_session.set_grammar(
            grammar_str, grammar_type, options, session_index=session_index
        )

    def clear_grammar(self, session_index=0):
        """Clear the structured-output grammar from an LLM session."""
        return self.rknn_session.clear_grammar(session_index=session_index)

    def inference(self, prompt: Optional[str], embeds: Optional[Any], tokens: Optional[Any], inputs: Optional[list], keep_history: Optional[bool] = None, max_new_tokens: Optional[int] = None, prefill_only: Optional[bool] = None, disable_sampling: Optional[bool] = None, keep_grammar: Optional[bool] = None, enable_thinking: bool = False, session_index: int = 0):
        """Run LLM inference synchronously.

        :param prompt: Text prompt string. The runtime tokenizes it internally.
        :param embeds: Pre-computed embedding vectors (2-D numpy float16 array).
        :param tokens: 1-D array of token IDs (ndarray or list). Will be
            converted to int32 automatically. Use this when you have already
            tokenized the input and want to feed raw token IDs.
        :param inputs: Multimodal input list (RKNN3Image / RKNN3Audio /
            RKNN3Video / RKNN3AuxTensorWrapper).
        :param keep_history: Whether to keep history context. None uses default.
        :param max_new_tokens: Max tokens to generate. None uses default.
        :param prefill_only: If set, overrides infer_param.prefill_only.
        :param disable_sampling: If set, overrides infer_param.disable_sampling.
        :param keep_grammar: If set, overrides infer_param.keep_grammar. When True the
            per-request grammar matcher state is retained across runs for continuous
            generation; when False (default) the matcher is re-initialized each run.
        :param enable_thinking: Enable thinking mode. Default False.
        :param session_index: LLM session index. Default 0.
        :return: (ret, [n_decode_tokens, n_prefill_tokens, llm_start_time, llm_end_time])
        """
        if self.rknn_session is None:
            self.rknn_log.e('LLM runtime environment is not inited, please call init_runtime and set llm_init first!', False)
            return None

        if (embeds is not None) + (prompt is not None) + (tokens is not None) > 1:
            self.rknn_log.e("RKLLM Input prompt or embeds or tokens only support one.") 
            return None

        # set inputs
        try:
            self.rknn_session.set_llm_inputs(prompt, embeds, tokens, inputs, enable_thinking=enable_thinking)
        except:
            self.rknn_log.e('Catch exception when setting inputs.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return None

        keep_history = bool(keep_history) if keep_history is not None else None
        prefill_only = bool(prefill_only) if prefill_only is not None else False
        disable_sampling = bool(disable_sampling) if disable_sampling is not None else False
        keep_grammar = bool(keep_grammar) if keep_grammar is not None else False
        try:
            ret, [n_decode_tokens, n_prefill_tokens, llm_start_time, llm_end_time] = self.rknn_session.run(keep_history, max_new_tokens, prefill_only, disable_sampling, keep_grammar, session_index=session_index)
        except:
            self.rknn_log.e('Catch exception when running RKNN model on session[{}].'.format(session_index), False)
            self.rknn_log.e(traceback.format_exc(), False)
            return None

        return ret, [n_decode_tokens, n_prefill_tokens, llm_start_time, llm_end_time]

    def inference_async(self, prompt: Optional[str], embeds: Optional[Any], tokens: Optional[Any], inputs: Optional[list], keep_history: Optional[bool] = None, max_new_tokens: Optional[int] = None, prefill_only: Optional[bool] = None, disable_sampling: Optional[bool] = None, keep_grammar: Optional[bool] = None, enable_thinking: bool = False, session_index: int = 0):
        """Run LLM inference asynchronously.

        :param prompt: Text prompt string. The runtime tokenizes it internally.
        :param embeds: Pre-computed embedding vectors (2-D numpy float16 array).
        :param tokens: 1-D array of token IDs (ndarray or list). Will be
            converted to int32 automatically. Use this when you have already
            tokenized the input and want to feed raw token IDs.
        :param inputs: Multimodal input list (RKNN3Image / RKNN3Audio /
            RKNN3Video / RKNN3AuxTensorWrapper).
        :param keep_history: Whether to keep history, overrides infer_param if not None.
        :param max_new_tokens: Maximum number of new tokens, overrides infer_param if not None.
        :param prefill_only: If set, overrides infer_param.prefill_only.
        :param disable_sampling: If set, overrides infer_param.disable_sampling.
        :param keep_grammar: If set, overrides infer_param.keep_grammar. When True the
            per-request grammar matcher state is retained across runs for continuous
            generation; when False (default) the matcher is re-initialized each run.
        :param enable_thinking: Whether to enable thinking mode for this request.
        :param session_index: LLM session index. Default 0.
        :return: (ret, [n_decode_tokens, n_prefill_tokens, llm_start_time, llm_end_time])
        """
        if self.rknn_session is None:
            self.rknn_log.e('LLM runtime environment is not inited, please call init_runtime and set llm_init first!', False)
            return None

        if (embeds is not None) + (prompt is not None) + (tokens is not None) > 1:
            self.rknn_log.e("RKLLM Input prompt or embeds or tokens only support one.")
            return None

        # set inputs
        try:
            self.rknn_session.set_llm_inputs(prompt, embeds, tokens, inputs, enable_thinking=enable_thinking)
        except:
            self.rknn_log.e('Catch exception when setting inputs.', False)
            self.rknn_log.e(traceback.format_exc(), False)
            return None

        # run async
        # 防御性归一化，原因同 inference()：native 绑定版本的形参是 C++ bool，
        # 不接受 int -> bool 隐式转换。
        keep_history = bool(keep_history) if keep_history is not None else None
        prefill_only = bool(prefill_only) if prefill_only is not None else False
        disable_sampling = bool(disable_sampling) if disable_sampling is not None else False
        keep_grammar = bool(keep_grammar) if keep_grammar is not None else False
        try:
            ret, [n_decode_tokens, n_prefill_tokens, llm_start_time, llm_end_time] = self.rknn_session.run_async(keep_history, max_new_tokens, prefill_only, disable_sampling, keep_grammar, session_index=session_index)
        except:
            self.rknn_log.e('Catch exception when running RKNN model async on session[{}].'.format(session_index), False)
            self.rknn_log.e(traceback.format_exc(), False)
            return None

        return ret, [n_decode_tokens, n_prefill_tokens, llm_start_time, llm_end_time]

    # LoRA
    def init_lora(self, lora_weight_path=None, weight_data=None, weight_size=None, session_index=0):
        """Initialize LoRA from file path or memory buffer.

        May be called repeatedly to register multiple weight files/buffers;
        adapter names must be unique across all registered files, and each
        in-memory buffer must remain valid until the context is released.
        """
        return self.rknn_session.init_lora(lora_weight_path, weight_data, weight_size, session_index=session_index)

    def load_lora(self, lora, session_index=0):
        return self.rknn_session.load_lora(lora, session_index=session_index)

    def unload_lora(self, lora, session_index=0):
        return self.rknn_session.unload_lora(lora, session_index=session_index)

    def enable_lora(self, lora, session_index=0):
        """Enable a LoRA adapter for this LLM session.

        Note: different adapters mapped to the same pattern slot cannot be
        enabled together in one session. Different sessions may reuse that
        slot; the runtime reapplies each session's LoRA binding before
        inference.
        """
        return self.rknn_session.enable_lora(lora, session_index=session_index)

    def disable_lora(self, lora, session_index=0):
        return self.rknn_session.disable_lora(lora, session_index=session_index)

    def query_lora(self, session_index=0):
        return self.rknn_session.query_lora(session_index=session_index)

    # KV Cache
    def set_kvcache_policy(self, policy, param=None, session_index=0):
        return self.rknn_session.set_kvcache_policy(policy, param, session_index=session_index)

    def load_kvcache(self, kvcache_path=None, kvcache_data=None, size=0, session_index=0):
        return self.rknn_session.load_kvcache(kvcache_path, kvcache_data, size, session_index=session_index)

    def save_kvcache(self, kvcache_path, session_index=0):
        return self.rknn_session.save_kvcache(kvcache_path, session_index=session_index)

    def clear_kvcache(self, clear_policy=None, param=None, session_index=0):
        if clear_policy is not None:
            return self.rknn_session.clear_kvcache(
                clear_policy, param, session_index=session_index
            )
        return self.rknn_session.clear_kvcache(param=param, session_index=session_index)

    def set_kvcache_pages(self, bindings):
        """Replace KV cache page bindings for the current context.

        Context-level operation (not session-scoped): see
        RKNN3Session.set_kvcache_pages for the full contract.
        """
        return self.rknn_session.set_kvcache_pages(bindings)

    # Session control
    def stop(self, session_index=0):
        return self.rknn_session.stop(session_index=session_index)

    def pause(self, session_index=0):
        return self.rknn_session.pause(session_index=session_index)

    def resume(self, session_index=0):
        return self.rknn_session.resume(session_index=session_index)

    def query_state(self, session_index=0):
        return self.rknn_session.query_state(session_index=session_index)

    def get_session_count(self):
        return self.rknn_session.get_session_count()
    
    # Function tools
    def set_function_tools(self, tools, session_index=0):
        return self.rknn_session.set_function_tools(tools, session_index=session_index)

    # LLM param
    def set_session_llm_param(self, params, n_params=1, session_index=0):
        return self.rknn_session.set_session_llm_param(params, n_params, session_index=session_index)

    def release(self, session_index=None):
        if self.rknn_session is not None:
            self.rknn_session.destroy(session_index=session_index)
            if session_index is None:
                self.rknn_session = None
