# -*- coding:utf-8 -*-
import os
import sys
import copy
import json
import platform
from .rknn_log import RKNNLog, set_log_level_and_file_path
from .rknn_platform import (
    get_host_os_platform,
    get_librknn_api_require_dll_dir,
)
from .rknn_base import RKNNBase
from .rknn_kvcache_controller import RKNNKVCacheController
from argparse import Namespace
# from .rknn_llm import RKNN_LLM

already_imported = False
for path in sys.path:
    if os.path.join('rknn', 'base') in path:
        already_imported = True
if not already_imported:
    lib_path = os.path.abspath(os.path.join(os.path.dirname('__file__'), '..', 'base'))
    sys.path.append(lib_path)


DEFAULT_RKNN_LLM_CONFIG_ = {
'attention_config': [{                                   # accept multi internal kvcache as list(dict)
    'mask_name'              : 'attention_mask',         # required, this is used for recognize which attn belong to this config
    'kvcache_buffer_len'     : 1024,                     # feed int or str "real_time"
    'kvcache_dtype'          : 'Float16',                # Float16, Int8_to_F16, Int4_to_F16
    'kvcache_store_method'   : None,                 # GroupQuant, Normal
    'kvcache_group_size'     : None,
    'kvcache_residual_depth' : None,
    'tokens_per_page'        : 512,                      # None disables paged attention; <= 0 uses kvcache_buffer_len
    'request_num'            : 1,
    'kvcache_write_policy'   : 'WRITE_THROUGH',          # 'WRITE_THROUGH', 'DEFERRED_WRITE', 'SKIP_WRITE'
    'sliding_window_size'    : -1,
    'attention_type'         : 'FullAttention',          # FullAttention, SlidingAttention

    'position_name'          : 'position_ids',           # allow None if no position_ids input
    'max_position_embeddings': 8192,
    'position_embeddings_host_storage': False,
    'mrope_type'             : None,                     # 'Qwen2.5-VL', 'Qwen3-VL', 'Qwen3.5'
    'mrope_section'          : None,                     # [24,20,20]
    'mrope_new_id_name'      : None,                     # new name to insert position id input

}],
'llm_head':[{
    'name'                  : 'auto',                       # auto or specify head tensor name, if multiple heads in model, please specify head tensor name
    'device'                : 'RK1820',                     # RK3588, RK3576,
    'quantized_dtype'       : 'w6a16',                      # w16a16, w4a16, w6a16, w8a8
    'quantized_method'      : 'group32',                    # layer, channel, group{SIZE}
}],
'vocab':[{
    'index_name'            : 'auto',                       # auto or specify embedding tensor name, if multiple embeddings in model, please specify embedding tensor name
    'tie_embeddings'         : False,                        #! True, False, current not support
    'store_on_compute_device': False,                       # True, False
}],
'keep_one_logit': [{                               # accept multi internal kvcache as list(dict)
    'output_name': None,
    'idx_name'   : 'num_logits_to_keep',
    'axis'       : None,
}],
}


def compatible_decorator_config_func(func):
    key_in_elder_version = ['kvcache_store_method', 'kvcache_dtype', 'max_ctx_len',
                            'kvcache_group_size', 'kvcache_residual_depth', 'max_position_embeddings']
    def wrapper(*args, **kwargs):
        compatible_trans = False
        for k, v in kwargs.items():
            if k in key_in_elder_version:
                RKNNLog.w("The parameter '{}' has been deprecated in the latest version.".format(k) +
                          " Please use 'llm_config' parameter of 'config' interface.")
                compatible_trans = True
                break
        if compatible_trans and 'llm_config' in kwargs:
            RKNNLog.e("Cannot set both '{}' and 'llm_config' parameters at the same time.".format(
                "', '".join(key_in_elder_version)))
            return -1
        if compatible_trans:
            RKNNLog.w("Automatically converting to 'llm_config' parameter for compatibility.")
            llm_config = copy.deepcopy(DEFAULT_RKNN_LLM_CONFIG_)
            for k, v in kwargs.items():
                if k in key_in_elder_version:
                    k = 'kvcache_buffer_len' if k == 'max_ctx_len' else k
                    RKNNLog.w("Replacing llm_config['attention_config']['{}'] = {}. | Default value is {}".format(k, v, llm_config['attention_config'][0][k]))
                    llm_config['attention_config'][0][k] = v
            kwargs['llm_config'] = llm_config
            for k in key_in_elder_version:
                if k in kwargs:
                    del kwargs[k]
        return func(*args, **kwargs)
    return wrapper


class RKNN:
    """
    Rockchip NN Kit
    """

    # NPU Core Mask
    RKNN3_NPU_CORE_0 = 1 << 0
    RKNN3_NPU_CORE_1 = 1 << 1
    RKNN3_NPU_CORE_2 = 1 << 2
    RKNN3_NPU_CORE_3 = 1 << 3
    RKNN3_NPU_CORE_4 = 1 << 4
    RKNN3_NPU_CORE_5 = 1 << 5
    RKNN3_NPU_CORE_6 = 1 << 6
    RKNN3_NPU_CORE_7 = 1 << 7
    RKNN3_NPU_CORE_ALL = 0xFF

    def __init__(self, verbose=False, verbose_file=None):
        if type(verbose) == str:
            verbose = verbose.lower()
        cur_path = os.path.abspath(os.path.join(os.path.dirname('__file__'), '..'))
        if get_host_os_platform() == 'Windows_x64':
            require_dll_dir = get_librknn_api_require_dll_dir()
            new_path = os.environ["PATH"] + ";" + require_dll_dir
            os.environ["PATH"] = new_path
        self.verbose = verbose
        if verbose_file is not None:
            if os.path.dirname(verbose_file) != "" and not os.path.exists(os.path.dirname(verbose_file)):
                verbose_file = None
        self.rknn_log = set_log_level_and_file_path(verbose, verbose_file)
        if verbose not in [True, False, 'debug']:
            self.rknn_log.e("'verbose' must be True or False!")
        if verbose:
            if verbose_file:
                self.rknn_log.d('Save log info to: {}'.format(verbose_file))
        self.rknn_base = RKNNBase(cur_path, verbose)

        self.kvcache_controller = RKNNKVCacheController(self.rknn_base)

    @compatible_decorator_config_func
    def config(self,
               mean_values=None,
               std_values=None,
               quantized_dtype='w16a16',
               quantized_algorithm=None,
               quantized_method=None,
               quantized_hybrid_level=0,
               target_platform=None,
               quant_img_RGB2BGR=False,
               optimization_level=3,
               dynamic_input=None,
               core_num=0,                                # 0 means auto, reset to 8 when load_llm, reset to 1 when others.
               rknn_build_parallelism=-1,                 # <1 means auto, >=1 means user set value.

               llm_config=DEFAULT_RKNN_LLM_CONFIG_,

               input_attrs={},                            # input_attrs: {input_name: {attr_name: attr_value, ...}, ...}, such as {'input_name': {'dtype': 'float32', 'layout': 'NCHW', 'shape': [1, 3, 224, 224]}, ...}
                                                          # attr_name: dtype, layout, shape, stride, etc.
               output_attrs={},                           # output_attrs: {output_name: {attr_name: attr_value, ...}, ...}, such as {'output_name': {'dtype': 'float32', 'layout': 'UNDEFINED', 'shape': [1, 1000]}, ...}
                                                          # attr_name: dtype, layout, shape, stride, etc.

               # experiment
               custom_string=None,
               cvt_conv_streaming=[],                     # convert convolution to streaming convolution. [['Group0_conv0_output0', 'Group0_conv1_output0'], ['Group1_conv0_output0', ...], ...]
               disable_logN_rcclReduce=False,
               distribute_full_search_space=False,        # whether to do full search space for distribution, such as different op search orders. set True may get better rknn performance but with much longer time cost.
               distribute_strategy='less_mem',            # less_subgraph, best_perf, less_mem
               enable_moe_tc=False,                       # bind runtime valid-token count for MoE; requires matching compiler support.
               float_dtype='float16',
               inputs_yuv_fmt=None,
               input_initial_value=None,                  # set initial value for model input tensor, set None for non-initial value, such as [[None, np.zeros([1,3,224,224])], [None, np.zeros([1,3,384,384])]], the length should be the same as model input number.
               linear_attn_out_project_dtype=None,     # Temporary solution, None mean no effect on special layers quantize dtype.
               merge_mean_std_to_conv=False,
               model_pruning=False,
               op_target={},
               profile_mode=False,
               op_quantized_dtype={},                     # Specify the quantization dtype for individual operator. Currently, only MatMul, Gemm, and Linear operators are supported, and the allowable quantization formats are restricted to: [w4a16, w6a16, w8a16, w16a16].
               sdpa_qk_scale={},
               shard_map={},                              # tensor, distribute aixs
               simulate_lut=False,                        # simulator use LUT to do activation if LUT implement is available, accuracy will be more close to npu inference result.
               sparse_infer=False,
               subgraph_dtype_target=None,                # [[], [], 'w16a16']* N

               # deprecate
               auto_hybrid_cos_thresh=None,
               auto_hybrid_euc_thresh=None,
               attn_nodes_config=None,                 # {'attn.output': {kvcache_store_method:x, kvcache_dtype:x, ...}}
               remove_reshape=None,
               single_core_mode=None,

               disable_stage=None,                       # 跳过 build 的某些阶段 (如 ['op_fuse'] 禁用算子融合)
               generate_torch_model=False,                # export_rknn 时对 check6 量化 IR 生成 torch 代码

               **kwargs,
               ):
        """
        Configs
        :param mean_values: Channel mean value list, default is None, means all mean is zero.
        :param std_values: Channel std value list, default is None, means all std is one.
        :param quantized_dtype: quantize data type, currently support: w8a8, w4a16. default is w8a8.
        :param quantized_algorithm: currently support: normal, mmse (Min Mean Square Error), kl_divergence. default is normal.
        :param quantized_method: quantize method, currently support: layer, channel, group{SIZE}. default is channel.
                                 {SIZE} is the multiple value of 32 between 32 and 256, e.g group32.
        :param target_platform: target chip platform, currently support rv1103 / rv1103b / rv1106 / rv1106b / rk2118 / rk3562 / rk3566 /
                                rk3568 / rk3576 / rk3588 / rk1820. default is None.
        :param quant_img_RGB2BGR: whether to do RGB2BGR when load quantize image (jpg/jpeg/png/bmp), default is False.
        :param float_dtype: non quantize data type, currently support: float16, bfloat16, default is float16.
        :param generate_torch_model: generate editable PyTorch source, a weight store, and regenerated
                                     ONNX under the build cache when export_rknn is called. default is False.
        :param optimization_level: set optimization level. default is 3, means use all default optimization options.
        :param custom_string: add custom string information to rknn model, then can query the information at runtime. default is None.
        :param inputs_yuv_fmt: add yuv preprocess at the top of model. default is None.
        :param single_core_mode: single_core_mode=True can reduce the size of rknn model, only for rk3588. default is False.
        :param model_pruning: pruning the model to reduce the model size, default is False.
        :param op_target: used to specify the target of each operation, the format is {'111':'cpu', '222':'cpu', ...}, default is None.
        :param dynamic_input: simulate the function of dynamic input according to multiple sets of input shapes specified by the user,
                              the format is [[[1,3,224,224],[1,1,224,224], ...], [[1,3,160,160],[1,1,160,160], ...], ...].
                              default is None, experimental.
        :param sdpa_qk_scale: Apply q,k scale for Attention op to avoid possible overflow during calculation of exSDPA, the format is {'exSDPA_op_name' : [float(1/50), float(1/50)]} . default is None.
        :param remove_reshape: Remove possible 'Reshape' in model inputs and outputs to improve model runtime performance. default is False.
        :param sparse_infer: Sparse inference on already sparsified models to improve performance. default is False.
        :param auto_hybrid_cos_thresh: The thresholds of cosine distance in auto hybrid when model is quantizate. default is 0.98
        :param auto_hybrid_euc_thresh: The thresholds of euclidean distance in auto hybrid when model is quantizate. default is None
        :param profile_mode: Whether to enable profile mode. default is False.If profile_mode is True, runtime will print layer performance instead of giving the overall performance.The option can be used for model internal tensor dump.
        :param input_attrs: Input attributes, default is {}. The format is {'input_name': {'dtype': 'float32', 'layout': 'NCHW', 'shape': [1, 3, 224, 224]}, ...}
                            The attr_name is dtype, layout, shape, stride, etc. The input_name is the name of the input tensor.
                            dtype: support float32, float16, int8, uint8, int16, uint16, int32, uint32, int64, uint64.
                            layout: support NCHW, NHWC, NC1HWC2, UNDEFINED. If shape is not 4-dims, layout is UNDEFINED.
        :param output_attrs: Output attributes, default is {}. The format is {'output_name': {'dtype': 'float32', 'layout': 'NCHW', 'shape': [1, 1000]}, ...}
                            The attr_name is dtype, layout, shape, stride, etc. The output_name is the name of the output tensor.
                            dtype: support float32, float16, int8, uint8, int16, uint16, int32, uint32, int64, uint64.
                            layout: support NCHW, NHWC, NC1HWC2, UNDEFINED. If shape is not 4-dims, layout is UNDEFINED.

        :return: success: 0, failure: -1
        """
        # This release deliberately excludes the runtime-profiler extension.
        unsupported = {'runtime_profile_mode', 'runtime_profiler_options'} & kwargs.keys()
        if unsupported:
            raise ValueError('Runtime profiler is not supported by this release: ' +
                             ', '.join(sorted(unsupported)))

        # Workspace args
        args = Namespace()
        import inspect
        frame = inspect.currentframe()
        args_key, _, _, _ = inspect.getargvalues(frame)
        for key in args_key:
            if key == 'self':
                continue
            setattr(args, key, locals()[key])
        args.kwargs = kwargs
        if id(args.llm_config) == id(DEFAULT_RKNN_LLM_CONFIG_):
            args.llm_config = copy.deepcopy(DEFAULT_RKNN_LLM_CONFIG_)
            args.llm_config['default_config'] = True
        else:
            args.llm_config = copy.deepcopy(args.llm_config)
            args.llm_config['default_config'] = False

        return self.rknn_base.config(args)

    def load_onnx(self, model, inputs=None, input_size_list=None, input_initial_val=None, outputs=None):
        """
        Load ONNX Model
        :param model: ONNX model file path.
        :param inputs: Specified model inputs, Such as: ['data']. default is None, means get from model.
        :param input_size_list: Set each input tensor size list, Such as: [[1,224,224],[3,224,224]], If inputs set, the
                                input_size_list should be set also. defualt is None.
        :param input_initial_val: Set each input initial value (ndarray list). default is None.
        :param outputs: Specified model outputs, Such as: ['resnetv24_dense0_fwd']. defualt is None, means get from model.
        :return: success: 0, failure: -1
        """
        return self.rknn_base.load_onnx(model, inputs, input_size_list, input_initial_val, outputs)

    def load_llm(self, model, config='', seq_lens=[1,128], **kwargs):
        """
        Load llm model from export_llm (https://...)
        :param model: base model path
        :param config: llm config
        :param seq_len: sequence length of dynamic shapes, default is [1, 128]
        :return: success: 0, failure: -1
        """
        return self.rknn_base.load_llm(model=model, config=config, seq_lens=seq_lens, **kwargs)

    def load_lora(self, lora_paths, lora_config_paths, lora_patterns, lora_quantized_dtype=None, lora_quantized_method=None, lora_node_map=None, **kwargs):
        """
        Load LoRA Weight
        :param lora_paths: Nested list of LoRA weight file paths. The outer list represents mutually exclusive LoRA groups, and paths in one inner list share the same graph computation.
                            Such as: [['lora0_p0.safetensors', 'lora0_p1.safetensors'], ['lora1_p0.safetensors']].
        :param lora_config_paths: Nested list of LoRA configuration file paths. Each inner list corresponds one-to-one with lora_paths.
        :param lora_patterns: Nested list of LoRA pattern names. Each inner list corresponds one-to-one with lora_paths; only one pattern in the same outer group can be enabled.
        :param lora_quantized_dtype: LoRA weight quantized data type, currently support: 'int4', 'int6', 'int8', 'float16', 'bfloat16'. If None, follows float_dtype when it is 'float16' or 'bfloat16'; default is None.
        :param lora_quantized_method: LoRA weight quantized method, currently support: layer, channel, group{SIZE}. default is None.
        :param lora_node_map: Optional custom LoRA node mapping dictionary or JSON file path. When set, exact model node names and LoRA A/B keys are used and prefix/postfix matching is disabled. Format: {base_node_name: [group_0_records, group_1_records, ...]}, with each record as [a_key, b_key, weight_index].
                              Example: {'decoder.layers.0.self_attn.q_proj': [[['adapter.g0.p0.lora_A.weight', 'adapter.g0.p0.lora_B.weight', 0]], [['adapter.g1.p0.lora_A.weight', 'adapter.g1.p0.lora_B.weight', 0]]]}.
        :return: success: 0, failure: -1
        """
        return self.rknn_base.load_lora(lora_paths, lora_config_paths, lora_patterns=lora_patterns, lora_quantized_dtype=lora_quantized_dtype, lora_quantized_method=lora_quantized_method, lora_node_map=lora_node_map, **kwargs)

    def build(self, do_quantization=True, dataset=None, rknn_batch_size=None, auto_hybrid=False):
        """
        Build RKNN model
        :param do_quantization: Whether to quantize the model. default is True.
        :param dataset: DataSet file for quantization. default is None.
        :param rknn_batch_size: Batch size to inference. default is None.
        :param auto_hybrid: Whether to enable automatic hybrid quantization to adjust accuracy or overflow. default is False.
        :return: success: 0, failure: -1
        """

        return self.rknn_base.build(do_quantization=do_quantization, dataset=dataset, expand_batch_size=rknn_batch_size, auto_hybrid=auto_hybrid)

    def rebuild(self, build_cache_dir, strict_check=True, quant_json=None, dataset=None):
        """
        Rebuild RKNN model, allow call rknn.config to reset 'profile_mode' and 'kvcache relate param' and rebuild model
        :param build_cache_dir: build_cache_dir is the path that 'rknn.build' generated normally as './tmp'
        :param strict_check: whether to perform strict build-cache integrity checks. default is True.
        :param quant_json: quantization manifest override for a generate_torch_model cache. When graph
                           structure is unchanged, compatible compiler parameters are fully replaced.
                           After a structural edit, mappable weight parameters are retained and activation
                           parameters are recalibrated from dataset.
        :param dataset: calibration dataset required for a full rebuild after structural edits to a
                        quantized generated model. Not required for a compatible parameter-only update.
        :return: success: 0, failure: -1
        """
        return self.rknn_base.rebuild(build_cache_dir, strict_check, quant_json=quant_json, dataset=dataset)

    def hybrid_quantization_step1(self, dataset='dataset.txt', rknn_batch_size=None, proposal=False, proposal_dataset_size=1, custom_hybrid=None):
        """
        Generate hybrid quantization config
        :param dataset: DataSet for quantization
        :param rknn_batch_size: batch size to inference.
        :param proposal: Generate hybrid quantization config suggestions
        :param proposal_dataset_size: The size of dataset used for proposal
        :param custom_hybrid: Generate hybrid quantization config files, the format is [[input_name, output_name], ...], default is None
        :return: success: 0, failure: -1
        """
        return self.rknn_base.hybrid_quantization_step1(
            dataset=dataset, expand_batch_size=rknn_batch_size,
            proposal=proposal, proposal_dataset_size=proposal_dataset_size, custom_hybrid=custom_hybrid)

    def hybrid_quantization_step2(self, model_input, data_input, model_quantization_cfg):
        """
        Generate rknn model info
        :param model_input: Model file path.
        :param data_input: Data file path.
        :param model_quantization_cfg: config file path for model quantization.
        :return: success: 0, failure: -1
        """
        return self.rknn_base.hybrid_quantization_step2(model_input, data_input, model_quantization_cfg)

    def export_rknn(self, export_path, save_ctx=False, **kwargs):
        """
        Export rknn model to file
        :param export_path: Export rknn model file path.
        :param save_ctx: Whether to save context. default is False.
        :return: success: 0, failure: -1
        """

        if 'cpp_gen_cfg' in kwargs:
            self.rknn_log.w("'cpp_gen_cfg' param of 'export_rknn' has been deprecated. Please call 'gen_cpp_demo' interface to generate cpp demo.")

        return self.rknn_base.export_rknn(export_path, save_ctx=save_ctx, **kwargs)

    def export_rknn_from_tmp(self, export_path, tmp_path="./tmp"):
        #! deprecated
        """
        Export rknn model to file
        :param export_path: Export rknn model file path.
        :param tmp_path: Temporary file path. default is "./tmp".
        :return: success: 0, failure: -1
        """

        return self.rknn_base.export_rknn_from_tmp(export_path, tmp_path)

    def export_encrypted_rknn_model(self, input_model, output_model=None, crypt_level=1):
        """
        Encrypt a rknn model.
        :param input_model: Path of rknn model which need encrypt.
        :param output_model: Encrypted rknn model path. default is None.
        :param crypt_level: Crypt level, 1~3. default is 1. The lower the level, the faster the decryption and
                            the lower the security. The higher the level, the slower the decryption and the higher the
                            security.
        :return: success: 0, failure: -1
        """
        if input_model is None:
            self.rknn_log.e('The input_model is None! Please specify input model path!')
            return -1

        if output_model is None:
            output_model_path = os.path.splitext(input_model)[0] + '.crypt.rknn'
            self.rknn_log.w('The output_model is None, using {} as output model name.'.format(output_model_path))
        else:
            output_model_path = output_model

        if crypt_level < 1 or crypt_level > 3:
            crypt_level = 1
            self.rknn_log.w('Unsupport crypt_level {}. It should be 1, 2 or 3. Reset to default: 1.'.format(
                crypt_level))

        return self.rknn_base.get_encrypted_rknn_model(input_model, output_model_path, crypt_level)

    def load_rknn(self, model_path, weight_path, lora_weight_path=None, load_ctx=False, **kwargs):
        """
        Load RKNN model
        :param path: RKNN model file path.
        :param load_ctx: Whether to load context. default is False.
        :param lora_weight_path: LoRA weight file path, directory, or list of paths, default is None. If the model has LoRA weight, specify the exported LoRA file(s) to load them together.
        :return: success: 0, failure: -1
        """
        return self.rknn_base.load_rknn(model_path, weight_path, lora_weight_path=lora_weight_path, load_ctx=load_ctx, rknn_ctx=self, **kwargs)

    def enable_lora(self, enable_patterns, scales=None):
        """
        Enable LoRA Weight
        :param enable_patterns: List of enable lora pattern names, Such as: ['slot0_lora0', 'slot1_lora0'].
        :param scales: List of scale factors for LoRA weights, e.g. [1.0, 0.8]. Default is None, which means scales are read from the LoRA config file.
        :return: success: 0, failure: -1
        """
        return self.rknn_base.enable_lora(enable_patterns=enable_patterns, scales=scales)

    def disable_lora(self, disable_patterns):
        """
        Disable LoRA Weight
        :param disable_patterns: List of disable lora pattern names, Such as: ['slot0_lora0', 'slot1_lora0'].
        :return: success: 0, failure: -1
        """
        return self.rknn_base.disable_lora(disable_patterns=disable_patterns)

    def init_runtime(self, target=None, device_id=None, perf_debug=False, eval_mem=False,
                     async_mode=False, core_mask=-1, fallback_prior_device="cpu",
                     custom_op_plugins=None, simulator_backend=None, pytorch_artifact_dir=None,
                     pytorch_quant_json=None):
        """
        Init run time environment. Needed by called before inference or eval performance.
        :param target: target platform, simulator or rv1103 / rv1103b / rv1106 / rv1106b / rk3562 / rk3566 / rk3568 / rk3576 / rk3588 / rk1820.
                       default is None, means simulator.
                       On macOS Apple Silicon, only simulator targets (None or 'simulator') are supported.
        :param device_id: adb device id, only needed when multiple devices connected to pc. default is None.
        :param perf_debug: enable or disable debugging performance, it will affect performance. defualt is False.
        :param eval_mem: enable or disable debugging memory usage, it will affect performance. default is False.
        :param async_mode: enable or disable async mode. default is False.
        :param core_mask: set npu core mask, currently support an integer between 0x1 and 0xff
                          default is -1.
        :param fallback_prior_device: set fallback prior device when OP is not supported by NPU.
                                      currently support: 'gpu' or 'cpu', 'gpu' is only valid for platform which has gpu hardware.
        :param custom_op_plugins: path to a custom op plugin shared library (.so).
                                  This plugin will be registered to the runtime context after model init.
                                  If already provided via ``reg_custom_op``, there is no need to pass it again here.
                                  default is None.
        :param simulator_backend: select simulator backend when target is None/'simulator'.
                                   'onnx' (default) or 'pytorch'. 'pytorch' runs the model via PyTorch
                                   on GPU/CPU using pre-generated generated.py + generated_weights.pth.
        :param pytorch_artifact_dir: directory containing generated.py and generated_weights.pth.
                                     Required when simulator_backend='pytorch' and not set via config/env.
        :param pytorch_quant_json: optional quantization manifest used to override the generated
                                   PyTorch model's quantized weights and scale/zero-point buffers.
        :return: success: 0, failure: -1
        """

        return self.rknn_base.init_runtime(target=target, device_id=device_id,
                                           perf_debug=perf_debug, eval_mem=eval_mem, async_mode=async_mode, core_mask=core_mask,
                                           fallback_prior_device=fallback_prior_device,
                                           custom_op_plugins=custom_op_plugins,
                                           simulator_backend=simulator_backend,
                                           pytorch_artifact_dir=pytorch_artifact_dir,
                                           pytorch_quant_json=pytorch_quant_json)

    def query(self, cmd):
        """
        Query model or runtime information
        :param cmd: query type string.
        :return: query result
        """
        return self.rknn_base.query(cmd)

    def alloc_kvcache_pages(self, max_tokens=None):
        """Allocate and bind paged KV cache for hardware inference.

        :param max_tokens: Number of tokens that full-attention pages must cover.
                           None allocates the model's complete context capacity.
                           Repeated calls only grow existing bindings and preserve
                           their page contents. Other cache categories allocate
                           their complete compiler-planned capacity for every
                           supported request. The runtime context must be idle.
        :return: success: 0, failure: negative runtime error code.
        """
        return self.rknn_base.alloc_kvcache_pages(max_tokens=max_tokens)

    def grow_kvcache_pages(self, max_tokens=None):
        """Grow paged KV cache without discarding existing cache contents.

        The runtime context must be idle. Only missing full-attention pages are
        allocated; passing None grows to the model's complete context capacity.

        :param max_tokens: Token capacity required after growth.
        :return: success: 0, failure: negative runtime error code.
        """
        return self.rknn_base.grow_kvcache_pages(max_tokens=max_tokens)

    def inference(self, inputs, data_format=None, output_dir='./snapshot', inputs_pass_through=None, accuracy_analysis=False, analysis_core_mask=0, shape_idx=None):
        """
        Run model inference
        :param inputs: Input ndarray list. Recognized LLM RoPE/control entries may
                       be None to use the KVCache controller and current BN mask.
        :param data_format: Data format list, current support: 'nhwc', 'nchw', default is 'nhwc', only valid for 4-dims input. default is None.
        :param output_dir: Output directory. defualt is './snapshot'.
        :param inputs_pass_through: The pass_through flag (0 or 1: 0 means False, 1 means True) list. default is None.
        :param accuracy_analysis: Whether to do accuracy analysis. default is False.
        :param analysis_core_mask: set npu core mask for dumping tensor when accuracy_analysis is True, currently support an integer between 0x1 and 0xff. default is 0, means dump on all cores.
        :return: Output ndarray list
        """
        inference_args = dict(inputs=inputs, data_format=data_format, output_dir=output_dir,
                              inputs_pass_through=inputs_pass_through,
                              accuracy_analysis=accuracy_analysis,
                              analysis_core_mask=analysis_core_mask, shape_idx=shape_idx)
        if isinstance(inputs, list) and any(value is None for value in inputs):
            if accuracy_analysis:
                self.rknn_log.e(
                    'Automatic KVCache inputs do not support accuracy_analysis; '
                    'provide explicit RoPE and control tensors for analysis.', False)
                return None
            try:
                resolved_inputs, transaction = self.kvcache_controller.prepare_inference_inputs(inputs)
            except (ValueError, RuntimeError) as error:
                self.rknn_log.e('Preparing KVCache inputs failed: {}'.format(error), False)
                return None
            inference_args['inputs'] = resolved_inputs
            if transaction is not None:
                inference_args['kvcache_transaction'] = transaction
        return self.rknn_base.inference(**inference_args)

    def accuracy_analysis(self, inputs, output_dir='./snapshot', core_mask=-1, target=None, device_id=None):
        """
        generate inference snapshots (fp32 && qnt) and calculate quantize error.
        :param inputs: The path list of image (jpg/png/bmp/npy).
        :param output_dir: Output directory. defualt is './snapshot'.
        :param target: Currently support rk1820 / rk1828.
                       If target is set, the output of each layer of NPU will be obtained, and analyze it's accuracy.
                       default is None.
        :param core_mask: set npu core mask, currently support an integer between 0x1 and 0xff
        :param device_id: if multi devices are connected, device id need be specified. default is None.
        """
        return self.rknn_base.accuracy_analysis(inputs, output_dir, core_mask, target, device_id)

    def eval_perf(self, log_level=0, dynamic_idx=0):
        """
        Evaluate model performance
        :param log_level: Log verbosity level. default is 0.
                        - 0: Only print OpType summary table
                        - 1: Print per-Op details table + summary table
                        - 2: Print per-Op details (time/cycles/bandwidth) + summary table
        :param dynamic_idx: Dynamic input index. default is 0.
        :return: success: 0, failure: -1
        """
        return self.rknn_base.eval_perf(log_level, dynamic_idx)

    def eval_memory(self):
        """
        Evaluate model memory usage
        :return: success: 0, failure: -1
        """
        return self.rknn_base.eval_memory()

    def list_devices(self):
        """
        print all adb devices.
        :return: adb_devices, list; example:
                 adb_devices = ['0123456789ABCDEF']
        """
        adb_devices, ntb_devices = self.rknn_base.list_devices()
        ntb_devices = []
        self.rknn_log.p('*' * 25)
        if len(adb_devices) > 0:
            self.rknn_log.p('all device(s) with adb mode:')
            self.rknn_log.p(",".join(adb_devices))
        if len(ntb_devices) > 0:
            self.rknn_log.p('all device(s) with ntb mode:')
            self.rknn_log.p(",".join(ntb_devices))
        if len(adb_devices) == 0 and len(ntb_devices) == 0:
            self.rknn_log.p('None devices connected.')
        self.rknn_log.p('*' * 25)
        if len(adb_devices) > 0 and len(ntb_devices) > 0:
            all_adb_devices_are_ntb_also = True
            for device in adb_devices:
                if device not in ntb_devices:
                    all_adb_devices_are_ntb_also = False
            if not all_adb_devices_are_ntb_also:
                self.rknn_log.w('Cannot use both device with adb mode and device with ntb mode.')
        return adb_devices

    def get_sdk_version(self):
        """
        Get SDK version
        :return: sdk_version
        """
        return self.rknn_base.get_sdk_version()

    def reg_custom_op(self, custom_op, custom_op_plugins=None):
        """
        Register custom operator, only supported for ONNX model.
        :param custom_op: needs to be a class similar to the following cases:
            import numpy as np
            from rknn.api.custom_op import get_node_attr
            class cstSoftmax:
                op_type = 'cstSoftmax'
                def shape_infer(self, node, in_shapes, in_dtypes):
                    out_shapes = in_shapes.copy()
                    out_dtypes = in_dtypes.copy()
                    return out_shapes, out_dtypes
                def compute(self, node, inputs):
                    x = inputs[0]
                    axis = get_node_attr(node, 'axis')
                    x_max = np.max(x, axis=axis, keepdims=True)
                    tmp = np.exp(x - x_max)
                    s = np.sum(tmp, axis=axis, keepdims=True)
                    outputs = [tmp / s]
                    return outputs
          The applicable situations:
            User needs to customize a new OP, which is not within the ONNX OP specification.
            The op_type of this new OP is recommended to start with 'cst', and the 'shape_infer'
            and 'compute' functions need to be implemented.
        :param custom_op_plugins: path to a custom op plugin shared library (.so).
                                  This plugin will be registered to the runtime context during init_runtime.
                                  If specified here, there is no need to pass it again in ``init_runtime``.
                                  If not specified here, it must be passed via ``init_runtime(custom_op_plugins=...)``
                                  before any board-side runtime or accuracy analysis.
                                  default is None.

        :return: success: 0, failure: -1
        """
        return self.rknn_base.reg_custom_op(custom_op, custom_op_plugins=custom_op_plugins)

    def optimize_onnx(self, model, optimized_path=None, passes_enable=None, inputs_for_dump=None):
        """
        Optimize the onnx graph for NPU
        :param model: ONNX model file
        :param optimized_path: the path of optimized ONNX model
        :param passes_enable: the optimzie passes list that need to be enabled, default is None, means enable all passes.
        :param inputs_for_dump: input path (npy) list for dump function, if set, will dump all tensors of simulator.
        :return: success: 0, failure: -1
        """
        return self.rknn_base.optimize_onnx(model, optimized_path, passes_enable, inputs_for_dump)

    def codegen(self, output_path, inputs=None, overwrite=False):
        """
        Generate C++ deployment example
        :param output_path: Output directory
        :param inputs: The path list of image (jpg/png/bmp/npy). Cpp demo will run with inputs if inputs is given. Default is None.
        :param overwrite: Whether to overwrite the existing file. default is False.
        :return: success: 0, failure: -1
        """
        return self.rknn_base.codegen(output_path, inputs, overwrite)

    def release(self):
        """
        Release RKNN resource
        :return: None
        """
        if platform.machine().lower() != 'amd64':
            # windows can not unsetenv
            os.unsetenv('TMPDIR')
        self.rknn_base.release()

    def profile(self, cache_file, prefill_len, generate_len, max_ctx_len=None):
        return self.rknn_base.profile(cache_file, prefill_len, generate_len, max_ctx_len)
