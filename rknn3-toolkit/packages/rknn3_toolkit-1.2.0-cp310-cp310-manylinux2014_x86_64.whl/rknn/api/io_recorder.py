import copy
import numpy as np
from collections import namedtuple
from tabulate import tabulate

from rknn.api.base_utils import inf_shape, to_np_type
from rknn.api.rknn_log import RKNNLog as rknnLog

valid_io_type_key = ['input', 'input_generated', 'input_hidden', 'output', 'output_useless', 'output_hidden']

io_keys = [
'io_type',
'idx_at_full_model',
'idx_at_task_model',
'shape',
'dtype',
'src_dtype',
'layout_set',
'mean',
'std',
'core_id',
'value_range',
'rgb2bgr',
'origin_dynamic',
'rt_tensor_attrs',
'removeable',
'description',
'change_log',
'value',
]

# 描述 OP 的拆分方式，记载每个输入输出的拆分方式
IO_info = namedtuple('IO_info', io_keys, defaults=[None]*len(io_keys))

# 转译 key map
# sp key: layout_ori, is_output,
history_input_meta_key_map = {
    'idx'   : 'idx_at_full_model',
    'shape' : 'shape',
    'layout': 'layout_set',
    'range' : 'value_range',
    'dtype' : 'src_dtype',
    'mean'  : 'mean',
    'std'   : 'std',
    'rgb2bgr'       : 'rgb2bgr',
    'origin_dynamic': 'origin_dynamic',
}
history_input_meta_key_map_inv = {v:k for k,v in history_input_meta_key_map.items()}
history_input_meta_sp_key = ['layout_ori', 'is_output']
io_sp_key = ['io_type']

_REPORT_COLORS = {
    'removed': '\033[91m',
    'changed': '\033[1;38;5;220m',
    'added': '\033[92m',
}
_REPORT_COLOR_RESET = '\033[0m'


def _cvt_input_meta_to_io_info(input_meta):
    _new = {}
    for k, v in input_meta.items():
        if k not in history_input_meta_key_map and k not in history_input_meta_sp_key:
            rknnLog.e(f'Key {k} not support')
            return None
        if k in history_input_meta_key_map:
            _new[history_input_meta_key_map[k]] = v
        elif k == 'layout_ori':
            # 不处理
            pass
        elif k == 'is_output':
            v = 'output' if v else 'input'
            _new['io_type'] = v
    return _wrap_io_info(**_new)


def _cvt_io_info_to_input_meta(io_info):
    input_meta = {k: getattr(io_info, v) for k, v in history_input_meta_key_map.items()}
    input_meta['is_output'] = io_info.io_type in ['output', 'output_useless', 'output_hidden']
    input_meta['layout_ori'] = 'undefined' if len(io_info.shape) != 4 else 'nchw'
    return input_meta


def _wrap_io_info(**kwargs):
    # TODO 增加数据类型校验
    attrs = {}
    for k, v in kwargs.items():
        if k == 'io_type' and v not in valid_io_type_key:
            rknnLog.e(f"io_type only support {valid_io_type_key}, get {v}")

        if k in IO_info._fields:
            attrs[k] = v

    _io_info = IO_info(**attrs)
    return _io_info


def collect_onnx_io_infos(onnx_model):
    # 在任何图改造前保存用户看到的原始 ONNX IO，供 origin_status 对比。
    # initializer 即使同时出现在 graph.input 中，也不属于外部输入，需要排除。
    initializer_names = {initializer.name for initializer in onnx_model.graph.initializer}
    io_infos = {}

    def _collect(value_infos, io_type):
        index = 0
        for value_info in value_infos:
            if io_type == 'input' and value_info.name in initializer_names:
                continue

            src_dtype = 'unknown'
            tensor_type = value_info.type.tensor_type
            if tensor_type.elem_type:
                try:
                    src_dtype = str(np.dtype(to_np_type(tensor_type.elem_type)))
                except (KeyError, TypeError, ValueError):
                    pass

            io_infos[value_info.name] = _wrap_io_info(
                io_type=io_type,
                idx_at_full_model=index,
                shape=inf_shape(value_info),
                src_dtype=src_dtype,
            )
            index += 1

    _collect(onnx_model.graph.input, 'input')
    _collect(onnx_model.graph.output, 'output')
    return io_infos


def _normalize_dtype(dtype):
    if dtype is None:
        return None
    try:
        return str(np.dtype(dtype))
    except (TypeError, ValueError):
        return str(dtype)


def _values_equal(left, right):
    if left is right:
        return True
    if left is None or right is None:
        return False
    if isinstance(left, np.generic):
        left = left.item()
    if isinstance(right, np.generic):
        right = right.item()
    if isinstance(left, np.ndarray) or isinstance(right, np.ndarray):
        # ndarray 不能直接作为 bool 判断；shape 或 dtype 不同也应视为 IO 属性变化。
        try:
            left_array = np.asarray(left)
            right_array = np.asarray(right)
            if left_array.shape != right_array.shape or left_array.dtype != right_array.dtype:
                return False
            try:
                return bool(np.array_equal(left_array, right_array, equal_nan=True))
            except TypeError:
                return bool(np.array_equal(left_array, right_array))
        except (TypeError, ValueError):
            return False
    if isinstance(left, dict) and isinstance(right, dict):
        if left.keys() != right.keys():
            return False
        return all(_values_equal(left[key], right[key]) for key in left)
    if isinstance(left, (list, tuple)) and isinstance(right, (list, tuple)):
        if len(left) != len(right):
            return False
        return all(_values_equal(l_value, r_value) for l_value, r_value in zip(left, right))
    try:
        result = left == right
        if isinstance(result, np.ndarray):
            return bool(result.all())
        return bool(result)
    except (TypeError, ValueError):
        return False


def _format_value(value, max_items=8):
    # 默认值可能是大数组或嵌套结构，报告只展示有限元素，避免日志被模型数据淹没。
    if value is None:
        return 'None'
    if isinstance(value, np.dtype):
        return str(value)
    if isinstance(value, np.generic):
        return repr(value.item())
    if isinstance(value, np.ndarray):
        flat = value.reshape(-1)
        shown = flat[:max_items].tolist()
        suffix = ', ...' if flat.size > max_items else ''
        return 'ndarray(shape={}, dtype={}, values=[{}{}])'.format(
            value.shape,
            value.dtype,
            ', '.join(repr(item) for item in shown),
            suffix,
        )
    if isinstance(value, dict):
        items = list(value.items())
        shown = items[:max_items]
        suffix = ', ...' if len(items) > max_items else ''
        return '{{{}{}}}'.format(
            ', '.join('{}: {}'.format(repr(key), _format_value(item, max_items)) for key, item in shown),
            suffix,
        )
    if isinstance(value, (list, tuple)):
        shown = value[:max_items]
        suffix = ', ...' if len(value) > max_items else ''
        left, right = ('[', ']') if isinstance(value, list) else ('(', ')')
        return '{}{}{}{}'.format(
            left,
            ', '.join(_format_value(item, max_items) for item in shown),
            suffix,
            right,
        )
    if isinstance(value, bytes):
        return 'bytes(length={})'.format(len(value))
    if isinstance(value, (str, int, float, bool)):
        rendered = repr(value)
        return rendered if len(rendered) <= 160 else rendered[:157] + '...'
    return '<{}>'.format(type(value).__name__)


def _sort_io_names(names, io_infos):
    def _sort_key(name):
        info = io_infos[name]
        is_output = 0 if info.io_type.startswith('input') else 1
        index = info.idx_at_full_model
        return (is_output, index is None, index if index is not None else 0, name)

    return sorted(names, key=_sort_key)


def _format_io_info(name, info, indent='  '):
    direction = 'input' if info.io_type.startswith('input') else 'output'
    index = info.idx_at_full_model if info.idx_at_full_model is not None else '?'
    lines = ['{}[{}-{}] {}'.format(indent, direction, index, name)]
    # 最终清单用于排查实际 IO 状态，完整展示每个有值的 IO_info 字段。
    field_width = max(len(field) for field in IO_info._fields)
    for field in IO_info._fields:
        value = getattr(info, field)
        if value is not None:
            lines.append(
                '{}  {:<{}} = {}'.format(
                    indent,
                    field,
                    field_width,
                    _format_value(value),
                )
            )
    return lines


def _format_io_summary(name, info, status):
    # 对照表只保留最常用信息，完整属性统一放在报告底部，避免变化信息淹没重点。
    dtype = info.dtype if info.dtype is not None else info.src_dtype
    return '\n'.join([
        'name: {}'.format(name),
        'shape: {}'.format(_format_value(info.shape)),
        'dtype: {}'.format(dtype),
        'status: {}'.format(status),
    ])


def _color_report_cell(text, status):
    color = _REPORT_COLORS.get(status)
    if color is None:
        return text
    # 每行单独重置颜色，避免多行单元格的填充区和表格边框被连带着色。
    return '\n'.join(
        '{}{}{}'.format(color, line, _REPORT_COLOR_RESET)
        for line in text.splitlines()
    )


class IO_recorder():
    def __init__(self, ir):
        self.ir = ir
        # io_status_infos 保存已命名的阶段快照，last_info_dup 保存尚未 apply 的修改。
        self.io_status_infos = {}
        self.last_info_dup = None
        self.origin_io_infos = None

    def _create_last_info_dup(self):
        if self.last_info_dup is None:
            if len(self.io_status_infos) > 0:
                self.last_info_dup = copy.deepcopy(list(self.io_status_infos.values())[-1])
            else:
                self.last_info_dup = {}
        return

    def _get_cur_dict(self):
        cur_dict = self.last_info_dup
        if cur_dict is None:
            cur_dict = list(self.io_status_infos.values())[-1]
        return cur_dict

    def query_io_infos(self, args, key=None):
        # 目前暂时用不到
        rknnLog.e('current not support')
        return
        save_key = str(len(self.io_status_infos)) if key is None else key
        if len(self.io_status_infos) > 0:
            rknnLog.e('Only support query first infos')
        else:
            last_infos_key = None

        cur_infos = {}
        for i, _inp in enumerate(self.ir.inputs):
            _io_info = _wrap_io_info(name=_inp,
                                     io_type='input',
                                     idx_at_full_model=i,
                                     shape=self.ir.get_shape(_inp),
                                     src_dtype=self.ir.get_dtype(_inp),
                                     )
            cur_infos[_inp] = _io_info

        for i, _out in enumerate(self.ir.outputs):
            _io_info = _wrap_io_info(name=_inp,
                                     io_type='output',
                                     idx_at_full_model=i,
                                     shape=self.ir.get_shape(_inp),
                                     src_dtype=self.ir.get_dtype(_inp),
                                     )
            cur_infos[_out] = _io_info

        self.io_status_infos[save_key] = cur_infos
        return


    def add_input(self, name, io_type, idx_at_full_model, shape, src_dtype, value=None):
        if io_type not in ['input', 'input_generated', 'input_hidden']:
            rknnLog.e(f'{io_type} is not valid')
        self._create_last_info_dup()
        kwargs = {
            'name': name,
            'io_type': io_type,
            'idx_at_full_model': idx_at_full_model,
            'shape': shape,
            'src_dtype': src_dtype,
            'value': value,
        }
        new_inf = _wrap_io_info(**kwargs)
        self.last_info_dup[name] = new_inf
        return

    def add_output(self, name, io_type, idx_at_full_model, shape, src_dtype):
        if io_type not in ['output', 'output_useless', 'output_hidden']:
            rknnLog.e(f'{io_type} is not valid')
        self._create_last_info_dup()
        kwargs = {
            'name': name,
            'io_type': io_type,
            'idx_at_full_model': idx_at_full_model,
            'shape': shape,
            'src_dtype': src_dtype,
        }
        if io_type == 'output_useless':
            kwargs['removeable'] = True
        new_inf = _wrap_io_info(**kwargs)
        self.last_info_dup[name] = new_inf
        return

    def remove(self, names):
        self._create_last_info_dup()
        if isinstance(names, str):
            names = [names]
        names = set(names)

        # 收集被移除项的 idx_at_full_model，按 io_type 分类（输入/输出索引空间独立）
        removed_input_idxs = set()
        removed_output_idxs = set()
        valid_names = set()
        for _n in names:
            if _n not in self.last_info_dup:
                rknnLog.w("IO recorder remove non exist io, failed to remove")
                continue
            info = self.last_info_dup[_n]
            if info.idx_at_full_model is not None:
                if info.io_type.startswith('input'):
                    removed_input_idxs.add(info.idx_at_full_model)
                else:
                    removed_output_idxs.add(info.idx_at_full_model)
            valid_names.add(_n)

        # Pop 移除项
        for _n in valid_names:
            self.last_info_dup.pop(_n)

        # 后续项的 idx_at_full_model 前移（输入输出分开计算 shift）
        if removed_input_idxs or removed_output_idxs:
            for t_name in list(self.last_info_dup.keys()):
                io_info = self.last_info_dup[t_name]
                old_idx = io_info.idx_at_full_model
                if old_idx is not None:
                    # 根据 io_type 选择对应的 removed 集合
                    if io_info.io_type.startswith('input'):
                        removed_set = removed_input_idxs
                    else:
                        removed_set = removed_output_idxs
                    shift = sum(1 for r_idx in removed_set if r_idx < old_idx)
                    if shift > 0:
                        new_idx = old_idx - shift
                        msg = f"update 'idx_at_full_model' from '{old_idx}' to '{new_idx}' (after remove)"
                        history_msg = getattr(io_info, 'change_log')
                        if isinstance(history_msg, str):
                            msg = history_msg + '; ' + msg
                        self.last_info_dup[t_name] = io_info._replace(
                            idx_at_full_model=new_idx,
                            change_log=msg,
                        )
        return

    def apply_changes(self, key=None):
        if self.last_info_dup is None:
            rknnLog.w("Apply blank change, ignore!")
            return
        save_key = str(len(self.io_status_infos)) if key is None else key
        self.io_status_infos[save_key] = self.last_info_dup
        self.last_info_dup = None
        return

    def update(self, t_name, key, value, update_immediately=False, change_log_prefix='', change_record=True):
        if (not update_immediately) and (self.last_info_dup is None):
            self._create_last_info_dup()

        cur_dict = self._get_cur_dict()

        new_info = cur_dict[t_name]._replace(**{key: value})
        if change_record:
            msg = f"update '{key}' from '{getattr(cur_dict[t_name], key)}' to '{getattr(new_info, key)}'"
            if change_log_prefix:
                msg = change_log_prefix + '_' + msg
            history_msg = getattr(cur_dict[t_name], 'change_log')
            if isinstance(history_msg, str):
                msg = history_msg + '; ' + msg
            new_info = new_info._replace(**{'change_log': msg})
        cur_dict[t_name] = new_info

        return

    def update_infos(self, io_updates):
        if not isinstance(io_updates, dict):
            rknnLog.e("io_updates must be a dict")
        if not io_updates:
            return
        if self.last_info_dup is None and not self.io_status_infos:
            rknnLog.e("IO recorder has not been initialized")

        cur_dict = self._get_cur_dict()
        # 先校验整个批次再开始更新，避免后续字段报错时留下只改了一半的状态。
        for t_name, updates in io_updates.items():
            if t_name not in cur_dict:
                rknnLog.e("Update non-existent IO '{}'".format(t_name))
            if not isinstance(updates, dict):
                rknnLog.e("Updates for IO '{}' must be a dict".format(t_name))
            for key, value in updates.items():
                if key not in IO_info._fields:
                    rknnLog.e("Key '{}' is not supported for IO '{}'".format(key, t_name))
                if key == 'io_type' and value not in valid_io_type_key:
                    rknnLog.e("io_type only support {}, get {}".format(valid_io_type_key, value))

        for t_name, updates in io_updates.items():
            for key, value in updates.items():
                self.update(t_name, key, value)
        return

    def set_origin_infos(self, io_infos):
        # 原始 ONNX IO 是固定比较基准，只允许在 load 阶段设置一次。
        if not isinstance(io_infos, dict):
            rknnLog.e("Origin IO infos must be a dict")
        if self.origin_io_infos is not None:
            rknnLog.e("Origin IO infos have already been set")
        for t_name, io_info in io_infos.items():
            if not isinstance(t_name, str) or not isinstance(io_info, IO_info):
                rknnLog.e("Invalid origin IO info for '{}'".format(t_name))
        self.origin_io_infos = copy.deepcopy(io_infos)
        return

    def sync_with_ir(self, ir=None):
        if self.last_info_dup is None and not self.io_status_infos:
            rknnLog.e("IO recorder has not been initialized")
        ir = self.ir if ir is None else ir
        if ir is None:
            rknnLog.e("IR is required to synchronize IO infos")

        # 图优化和 rebuild 可能级联新增、删除 IO，最终以 IR 的实际输入输出为准，
        # 再把 recorder 的名称、顺序、shape 和 dtype 同步到相同状态。
        current_infos = self._get_cur_dict()
        actual_infos = {}
        for io_type, names in [('input', ir.inputs), ('output', ir.outputs)]:
            for index, name in enumerate(names):
                current_info = current_infos.get(name)
                current_type = current_info.io_type if current_info is not None else None
                # input_generated/output_useless 等类型带有业务语义；只要 IO 方向未变就保留。
                if current_type is not None and current_type.startswith(io_type):
                    actual_type = current_type
                else:
                    actual_type = io_type
                dtype = ir.get_dtype(name)
                actual_infos[name] = {
                    'io_type': actual_type,
                    'idx_at_full_model': index,
                    'shape': ir.get_shape(name),
                    'src_dtype': 'unknown' if dtype is None else _normalize_dtype(dtype),
                }

        removed_names = [name for name in current_infos if name not in actual_infos]
        added_names = [name for name in actual_infos if name not in current_infos]
        updates = {}
        for name in current_infos:
            if name not in actual_infos:
                continue
            field_updates = {}
            for field, actual_value in actual_infos[name].items():
                current_value = getattr(current_infos[name], field)
                if field == 'src_dtype':
                    is_equal = _normalize_dtype(current_value) == _normalize_dtype(actual_value)
                else:
                    is_equal = _values_equal(current_value, actual_value)
                if not is_equal:
                    field_updates[field] = actual_value
            if field_updates:
                updates[name] = field_updates

        if not (removed_names or added_names or updates):
            return False

        if removed_names:
            self.remove(removed_names)
        for name in added_names:
            info = actual_infos[name]
            if info['io_type'].startswith('input'):
                self.add_input(
                    name,
                    info['io_type'],
                    info['idx_at_full_model'],
                    info['shape'],
                    info['src_dtype'],
                )
            else:
                self.add_output(
                    name,
                    info['io_type'],
                    info['idx_at_full_model'],
                    info['shape'],
                    info['src_dtype'],
                )
        if updates:
            self.update_infos(updates)
        return True

    def query_latest_infos(self):
        if self.last_info_dup is not None:
            return self.last_info_dup
        return list(self.io_status_infos.values())[-1]

    def update_input_meta_with_last_info(self, input_metas):
        cur_dict = self._get_cur_dict()
        for t_name, io_info in cur_dict.items():
            cvt_meta = _cvt_io_info_to_input_meta(io_info)
            old_meta = copy.deepcopy(input_metas.get(t_name, {}))
            old_meta.update(cvt_meta)
            input_metas[t_name] = old_meta
        return input_metas

    def cvt_input_meta_to_io_info(self, input_meta):
        return _cvt_input_meta_to_io_info(input_meta)

    def cvt_io_info_to_input_meta(self, io_info):
        return _cvt_io_info_to_input_meta(io_info)

    def add_input_meta_as_io_info(self, key, input_meta):
        self._create_last_info_dup()
        self.last_info_dup[key] = _cvt_input_meta_to_io_info(input_meta)
        return

    def query_all_values(self):
        v_dict = {}
        cur_dict = self._get_cur_dict()
        for k, io_info in cur_dict.items():
            if io_info.value is not None:
                v_dict[k] = io_info.value
        return v_dict

    def _select_compare_infos(self, compare_mode):
        # last/init/origin 分别用于阶段调试、全流程变化和相对原始 ONNX 的用户报告。
        valid_compare_modes = ['last_status', 'init_status', 'origin_status']
        if compare_mode not in valid_compare_modes:
            rknnLog.e("compare_mode only support {}, get {}".format(valid_compare_modes, compare_mode))

        keys = list(self.io_status_infos.keys())
        cur_infos = self.query_latest_infos()
        cur_key = 'pending' if self.last_info_dup is not None else keys[-1]
        if compare_mode == 'origin_status':
            if self.origin_io_infos is None:
                rknnLog.e("Origin IO infos have not been recorded")
            return 'origin', self.origin_io_infos, cur_key, cur_infos
        if compare_mode == 'init_status':
            return keys[0], self.io_status_infos[keys[0]], cur_key, cur_infos

        if self.last_info_dup is not None:
            return keys[-1], self.io_status_infos[keys[-1]], cur_key, cur_infos
        if len(keys) > 1:
            return keys[-2], self.io_status_infos[keys[-2]], cur_key, cur_infos
        return 'empty', {}, cur_key, cur_infos

    def query_changes(self, compare_mode='last_status'):
        if not self.io_status_infos:
            return {
                'added': {},
                'removed': {},
                'changed': {},
                'unchanged': {},
                'previous_key': None,
                'current_key': None,
            }

        previous_key, previous_infos, current_key, current_infos = self._select_compare_infos(compare_mode)
        # 直接比较字段值而不是依赖 change_log，才能识别同步 IR 或删除 IO 产生的变化。
        compare_fields = [field for field in IO_info._fields if field != 'change_log']
        if compare_mode == 'origin_status':
            # 原始 ONNX 没有 removeable/default value 等 Toolkit 属性，只比较图本身可提供的字段。
            compare_fields = ['io_type', 'idx_at_full_model', 'shape', 'src_dtype']

        added = {}
        removed = {}
        changed = {}
        unchanged = {}
        all_names = set(previous_infos) | set(current_infos)
        for name in _sort_io_names(all_names, {**previous_infos, **current_infos}):
            if name not in previous_infos:
                added[name] = current_infos[name]
                continue
            if name not in current_infos:
                removed[name] = previous_infos[name]
                continue

            field_changes = {}
            previous_info = previous_infos[name]
            current_info = current_infos[name]
            for field in compare_fields:
                previous_value = getattr(previous_info, field)
                current_value = getattr(current_info, field)
                if field in ['dtype', 'src_dtype']:
                    is_equal = _normalize_dtype(previous_value) == _normalize_dtype(current_value)
                else:
                    is_equal = _values_equal(previous_value, current_value)
                if not is_equal:
                    field_changes[field] = (previous_value, current_value)

            if field_changes:
                changed[name] = field_changes
            else:
                unchanged[name] = current_info

        return {
            'added': added,
            'removed': removed,
            'changed': changed,
            'unchanged': unchanged,
            'previous_key': previous_key,
            'current_key': current_key,
        }

    def _format_current_infos(self):
        infos = self.query_latest_infos()
        key = 'pending' if self.last_info_dup is not None else list(self.io_status_infos.keys())[-1]
        lines = ['Current IO (stage: {})'.format(key)]
        for index, name in enumerate(_sort_io_names(infos.keys(), infos)):
            if index > 0:
                lines.append('')
            lines.extend(_format_io_info(name, infos[name]))
        return '\n'.join(lines)

    def _format_changes(self, compare_mode):
        changes = self.query_changes(compare_mode)
        lines = ['IO Changes ({} -> {})'.format(changes['previous_key'], changes['current_key'])]
        lines.append(
            '  summary: added={}, removed={}, changed={}, unchanged={}'.format(
                len(changes['added']),
                len(changes['removed']),
                len(changes['changed']),
                len(changes['unchanged']),
            )
        )

        _, previous_infos, _, current_infos = self._select_compare_infos(compare_mode)

        # old/new 按各自 ONNX IO 位置对齐。输入和输出的索引空间彼此独立，
        # 因此 idx 同时展示方向，避免把临时报告行号误认为模型中的真实索引。
        def _group_by_position(infos):
            positions = {}
            for name, info in infos.items():
                direction = 'input' if info.io_type.startswith('input') else 'output'
                position = (direction, info.idx_at_full_model)
                positions.setdefault(position, []).append((name, info))
            for items in positions.values():
                items.sort(key=lambda item: item[0])
            return positions

        def _position_sort_key(position):
            direction, index = position
            return (
                0 if direction == 'input' else 1,
                index is None,
                index if index is not None else 0,
            )

        def _status(name):
            if name in changes['added']:
                return 'added'
            if name in changes['removed']:
                return 'removed'
            if name in changes['changed']:
                return 'changed'
            return 'unchanged'

        previous_positions = _group_by_position(previous_infos)
        current_positions = _group_by_position(current_infos)
        positions = set(previous_positions) | set(current_positions)
        table_rows = {}
        for direction in ['input', 'output']:
            rows = []
            direction_positions = [
                position for position in positions
                if position[0] == direction
            ]
            for _, index in sorted(direction_positions, key=_position_sort_key):
                old_items = previous_positions.get((direction, index), [])
                new_items = current_positions.get((direction, index), [])
                for offset in range(max(len(old_items), len(new_items))):
                    old = '-'
                    if offset < len(old_items):
                        old_name, old_info = old_items[offset]
                        old_status = _status(old_name)
                        old = _color_report_cell(
                            _format_io_summary(old_name, old_info, old_status),
                            old_status,
                        )

                    new = '-'
                    if offset < len(new_items):
                        new_name, new_info = new_items[offset]
                        new_status = _status(new_name)
                        new = _color_report_cell(
                            _format_io_summary(new_name, new_info, new_status),
                            new_status,
                        )

                    rows.append([
                        '?' if index is None else index,
                        old,
                        new,
                    ])

            table_rows[direction] = rows

        # input/output 分表仍使用同一组列宽，便于上下对照。宽度计算需忽略
        # 单元格内的 ANSI 颜色码，否则彩色列会被错误撑宽。
        headers = {
            direction: ['{}_idx'.format(direction), 'old', 'new']
            for direction in ['input', 'output']
        }

        def _visible_width(value):
            text = str(value)
            for color in _REPORT_COLORS.values():
                text = text.replace(color, '')
            text = text.replace(_REPORT_COLOR_RESET, '')
            return max([len(line) for line in text.splitlines()] or [0])

        column_widths = []
        for column in range(3):
            widths = [
                len(headers[direction][column])
                for direction in ['input', 'output']
            ]
            widths.extend(
                _visible_width(row[column])
                for direction in ['input', 'output']
                for row in table_rows[direction]
            )
            column_widths.append(max(widths))

        for direction in ['input', 'output']:
            padded_headers = [
                header.ljust(column_widths[column])
                for column, header in enumerate(headers[direction])
            ]
            lines.append(
                tabulate(
                    table_rows[direction],
                    headers=padded_headers,
                    tablefmt='grid',
                )
            )
            if direction == 'input':
                lines.append('')
        return '\n'.join(lines)

    def format_report(self, report_mode='all', compare_mode='last_status'):
        # report_mode 控制输出最终 IO、变化明细或两者；compare_mode 控制变化的基准快照。
        valid_report_modes = ['io', 'changes', 'all']
        if report_mode not in valid_report_modes:
            rknnLog.e("report_mode only support {}, get {}".format(valid_report_modes, report_mode))
        valid_compare_modes = ['last_status', 'init_status', 'origin_status']
        if report_mode in ['changes', 'all'] and compare_mode not in valid_compare_modes:
            rknnLog.e("compare_mode only support {}, get {}".format(valid_compare_modes, compare_mode))
        if not self.io_status_infos:
            return 'No IO information recorded.'

        sections = []
        if report_mode in ['changes', 'all']:
            sections.append(self._format_changes(compare_mode))
        if report_mode in ['io', 'all']:
            sections.append(self._format_current_infos())
        return '\n\n'.join(sections)

    def report(self, report_mode='all', compare_mode='last_status'):
        report_text = self.format_report(report_mode, compare_mode)
        # 统一走项目日志模块，使控制台和 verbose_file 中的输出行为保持一致。
        rknnLog.i(report_text)
        return report_text

    def report_changes(self, compare_mode='last_status'):
        return self.report(report_mode='changes', compare_mode=compare_mode)
