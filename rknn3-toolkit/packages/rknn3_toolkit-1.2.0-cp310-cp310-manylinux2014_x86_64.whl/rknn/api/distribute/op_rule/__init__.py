import numpy as np

from rknn.api.distribute.tensor_dist_utils import _distribute_dim
from rknn.api.ir_graph import ACTIVATION_OPS
from rknn.api.rknn_log import RKNNLog
from ..basic_definition import T_distribute_status, _wrap_tensor_dist, OP_distribute, _warp_op_dist

from .conv_d import Conv_dist
from .reshape_d import Reshape_dist
from .exsdpattention_d import exSDPAttention_dist
from .mul_d import Mul_dist
from .gather_d import Gather_dist
from .slice_d import Slice_dist
from .add_d import Add_dist
from .transpose_d import Transpose_dist
from .exmatmul_d import exMatMul_dist
from .bn_d import BatchNormalization_dist
from .exnorm_d import exNorm_dist
from .exattention_d import exAttention_dist
exPagedAttention_dist = exAttention_dist
from .pool_d import Pool_dist
from .exwindow_d import exWindow_dist
from .pad_d import Pad_dist
from .convtranspose_d import ConvTranspose_dist
# from .resize_d import Resize_dist
from .exrope_d import exRoPE_dist
from .exsum_d import exSum_dist
from .exlinearattention_d import exLinearAttention_dist
from .exmoeffn_d import exMoEFFN_dist

exConvStreaming_dist = Conv_dist

class OP_dist_passthrough:
    # 适用于单输入单输出 passthrough op
    op_type = [t for t in ACTIVATION_OPS if t.lower() not in ['exglu', 'glu', 'clip', 'prelu']]
    op_type += ['Abs', 'Acos', 'Acosh', 'Asin', 'Asinh', 'Atan', 'Atanh',
                'Cast', 'Ceil', 'Celu', 'Cos', 'Cosh',
                'Elu', 'Erf', 'Exp', 'Log', 'Neg', 'NonZero', 'Not',
                'Reciprocal', 'Sign', 'Sin', 'Sinh', 'Sqrt', 'Tan', 'Tanh']
    def _transmit(ir, node, in_shapes, out_shapes, in_dist, out_dist):
        if len(in_dist) > 1:
            RKNNLog.d(f"OP_dist_passthrough require single input, {node.op_type}:{node.name} meet {len(in_dist)}")
            return []
        base_d = in_dist[0] if in_dist[0] is not None else out_dist[0]
        if base_d is None or base_d.status in ['unsum', 'undefine']:
            return []
        return [_warp_op_dist(node, [base_d], [base_d])]

    def forward(ir, node, in_shapes, out_shapes, in_dist, out_dist):
        return OP_dist_passthrough._transmit(ir, node, in_shapes, out_shapes, in_dist, out_dist)

    def backward(ir, node, in_shapes, out_shapes, in_dist, out_dist):
        return OP_dist_passthrough._transmit(ir, node, in_shapes, out_shapes, in_dist, out_dist)


class OP_dist_multi_input:
    # 适用于多输入单输出的 passthrough op.
    op_type = ['Clip', 'Pow', 'PRelu',
               'And', 'Or', 'Xor', 'Equal', 'Greater', 'GreaterEqual', 'Where']
    def _transmit(ir, node, in_shapes, out_shapes, in_dist, out_dist):
        if len(in_dist) < 2:
            return []

        out_shape = out_shapes[0] if out_shapes else None
        if out_shape is None or any(s is None for s in in_shapes):
            return []

        # 收集所有非 None 的分布信息
        all_dists = [_ for _ in in_dist + out_dist if _ is not None]
        if not all_dists:
            return []

        # 优先选择与输出 shape 一致的输入作为 base_d
        base_d = None
        if out_shape is not None:
            for in_shape, in_d in zip(in_shapes, in_dist):
                if in_d is not None and in_shape == out_shape:
                    base_d = in_d
                    break

        if base_d is None:
            # 没有与输出 shape 一致的输入，尝试使用 split 类型的 dist
            split_ds = [d for d in all_dists if d.status == 'split']
            if split_ds:
                base_d = split_ds[0]
            elif len(set(all_dists)) == 1 and all_dists[0].status == 'unique':
                # 所有非 None dist 相同，任取一个
                base_d = all_dists[0]
            else:
                return []

        if base_d.status in ['unsum', 'undefine']:
            return []

        if base_d.status in ['unique', 'broadcast']:
            new_in_dist = [base_d]*len(node.input)
            new_out_dist = [base_d]*len(node.output)
            return [_warp_op_dist(node, new_in_dist, new_out_dist)]

        # split 状态的输入需要特殊处理
        new_in_dist = []
        new_out_dist = [base_d]
        for i, _in in enumerate(node.input):
            if in_shapes[i] == out_shape:
                # 输入与输出 shape 一致，直接使用 base_d
                new_in_dist.append(base_d)
            elif np.prod(in_shapes[i]) == 1:
                # 如果输入是单值
                new_in_dist.append(_wrap_tensor_dist('broadcast', base_d.core_assigned, base_d.core_used))
            else:
                if len(out_shape) != len(in_shapes[i]):
                    # 遇到不对齐的情况, 暂不处理
                    return []
                other_dist = base_d if in_shapes[i][base_d.axis] != 1 else _wrap_tensor_dist('broadcast', base_d.core_assigned, base_d.core_used)
                new_in_dist.append(other_dist)
        return [_warp_op_dist(node, new_in_dist, new_out_dist)]

    def forward(ir, node, in_shapes, out_shapes, in_dist, out_dist):
        return OP_dist_multi_input._transmit(ir, node, in_shapes, out_shapes, in_dist, out_dist)

    def backward(ir, node, in_shapes, out_shapes, in_dist, out_dist):
        return OP_dist_multi_input._transmit(ir, node, in_shapes, out_shapes, in_dist, out_dist)


class OP_dist_axis:
    # 适用于带有 axis 的常规 op
    op_type = ['Concat', 'Split', 'exSoftmax13', 'Softmax']         # TODO add - 'TopK'
    def _transmit(ir, node, in_shapes, out_shapes, in_dist, out_dist):
        base_d = [_ for _ in in_dist + out_dist if _ is not None]
        if not base_d:
            return []
        base_d = base_d[0]

        if node.op_type in ['Softmax', 'exSoftmax13'] and base_d.status in ['unsum', 'undefine']:
            # Softmax 不能在部分和或改写后的常量上直接计算。
            return []
        if base_d.status == 'split':
            if not in_shapes or not in_shapes[0]:
                return []
            rank = len(in_shapes[0])
            axis = ir.get_attr(node, 'axis')
            if axis is None:
                return []
            axis = axis + rank if axis < 0 else axis
            if axis < 0 or axis >= rank or base_d.axis == axis:
                return []
            if node.op_type == 'Softmax' and ir.opset < 13 and base_d.axis >= axis:
                # 旧版 Softmax 将 axis 及其后面的维度展平后一起归一化。
                return []
        if node.op_type == 'Concat':
            in_status = set([_.status if _ is not None else None for _ in in_dist])
            if 'unsum' in set(in_status) and len(in_status) > 1:
                # concat 的 unsum 输入不能把其他输入也变成 unsum
                return []

        if node.op_type == 'Split' and any([len(ir.next_nodes(_out))==0 and _out not in ir.outputs for _out in node.output]):
            # 悬空 split 输出会导致 mpi 节点异常，此时 fallback 会单个节点。
            return []

        new_in_dist = [base_d]*len(node.input)
        new_out_dist = [base_d]*len(node.output)
        if node.op_type == 'Split' and len(node.input) > 1:
            new_in_dist[1:] = [_wrap_tensor_dist('broadcast', base_d.core_assigned, base_d.core_used)] * (len(node.input) - 1)
        return [_warp_op_dist(node, new_in_dist, new_out_dist)]

    def forward(ir, node, in_shapes, out_shapes, in_dist, out_dist):
        return OP_dist_axis._transmit(ir, node, in_shapes, out_shapes, in_dist, out_dist)

    def backward(ir, node, in_shapes, out_shapes, in_dist, out_dist):
        return OP_dist_axis._transmit(ir, node, in_shapes, out_shapes, in_dist, out_dist)

    @staticmethod
    def gen_dist(ir, node, in_shapes, out_shapes, device_num):
        candidate = []
        if device_num <= 1 or not out_shapes or not out_shapes[0]:
            return candidate
        for i, dim in enumerate(out_shapes[0]):
            if not isinstance(dim, (int, np.integer)) or dim <= 1:
                continue
            out_dist = _wrap_tensor_dist('split', device_num, None, *_distribute_dim(dim, device_num), i)
            candidate.extend(OP_dist_axis._transmit(
                ir, node, in_shapes, out_shapes, [None]*len(in_shapes), [out_dist]*len(out_shapes)))
        return candidate


OP_dist_map = {k:v for k, v in locals().items() if k.endswith('_dist')}
for _general_dist in [OP_dist_passthrough, OP_dist_multi_input, OP_dist_axis, Mul_dist, Add_dist, Pool_dist]:
    for _op_type in _general_dist.op_type:
        OP_dist_map[_op_type + '_dist'] = _general_dist
