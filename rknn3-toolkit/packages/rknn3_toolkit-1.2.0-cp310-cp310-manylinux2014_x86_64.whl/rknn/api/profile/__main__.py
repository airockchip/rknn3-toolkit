#!/usr/bin/env python3
import argparse

from rknn.utils._profile_log import profile_with_cache_model

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="RKNN Profile")
    parser.add_argument("--cache_file", type=str, help="cache file path", required=True)
    parser.add_argument("--prefill_len", type=int, help="prefill length", required=True)
    parser.add_argument("--generate_len", type=int, help="generate length", required=True)
    parser.add_argument("--max_ctx_len", type=int, help="max context length", required=False, default=None)

    args = parser.parse_args()

    profile_with_cache_model(args.cache_file, args.prefill_len, args.generate_len, args.max_ctx_len)
    print("Profile done")