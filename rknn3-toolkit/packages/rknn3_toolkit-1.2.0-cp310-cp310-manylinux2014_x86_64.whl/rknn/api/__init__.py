from rknn.api.rknn import RKNN, DEFAULT_RKNN_LLM_CONFIG_
from rknn.api.rknn_session import (
    RKLLMCallback,
    RKLLMResult,
    LLMCallState,
    LLMResultCallback,
    LLMGetEmbedCallback,
    LLMSamplingCallback,
    LLMTokenizerCallback,
    LLMGetLastHiddenLayerCallback,
    RKLLMResultLastHiddenLayer,
)
from rknn.api.rknn_float16 import Float16, Float32, fp32_to_fp16, fp16_to_fp32

import copy
DEFAULT_RKNN_LLM_CONFIG = copy.deepcopy(DEFAULT_RKNN_LLM_CONFIG_)
del DEFAULT_RKNN_LLM_CONFIG['attention_config'][0]['kvcache_store_method']
del DEFAULT_RKNN_LLM_CONFIG['attention_config'][0]['kvcache_group_size']
del DEFAULT_RKNN_LLM_CONFIG['attention_config'][0]['kvcache_residual_depth']
del DEFAULT_RKNN_LLM_CONFIG_