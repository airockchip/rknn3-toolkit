from .rknn_llm_base import RKNN_LLM_Base


class RKNN_LLM:
    def __init__(self, rknn_base):
        self.rknn_llm_base = RKNN_LLM_Base(rknn_base)

    def inference(self, token_ids, embeds, args, callback=None, embed_path=None):
        """
        LLM Inference.
        Only one of token_ids or embeds can be provided as input.
        :param token_ids: Input token ids ndarray.
        :param embeds: Input embeds ndarray.
        :param args: Inference args dict. Include max_new_token, top_k, top_p, temperature, do_sample, repetition_penalty.
        :param callback: Target inference callback.
        :param embed_path: LLM Model embed_path in target inference callback.
        :return: Token id results list
        """

        return self.rknn_llm_base.inference(token_ids, embeds, args, callback, embed_path)

    def get_token_embeds(self, input_ids):
        """
        Get the embeddings output for token ids.
        :param input_ids: Input token ids ndarray.
        :return: Embeddings ndarray.
        """

        return self.rknn_llm_base.get_token_embeds(input_ids)
