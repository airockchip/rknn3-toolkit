import argparse
import copy
import gc
import json
import os
import sys
import tempfile
import time
from contextlib import contextmanager
from typing import Iterator

import numpy as np
import onnx
import torch
import onnxruntime as ort

# Allow ``python rknn/base/gpu/convert_onnx_to_torch.py`` from a source tree,
# while remaining a no-op when imported as ``rknn.base.gpu...``.
_REPO_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(
    os.path.abspath(__file__)))))
if _REPO_ROOT not in sys.path:
    sys.path.insert(0, _REPO_ROOT)

try:
    from torch.profiler import ProfilerActivity, profile as torch_profile
except Exception:
    ProfilerActivity = None
    torch_profile = None

from rknn.base.gpu.backend_config import BackendConfig
from rknn.base.gpu.constants import (
    DEFAULT_BACKEND,
    DEFAULT_BASELINE_COS_THRESHOLD,
    DEFAULT_INPUT_SHAPE,
    DEFAULT_OPSET_VERSION,
    DEFAULT_SHARD_BYTES,
    DEFAULT_STATE_INPUT_MODE,
    DEFAULT_STATE_INPUT_SEED,
    DEFAULT_TORCH_PROFILE_ROW_LIMIT,
    DEFAULT_WEIGHT_FORMAT,
    as_output_sequence,
    cast_floating_inputs,
    infer_model_device,
    instantiate_model_from_state_dict,
    move_to_device,
    to_torch,
)
from rknn.api.onnx_torch_codegen import (
    load_generated_module,
    load_model_from_weight_store,
)
from rknn.base.gpu.onnx_torch_codegen import (
    CODEGEN_FINGERPRINT,
    CUSTOM_OP_TYPES,
    collect_required_initializers,
    collect_lora_weight_names,
    get_const_map,
    get_shape_map,
    materialize_missing_initializers,
    remove_initializers_from_inputs,
    restore_check_weights,
    sanitize_name,
    save_onnx_to_torch,
)

def _shape_from_value_info(value_info):
    dims = []
    for dim in value_info.type.tensor_type.shape.dim:
        if dim.HasField("dim_value"):
            dims.append(dim.dim_value)
        elif dim.HasField("dim_param"):
            dims.append(dim.dim_param)
        else:
            dims.append(None)
    return dims


def parse_args():
    parser = argparse.ArgumentParser(description="Convert ONNX to torch python, then export back to ONNX.")
    parser.add_argument("--model", default="models/examples/exattention.onnx", help="Input ONNX model path.")
    parser.add_argument("--generated-py", default="model_generated.py", help="Generated python file path.")
    parser.add_argument("--generated-onnx", default="model_generated.onnx", help="Regenerated ONNX file path.")
    parser.add_argument(
        "--artifacts-dir",
        default="models/generated",
        help="Directory for generated artifacts. Relative output paths are written under this directory.",
    )
    parser.add_argument(
        "--input-shape",
        default=",".join(str(d) for d in DEFAULT_INPUT_SHAPE),
        help="Fake input shape for the first non-initializer ONNX input, format like 1,3,640,640.",
    )
    parser.add_argument("--opset-version", type=int, default=DEFAULT_OPSET_VERSION, help="Opset version for torch.onnx.export.")
    parser.add_argument(
        "--no-preserve",
        action="store_true",
        help="未量化/量化模型统一关闭默认 preserve (展开 ex* 导出标准 onnx)。"
             "未量化与量化模型默认都保留 ex*; 传此参数任一类型模型都导出标准 onnx。",
    )
    parser.add_argument(
        "--reuse-artifacts",
        default=None,
        metavar="DIR",
        help="Reuse an existing generated.py + generated_weights (.pth/.npz/sharded) dir "
             "instead of regenerating code in the main flow. Equivalent to the old "
             "--pytorch-artifact-dir external-artifact usage; skip in-flow codegen.",
    )
    parser.add_argument(
        "--state-input-mode",
        choices=("legacy", "random"),
        default=DEFAULT_STATE_INPUT_MODE,
        help="How to generate fake state/control inputs (position_ids/Th/Tc/Ts/Tsr).",
    )
    parser.add_argument(
        "--state-input-seed",
        type=int,
        default=DEFAULT_STATE_INPUT_SEED,
        help="Seed used when --state-input-mode=random for reproducible fake state inputs.",
    )
    parser.add_argument(
        "--baseline-cos-threshold",
        type=float,
        default=DEFAULT_BASELINE_COS_THRESHOLD,
        help="Minimum cosine required for custom-domain baseline checks (PyTorch/Regenerated vs RKNN numpy base A).",
    )
    parser.add_argument(
        "--skip-regenerated-onnx",
        action="store_true",
        help="Skip exporting regenerated ONNX and skip all regenerated-ONNX runtime/model-compare steps.",
    )
    parser.add_argument(
        "--pytorch-artifact-dir",
        default=None,
        help="Optional pre-generated PyTorch artifact dir for Toolkit PyTorch Simulator (expects generated.py and generated_weights.pth).",
    )
    parser.add_argument(
        "--quant-json",
        default=None,
        help="Quantization params json (export_rknn 导出). When provided, the model is quantized: "
             "codegen uses quantized weights + scale/zp for QDQ simulation; the re-exported ONNX is a "
             "float operator graph and quantization stays in the separate manifest.",
    )
    parser.add_argument(
        "--input-preprocess-json",
        default=None,
        help="Input preprocessing metadata emitted from RKNN.config().",
    )
    parser.add_argument(
        "--lora-metadata-json",
        default=None,
        help="LoRA control metadata emitted by RKNN build for Torch codegen.",
    )
    parser.add_argument(
        "--quant-input-file",
        default=None,
        help="Quantized-model input image or .npy tensor (uint8/0-255) for CNN models; "
             "when omitted a distribution-matched synthetic input is generated.",
    )
    parser.add_argument(
        "--torch-profile",
        action="store_true",
        help="Enable torch.profiler analysis for Toolkit PyTorch Simulator and direct PyTorch forward.",
    )
    parser.add_argument(
        "--torch-profile-dir",
        default=None,
        help="Directory to save torch.profiler traces (default: <artifacts-dir>/torch_profile).",
    )
    parser.add_argument(
        "--torch-profile-row-limit",
        type=int,
        default=DEFAULT_TORCH_PROFILE_ROW_LIMIT,
        help="Max rows printed in torch.profiler summary tables.",
    )
    parser.add_argument(
        "--torch-profile-record-shapes",
        action="store_true",
        help="Enable record_shapes in torch.profiler.",
    )
    parser.add_argument(
        "--torch-profile-memory",
        action="store_true",
        help="Enable profile_memory in torch.profiler.",
    )
    parser.add_argument(
        "--torch-profile-with-stack",
        action="store_true",
        help="Enable with_stack in torch.profiler (more overhead).",
    )
    parser.add_argument(
        "--run-pytorch-accuracy-analysis",
        action="store_true",
        help="Run simulator_pytorch.accuracy_analysis and export analysis artifacts under artifacts-dir.",
    )
    parser.add_argument(
        "--pytorch-accuracy-dir",
        default=None,
        help="Output directory for simulator_pytorch accuracy-analysis artifacts (default: <artifacts-dir>/accuracy_analysis/pytorch_simulator).",
    )
    parser.add_argument(
        "--artifact-fast-mode",
        action="store_true",
        help="Fast benchmark mode: keep only PyTorch vs Toolkit ONNX Simulator and skip Original ONNX Base A/Toolkit PyTorch/custom-ops runtime branches.",
    )
    parser.add_argument(
        "--del-opt",
        action="store_true",
        help="Emit del statements in generated.py to release variables after their last "
             "consumer (node-level + block-level). Reduces forward peak memory for large "
             "D8C8-expanded models (e.g. qwen2.5_vl_llm_check5) at the cost of generated "
             "code readability. Mirrors gen_pytorch.py --del-opt.",
    )
    parser.add_argument(
        "--backend",
        choices=("auto", "torch_gpu", "torch_cpu", "onnxruntime"),
        default=DEFAULT_BACKEND,
        help="Backend for PyTorch/ORT execution. auto=detect CUDA, torch_gpu=force GPU, torch_cpu=force CPU, onnxruntime=ORT only.",
    )
    parser.add_argument(
        "--weight-format",
        choices=("pth", "npz"),
        default=DEFAULT_WEIGHT_FORMAT,
        help="Weight serialization format for generated_weights (default: pth). npz supports --shard-bytes sharding.",
    )
    parser.add_argument(
        "--shard-bytes",
        type=int,
        default=DEFAULT_SHARD_BYTES,
        help="Max bytes per npz shard file (0=no sharding, only affects npz format).",
    )
    return parser.parse_args()


def parse_input_shape(shape_str):
    return tuple(int(part.strip()) for part in shape_str.split(",") if part.strip())


def resolve_artifact_path(path, artifacts_dir):
    if os.path.isabs(path):
        return path
    return os.path.join(artifacts_dir, os.path.basename(path))


def resolve_model_path(path):
    if os.path.isabs(path) or os.path.exists(path):
        return path
    candidates = [
        os.path.join("models", "examples", os.path.basename(path)),
        os.path.join("models", "onnx_samples", os.path.basename(path)),
    ]
    for candidate in candidates:
        if os.path.exists(candidate):
            return candidate
    return path


def _real_input_value_infos(onnx_model):
    initializer_names = {init.name for init in onnx_model.graph.initializer}
    return [inp for inp in onnx_model.graph.input if inp.name not in initializer_names]


def _dim_to_int(dim):
    if dim.HasField("dim_value") and dim.dim_value > 0:
        return dim.dim_value
    return 1


def _onnx_elem_type_to_torch(elem_type):
    mapping = {
        onnx.TensorProto.FLOAT: torch.float32,
        onnx.TensorProto.FLOAT16: torch.float16,
        onnx.TensorProto.DOUBLE: torch.float64,
        onnx.TensorProto.INT8: torch.int8,
        onnx.TensorProto.INT16: torch.int16,
        onnx.TensorProto.INT32: torch.int32,
        onnx.TensorProto.INT64: torch.int64,
        onnx.TensorProto.UINT8: torch.uint8,
        onnx.TensorProto.BOOL: torch.bool,
    }
    return mapping.get(elem_type, torch.float32)


def _build_fake_input_from_value_info(
        value_info, default_main_shape=None, state_input_mode="legacy",
        state_rng=None, llm_seq_len: int | None = None, paged_tc=None):
    shape = [_dim_to_int(dim) for dim in value_info.type.tensor_type.shape.dim]
    if default_main_shape is not None and len(shape) == len(default_main_shape) and all(dim == 1 for dim in shape):
        shape = list(default_main_shape)
    dtype = _onnx_elem_type_to_torch(value_info.type.tensor_type.elem_type)
    name = value_info.name.lower()
    is_random_state = state_input_mode == "random"
    tc_default = default_main_shape[-1] if default_main_shape else 1

    if paged_tc is not None and dtype in (
            torch.int8, torch.int16, torch.int32, torch.int64, torch.uint8):
        if len(shape) != 2 or shape[1] != 9:
            raise ValueError("exPagedAttention control_variables must have shape [request_num, 9]")
        control = torch.zeros(shape, dtype=dtype)
        control[:, 1] = 1 if shape[0] > 1 else paged_tc
        control[:, 4] = -1 if dtype != torch.uint8 else 0
        control[:, 8] = 1
        return control

    # A full LLM prefill needs mutually consistent sequence controls. The
    # independent rank-1 defaults below otherwise set Tc=1 and gather index=1
    # even when input_embeds contains many valid tokens, giving a misleading
    # quantized simulator comparison and tracing a decoder-like ONNX graph.
    if llm_seq_len is not None:
        if name in ("attention_mask", "position_ids") and len(shape) == 2 \
                and shape[1] == 1:
            shape[1] = llm_seq_len
        if name == "num_logits_to_keep":
            return torch.full(
                shape, max(llm_seq_len - 1, 0), dtype=dtype)
        if name == "position_ids" and len(shape) == 2:
            return torch.arange(shape[1], dtype=dtype).unsqueeze(0).expand(
                shape[0], -1)
        if name == "tc":
            return torch.full(shape, llm_seq_len, dtype=dtype)

    if name == "attention_mask":
        return torch.ones(shape, dtype=dtype)

    if name == "num_logits_to_keep":
        return torch.ones(shape, dtype=dtype)

    if name in ("rope_cos_cache", "rope_sin_cache"):
        # 真实 RoPE 位置编码表 (替代随机输入): exRoPE 布局 [1, head_dim/2, 1, max_pos],
        # cos_[i, pos] = cos(pos / 10000^(2i/head_dim)), 与主流 rotary embedding 一致。
        # 确定性输入, 避免随机 rope 放大 LLM attention 层差异 (logits cos 波动)。
        try:
            half_dim, max_pos = shape[1], shape[-1]
            head_dim = half_dim * 2
            inv_freq = 1.0 / (10000.0 ** (torch.arange(0, head_dim, 2, dtype=torch.float32) / head_dim))
            pos = torch.arange(max_pos, dtype=torch.float32)
            angles = pos[:, None] * inv_freq[None, :]          # [max_pos, half_dim]
            table = torch.cos(angles) if name == "rope_cos_cache" else torch.sin(angles)
            return table.t().reshape(1, half_dim, 1, max_pos).to(dtype=dtype)
        except Exception:
            pass  # shape 异常回退随机输入

    if is_random_state and state_rng is not None:
        if name == "position_ids":
            # Keep random mode numerically safe for downstream Gather-like indices.
            # Use a small non-negative range to avoid generating out-of-bound negatives
            # after graph arithmetic (e.g. position/state offset subtraction).
            high = 1
            return torch.randint(0, high, shape, dtype=dtype)
        if name == "th":
            return torch.zeros(shape, dtype=dtype)
        if name == "tc":
            return torch.ones(shape, dtype=dtype)
        if name in ("ts", "tsr"):
            return torch.zeros(shape, dtype=dtype)

    if dtype == torch.bool:
        return torch.zeros(shape, dtype=dtype)
    if dtype in (torch.int8, torch.int16, torch.int32, torch.int64, torch.uint8):
        if len(shape) == 1 and shape[0] == 1:
            # linear attention 的 token count (Linear_Tc / Conv_streaming_Tc):
            # 本次推理有效 token 数 = 输入序列长度 (default_main_shape[1]).
            # 之前生成 0 会导致 exLinearAttention 的 tc mask (positions<tc) 全零,
            # torch 输出被清零, 而 check6 numpy 对 tc<=1 不清零 (q_0.8b linear
            # attention fake 输出全零实测)。旧 KV cache 的 "tc" 语义 (main_shape
            # 末维) 保持不变。
            if name in ("linear_tc", "conv_streaming_tc"):
                _seq = default_main_shape[1] if (default_main_shape and len(default_main_shape) >= 2) else 1
                return torch.tensor([_seq], dtype=dtype)
            if name in ("tc",):
                return torch.tensor([tc_default], dtype=dtype)
            if name in ("th", "ts", "tsr"):
                return torch.tensor([0], dtype=dtype)
        return torch.zeros(shape, dtype=dtype)
    # 主输入 (如 LLM input_embeds / CNN 图像) 用 state_rng 固定 seed 生成:
    # 否则每次 torch.randn 全局随机, 同一模型的 sim verify cos 随输入波动
    # (0.8b 实测 0.9909/0.9943/0.9946), 无法复现与比较。state_input_seed
    # 默认 0, 传入不同 seed 可换一组可复现输入。
    return torch.randn(*shape, dtype=dtype, generator=state_rng)


def build_fake_inputs(onnx_model, input_shape_override=None, state_input_mode="legacy", state_input_seed=0, device=None):
    real_inputs = _real_input_value_infos(onnx_model)
    paged_controls = {
        node.input[-1]: node.input[0] for node in onnx_model.graph.node
        if node.op_type == "exPagedAttention" and node.input
    }
    shape_map = get_shape_map(onnx_model) if paged_controls else {}
    default_main_shape = parse_input_shape(input_shape_override) if input_shape_override else None
    llm_seq_len = None
    if real_inputs and real_inputs[0].name.lower() == "input_embeds":
        declared_main_shape = [
            _dim_to_int(dim)
            for dim in real_inputs[0].type.tensor_type.shape.dim]
        # The CLI's historical default is a 4-D CNN shape.  Do not let that
        # unrelated default suppress LLM state derivation for a 3-D
        # ``input_embeds`` tensor.  A caller-provided compatible-rank override
        # still takes precedence for dynamic LLM fixtures.
        main_shape = (
            default_main_shape
            if (default_main_shape is not None
                and len(default_main_shape) == len(declared_main_shape))
            else declared_main_shape
        )
        if len(main_shape) == 3:
            llm_seq_len = int(main_shape[1])
    state_rng = torch.Generator()
    state_rng.manual_seed(int(state_input_seed))
    tensors = []
    for idx, value_info in enumerate(real_inputs):
        override = default_main_shape if idx == 0 else None
        t = _build_fake_input_from_value_info(
            value_info,
            default_main_shape=override,
            state_input_mode=state_input_mode,
            state_rng=state_rng,
            paged_tc=(
                max(1, int(shape_map.get(paged_controls[value_info.name], [1])[-1]))
                if value_info.name in paged_controls else None
            ),
            llm_seq_len=llm_seq_len,
        )
        # Move to specified device (unified backend control)
        if isinstance(t, torch.Tensor) and device is not None:
            t = t.to(device)
        tensors.append(t)
    return tensors


def _has_custom_domain(onnx_model):
    return any(node.domain or node.op_type in CUSTOM_OP_TYPES for node in onnx_model.graph.node)


def _as_output_sequence(output):
    # Delegate to constants.as_output_sequence (kept for backward-compatible calls).
    return as_output_sequence(output)


def _to_torch_tensor(output):
    # Delegate to constants.to_torch. Old behavior forced cpu; callers that need
    # cpu now pass device explicitly, but most callers relied on the cpu side
    # effect for .numpy() conversion, so keep forcing cpu here for safety.
    return to_torch(output, device=torch.device("cpu"))


def compare_output_sequences(lhs_name, lhs_output, rhs_name, rhs_output):
    lhs_outputs = _as_output_sequence(lhs_output)
    rhs_outputs = _as_output_sequence(rhs_output)

    if len(lhs_outputs) != len(rhs_outputs):
        print(
            "  WARNING: output count mismatch: {}={}, {}={}; compare the "
            "{} shared output(s)".format(
                lhs_name, len(lhs_outputs), rhs_name, len(rhs_outputs),
                min(len(lhs_outputs), len(rhs_outputs)),
            )
        )

    results = []
    for idx, (lhs_item, rhs_item) in enumerate(zip(lhs_outputs, rhs_outputs)):
        lhs_tensor = _to_torch_tensor(lhs_item)
        rhs_tensor = _to_torch_tensor(rhs_item)
        if lhs_tensor.shape != rhs_tensor.shape:
            print(
                "  WARNING: output[{}] shape mismatch for '{} vs {}': "
                "{} != {}".format(
                    idx, lhs_name, rhs_name,
                    tuple(lhs_tensor.shape), tuple(rhs_tensor.shape)))
            cos_value = float("nan")
            results.append(
                {
                    "index": idx,
                    "lhs_name": lhs_name,
                    "rhs_name": rhs_name,
                    "cosine": cos_value,
                    "lhs_first10": lhs_tensor.flatten()[:10],
                    "rhs_first10": rhs_tensor.flatten()[:10],
                }
            )
            continue
        lhs_compare = lhs_tensor.float()
        rhs_compare = rhs_tensor.float()
        if torch.equal(lhs_tensor, rhs_tensor):
            cos_value = 1.0
        else:
            cos_value = torch.nn.functional.cosine_similarity(
                lhs_compare.flatten(), rhs_compare.flatten(), dim=0
            ).item()
        results.append(
            {
                "index": idx,
                "lhs_name": lhs_name,
                "rhs_name": rhs_name,
                "cosine": cos_value,
                "lhs_first10": lhs_tensor.flatten()[:10],
                "rhs_first10": rhs_tensor.flatten()[:10],
            }
        )
    return results


def print_comparison_summary(results):
    grouped = {}
    for item in results:
        key = (item["lhs_name"], item["rhs_name"])
        grouped.setdefault(key, []).append(item)

    for (lhs_name, rhs_name), items in grouped.items():
        cosines = [float(entry.get("cosine", float("nan"))) for entry in items]
        finite_cosines = [value for value in cosines if np.isfinite(value)]
        if finite_cosines:
            min_cosine = min(finite_cosines)
            avg_cosine = sum(finite_cosines) / len(finite_cosines)
        else:
            min_cosine = float("nan")
            avg_cosine = float("nan")
        non_finite_count = len(cosines) - len(finite_cosines)
        conclusion = (
            "PASS" if non_finite_count == 0
            and np.isfinite(min_cosine) and min_cosine >= 0.99999
            else "CHECK")
        warning_prefix = "" if conclusion == "PASS" else "WARNING: "
        non_finite_warning = (
            " ({} NaN/Inf cosine output(s))".format(non_finite_count)
            if non_finite_count > 0 else "")
        print(
            "{}{} vs {}: outputs={} min_cosine={:.8f} "
            "avg_cosine={:.8f} conclusion={}{}".format(
                warning_prefix,
                lhs_name,
                rhs_name,
                len(items),
                min_cosine,
                avg_cosine,
                conclusion,
                non_finite_warning,
            )
        )


def print_timing_profile(profile, total_elapsed, indent="    "):
    if not profile:
        return

    if total_elapsed is None:
        total_elapsed = float(profile.get("total_elapsed", float("nan")))

    aggregate_fields = [
        ("model_ready_elapsed", "model_ready"),
        ("total_elapsed", "total"),
    ]
    detail_fields = [
        ("session_prepare_elapsed", "session_prepare"),
        ("model_prep_elapsed", "model_prep"),
        ("model_prep_shape_elapsed", "model_prep_shape"),
        ("model_prep_const_elapsed", "model_prep_const"),
        ("disk_codegen_elapsed", "disk_codegen"),
        ("codegen_elapsed", "in_memory_codegen"),
        ("exec_build_elapsed", "exec_build"),
        ("load_state_dict_elapsed", "load_state_dict"),
        ("artifact_load_elapsed", "artifact_load"),
        ("model_to_device_elapsed", "model_to_device"),
        ("inputs_prepare_elapsed", "inputs_prepare"),
        ("session_execute_elapsed", "session_execute"),
        ("output_collect_elapsed", "output_collect"),
        ("free_intermediate_elapsed", "free_intermediate"),
        ("output_order_elapsed", "output_order"),
        ("inputs_transfer_elapsed", "inputs_transfer"),
        ("forward_elapsed", "forward"),
        ("output_convert_elapsed", "output_convert"),
    ]

    printed_details = []
    for key, label in aggregate_fields:
        value = profile.get(key)
        if value is None:
            continue
        value = float(value)
        print("{}{}={:.4f}s".format(indent, label, value))

    for key, label in detail_fields:
        value = profile.get(key)
        if value is None:
            continue
        value = float(value)
        printed_details.append((label, value))

    if not printed_details:
        return

    detail_sum = sum(value for _, value in printed_details)
    if np.isfinite(total_elapsed):
        remainder = total_elapsed - detail_sum
    else:
        remainder = float("nan")

    for label, value in printed_details:
        pct = (value / total_elapsed * 100.0) if np.isfinite(total_elapsed) and total_elapsed > 0 else float("nan")
        print("{}{}={:.4f}s ({:.1f}%)".format(indent, label, value, pct))

    largest_label, largest_value = max(printed_details, key=lambda item: item[1])
    largest_pct = (largest_value / total_elapsed * 100.0) if np.isfinite(total_elapsed) and total_elapsed > 0 else float("nan")
    print("{}detail_sum={:.4f}s".format(indent, detail_sum))
    print("{}other_overhead={:.4f}s".format(indent, remainder))
    print("{}largest_detailed_stage={} ({:.4f}s, {:.1f}%)".format(indent, largest_label, largest_value, largest_pct))


def _warn_min_cosine(results, lhs_name, rhs_name, min_cosine, check_name="baseline"):
    """cos 低于阈值时打印 warning 而非中断。

    用户在 torch 代码中加/改 op 后, 回导/forward 输出与原始图必然不同,
    cos 低于阈值是预期行为, 不应阻断回导 (回导验证以 simulator 量化推理
    对比为准, 见 _verify_quant_simulator)。阈值/配对缺失同样降级 warning。
    """
    matched = [
        item for item in results
        if item.get("lhs_name") == lhs_name and item.get("rhs_name") == rhs_name
    ]
    if not matched:
        print(
            "  WARNING: missing comparison pair '{} vs {}' for {} consistency check (skipped)".format(
                lhs_name, rhs_name, check_name
            )
        )
        return
    bad = [
        item for item in matched
        if not np.isfinite(float(item.get("cosine", float("nan"))))
        or float(item.get("cosine", -1.0)) < float(min_cosine)
    ]
    if bad:
        non_finite_count = sum(
            not np.isfinite(float(item.get("cosine", float("nan"))))
            for item in bad)
        bad_cosines = [
            float(item.get("cosine", float("nan")))
            for item in bad
            if np.isfinite(float(item.get("cosine", float("nan"))))
        ]
        bad_min = min(bad_cosines) if bad_cosines else float("nan")
        print(
            "  WARNING: {} consistency check for '{} vs {}': {} output(s) "
            "below cosine {}, {} output(s) contain NaN/Inf cosine; finite "
            "minimum={} (editing forward/ONNX or fake-quantization drift may "
            "cause this difference)".format(
                check_name,
                lhs_name,
                rhs_name,
                len(bad) - non_finite_count,
                float(min_cosine),
                non_finite_count,
                bad_min,
            )
        )


def _is_ort_cuda_allocation_error(exc):
    message = str(exc).lower()
    return (
        "failed to allocate memory" in message
        or "bfcarena::allocaterawinternal" in message
        or "cuda out of memory" in message
        or ("onnxruntimeerror" in message and "allocate memory" in message)
    )


def _is_invalid_scatternd_index_error(exc):
    message = str(exc).lower()
    return "scatternd" in message and ("invalid indice" in message or "invalid index" in message)


def _is_invalid_gather_index_error(exc):
    message = str(exc).lower()
    return "gather" in message and "indices element out of data bounds" in message


def _normalize_scatternd_indices(indices, data_shape):
    if indices is None:
        return None, False
    arr = np.asarray(indices)
    if arr.ndim == 0 or arr.size == 0:
        return arr, False
    if arr.shape[-1] > len(data_shape):
        return arr, False

    normalized = arr.astype(np.int64, copy=True)
    changed = False
    for axis, dim in enumerate(data_shape[: arr.shape[-1]]):
        dim = int(dim)
        if dim <= 0:
            continue
        axis_values = normalized[..., axis]
        axis_normalized = np.mod(axis_values, dim)
        if not np.array_equal(axis_values, axis_normalized):
            changed = True
            normalized[..., axis] = axis_normalized

    if not changed:
        return arr, False
    return normalized.astype(arr.dtype, copy=False), True


def _normalize_irgraph_scatternd_indices(ir):
    normalized_count = 0
    for node in ir.model.graph.node:
        if node.op_type != "ScatterND":
            continue
        data_shape = ir.get_shape(node.input[0])
        indices = ir.get_const(node.input[1])
        if indices is None or not data_shape:
            continue
        normalized, changed = _normalize_scatternd_indices(indices, data_shape)
        if not changed:
            continue
        ir.set_const(node.input[1], normalized)
        normalized_count += 1
    return normalized_count


def _node_attr_int(node, attr_name, default):
    for attr in node.attribute:
        if attr.name != attr_name:
            continue
        value = onnx.helper.get_attribute_value(attr)
        try:
            return int(value)
        except Exception:
            return int(default)
    return int(default)


def _normalize_gather_indices(indices, axis_dim):
    if indices is None:
        return None, False
    arr = np.asarray(indices)
    if arr.size == 0:
        return arr, False
    axis_dim = int(axis_dim)
    if axis_dim <= 0:
        return arr, False
    normalized = np.mod(arr.astype(np.int64, copy=False), axis_dim)
    if np.array_equal(arr, normalized):
        return arr, False
    return normalized.astype(arr.dtype, copy=False), True


def _normalize_irgraph_gather_indices(ir):
    normalized_count = 0
    for node in ir.model.graph.node:
        if node.op_type != "Gather":
            continue
        if len(node.input) < 2:
            continue
        indices = ir.get_const(node.input[1])
        data_shape = ir.get_shape(node.input[0])
        if indices is None or not data_shape:
            continue

        axis = _node_attr_int(node, "axis", 0)
        rank = len(data_shape)
        if rank == 0:
            continue
        if axis < 0:
            axis += rank
        if axis < 0 or axis >= rank:
            continue

        axis_dim = int(data_shape[axis])
        normalized, changed = _normalize_gather_indices(indices, axis_dim)
        if not changed:
            continue
        ir.set_const(node.input[1], normalized)
        normalized_count += 1
    return normalized_count


def _sync_graph_input_consts_from_ir(name_to_value, ir):
    synced = dict(name_to_value)
    graph_input_names = {value_info.name for value_info in ir.model.graph.input}
    for name in graph_input_names:
        value = ir.get_const(name)
        if value is None:
            continue
        synced[name] = np.asarray(value)
    return synced


def run_onnxruntime(model_source, fake_inputs, custom_ops_so=None, model_label=None, providers_override=None, config=None):
    torch_to_numpy_dtype = {
        torch.float16: np.float16,
        torch.float32: np.float32,
        torch.float64: np.float64,
        torch.int8: np.int8,
        torch.int16: np.int16,
        torch.int32: np.int32,
        torch.int64: np.int64,
        torch.uint8: np.uint8,
        torch.bool: np.bool_,
    }

    session_options = ort.SessionOptions()
    session_options.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
    if custom_ops_so:
        so_path = os.path.abspath(custom_ops_so)
        if not os.path.exists(so_path):
            raise RuntimeError("Custom ops shared library not found: {}".format(so_path))
        session_options.register_custom_ops_library(so_path)
        print("Loaded custom ops library: {}".format(so_path))

    if providers_override is not None:
        providers = list(providers_override)
    elif config is not None:
        providers = config.ort_providers
    else:
        providers = ["CPUExecutionProvider"]
        available = ort.get_available_providers()
        if "CUDAExecutionProvider" in available:
            providers = ["CUDAExecutionProvider", "CPUExecutionProvider"]

    source_label = model_label if model_label is not None else model_source
    try:
        session = ort.InferenceSession(model_source, sess_options=session_options, providers=providers)
    except Exception as exc:
        can_retry_cpu = "CUDAExecutionProvider" in providers and "CPUExecutionProvider" in ort.get_available_providers()
        if can_retry_cpu and _is_ort_cuda_allocation_error(exc):
            print(
                "ORT CUDA session initialization OOM for {}; fallback to CPUExecutionProvider: {}".format(
                    source_label,
                    exc,
                )
            )
            session = ort.InferenceSession(
                model_source,
                sess_options=session_options,
                providers=["CPUExecutionProvider"],
            )
        else:
            raise

    session_providers = session.get_providers()
    print("ORT session providers for {}: {}".format(source_label, session_providers))
    inputs = session.get_inputs()
    fake_inputs = _as_output_sequence(fake_inputs)
    if len(inputs) != len(fake_inputs):
        raise RuntimeError("ONNX input count mismatch: model={}, provided={}".format(len(inputs), len(fake_inputs)))

    can_use_cuda_iobinding = (
        len(session_providers) > 0
        and session_providers[0] == "CUDAExecutionProvider"
        and torch.cuda.is_available()
    )

    bound_cuda_inputs = {}
    if can_use_cuda_iobinding:
        try:
            io_binding = session.io_binding()
            for input_info, fake_input in zip(inputs, fake_inputs):
                torch_input = _to_torch_tensor(fake_input).detach()
                if torch_input.device.type != "cuda":
                    torch_input = torch_input.to("cuda")
                if not torch_input.is_contiguous():
                    torch_input = torch_input.contiguous()
                bound_cuda_inputs[input_info.name] = torch_input
                if torch_input.dtype not in torch_to_numpy_dtype:
                    raise RuntimeError("Unsupported torch dtype for ORT CUDA I/O binding: {}".format(torch_input.dtype))
                io_binding.bind_input(
                    name=input_info.name,
                    device_type="cuda",
                    device_id=0,
                    element_type=torch_to_numpy_dtype[torch_input.dtype],
                    shape=tuple(torch_input.shape),
                    buffer_ptr=torch_input.data_ptr(),
                )

            for out in session.get_outputs():
                io_binding.bind_output(out.name, "cuda", 0)

            print("Using ORT CUDA I/O binding for {} to reduce host/device copies".format(source_label))
            start_time = time.perf_counter()
            session.run_with_iobinding(io_binding)
            ort_outs = io_binding.get_outputs()
            outputs = [ov.numpy() for ov in ort_outs]
            elapsed_sec = time.perf_counter() - start_time
            return outputs, session_providers, elapsed_sec
        except Exception as exc:
            print("ORT CUDA I/O binding fallback to session.run for {}: {}".format(source_label, exc))

    onnx_input = {
        input_info.name: _to_torch_tensor(fake_input).detach().cpu().numpy()
        for input_info, fake_input in zip(inputs, fake_inputs)
    }
    start_time = time.perf_counter()
    outputs = session.run(None, onnx_input)
    elapsed_sec = time.perf_counter() - start_time
    return outputs, session_providers, elapsed_sec


def run_rknn_numpy_baseline(onnx_model, fake_inputs, const_values,
                            model_label=None, quant_tab=None,
                            lora_metadata=None):
    """RKNN IRGraph+Session 浮点/量化推理基线。

    quant_tab: 量化参数表 {tensor 名: {name, dtype, scale, zero_point, qmethod}}
    (tensor 名须与 onnx_model 图内的名字一致)。非 None 时 simulator 对图中
    的权重/激活做量化仿真 ((w-zp)*scale + 激活 fake quant), 与 torch 的
    QDQ 仿真 forward 语义一致; 默认 {} 即纯浮点执行。
    """
    try:
        from rknn.api.ir_graph import IRGraph
        from rknn.api.session import Session
    except Exception as exc:
        raise RuntimeError("Failed to import RKNN graph execution framework: {}".format(exc))

    real_inputs = _real_input_value_infos(onnx_model)
    fake_inputs = _as_output_sequence(fake_inputs)
    if len(real_inputs) != len(fake_inputs):
        raise RuntimeError(
            "RKNN numpy baseline input mismatch: model={}, provided={}".format(
                len(real_inputs), len(fake_inputs)
            )
        )

    name_to_value = {
        vi.name: _to_torch_tensor(t).detach().cpu().numpy()
        for vi, t in zip(real_inputs, fake_inputs)
    }
    for k, v in const_values.items():
        if k not in name_to_value:
            name_to_value[k] = np.asarray(v)

    source_label = model_label if model_label is not None else "rknn_numpy"
    print(
        "RKNN graph baseline simulator for {} with {} nodes (IRGraph+Session mode)".format(
            source_label,
            len(list(onnx_model.graph.node)),
        )
    )

    start_time = time.perf_counter()
    # onnx.shape_inference 对 protobuf >2GB (C++ 单消息大小限制) 的图会静默
    # 返回空图 (nodes=0, 不抛异常), IRGraph 构造内部 infer_shapes 后
    # model.graph.node 为空。大权重数据已通过 const_values 传入 (IRGraph 的
    # initializer_dat), get_array 优先从 initializer_dat 读, 这里 deepcopy 后
    # 就地清掉 raw_data/external_data 缩小 protobuf, 绕开该限制。
    # 保留 int64 小 initializer 的 raw_data (如 Reshape 的 shape 参数):
    # 全清会导致 onnx.shape_inference 读 shape 数据时 Data size mismatch,
    # IRGraph 的 shape 推断断链 (float16 模拟的 D8 展开 Reshape 即因此触发,
    # 实测 exmpiConcat_shape_infer IndexError); int64 数据量小, 保留不影响
    # protobuf 大小与构建性能。
    _deep = copy.deepcopy(onnx_model)
    for _const in _deep.graph.initializer:
        if _const.raw_data and not (_const.data_type == onnx.TensorProto.INT64 and len(_const.raw_data) <= 4096):
            _const.ClearField('raw_data')
        if _const.HasField('data_location'):
            _const.ClearField('data_location')
            _const.ClearField('external_data')
    ir = IRGraph(
        _deep, check=False, verbose=False,
        initializer_dat=dict(const_values) if lora_metadata else const_values,
        args={})
    if len(ir.model.graph.node) == 0:
        raise RuntimeError(
            "IRGraph produced an empty graph. Ensure baseline model is captured before synthetic initializer materialization."
        )
    if lora_metadata:
        from rknn.api.rknn_lora import (
            apply_selected_lora_weights,
            restore_lora_torch_metadata,
        )
        restore_lora_torch_metadata(
            lora_metadata, [ir], fallback_values=const_values)
        apply_selected_lora_weights(lora_metadata, ir)
    sess = Session(ir, forbit_release=True)
    try:
        outputs = sess.run(name_to_value, inters={}, quant_tab=quant_tab or {})
    except Exception as exc:
        retried = False
        if _is_invalid_scatternd_index_error(exc):
            normalized_count = _normalize_irgraph_scatternd_indices(ir)
            if normalized_count > 0:
                print(
                    "Retry RKNN graph baseline after normalizing constant ScatterND indices on {} nodes".format(
                        normalized_count
                    )
                )
                name_to_value = _sync_graph_input_consts_from_ir(name_to_value, ir)
                sess = Session(ir, forbit_release=True)
                outputs = sess.run(name_to_value, inters={}, quant_tab=quant_tab or {})
                retried = True

        if (not retried) and _is_invalid_gather_index_error(exc):
            normalized_count = _normalize_irgraph_gather_indices(ir)
            if normalized_count > 0:
                print(
                    "Retry RKNN graph baseline after normalizing constant Gather indices on {} nodes".format(
                        normalized_count
                    )
                )
                name_to_value = _sync_graph_input_consts_from_ir(name_to_value, ir)
                sess = Session(ir, forbit_release=True)
                outputs = sess.run(name_to_value, inters={}, quant_tab=quant_tab or {})
                retried = True

        if not retried:
            raise
    outputs = _as_output_sequence(outputs)
    if len(outputs) != len(onnx_model.graph.output):
        raise RuntimeError(
            "RKNN graph baseline output count mismatch: expected {}, got {}".format(
                len(onnx_model.graph.output),
                len(outputs),
            )
        )

    elapsed_sec = time.perf_counter() - start_time
    return outputs, ["RKNNGraphSessionSimulator"], elapsed_sec


class _SimulatorArgs(object):
    def __init__(self, core_num=1):
        self.core_num = core_num


class _SimulatorBase(object):
    def __init__(self, ir, input_names, input_shapes, input_dtypes):
        self.inputs_meta = {"attrs": {}}
        for idx, name in enumerate(input_names):
            self.inputs_meta["attrs"][name] = {
                "idx": idx,
                "shape": input_shapes[idx],
                "layout": "nchw",
                "rgb2bgr": False,
                "mean": [0],
                "std": [1],
                "dtype": input_dtypes[idx],
            }
        self.irs = [ir]
        self.args = _SimulatorArgs(core_num=1)
        self.temp_dir = tempfile.TemporaryDirectory()

    def cleanup(self):
        self.temp_dir.cleanup()


def _copy_graph_without_large_initializer_payloads(onnx_model):
    """Copy a model for IRGraph while keeping large tensors in initializer_dat."""
    graph = copy.deepcopy(onnx_model)
    for initializer in graph.graph.initializer:
        keep_small_int64 = (
            initializer.data_type == onnx.TensorProto.INT64
            and bool(initializer.raw_data)
            and len(initializer.raw_data) <= 4096
        )
        if not keep_small_int64:
            initializer.ClearField('raw_data')
            initializer.ClearField('float_data')
            initializer.ClearField('int32_data')
            initializer.ClearField('int64_data')
            initializer.ClearField('double_data')
            initializer.ClearField('uint64_data')
        if initializer.HasField('data_location'):
            initializer.ClearField('data_location')
            initializer.ClearField('external_data')
    return graph


def _shape_from_value_info_dims(value_info):
    dims = []
    for dim in value_info.type.tensor_type.shape.dim:
        if dim.HasField("dim_value") and dim.dim_value > 0:
            dims.append(int(dim.dim_value))
        else:
            dims.append(1)
    return dims


def run_toolkit_simulator(
    backend,
    onnx_model,
    fake_inputs,
    const_values,
    model_label=None,
    pytorch_artifact_dir=None,
    profiler_options=None,
    lora_metadata=None,
):
    try:
        from rknn.api.ir_graph import IRGraph
        if backend == "onnx":
            from rknn.api.simulator import Simulator as ToolkitSimulator
        elif backend == "pytorch":
            from rknn.api.simulator_pytorch import Simulator as ToolkitSimulator
        else:
            raise RuntimeError("Unsupported simulator backend '{}'".format(backend))
    except Exception as exc:
        raise RuntimeError("Failed to import simulator backend '{}': {}".format(backend, exc))

    real_inputs = _real_input_value_infos(onnx_model)
    fake_inputs = _as_output_sequence(fake_inputs)
    if len(real_inputs) != len(fake_inputs):
        raise RuntimeError(
            "Toolkit simulator input mismatch: model={}, provided={}".format(
                len(real_inputs), len(fake_inputs)
            )
        )

    # Keep large initializer payloads out of the protobuf passed to IRGraph.
    # ONNX shape inference can silently return an empty graph once an LLM
    # model with embedded weights grows beyond protobuf's practical 2 GB
    # boundary.  The tensors remain available through ``initializer_dat``.
    runtime_graph = _copy_graph_without_large_initializer_payloads(
        onnx_model)
    ir = IRGraph(
        runtime_graph, check=False, verbose=False,
        initializer_dat=dict(const_values) if lora_metadata else const_values,
        args={})
    if lora_metadata:
        from rknn.api.rknn_lora import restore_lora_torch_metadata
        lora_controller = restore_lora_torch_metadata(
            lora_metadata, [ir], fallback_values=const_values)
    input_names = [vi.name for vi in real_inputs]
    input_shapes = [_shape_from_value_info_dims(vi) for vi in real_inputs]
    input_dtypes = [str(ir.get_dtype(vi.name)) for vi in real_inputs]
    sim_base = _SimulatorBase(ir, input_names, input_shapes, input_dtypes)
    if lora_metadata:
        sim_base.rknn_lora = lora_controller
        sim_base.ir = ir
        if backend == "onnx":
            from rknn.api.rknn_lora import apply_selected_lora_weights
            apply_selected_lora_weights(lora_metadata, ir)
    if backend == "pytorch":
        simulator = ToolkitSimulator(
            sim_base,
            log=False,
            infer_once=True,
            pytorch_artifact_dir=pytorch_artifact_dir,
        )
    else:
        simulator = ToolkitSimulator(sim_base, log=False, infer_once=True)
    np_inputs = [_to_torch_tensor(t).detach().cpu().numpy() for t in fake_inputs]
    source_label = model_label if model_label is not None else backend

    start_time = time.perf_counter()
    try:
        if backend == "pytorch":
            outputs = _run_with_torch_profiler(
                "toolkit_pytorch_simulator",
                lambda: simulator.inference(np_inputs, ["nchw"] * len(np_inputs), [1] * len(np_inputs), dynamic_idx=0),
                profiler_options=profiler_options,
            )
        else:
            outputs = simulator.inference(np_inputs, ["nchw"] * len(np_inputs), [1] * len(np_inputs), dynamic_idx=0)
    finally:
        sim_base.cleanup()
        # Release the simulator's GPU model immediately. In the full closed-loop
        # flow the PyTorch direct path loads the same weights again afterwards;
        # keeping both on device doubles weight memory (OOM on 24GB for large
        # models like gemma4_llm with 18.6GB fp32 weights).
        clean = getattr(simulator, "clean_infer_state", None)
        if callable(clean):
            clean()
        _last_run_profile = getattr(simulator, "_last_run_profile", None)
        del simulator
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
    elapsed_sec = time.perf_counter() - start_time
    provider = "Toolkit{}Simulator".format("PyTorch" if backend == "pytorch" else "Onnx")
    print("Run {} for {} finished in {:.4f}s".format(provider, source_label, elapsed_sec))
    return _as_output_sequence(outputs), [provider], elapsed_sec, _last_run_profile


def run_toolkit_pytorch_accuracy_analysis(
    onnx_model,
    fake_inputs,
    const_values,
    pytorch_artifact_dir,
    output_dir,
    model_label=None,
    quant_json=None,
    lora_metadata=None,
):
    try:
        from rknn.api.ir_graph import IRGraph
        from rknn.api.simulator_pytorch import Simulator as ToolkitPyTorchSimulator
    except Exception as exc:
        raise RuntimeError("Failed to import toolkit pytorch simulator for accuracy analysis: {}".format(exc))

    real_inputs = _real_input_value_infos(onnx_model)
    fake_inputs = _as_output_sequence(fake_inputs)
    if len(real_inputs) != len(fake_inputs):
        raise RuntimeError(
            "Toolkit pytorch accuracy-analysis input mismatch: model={}, provided={}".format(
                len(real_inputs), len(fake_inputs)
            )
        )

    os.makedirs(output_dir, exist_ok=True)

    analysis_graph = _copy_graph_without_large_initializer_payloads(
        onnx_model)
    ir = IRGraph(
        analysis_graph, check=False, verbose=False,
        initializer_dat=dict(const_values) if lora_metadata else const_values,
        args={})
    if lora_metadata:
        from rknn.api.rknn_lora import restore_lora_torch_metadata
        lora_controller = restore_lora_torch_metadata(
            lora_metadata, [ir], fallback_values=const_values)
    # 量化模型: 填充 ir.quant_tab, 使 accuracy_analysis 的 golden (_infer_by_sess
    # fake=True) 对标准算子输出做 fake_tensor 量化激活, 与 torch QDQ 同语义对比。
    # 不填充则 ir.quant_tab 空, fake_tensor(o, None) 直通, golden 仍是浮点 (对比
    # 反映量化损失而非 torch 仿真准确性)。
    if quant_json and os.path.exists(quant_json):
        _qt, _rawj, _rawn = _load_quant_tab(quant_json)
        if _qt:
            _restore_quant_weight_shapes(_qt, onnx_model)
            ir.quant_tab = _qt
            print("  accuracy_analysis: filled ir.quant_tab with {} entries from {}".format(
                len(_qt), os.path.basename(quant_json)))
            if _rawn is not None:
                try:
                    _rawn.close()
                except Exception:
                    pass
    input_names = [vi.name for vi in real_inputs]
    input_shapes = [_shape_from_value_info_dims(vi) for vi in real_inputs]
    input_dtypes = [str(ir.get_dtype(vi.name)) for vi in real_inputs]
    sim_base = _SimulatorBase(ir, input_names, input_shapes, input_dtypes)
    if lora_metadata:
        sim_base.rknn_lora = lora_controller
        sim_base.ir = ir
    simulator = ToolkitPyTorchSimulator(
        sim_base,
        log=False,
        infer_once=True,
        out_dir=output_dir,
        pytorch_artifact_dir=pytorch_artifact_dir,
    )
    np_inputs = [_to_torch_tensor(t).detach().cpu().numpy() for t in fake_inputs]
    source_label = model_label if model_label is not None else "toolkit pytorch simulator accuracy_analysis"

    start_time = time.perf_counter()
    try:
        err_dict = simulator.accuracy_analysis(np_inputs, target=None, dynamic_idx=0, data_format=["nchw"] * len(np_inputs))
    finally:
        sim_base.cleanup()
    elapsed_sec = time.perf_counter() - start_time
    print(
        "Run ToolkitPyTorchSimulator accuracy_analysis for {} finished in {:.4f}s (output_dir={})".format(
            source_label,
            elapsed_sec,
            output_dir,
        )
    )
    return err_dict, elapsed_sec, output_dir


def _infer_model_device(model, export_args):
    # Delegate to constants.infer_model_device.
    return infer_model_device(model, fallback_args=export_args)


def _move_export_args_to_device(export_args, device):
    # Delegate to constants.move_to_device (returns list; callers accept tuple-like).
    return tuple(move_to_device(export_args, device))


def _model_contains_range_op(model):
    return any(module.__class__.__name__ == "Range_torch" for module in model.modules())


def _outputs_have_non_finite(outputs):
    for item in _as_output_sequence(outputs):
        tensor = _to_torch_tensor(item)
        if torch.is_floating_point(tensor) and not torch.isfinite(tensor).all():
            return True
    return False


def _run_with_torch_profiler(run_name, fn, profiler_options=None):
    if not profiler_options or not profiler_options.get("enabled", False):
        return fn()

    if torch_profile is None or ProfilerActivity is None:
        print("[torch.profiler] unavailable in current torch build; run without profiler for {}".format(run_name))
        return fn()

    trace_dir = profiler_options.get("trace_dir")
    if trace_dir:
        os.makedirs(trace_dir, exist_ok=True)

    row_limit = int(profiler_options.get("row_limit", 40))
    record_shapes = bool(profiler_options.get("record_shapes", False))
    profile_memory = bool(profiler_options.get("profile_memory", False))
    with_stack = bool(profiler_options.get("with_stack", False))

    activities = [ProfilerActivity.CPU]
    if torch.cuda.is_available():
        activities.append(ProfilerActivity.CUDA)

    with torch_profile(
        activities=activities,
        record_shapes=record_shapes,
        profile_memory=profile_memory,
        with_stack=with_stack,
    ) as prof:
        result = fn()
        if torch.cuda.is_available():
            torch.cuda.synchronize()

    sort_key = "self_cuda_time_total" if torch.cuda.is_available() else "self_cpu_time_total"
    print("[torch.profiler] {} summary (sort_by={}):".format(run_name, sort_key))
    print(prof.key_averages().table(sort_by=sort_key, row_limit=row_limit))

    flow_rows = []
    for evt in prof.key_averages():
        key_lower = str(evt.key).lower()
        if "memcpy" in key_lower or "memset" in key_lower or "copy" in key_lower:
            flow_rows.append(
                (
                    evt.key,
                    float(getattr(evt, "self_cpu_time_total", 0.0)),
                    float(getattr(evt, "self_cuda_time_total", 0.0)),
                    int(getattr(evt, "count", 0)),
                )
            )
    flow_rows.sort(key=lambda x: x[2] if torch.cuda.is_available() else x[1], reverse=True)
    if flow_rows:
        print("[torch.profiler] {} data-flow hotspots (copy/memcpy/memset):".format(run_name))
        for key, cpu_us, cuda_us, count in flow_rows[: min(10, len(flow_rows))]:
            print(
                "  {} | calls={} | self_cpu={:.3f}us | self_cuda={:.3f}us".format(
                    key,
                    count,
                    cpu_us,
                    cuda_us,
                )
            )

    if trace_dir:
        trace_path = os.path.join(trace_dir, "{}_trace.json".format(run_name))
        prof.export_chrome_trace(trace_path)
        print("[torch.profiler] {} trace exported: {}".format(run_name, trace_path))

    return result


def _cast_floating_inputs(inputs, dtype):
    # Delegate to constants.cast_floating_inputs.
    return cast_floating_inputs(inputs, dtype)


def _remove_redundant_casts(onnx_model):
    """Remove Cast nodes where input and output dtype are identical (FLOAT->FLOAT).

    TorchScript export inserts defensive Cast(FLOAT->FLOAT) nodes due to dtype
    alignment branches in operator forward (e.g. conv_torch's weight.dtype check).
    These are no-ops at runtime and clutter the graph. This pass rewires them:
    any consumer of the Cast output is redirected to the Cast input, then the Cast
    node is deleted.

    Args:
        onnx_model: onnx.ModelProto (modified in place).

    Returns:
        (model, removed_count)
    """
    # Only remove a Cast when type metadata proves it is a no-op. Unknown
    # intermediate types must be preserved: Constant/Range/custom producers can
    # legitimately emit integer tensors without value_info.
    # Build the dtype lookup once.  Large LLM graphs can contain thousands of
    # initializers and Cast nodes; rescanning every collection for every Cast
    # turns this otherwise simple cleanup into an O(Casts * tensors) pass.
    dtype_by_name = {}
    for vi in list(onnx_model.graph.value_info) + list(onnx_model.graph.output):
        dtype_by_name[vi.name] = vi.type.tensor_type.elem_type
    for init in onnx_model.graph.initializer:
        dtype_by_name[init.name] = init.data_type
    for graph_input in onnx_model.graph.input:
        dtype_by_name[graph_input.name] = graph_input.type.tensor_type.elem_type

    cast_bypass = {}
    for node in onnx_model.graph.node:
        if node.op_type != "Cast":
            continue
        to_type = None
        for attr in node.attribute:
            if attr.name == "to":
                to_type = attr.i
        if to_type is None or len(node.input) == 0:
            continue
        inp_name = node.input[0]
        inp_type = dtype_by_name.get(inp_name)
        # Bypass if input dtype == output dtype (redundant cast).
        if inp_type is not None and inp_type == to_type:
            cast_bypass[node.output[0]] = inp_name

    if not cast_bypass:
        return onnx_model, 0

    # Resolve transitive chains: if a Cast input is itself a bypassed Cast output,
    # follow the chain to the original source. e.g. Cast1(out=B) <- Cast2(out=C) <- src
    def _resolve(name):
        seen = set()
        while name in cast_bypass and name not in seen:
            seen.add(name)
            name = cast_bypass[name]
        return name

    resolved_bypass = {k: _resolve(v) for k, v in cast_bypass.items()}

    # Rewire: replace cast output references with resolved source.
    for node in onnx_model.graph.node:
        for i, inp in enumerate(node.input):
            if inp in resolved_bypass:
                node.input[i] = resolved_bypass[inp]
    for out in onnx_model.graph.output:
        if out.name in resolved_bypass:
            out.name = resolved_bypass[out.name]

    # Remove the redundant Cast nodes.
    removed = 0
    new_nodes = []
    for node in onnx_model.graph.node:
        if node.op_type == "Cast" and node.output[0] in cast_bypass:
            removed += 1
            continue
        new_nodes.append(node)
    del onnx_model.graph.node[:]
    onnx_model.graph.node.extend(new_nodes)

    # Also remove Identity nodes (TorchScript inserts them for intermediate tensor
    # bookkeeping). They are pure pass-through (output == input).
    identity_bypass = {}
    for node in onnx_model.graph.node:
        if node.op_type == "Identity" and len(node.input) == 1 and len(node.output) == 1:
            identity_bypass[node.output[0]] = node.input[0]
    if identity_bypass:
        # Resolve transitive chains (Identity -> Identity).
        def _resolve_id(name):
            seen = set()
            while name in identity_bypass and name not in seen:
                seen.add(name)
                name = identity_bypass[name]
            return name
        resolved_id = {k: _resolve_id(v) for k, v in identity_bypass.items()}
        for node in onnx_model.graph.node:
            for i, inp in enumerate(node.input):
                if inp in resolved_id:
                    node.input[i] = resolved_id[inp]
        for out in onnx_model.graph.output:
            if out.name in resolved_id:
                out.name = resolved_id[out.name]
        new_nodes = []
        for node in onnx_model.graph.node:
            if node.op_type == "Identity" and node.output[0] in identity_bypass:
                removed += 1
                continue
            new_nodes.append(node)
        del onnx_model.graph.node[:]
        onnx_model.graph.node.extend(new_nodes)

    return onnx_model, removed


def _strip_exporter_only_casts(onnx_model, original_onnx):
    """Remove exporter Cast nodes from an otherwise identical check6 graph."""
    if original_onnx is None:
        return 0
    expected = list(original_onnx.graph.node)
    actual = list(onnx_model.graph.node)
    expected_non_cast = [node for node in expected if node.op_type != "Cast"]
    non_cast = [node for node in actual if node.op_type != "Cast"]
    if ([node.op_type for node in expected_non_cast]
            != [node.op_type for node in non_cast]):
        return 0

    def _cast_to(node):
        for attr in node.attribute:
            if attr.name == "to":
                return int(attr.i)
        return None

    def _casts_by_gap(nodes):
        """Index Casts by the number of non-Cast nodes before them."""
        gaps = {}
        non_cast_index = 0
        for node in nodes:
            if node.op_type == "Cast":
                gaps.setdefault(non_cast_index, []).append(node)
            else:
                non_cast_index += 1
        return gaps

    expected_gaps = _casts_by_gap(expected)
    actual_gaps = _casts_by_gap(actual)
    retained_ids = set()
    for gap, expected_casts in expected_gaps.items():
        candidates = actual_gaps.get(gap, [])
        candidate_index = 0
        for expected_cast in expected_casts:
            expected_to = _cast_to(expected_cast)
            while (candidate_index < len(candidates)
                   and _cast_to(candidates[candidate_index]) != expected_to):
                candidate_index += 1
            if candidate_index >= len(candidates):
                # The graphs are not Cast-equivalent; do not mutate anything.
                return 0
            retained_ids.add(id(candidates[candidate_index]))
            candidate_index += 1

    bypass = {
        node.output[0]: node.input[0]
        for node in actual
        if (node.op_type == "Cast" and len(node.input) == 1
            and id(node) not in retained_ids
            and len(node.output) == 1 and node.input[0] and node.output[0])
    }
    removable_count = sum(
        node.op_type == "Cast" and id(node) not in retained_ids
        for node in actual
    )
    if len(bypass) != removable_count:
        return 0

    def resolve(name):
        visited = set()
        while name in bypass and name not in visited:
            visited.add(name)
            name = bypass[name]
        return name

    for node in actual:
        if node.op_type == "Cast" and id(node) not in retained_ids:
            continue
        for index, name in enumerate(node.input):
            node.input[index] = resolve(name)
    for output in onnx_model.graph.output:
        output.name = resolve(output.name)
    del onnx_model.graph.node[:]
    onnx_model.graph.node.extend(
        node for node in actual
        if node.op_type != "Cast" or id(node) in retained_ids
    )
    return removable_count


def _fuse_pad_into_conv(onnx_model, original_onnx=None):
    """Fuse Pad -> Conv(padding=0) into Conv(pads=...) to match original graph.

    When conv_torch handles asymmetric padding, it emits F.pad (ONNX Pad) before
    Conv with pads=0. The original ONNX has a single Conv with pads attribute.
    This pass fuses the Pad's constant pads value into the Conv's pads attribute
    and removes the Pad node.

    Only fuses when:
    - Pad has constant pads (initializer or Constant node)
    - Pad's output is the sole input to Conv's first input
    - Conv has pads all zeros (padding done by the Pad)
    - (original_onnx given) the matching Conv in the original graph has non-zero
      pads. If the original Conv has zero pads, the Pad is an independent node
      in the original graph and must be preserved (node-count fidelity).
    """
    from onnx import TensorProto, numpy_helper

    # Build original-graph lookup: normalized Conv name -> pads attr (all zero?).
    # Regen names are like "/node_Gather_605_D4C0_2conv/Conv"; original names
    # are like "node_Gather_605_D4C0_2conv".
    orig_conv_zero_pads = set()  # normalized names whose original Conv has zero pads
    if original_onnx is not None:
        for node in original_onnx.graph.node:
            if node.op_type != "Conv":
                continue
            pads = None
            for attr in node.attribute:
                if attr.name == "pads":
                    pads = list(attr.ints)
            if pads is None or all(p == 0 for p in pads):
                orig_conv_zero_pads.add(node.name)

    def _norm_conv_name(name):
        """Normalize regen Conv name to original node name."""
        n = name
        if n.startswith("/"):
            n = n[1:]
        for suffix in ("/Conv", "/Gemm", "/MatMul"):
            if n.endswith(suffix):
                n = n[: -len(suffix)]
                break
        return n

    # Build initializer lookup.
    init_map = {}
    for init in onnx_model.graph.initializer:
        init_map[init.name] = numpy_helper.to_array(init)

    # Build Constant node lookup (for inline constant values).
    const_map = {}
    for node in onnx_model.graph.node:
        if node.op_type == "Constant":
            for attr in node.attribute:
                if attr.name == "value":
                    const_map[node.output[0]] = numpy_helper.to_array(attr.t)
                    break

    def _get_const(name):
        """Get constant value, following Cast chains to the source.
        If the chain is too long (Concat/Reshape/Slice/...), use ORT to eval."""
        # Direct lookup
        if name in init_map:
            return init_map[name]
        if name in const_map:
            return const_map[name]
        # Follow Cast chain (1 level)
        for n2 in onnx_model.graph.node:
            if n2.op_type == "Cast" and n2.output and n2.output[0] == name:
                src = n2.input[0] if n2.input else None
                if src and src in init_map:
                    return init_map[src]
                if src and src in const_map:
                    return const_map[src]
                break
        # Fallback: use ORT to evaluate the subgraph producing this value.
        try:
            import onnxruntime as ort
            # Trace back all nodes producing this output (transitively).
            needed_outputs = {name}
            nodes_to_keep = []
            queue = [name]
            visited = set()
            while queue:
                cur = queue.pop()
                if cur in visited:
                    continue
                visited.add(cur)
                for n2 in onnx_model.graph.node:
                    if n2.output and n2.output[0] == cur:
                        nodes_to_keep.append(n2)
                        for inp in n2.input:
                            if inp and inp not in init_map:
                                queue.append(inp)
                        break
            if not nodes_to_keep:
                return None
            # Build mini model.
            mini = onnx.ModelProto()
            mini.ir_version = onnx_model.ir_version
            mini.opset_import.extend(onnx_model.opset_import)
            g = mini.graph
            g.name = "const_eval"
            # Add nodes in reverse (topological order for single-output chain).
            for n2 in reversed(nodes_to_keep):
                g.node.append(n2)
            g.output.add().name = name
            sess = ort.InferenceSession(mini.SerializeToString(), providers=["CPUExecutionProvider"])
            result = sess.run(None, {})
            return result[0]
        except Exception:
            return None

    # Find Pad -> Conv patterns.
    _fuse_pad_debug = False
    pad_to_fuse = set()  # Pad node ids to remove
    conv_pads_updates = {}  # Conv node id -> new pads list

    for node in onnx_model.graph.node:
        if node.op_type != "Conv":
            continue
        # Check Conv has pads all zeros.
        conv_pads = None
        for attr in node.attribute:
            if attr.name == "pads":
                conv_pads = list(attr.ints)
        if conv_pads is None:
            conv_pads = [0, 0, 0, 0]  # default
        if any(p != 0 for p in conv_pads):
            continue  # Conv already has non-zero pads, skip

        # Check if Conv's first input comes from a Pad.
        conv_input = node.input[0]
        pad_node = None
        for n2 in onnx_model.graph.node:
            if n2.op_type == "Pad" and n2.output and n2.output[0] == conv_input:
                pad_node = n2
                break
        if pad_node is None:
            continue

        # If the original graph has this Conv with zero pads, the Pad is an
        # independent node there; keep it (node-count fidelity).
        if original_onnx is not None and _norm_conv_name(node.name) in orig_conv_zero_pads:
            continue

        # Check Pad has constant pads (input[1]).
        if len(pad_node.input) < 2:
            continue
        pad_pads_name = pad_node.input[1]
        pad_pads = _get_const(pad_pads_name)
        if pad_pads is None:
            if _fuse_pad_debug:
                print("  [fuse_pad] Pad {} pads input '{}' not const".format(pad_node.name[:40], pad_pads_name[:40]))
            continue

        # Pad's pads are ONNX format: [b0, b1, ..., e0, e1, ...] covering ALL dims.
        pad_pads_list = [int(v) for v in pad_pads]
        # Conv's pads only cover spatial dims (exclude batch and channel).
        weight_name = node.input[1] if len(node.input) > 1 else None
        spatial_rank = 2  # default 2D
        if weight_name:
            for init in onnx_model.graph.initializer:
                if init.name == weight_name:
                    spatial_rank = len(init.dims) - 2  # [out_ch, in_ch, *kernel]
                    break
        # Pad pads: [b_all_dims..., e_all_dims...], half = total_input_rank.
        # Conv pads: [b_spatial..., e_spatial...], spatial_rank dims each half.
        half = len(pad_pads_list) // 2
        if half > spatial_rank:
            # Skip non-spatial dims (batch + channel = first 2 in each half)
            skip = half - spatial_rank
            conv_pads_list = pad_pads_list[skip:skip + spatial_rank] + pad_pads_list[half + skip:half + skip + spatial_rank]
        else:
            conv_pads_list = pad_pads_list

        # Verify Pad's input is not used by other nodes (sole consumer = this Conv).
        pad_output = pad_node.output[0]
        consumers = 0
        for n2 in onnx_model.graph.node:
            if pad_output in n2.input:
                consumers += 1
        if consumers != 1:
            continue

        # Fuse: set Conv's pads to Pad's pads, rewire Conv input to Pad's input.
        pad_to_fuse.add(pad_node.output[0])
        conv_pads_updates[node.name] = (conv_pads_list, pad_node.input[0])

    if not pad_to_fuse:
        # Debug: count Pad nodes and Conv nodes with zero pads
        pad_count = sum(1 for n in onnx_model.graph.node if n.op_type == "Pad")
        conv_zero = 0
        for node in onnx_model.graph.node:
            if node.op_type == "Conv":
                conv_pads = None
                for attr in node.attribute:
                    if attr.name == "pads":
                        conv_pads = list(attr.ints)
                if conv_pads and all(p == 0 for p in conv_pads):
                    conv_zero += 1
        if _fuse_pad_debug:
            print("  [fuse_pad] Pad={}, Conv_zero_pads={}, no fusion candidates".format(pad_count, conv_zero))
        return onnx_model, 0

    # Apply Conv pads updates.
    for node in onnx_model.graph.node:
        if node.name in conv_pads_updates:
            new_pads, new_input = conv_pads_updates[node.name]
            node.input[0] = new_input
            # Update or add pads attribute.
            found = False
            for attr in node.attribute:
                if attr.name == "pads":
                    attr.ints[:] = new_pads
                    found = True
                    break
            if not found:
                from onnx import helper
                node.attribute.append(helper.make_attribute("pads", new_pads))

    # Remove fused Pad nodes (by output name, not id()).
    new_nodes = []
    for node in onnx_model.graph.node:
        if node.output and node.output[0] in pad_to_fuse:
            continue
        new_nodes.append(node)
    del onnx_model.graph.node[:]
    onnx_model.graph.node.extend(new_nodes)

    # Clean up orphaned nodes (outputs not consumed by anyone, and not graph
    # outputs). These are the pad-value computation chains (Constant->Concat->
    # Reshape->Slice->Transpose->Reshape->Cast) left behind after fusion.
    graph_output_names = set(o.name for o in onnx_model.graph.output)
    # Iterate: removing nodes may orphan more nodes.
    changed = True
    while changed:
        changed = False
        # Collect all consumed input names.
        consumed = set()
        for node in onnx_model.graph.node:
            for inp in node.input:
                if inp:
                    consumed.add(inp)
        # Remove nodes whose outputs are not consumed and not graph outputs.
        kept = []
        for node in onnx_model.graph.node:
            has_consumer = False
            for out in node.output:
                if out in consumed or out in graph_output_names:
                    has_consumer = True
                    break
            if has_consumer:
                kept.append(node)
            else:
                changed = True  # removed an orphan
        del onnx_model.graph.node[:]
        onnx_model.graph.node.extend(kept)

    return onnx_model, len(pad_to_fuse)


def _expand_symbolic_wrapper(g, x, shape, implicit):
    """Symbolic override for aten::expand.

    TorchScript's default symbolic for aten::expand turns the tensor shape
    argument into ConstantOfShape/Equal/Where/Mul nodes. This override emits
    a single ONNX Expand node directly, keeping the graph clean.
    """
    return g.op("Expand", x, shape)


def _isnan_symbolic_wrapper(g, x):
    """Symbolic override for aten::isnan.

    TorchScript inserts Cast(DOUBLE) before and after isnan for FLOAT inputs.
    This override emits ONNX IsNaN directly without dtype conversion.
    """
    return g.op("IsNaN", x)


def _where_symbolic_wrapper(g, condition, x, y):
    """Symbolic override for aten::where.

    TorchScript inserts Cast(BOOL) on the condition input. This override
    emits ONNX Where directly without the redundant Cast.
    """
    return g.op("Where", condition, x, y)


def compare_regen_structure(check6_model, regen_model):
    """Compare operator topology and return an unambiguous tensor-name map."""
    check_nodes = list(check6_model.graph.node)
    regen_nodes = list(regen_model.graph.node)
    issues = []
    if len(check_nodes) != len(regen_nodes):
        issues.append(
            "node count {} != {}".format(
                len(check_nodes), len(regen_nodes)))

    tensor_map = {}
    reverse_map = {}

    def add_mapping(check_name, regen_name, context):
        if not check_name or not regen_name:
            if check_name != regen_name:
                issues.append("{} optional input differs".format(context))
            return
        old_regen = tensor_map.get(check_name)
        old_check = reverse_map.get(regen_name)
        if old_regen not in (None, regen_name):
            issues.append(
                "{} maps {!r} to both {!r} and {!r}".format(
                    context, check_name, old_regen, regen_name))
            return
        if old_check not in (None, check_name):
            issues.append(
                "{} maps {!r} from both {!r} and {!r}".format(
                    context, regen_name, old_check, check_name))
            return
        tensor_map[check_name] = regen_name
        reverse_map[regen_name] = check_name

    check_initializers = {item.name for item in check6_model.graph.initializer}
    regen_initializers = {item.name for item in regen_model.graph.initializer}
    check_inputs = [
        item.name for item in check6_model.graph.input
        if item.name not in check_initializers]
    regen_inputs = [
        item.name for item in regen_model.graph.input
        if item.name not in regen_initializers]
    if len(check_inputs) != len(regen_inputs):
        issues.append(
            "graph input count {} != {}".format(
                len(check_inputs), len(regen_inputs)))
    for index, (check_name, regen_name) in enumerate(
            zip(check_inputs, regen_inputs)):
        add_mapping(check_name, regen_name, "graph input {}".format(index))

    check_outputs = [item.name for item in check6_model.graph.output]
    regen_outputs = [item.name for item in regen_model.graph.output]
    if len(check_outputs) != len(regen_outputs):
        issues.append(
            "graph output count {} != {}".format(
                len(check_outputs), len(regen_outputs)))

    check_producers = {
        name: (index, output_index)
        for index, node in enumerate(check_nodes)
        for output_index, name in enumerate(node.output) if name
    }
    regen_producers = {
        name: (index, output_index)
        for index, node in enumerate(regen_nodes)
        for output_index, name in enumerate(node.output) if name
    }

    for index, (check_node, regen_node) in enumerate(
            zip(check_nodes, regen_nodes)):
        if check_node.op_type != regen_node.op_type:
            issues.append(
                "node {} op {} != {}".format(
                    index, check_node.op_type, regen_node.op_type))
            continue
        if len(check_node.input) != len(regen_node.input):
            issues.append(
                "node {} ({}) input count {} != {}".format(
                    index, check_node.op_type, len(check_node.input),
                    len(regen_node.input)))
            continue
        if len(check_node.output) != len(regen_node.output):
            issues.append(
                "node {} ({}) output count {} != {}".format(
                    index, check_node.op_type, len(check_node.output),
                    len(regen_node.output)))
            continue

        for input_index, (check_name, regen_name) in enumerate(
                zip(check_node.input, regen_node.input)):
            context = "node {} input {}".format(index, input_index)
            add_mapping(check_name, regen_name, context)
            if not check_name or not regen_name:
                continue
            check_source = check_producers.get(check_name)
            regen_source = regen_producers.get(regen_name)
            if check_source != regen_source:
                check_kind = (
                    "initializer" if check_name in check_initializers
                    else "graph_input" if check_name in check_inputs
                    else check_source)
                regen_kind = (
                    "initializer" if regen_name in regen_initializers
                    else "graph_input" if regen_name in regen_inputs
                    else regen_source)
                if check_kind != regen_kind:
                    issues.append(
                        "{} source {} != {}".format(
                            context, check_kind, regen_kind))

        for output_index, (check_name, regen_name) in enumerate(
                zip(check_node.output, regen_node.output)):
            add_mapping(
                check_name, regen_name,
                "node {} output {}".format(index, output_index))

    for index, (check_name, regen_name) in enumerate(
            zip(check_outputs, regen_outputs)):
        add_mapping(check_name, regen_name, "graph output {}".format(index))

    return tensor_map, issues


def build_regen_name_map(check6_model, regen_model):
    """Build a complete check6-to-regenerated tensor map for isomorphic graphs.

    A repeated-op sequence cannot be mapped safely with a sequence matcher.
    Only graphs with the same node order, operator types, arity and producer
    topology return a mapping; otherwise the caller receives an empty map and
    reports the structural difference.
    """
    tensor_map, issues = compare_regen_structure(
        check6_model, regen_model)
    return {} if issues else tensor_map


def warn_regen_structure(check6_path, regen_path):
    """Report structural drift without turning accuracy validation into a gate."""
    try:
        check6_model = onnx.load(check6_path, load_external_data=False)
        regen_model = onnx.load(regen_path, load_external_data=False)
        _, issues = compare_regen_structure(check6_model, regen_model)
    except Exception as error:
        print(
            "  WARNING: regenerated ONNX structure comparison failed: {}".format(
                repr(error)[:200]))
        return False
    if issues:
        print(
            "  WARNING: regenerated ONNX structure differs from check6 "
            "({} issue(s)): {}".format(
                len(issues), "; ".join(issues[:10])))
        return False
    print(
        "  Regenerated ONNX structure matches check6: {} nodes, "
        "topology and tensor edges aligned".format(
            len(check6_model.graph.node)))
    return True


def build_regen_buffer_name_map(check6_model, regen_model):
    """回导图 (节点/tensor) 名 -> generated.py buffer 名 (check6 名 sanitize 清洗)。

    目标: 回导 onnx 的节点名/tensor 名统一为 codegen 的 buffer 名 (清洗后,
    '/'->'_', 数字开头加 '_'), 用户对照 generated.py 调试, rebuild 注入 json
    (key = buffer 名) 时直接匹配图。

    只有节点数量、op、输入输出位置、producer 拓扑和 tensor 双射全部一致时
    才生成映射。任何结构差异都返回空映射，禁止 preserve 名称前缀或重复 op
    序列产生部分、歧义映射。

    边界 tensor 保持回导原名，避免与 RKNN 内部动态插入的 cvt 节点撞名。
    sanitize 后出现任何冲突都拒绝整份映射，不产生部分 rename。
    返回 {回导名: buffer名}; 结构不一致或名称冲突时返回空映射。
    """
    _tensor_map, _issues = compare_regen_structure(
        check6_model, regen_model)
    if _issues:
        return {}
    pairs = zip(regen_model.graph.node, check6_model.graph.node)

    mp = {}   # 回导名 -> buffer 名
    _rev = {}  # (ONNX namespace, buffer 名) -> 回导名
    _source = {}  # (ONNX namespace, 回导名) -> buffer 名
    # 边界 tensor 名不 rename (保持回导原名): rknn 量化器内部按
    # '{io}__cvt_float32_to_{dtype}' / '{io}_{dtype}' 模式动态生成新节点名,
    # 边界名 rename 成 check6 名 (如 'input') 后, 插入的 cvt 节点名会与回导图
    # 里 check6 继承的 exDataConvert 头节点撞名 (ValueError: already in nodes)。
    _c6_init_names = {x.name for x in check6_model.graph.initializer}
    _c6_boundary = ({i.name for i in check6_model.graph.input if i.name not in _c6_init_names}
                    | {o.name for o in check6_model.graph.output})
    _rg_boundary = ({i.name for i in regen_model.graph.input
                     if i.name not in {x.name for x in regen_model.graph.initializer}}
                    | {o.name for o in regen_model.graph.output})

    def _add(r_name, c_name, namespace):
        if not r_name or not c_name:
            return True
        if r_name in _rg_boundary or c_name in _c6_boundary:
            return True  # 边界名保持原名 (避免与 rknn 内部动态节点名碰撞)
        _b = sanitize_name(c_name)
        _key = (namespace, _b)
        _source_key = (namespace, r_name)
        if _key in _rev and _rev[_key] != r_name:
            return False
        if _source_key in _source and _source[_source_key] != _b:
            return False
        if r_name in mp and mp[r_name] != _b:
            return False
        # ONNX node and tensor names are separate namespaces.  A node and its
        # output may legitimately share the same check6 name, so only reject
        # collisions within one namespace.
        _rev[_key] = r_name
        _source[_source_key] = _b
        mp[r_name] = _b
        return True

    for _rn, _cn in pairs:
        if not _add(_rn.name, _cn.name, "node"):
            return {}
    for _check_name, _regen_name in _tensor_map.items():
        if not _add(_regen_name, _check_name, "tensor"):
            return {}
    return mp


def rename_regen_onnx(onnx_path, check6_path):
    """把回导 onnx 的节点名/tensor 名统一为 generated.py buffer 名 (清洗后)。

    对最终落盘的回导 onnx 做 rename (node.name/input/output、initializer.name、
    value_info.name、graph.input/output.name), 保存回 onnx_path (external data
    保持一致, 原子替换)。返回 (rename 的 tensor 数, 映射表); 失败返回 (0, {})。
    """
    if not os.path.exists(onnx_path) or not os.path.exists(check6_path):
        return 0, {}
    try:
        _c6 = onnx.load(check6_path, load_external_data=False)
        _rg = onnx.load(onnx_path, load_external_data=True)
        _mp = build_regen_buffer_name_map(_c6, _rg)
    except Exception as _e:
        print("  Regen onnx rename skipped (load/map failed): {}".format(repr(_e)[:150]))
        return 0, {}
    if not _mp:
        print("  Regen onnx rename skipped (no name mapping)")
        return 0, {}
    _g = _rg.graph
    for _n in _g.node:
        if _n.name in _mp:
            _n.name = _mp[_n.name]
        for _i, _t in enumerate(_n.input):
            if _t in _mp:
                _n.input[_i] = _mp[_t]
        for _i, _t in enumerate(_n.output):
            if _t in _mp:
                _n.output[_i] = _mp[_t]
    for _init in _g.initializer:
        if _init.name in _mp:
            _init.name = _mp[_init.name]
    for _vi in _g.value_info:
        if _vi.name in _mp:
            _vi.name = _mp[_vi.name]
    for _inp in _g.input:
        if _inp.name in _mp:
            _inp.name = _mp[_inp.name]
    for _out in _g.output:
        if _out.name in _mp:
            _out.name = _mp[_out.name]
    # 原子保存: 先写临时 model + 临时 data 文件, 验证非空图 (onnx.save_model
    # 对 >2GB 模型触发 shape inference 会静默产出空图) 后再替换正式文件,
    # 失败时原模型与 data 文件完好。第二次 save 只重写 protobuf 头
    # (external_data 引用修正为正式名, 不重写权重数据)。
    _ext_name = os.path.basename(onnx_path) + ".data"
    _tmp_model = onnx_path + ".ren_tmp.onnx"
    _tmp_ext = _ext_name + ".ren_tmp"
    _dir = os.path.dirname(onnx_path) or '.'
    try:
        onnx.save_model(_rg, _tmp_model, save_as_external_data=True, location=_tmp_ext)
        _chk = onnx.load(_tmp_model, load_external_data=False)
        if len(_chk.graph.node) == 0:
            print("  Regen onnx rename skipped (saved model empty, shape inference issue)")
            for _p in (_tmp_model, os.path.join(_dir, _tmp_ext)):
                if os.path.exists(_p):
                    os.remove(_p)
            return 0, {}
        # 修正 external_data location 为正式名 (os.replace 只改文件名不改引用)
        for _init in _chk.graph.initializer:
            for _ed in _init.external_data:
                if _ed.key == "location":
                    _ed.value = _ext_name
        onnx.save_model(_chk, _tmp_model, save_as_external_data=True, location=_ext_name)
        _old_data = os.path.join(_dir, _ext_name)
        _tmp_data = os.path.join(_dir, _tmp_ext)
        if os.path.exists(_tmp_data):
            if os.path.exists(_old_data):
                os.remove(_old_data)
            os.replace(_tmp_data, _old_data)
        elif os.path.exists(_old_data):
            # Small models may keep every initializer inline and therefore do
            # not create an external-data file at all.
            os.remove(_old_data)
        os.replace(_tmp_model, onnx_path)
    except Exception as _e:
        for _p in (_tmp_model, os.path.join(_dir, _tmp_ext)):
            if os.path.exists(_p):
                try:
                    os.remove(_p)
                except Exception:
                    pass
        print("  Regen onnx rename failed: {}".format(repr(_e)[:150]))
        return 0, {}
    return len(_mp), _mp


def _fix_regen_exconvstreaming_layout(onnx_path):
    """修复回导图 exConvStreaming 的输入布局。

    check6 的 exConvStreaming 是 4 输入 [data, weight, bias, tc] (bias 可为空,
    tc 是 KV cache 状态, int32)。torch.onnx 导出时 bias=None 被省略, tc 从
    input[3] 掉到 input[2] (bias 位置) -> IRGraph/ORT 的 Conv 校验报
    "Input type (float) and bias type (int)" (q_0.8b linear attention 实测)。
    修复: input[2] (bias 位) 插空字符串, tc 移到 input[3], 与 check6 布局一致。
    返回修复节点数。
    """
    if not os.path.exists(onnx_path):
        return 0
    try:
        import onnx
        _m = onnx.load(onnx_path, load_external_data=True)
        _fixed = 0
        for _n in _m.graph.node:
            if _n.op_type == 'exConvStreaming' and len(_n.input) == 3:
                _tc = _n.input[2]
                del _n.input[2]
                _n.input.append('')   # bias 位占位 (无 bias)
                _n.input.append(_tc)  # tc 回到 input[3]
                _fixed += 1
        if _fixed:
            _ext = os.path.basename(onnx_path) + '.data'
            _tmp = onnx_path + '.layout_tmp.onnx'
            _tmp_ext = _ext + '.layout_tmp'
            _dir = os.path.dirname(onnx_path) or '.'
            try:
                onnx.save_model(_m, _tmp, save_as_external_data=True,
                                location=_tmp_ext, all_tensors_to_one_file=True)
                _check = onnx.load(_tmp, load_external_data=False)
                if not _check.graph.node:
                    raise RuntimeError('saved model has empty graph')
                for _init in _check.graph.initializer:
                    for _ed in _init.external_data:
                        if _ed.key == 'location':
                            _ed.value = _ext
                onnx.save_model(_check, _tmp, save_as_external_data=True,
                                location=_ext, all_tensors_to_one_file=True)
                _old = os.path.join(_dir, _ext)
                if os.path.exists(_old):
                    os.remove(_old)
                os.replace(os.path.join(_dir, _tmp_ext), os.path.join(_dir, _ext))
                os.replace(_tmp, onnx_path)
            finally:
                for _p in (_tmp, os.path.join(_dir, _tmp_ext)):
                    if os.path.exists(_p):
                        os.remove(_p)
        return _fixed
    except Exception as _e:
        print("  Regen exConvStreaming layout fix skipped: {}".format(repr(_e)[:150]))
        return 0


def _load_quant_tab(quant_json_path):
    """解析 PTH/NPZ 量化清单，生成 Session.run 的 quant_tab。

    返回 ``(quant_tab, raw_json, manifest)``。manifest 保留对 PTH 或旧 NPZ
    backing store 的统一延迟访问能力，供 restore_check_weights 回填 check6
    真实权重。
    """
    from rknn.base.gpu.quant_manifest import QuantManifest
    _manifest = QuantManifest(quant_json_path)
    _raw = _manifest.data
    def _resolve_array(value, tensor_name, field_name):
        if value is None:
            return None
        return _manifest.array(value, tensor_name, field_name)

    array_fields = (
        'scale', 'zero_point', 'min', 'max', 'ori_min', 'ori_max',
        'ori_scale', 'w_int',
        'qmode_scale', 'qmode_zero_point', 'qmode_mean', 'qmode_std',
        'qmode_multipliers', 'qmode_shifts', 'qmode_offsets',
    )
    # quant json (build 导出的 quant_tab.json) 的 key = onnx/check6 tensor 名,
    # 直接匹配 check6, 无需 key 翻译。
    _qtab = {}
    for _k, _par in _raw.items():
        if not isinstance(_par, dict) or 'scale' not in _par:
            continue  # 顶层元数据 (如 _weights_source)
        _s_arr = _resolve_array(_par['scale'], _k, 'scale')
        if _s_arr.size == 0:
            continue  # 无量化参数条目 (float32 输入等), 不需要进 quant_tab
        _z_arr = _resolve_array(_par.get('zero_point'), _k, 'zero_point')
        if _z_arr is None:
            _z_arr = np.zeros(_s_arr.shape, dtype=np.int32)
        _entry = dict(_par)
        for _field in array_fields:
            if _field in _par:
                _entry[_field] = _resolve_array(
                    _par[_field], _k, _field)
        _entry['scale'] = np.asarray(_s_arr, dtype=np.float32)
        _entry['zero_point'] = np.asarray(_z_arr, dtype=np.int32) if np.issubdtype(
            _z_arr.dtype, np.integer) or _z_arr.size == 1 else _z_arr.astype(np.int32)
        _qtab[_k] = _entry
    return _qtab, _raw, _manifest


def _restore_quant_weight_shapes(quant_tab, onnx_model):
    """Restore flattened manifest w_int arrays to initializer tensor shapes."""
    initializer_shapes = {
        init.name: tuple(int(dim) for dim in init.dims)
        for init in onnx_model.graph.initializer
    }
    restored = 0
    for name, entry in quant_tab.items():
        if 'w_int' not in entry or name not in initializer_shapes:
            continue
        shape = initializer_shapes[name]
        numel = int(np.prod(shape, dtype=np.int64))
        w_int = np.asarray(entry['w_int'])
        if w_int.size == numel:
            entry['w_int'] = w_int.reshape(shape)
            restored += 1
            continue
        if (entry.get('dtype') in ('int4', 'int4_n')
                and w_int.size * 2 == numel and len(shape) <= 8):
            import struct
            from rknn.api.libcpputils2 import cpputils2
            header = list(shape) + [0] * (8 - len(shape))
            packed = bytearray(struct.pack('8i', *header))
            packed.extend(w_int.astype(np.uint8, copy=False).tobytes())
            entry['w_int'] = cpputils2.unpack_int4(packed)
            restored += 1
            continue
        raise ValueError(
            "Quantized weight '{}' has {} stored values, expected {} for "
            "shape {}".format(name, w_int.size, numel, shape))
    return restored


def _run_quant_sim_onnx(onnx_model, fake_inputs, const_values, quant_tab,
                        label=None, lora_metadata=None):
    """OnnxSimulator 逐层量化推理: 每层算子输出 fake_tensor (激活量化), 与 torch
    QDQ (全量化) 同语义对比。Session.run 全图对标准算子激活不量化 (float), torch
    全量化, 对比基准不一致 (LLM float16 激活实测 Session.run cos=0.99, OnnxSimulator
    逐层 fake 后 0.999998)。输入直通 (pass_through=1, 不预处理, 与 torch 原始输入一致)。
    """
    from rknn.api.ir_graph import IRGraph
    from rknn.api.simulator import Simulator as OnnxSim
    # 清大权重 raw_data 缩小 protobuf (绕开 onnx.shape_inference >2GB 静默空图);
    # 保留 int64 小 initializer (Reshape shape 参数), 否则 shape 推断断链。
    _deep = copy.deepcopy(onnx_model)
    for _c in _deep.graph.initializer:
        if _c.raw_data and not (_c.data_type == onnx.TensorProto.INT64 and len(_c.raw_data) <= 4096):
            _c.ClearField('raw_data')
        if _c.HasField('data_location'):
            _c.ClearField('data_location')
            _c.ClearField('external_data')
    _ir = IRGraph(
        _deep, check=False, verbose=False,
        initializer_dat=dict(const_values) if lora_metadata else const_values,
        args={})
    _ir.quant_tab = quant_tab or {}
    if lora_metadata:
        from rknn.api.rknn_lora import (
            apply_selected_lora_weights,
            restore_lora_torch_metadata,
        )
        restore_lora_torch_metadata(
            lora_metadata, [_ir], fallback_values=const_values)
        apply_selected_lora_weights(lora_metadata, _ir)
    real_inputs = _real_input_value_infos(onnx_model)
    fake_inputs = _as_output_sequence(fake_inputs)
    if len(real_inputs) != len(fake_inputs):
        raise RuntimeError("quant sim input mismatch: model={}, provided={}".format(
            len(real_inputs), len(fake_inputs)))
    input_names = [vi.name for vi in real_inputs]
    input_shapes = [_shape_from_value_info_dims(vi) for vi in real_inputs]
    input_dtypes = [str(_ir.get_dtype(vi.name)) for vi in real_inputs]
    sim_base = _SimulatorBase(_ir, input_names, input_shapes, input_dtypes)
    simulator = OnnxSim(sim_base, log=False, infer_once=True)
    np_inputs = [_to_torch_tensor(t).detach().cpu().numpy() for t in fake_inputs]
    start = time.perf_counter()
    try:
        # GeneratedModel.forward accepts already prepared floating tensors.
        # Bypass toolkit input preprocessing here so both sides receive the
        # exact same values; per-layer activation/weight fake quantization is
        # still driven by ir.quant_tab inside OnnxSimulator.
        outputs = simulator.inference(
            np_inputs, ["nchw"] * len(np_inputs), [1] * len(np_inputs), dynamic_idx=0)
    finally:
        sim_base.cleanup()
        clean = getattr(simulator, "clean_infer_state", None)
        if callable(clean):
            clean()
    _elapsed = time.perf_counter() - start
    print("  OnnxSimulator per-layer quant sim (fake=True) for {}: {:.2f}s".format(
        label or "check6_quant_sim", _elapsed))
    return _as_output_sequence(outputs), ["OnnxSimulatorFakeTrue"], _elapsed


def _verify_quant_simulator(check6_path, quant_json_path, fake_inputs,
                            pytorch_output, label=None,
                            lora_metadata=None):
    """量化路径验证: pytorch forward (QDQ 仿真) vs toolkit simulator 量化推理。

    用户量化闭环: 回导 onnx 是 float32 图 (不含 QDQ 节点, gongga 自定义 op
    也无法在 ORT 中推理), 量化参数走独立的 quant json (build 导出的
    quant_tab.json, key=onnx/check6 名) 输入 simulator 做量化推理。simulator
    运行的是 check6 (量化 IR, 原始 tensor 名与 quant json key 一致), 通过
    Session.run(..., quant_tab=...) 对权重/激活做 (w-zp)*scale 反量化 + fake
    quant, 与 forward 的 QDQ 仿真语义一致, 输出应逐元素一致 (cos≈1)。

    流程 (参考 quant_real_compare.py): load check6 -> restore_check_weights
    (回填 check_external_data 真实权重为 float32 反量化值; fake_tensor 对已
    反量化权重再做 QDQ 是幂等的, 浮点误差内恒等) -> 校验常量完整性 ->
    从 graph.input 移除权重 (只留真实输入) -> Session.run(quant_tab)。

    返回 (min_cos, simulator_elapsed): min_cos (float) ; 失败返回 (None, 0.0)。
    simulator_elapsed 是单次 Session.run 的耗时 (秒), 与 pytorch 单次 forward
    耗时 (main 的 pytorch_elapsed) 对比即 torch 仿真 vs simulator 的推理速度。
    """
    from onnx import numpy_helper
    _qtab, _raw_json, _raw_npz = _load_quant_tab(quant_json_path)
    if not _qtab:
        print("  Quant simulator verify skipped: no quant params in {}".format(quant_json_path))
        return (None, 0.0)
    _m6 = onnx.load(check6_path)
    _n_restored = restore_check_weights(_m6, check6_path, _raw_json, _raw_npz)
    materialize_missing_initializers(_m6)
    # fake_tensor gives w_int precedence over the real initializer, so restore
    # its declared rank before constructing per-layer sessions.
    _restore_quant_weight_shapes(_qtab, _m6)
    # check6 权重同时作为 graph.input 存在 (rknn 量化 IR 特性): 移除, 只留真实输入
    _init_names = {i.name for i in _m6.graph.initializer}
    _keep = [i for i in _m6.graph.input if i.name not in _init_names]
    del _m6.graph.input[:]
    _m6.graph.input.extend(_keep)
    _const_values = {}
    for _init in _m6.graph.initializer:
        try:
            _const_values[_init.name] = np.asarray(numpy_helper.to_array(_init))
        except Exception:
            pass
    print("  Quant simulator on check6: restored {} weights, {} quant_tab entries".format(
        _n_restored, len(_qtab)))
    try:
        # 逐层量化推理 (OnnxSimulator fake=True): 每层算子输出 fake_tensor 量化
        # 激活, 与 torch QDQ (全量化) 同语义对比。Session.run 全图对标准算子
        # 激活不量化 (float), torch 全量化, 对比基准不一致 (LLM float16 激活
        # 实测 Session.run cos=0.99, OnnxSimulator 逐层 fake 后 0.999998)。
        try:
            _sim_outs, _providers, _elapsed = _run_quant_sim_onnx(
                _m6, fake_inputs, _const_values, _qtab, label,
                lora_metadata=lora_metadata)
        except Exception as _e:
            print("  OnnxSimulator per-layer quant sim failed ({}), fallback to Session.run".format(
                str(_e)[:120]))
            _sim_outs, _providers, _elapsed = run_rknn_numpy_baseline(
                _m6, fake_inputs, _const_values,
                model_label=label or "check6_quant_sim", quant_tab=_qtab,
                lora_metadata=lora_metadata)
    finally:
        if _raw_npz is not None:
            try:
                _raw_npz.close()
            except Exception:
                pass
    _sim_outs = _as_output_sequence(_sim_outs)
    _res = compare_output_sequences(
        "Simulator[check6+quant_tab]", _sim_outs,
        "PyTorch forward[QDQ]", pytorch_output)
    for _r in _res:
        print("  Simulator vs PyTorch output[{}]: cos={:.6f}".format(
            _r.get("index", ""), _r.get("cosine", 0)))
    if not _res:
        return (None, _elapsed if isinstance(_elapsed, float) else 0.0)
    _cosines = [float(_r.get("cosine", float("nan"))) for _r in _res]
    _min_cos = min(_cosines) if all(np.isfinite(_v) for _v in _cosines) else float("nan")
    return (_min_cos, _elapsed if isinstance(_elapsed, float) else 0.0)


def _patch_dynamo_registry():
    """为 torch 2.8 dynamo exporter 补齐 QDQ 仿真链缺失的 prims op 注册。

    torchlib 覆盖 aten 算子, 但 QDQ 仿真链在 FX 分解后以 prims 形态出现
    (prims.sub/mul/div/add/round/broadcast_in_dim/collapse_view), torchlib
    无注册 (2.8.0 系统性缺陷: 连 aten.convolution 也无 ONNX 函数)。通过
    monkeypatch ONNXRegistry.from_torchlib 注册等价 onnxscript 函数;
    collapse_view (reshape 的 prim 形态) 直接复用 torchlib 的 aten::reshape
    函数。注意: 导出 opset 必须 >= 18, 否则 _cleanup_registry_based_on_
    opset_version 会清空全部 torchlib 注册。
    """
    from onnxscript import opset18 as _op
    from onnxscript import script
    from torch.onnx._internal.exporter._registration import ONNXRegistry

    @script()
    def _prims_sub(x, y):
        return _op.Sub(x, y)

    @script()
    def _prims_mul(x, y):
        return _op.Mul(x, y)

    @script()
    def _prims_div(x, y):
        return _op.Div(x, y)

    @script()
    def _prims_add(x, y):
        return _op.Add(x, y)

    @script()
    def _prims_round(x):
        return _op.Round(x)

    @script()
    def _prims_broadcast_in_dim(a, shape, broadcast_dimensions):
        return _op.Expand(a, shape)

    _orig = ONNXRegistry.from_torchlib.__func__

    def _patched(cls, opset_version=None):
        reg = _orig(cls, opset_version)
        for tgt, fn in (
            (torch.ops.prims.sub.default, _prims_sub),
            (torch.ops.prims.mul.default, _prims_mul),
            (torch.ops.prims.div.default, _prims_div),
            (torch.ops.prims.add.default, _prims_add),
            (torch.ops.prims.round.default, _prims_round),
            (torch.ops.prims.broadcast_in_dim.default, _prims_broadcast_in_dim),
        ):
            reg.register_op(tgt, fn)
        if torch.ops.prims.collapse_view.default not in reg.functions \
                and "prims::collapse_view" not in reg.functions:
            _rs = reg.functions.get("aten::reshape")
            if _rs:
                reg.register_op(torch.ops.prims.collapse_view.default, _rs[0].onnx_function)
        return reg

    if not getattr(_patch_dynamo_registry, "_applied", False):
        ONNXRegistry.from_torchlib = classmethod(_patched)
        _patch_dynamo_registry._applied = True


def _strip_qdq_to_float(onnx_model, model):
    """把 torch 导出的 QDQ 仿真展开链从回导图中删除 (QDQ-strip)。

    toolkit 的 IR 不需要 QDQ 节点: 回导 onnx 只保留 float32 图结构 (与
    check6 结构一致, 用户在 torch 中新加的 op 随 forward 导出), 量化参数
    走独立的 quant json (build 导出的 quant_tab.json) 输入 toolkit simulator
    做量化推理。

    激活链 (量化点, 对称无 Add/Sub):
        Div(x,s) -> Add(zp) -> Round -> Clip(qmin,qmax) -> Sub(zp) -> Mul(s)
    链整体删除, x 直通到链输出 (消费者改引用; 若链输出是 graph output 则
    直接改名)。权重反量化 (w - zp) * scale 在导出时已被 torch.export 常量
    折叠成 float32 权重 initializer, 保留原样 (已是反量化值, 与 check6 的
    float 权重语义一致)。删除链后成为孤儿的 scale/zp/qmin/qmax initializer
    一并清理。

    返回 (onnx_model, stripped_count)。
    """
    _nodes = list(onnx_model.graph.node)
    _by_output = {}
    _consumers = {}
    for _n in _nodes:
        for _o in _n.output:
            if _o:
                _by_output[_o] = _n
        for _i in _n.input:
            if _i:
                _consumers.setdefault(_i, []).append(_n)

    # Build constant lookup once.  The former helper rebuilt these maps and
    # rescanned every node for every Mul candidate, making large QDQ graphs O(N^2).
    # QDQ matching only needs to know whether an input is constant; it never
    # consumes the value. Keep names instead of materializing external tensors,
    # otherwise a dynamo export would immediately load all LLM weights back.
    _constants = {_init.name for _init in onnx_model.graph.initializer}
    _identities = {}
    for _n in _nodes:
        if _n.op_type == "Constant" and len(_n.output) == 1 and len(_n.attribute) == 1:
            _tp = _n.attribute[0].t
            if _tp is not None and _tp.ByteSize() > 0:
                _constants.add(_n.output[0])
        elif _n.op_type == "Identity" and len(_n.input) == 1 and len(_n.output) == 1:
            _identities[_n.output[0]] = _n.input[0]

    def _const_value(name):
        _seen = set()
        while name not in _seen:
            _seen.add(name)
            if name in _constants:
                return True
            name = _identities.get(name)
            if name is None:
                break
        return None

    _stripped = 0
    _remove_ids = set()
    _replacements = {}
    _graph_outputs = {_output.name for _output in onnx_model.graph.output}

    def _find_previous(name, expected):
        """Find *expected* while traversing exporter-only Cast/Identity nodes."""
        _transparent = []
        _seen = set()
        while name and name not in _seen:
            _seen.add(name)
            _previous = _by_output.get(name)
            if _previous is None:
                return None, []
            if _previous.op_type == expected:
                return _previous, _transparent
            if (_previous.op_type not in ("Cast", "Identity")
                    or len(_previous.input) != 1
                    or len(_previous.output) != 1):
                return None, []
            _transparent.append(_previous)
            name = _previous.input[0]
        return None, []

    for _node in _nodes:
        if id(_node) in _remove_ids:
            continue
        if _node.op_type != "Mul" or len(_node.input) != 2:
            continue
        _scale_name = _node.input[1]
        if _const_value(_scale_name) is None:
            continue
        _sub, _sub_transparent = _find_previous(_node.input[0], "Sub")
        _chain = [_node]
        if _sub is not None and _sub.op_type == "Sub" and len(_sub.input) == 2:
            # 非对称: Div->Add->Round->Clip->Sub->Mul
            _clip, _clip_transparent = _find_previous(_sub.input[0], "Clip")
            if _clip is None or _clip.op_type != "Clip" or len(_clip.input) < 2:
                continue
            _rnd, _rnd_transparent = _find_previous(_clip.input[0], "Round")
            if _rnd is None or _rnd.op_type != "Round":
                continue
            _add, _add_transparent = _find_previous(_rnd.input[0], "Add")
            if _add is None or _add.op_type != "Add" or len(_add.input) != 2:
                continue
            _div, _div_transparent = _find_previous(_add.input[0], "Div")
            if _div is None or _div.op_type != "Div" or len(_div.input) != 2:
                continue
            # Torch export may materialize the same zero-point twice under
            # different initializer names (for example ``Add_zp`` and
            # ``onnx::Sub_*``).  Both must be constants; name identity is not
            # required for the QDQ pattern.
            if (_div.input[1] != _scale_name
                    or _const_value(_add.input[1]) is None
                    or _const_value(_sub.input[1]) is None):
                continue
            # Clip 的 min 是 qmin 常量 (如 -128), 不要求等于 zp; max 是 qmax 常量
            _chain = ([_node] + _sub_transparent + [_sub] + _clip_transparent
                      + [_clip] + _rnd_transparent + [_rnd] + _add_transparent
                      + [_add] + _div_transparent + [_div])
        else:
            # 对称: Div->Round->Clip->Mul (无 Add/Sub, zp 省略)
            _clip, _clip_transparent = _find_previous(_node.input[0], "Clip")
            if _clip is None or _clip.op_type != "Clip" or len(_clip.input) < 2:
                continue
            _rnd, _rnd_transparent = _find_previous(_clip.input[0], "Round")
            if _rnd is None or _rnd.op_type != "Round":
                continue
            _div, _div_transparent = _find_previous(_rnd.input[0], "Div")
            if _div is None or _div.op_type != "Div" or len(_div.input) != 2:
                continue
            if _div.input[1] != _scale_name:
                continue
            _chain = ([_node] + _clip_transparent + [_clip] + _rnd_transparent
                      + [_rnd] + _div_transparent + [_div])
        if any(id(_c) in _remove_ids for _c in _chain):
            continue

        # Every intermediate value must be private to this chain.  Stripping a
        # shared QDQ prefix would otherwise change the semantics of its side branch.
        _forward_chain = list(reversed(_chain))
        _private = True
        for _current, _next in zip(_forward_chain[:-1], _forward_chain[1:]):
            _out = _current.output[0]
            if _out in _graph_outputs or [id(n) for n in _consumers.get(_out, [])] != [id(_next)]:
                _private = False
                break
        if not _private:
            continue

        # Record exact node identities and rewrite all consumers in one linear pass.
        _in, _out = _div.input[0], _node.output[0]
        if _in != _out:
            _replacements[_out] = _in
        for _c in _chain:
            _remove_ids.add(id(_c))
        _stripped += 1

    if _remove_ids:
        def _resolve(name):
            _seen = set()
            while name in _replacements and name not in _seen:
                _seen.add(name)
                name = _replacements[name]
            return name

        _kept = [_node for _node in _nodes if id(_node) not in _remove_ids]
        for _node in _kept:
            for _index, _name in enumerate(_node.input):
                _node.input[_index] = _resolve(_name)
        for _output in onnx_model.graph.output:
            _output.name = _resolve(_output.name)
        del onnx_model.graph.node[:]
        onnx_model.graph.node.extend(_kept)

    # 清理孤儿 initializer (链删除后无节点引用的 scale/zp/qmin/qmax 常量)
    if _stripped:
        _refs = set()
        for _n2 in onnx_model.graph.node:
            _refs.update(_i for _i in _n2.input if _i)
        _g_out = {_g.name for _g in onnx_model.graph.output}
        _removed = 0
        _kept_initializers = []
        for _init in onnx_model.graph.initializer:
            if _init.name in _refs or _init.name in _g_out:
                _kept_initializers.append(_init)
            else:
                _removed += 1
        del onnx_model.graph.initializer[:]
        onnx_model.graph.initializer.extend(_kept_initializers)
        if _removed:
            print("  Removed {} orphan initializers (stripped QDQ scale/zp consts)".format(_removed))

    if _stripped:
        print("  QDQ stripped: {} activation fake-quant chains -> float pass-through".format(_stripped))
    return onnx_model, _stripped


def _strip_identity_nodes(onnx_model):
    """Remove exporter-only one-input Identity nodes from the graph."""
    _replacements = {}
    _kept = []
    for _node in onnx_model.graph.node:
        if (_node.op_type == "Identity" and len(_node.input) == 1
                and len(_node.output) == 1):
            _replacements[_node.output[0]] = _node.input[0]
        else:
            _kept.append(_node)

    if not _replacements:
        return 0

    def _resolve(name):
        _seen = set()
        while name in _replacements and name not in _seen:
            _seen.add(name)
            name = _replacements[name]
        return name

    for _node in _kept:
        for _index, _name in enumerate(_node.input):
            _node.input[_index] = _resolve(_name)
    for _output in onnx_model.graph.output:
        _output.name = _resolve(_output.name)
    del onnx_model.graph.node[:]
    onnx_model.graph.node.extend(_kept)
    return len(_replacements)


def _restore_distinct_initializers(check6_model, regen_model):
    """Align regenerated initializer identity with the check6 graph.

    Different check6 tensors may have identical values (including empty Resize
    ROI tensors).  TorchScript is allowed to emit one shared initializer for
    them; conversely, it can copy one shared check6 initializer to several
    generated names.  Clone the first case and merge only byte-identical
    tensors in the second case so structural input identity remains stable
    without discarding an intentional generated-weight edit.
    """
    if check6_model is None:
        return 0
    check_nodes = list(check6_model.graph.node)
    regen_nodes = list(regen_model.graph.node)
    if len(check_nodes) != len(regen_nodes):
        return 0
    if any(check.op_type != regen.op_type
           for check, regen in zip(check_nodes, regen_nodes)):
        return 0
    if any(len(check.input) != len(regen.input)
           for check, regen in zip(check_nodes, regen_nodes)):
        # Validate the complete topology before mutating any node or
        # initializer.  A late mismatch must not leave a partially repaired
        # graph behind.
        return 0

    initializers = {
        initializer.name: initializer
        for initializer in regen_model.graph.initializer
    }

    used_names = set(initializers)
    reverse_map = {}
    forward_map = {}
    merge_candidates = set()
    cloned = 0
    merged = 0

    def initializer_payload_equal(left, right):
        if (left.data_type != right.data_type
                or tuple(left.dims) != tuple(right.dims)):
            return False
        try:
            left_array = np.ascontiguousarray(
                onnx.numpy_helper.to_array(left))
            right_array = np.ascontiguousarray(
                onnx.numpy_helper.to_array(right))
            return (
                left_array.dtype == right_array.dtype
                and left_array.shape == right_array.shape
                and left_array.tobytes() == right_array.tobytes()
            )
        except Exception:
            # Unresolved external-data tensors cannot be proven equal from
            # values.  Accept only identical serialized payload metadata;
            # otherwise preserve both tensors and favor correctness over a
            # cosmetic identity match.
            left_copy = onnx.TensorProto()
            right_copy = onnx.TensorProto()
            left_copy.CopyFrom(left)
            right_copy.CopyFrom(right)
            left_copy.name = ''
            right_copy.name = ''
            return left_copy.SerializeToString() == \
                right_copy.SerializeToString()

    for check_node, regen_node in zip(check_nodes, regen_nodes):
        for index, (check_name, regen_name) in enumerate(
                zip(check_node.input, regen_node.input)):
            if not check_name or regen_name not in initializers:
                continue
            canonical_name = forward_map.get(check_name)
            if canonical_name is not None and canonical_name != regen_name:
                # Both edges correspond to the very same check6 initializer.
                # Merge only when the generated values are also identical.
                # A user may deliberately edit one occurrence in generated.py;
                # source identity must not erase that edit during rebuild.
                if initializer_payload_equal(
                        initializers[canonical_name],
                        initializers[regen_name]):
                    regen_node.input[index] = canonical_name
                    merge_candidates.add(regen_name)
                    merged += 1
                else:
                    reverse_map.setdefault(regen_name, check_name)
                continue
            previous = reverse_map.get(regen_name)
            if previous in (None, check_name):
                reverse_map[regen_name] = check_name
                forward_map.setdefault(check_name, regen_name)
                continue
            new_name = sanitize_name(check_name)
            if new_name in used_names:
                suffix = 1
                while "{}_{}".format(new_name, suffix) in used_names:
                    suffix += 1
                new_name = "{}_{}".format(new_name, suffix)
            clone = onnx.TensorProto()
            clone.CopyFrom(initializers[regen_name])
            clone.name = new_name
            regen_model.graph.initializer.append(clone)
            initializers[new_name] = clone
            used_names.add(new_name)
            regen_node.input[index] = new_name
            reverse_map[new_name] = check_name
            forward_map[check_name] = new_name
            cloned += 1

    if merge_candidates:
        references = {
            name for node in regen_model.graph.node for name in node.input
            if name
        }
        references.update(output.name for output in regen_model.graph.output)
        kept = [
            initializer for initializer in regen_model.graph.initializer
            if initializer.name not in merge_candidates
            or initializer.name in references
        ]
        del regen_model.graph.initializer[:]
        regen_model.graph.initializer.extend(kept)
    return cloned + merged


def _restore_saved_regen_initializers(check6_path, regen_path):
    """Restore initializer identity after file-based layout corrections."""
    check6_model = onnx.load(check6_path, load_external_data=False)
    regen_model = onnx.load(regen_path, load_external_data=False)
    restored = _restore_distinct_initializers(check6_model, regen_model)
    if restored:
        # Both models keep external-data references unresolved, so this rewrite
        # updates only graph metadata and does not duplicate large LLM weights.
        onnx.save_model(regen_model, regen_path)
    return restored


def _export_with_all_lora(model, export_call):
    """Export model structure without freezing the current LoRA selection."""
    if not getattr(model, "_lora_metadata", None):
        return export_call()
    previous = None
    if hasattr(model, "prepare_lora_export"):
        previous = model.prepare_lora_export()
    try:
        return export_call()
    finally:
        if hasattr(model, "restore_lora_export"):
            model.restore_lora_export(previous)


def _export_with_float_quant_weights(model, export_call):
    """Trace a quantized artifact as the float graph consumed by rebuild."""
    if not getattr(model, "_quantized", False):
        return export_call()
    if not hasattr(model, "prepare_quant_export"):
        raise RuntimeError(
            "Quantized generated model does not support float-weight export")
    state = model.prepare_quant_export()
    try:
        return export_call()
    finally:
        model.restore_quant_export(state)


def _remove_dead_tuple_pythonops(graph: torch._C.Graph) -> int:
    """Drop unused tuple PythonOps before legacy TorchScript tuple lowering.

    PyTorch's dead-code pass assumes each node with a sub-block has the same
    number of outputs as its block return. A traced multi-output autograd
    Function can have one tuple output and several block returns. Usually a
    TupleUnpack keeps it live and the exporter normalizes it, but an unused
    exmpiBCast control-state output leaves the mismatch and triggers an
    internal assertion. Only nodes with *no* output uses can be removed here.
    """
    removed = 0
    for node in list(graph.nodes()):
        if (node.kind() != "prim::PythonOp"
                or not node.pyname().startswith("_exmpiBCast_")
                or not node.pyname().endswith("_Symbolic")):
            continue
        outputs = list(node.outputs())
        blocks = list(node.blocks())
        if len(outputs) != 1 or len(blocks) != 1:
            continue
        if len(list(blocks[0].returnNode().inputs())) == 1:
            continue
        if list(outputs[0].uses()):
            continue
        node.destroy()
        removed += 1
    return removed


@contextmanager
def _legacy_export_tuple_dce_workaround() -> Iterator[None]:
    original = torch._C._jit_pass_lower_all_tuples

    def lower_tuples(graph: torch._C.Graph) -> None:
        removed = _remove_dead_tuple_pythonops(graph)
        if removed:
            print("  Removed {} unused tuple-valued PythonOp(s) before "
                  "TorchScript lowering".format(removed))
        return original(graph)

    torch._C._jit_pass_lower_all_tuples = lower_tuples
    try:
        yield
    finally:
        torch._C._jit_pass_lower_all_tuples = original


def export_preserve_onnx(model, fake_inputs, output_path, opset_version, original_onnx=None,
                         quant_tab_json=None, force_dynamo=False):
    """Closed-loop preserve export, using the selected exporter and graph cleanup.

    This rebuilds the ONNX from the PyTorch model (true re-export, not a copy),
    preserving ex* ops as gongga:: nodes (via symbolic wrappers) and node naming
    (via dynamo=False submodule-name prefixing). Redundant FLOAT->FLOAT Cast
    nodes inserted by TorchScript are removed in post-processing.
    """
    if hasattr(model, "reset_cache_state"):
        model.reset_cache_state()
    # 回导 onnx 关闭 float16 激活模拟 (_fp16_sim): 精度仿真 (forward/sim verify)
    # 默认开启, 但导出时 fp32->fp16->fp32 双 Cast 在 torch.onnx.export 大图
    # 优化下会丢失回程 Cast, 导致下游 Mul 等输入类型不匹配 (fp16 vs fp32),
    # 回导 onnx 无法被 runtime 加载。关闭后回导是纯 float32 图 (结构一致)。
    # 量化模型回导: forward 保留完整 QDQ 仿真 (权重反量化 + 激活 fake quant),
    # 导出后处理 _strip_qdq_to_float 把激活 fake quant 展开链删除 (QDQ-strip),
    # 回导 onnx 是纯 float32 图 (结构与 check6 一致), 量化参数由 build 导出
    # 的 quant_tab.json 提供 (输入 toolkit simulator 做量化推理)。
    _is_quantized = bool(getattr(model, "_quantized", False))
    export_args = tuple(_as_output_sequence(fake_inputs))
    model_device = _infer_model_device(model, export_args)
    export_args = _move_export_args_to_device(export_args, model_device)

    common_kwargs = {
        # Quantized preserve export temporarily materializes float weights and
        # bypasses generated QDQ helpers, so no QuantizeLinear clamp signature
        # remains that would require downgrading an opset-19 source to 18.
        "opset_version": opset_version,
        # Quantized preserve export must keep QDQ/dequant chains until the
        # structural post-pass removes them. Exporter constant folding can
        # materialize compact W4/group weights as tens of gigabytes of float
        # constants (and OOM both CUDA and constrained host processes).
        # Non-quantized preserve export keeps the historical folding behavior.
        "do_constant_folding": not _is_quantized,
    }

    # Register symbolic overrides for standard ops whose default TorchScript
    # symbolic produces extra nodes (ConstantOfShape/Equal/Where/Mul).
    # aten::expand: default symbolic turns tensor shape into ConstantOfShape;
    # override to emit a single ONNX Expand node directly.
    from torch.onnx import register_custom_op_symbolic
    _expand_sym_registered = getattr(_expand_symbolic_wrapper, "_registered", False)
    if not _expand_sym_registered:
        register_custom_op_symbolic("aten::expand", _expand_symbolic_wrapper, opset_version)
        register_custom_op_symbolic("aten::isnan", _isnan_symbolic_wrapper, opset_version)
        register_custom_op_symbolic("aten::where", _where_symbolic_wrapper, opset_version)
        _expand_symbolic_wrapper._registered = True
        print("  Registered symbolic overrides: aten::expand, aten::isnan, aten::where (opset {})".format(opset_version))

    start_time = time.perf_counter()
    if force_dynamo:
        # LLM 大模型: TorchScript(dynamo=False) 导出峰值内存 ~333GB 会 OOM,
        # 改走 FX(dynamo=True) + external_data 导出 (权重存 .data 文件,
        # 不内嵌 protobuf, 内存友好; 节点为标准 op 展开)。
        # torchlib functions require opset >= 18. Keep that lower bound, but
        # do not downgrade the source graph's requested opset.
        _dyn_opset = max(18, int(opset_version or 18))
        if _is_quantized:
            _patch_dynamo_registry()
        _old_fp16_sim = getattr(model, "_fp16_sim", None)
        if _is_quantized and _old_fp16_sim:
            model._fp16_sim = False  # 回导导出关 float16 模拟, 避免类型不匹配
        try:
            _export_with_all_lora(
                model,
                lambda: _export_with_float_quant_weights(
                    model,
                    lambda: torch.onnx.export(
                        model, export_args, output_path, dynamo=True,
                        external_data=True, do_constant_folding=False,
                        opset_version=_dyn_opset)))
        finally:
            if _old_fp16_sim is not None:
                model._fp16_sim = _old_fp16_sim
        elapsed = time.perf_counter() - start_time
        if _is_quantized:
            # Preserve external-data references. QDQ strip is structural and
            # does not need to materialize large LLM weights in host memory.
            _onnx_qdq = onnx.load(output_path, load_external_data=False)
            _onnx_qdq, _nf = _strip_qdq_to_float(_onnx_qdq, model)
            if _nf:
                _ext_name = os.path.basename(output_path) + ".data"
                onnx.save_model(_onnx_qdq, output_path)
                print("  QDQ-stripped ONNX saved (external data: {})".format(_ext_name))
        print("Exported regenerated ONNX (LLM revert, dynamo=True+external_data): {}".format(output_path))
        return elapsed
    _old_fp16_sim = getattr(model, "_fp16_sim", None)
    if _is_quantized and _old_fp16_sim:
        model._fp16_sim = False  # 回导导出关 float16 模拟, 避免类型不匹配
    try:
        with _legacy_export_tuple_dce_workaround():
            _export_with_all_lora(
                model,
                lambda: _export_with_float_quant_weights(
                    model,
                    lambda: torch.onnx.export(
                        model, export_args, output_path, dynamo=False,
                        **common_kwargs)))
    finally:
        if _old_fp16_sim is not None:
            model._fp16_sim = _old_fp16_sim
    export_elapsed = time.perf_counter() - start_time

    # Post-process: remove redundant FLOAT->FLOAT Cast nodes.
    # Load with external data (weights in .data file for large models).
    onnx_model = onnx.load(output_path, load_external_data=True)

    # Convert non-FLOAT initializers (DOUBLE/INT64 mask tensors) to FLOAT.
    # TorchScript inserts Cast(DOUBLE) around every op touching these tensors,
    # inflating the graph. Converting them to FLOAT before Cast removal makes
    # all those Casts redundant (FLOAT->FLOAT) so they get eliminated.
    from onnx import numpy_helper, TensorProto
    init_map = {init.name: init for init in onnx_model.graph.initializer}
    _double_converted = 0
    _total_non_float = 0
    for init in onnx_model.graph.initializer:
        if init.data_type != TensorProto.FLOAT:
            _total_non_float += 1
        if init.data_type == TensorProto.DOUBLE and len(init.raw_data) > 0:
            arr = numpy_helper.to_array(init).astype('float32')
            new_init = numpy_helper.from_array(arr, name=init.name)
            init.CopyFrom(new_init)
            _double_converted += 1
    if _total_non_float:
        print("  Non-FLOAT inits: {} (DOUBLE converted: {})".format(_total_non_float, _double_converted))

    onnx_model, removed = _remove_redundant_casts(onnx_model)
    # 量化模型回导: torch 把 Resize scales 等常量导出为 Constant 节点,
    # 折叠成 initializer, 使节点数与 quant.onnx 一致 (quant.onnx 无 Constant 节点)
    if _is_quantized:
        _folded = 0
        _kept_nodes = []
        for _node in onnx_model.graph.node:
            if _node.op_type == "Constant" and len(_node.attribute) == 1:
                _tp = _node.attribute[0].t
                if _tp is not None and _tp.ByteSize() > 0:
                    _init = onnx.numpy_helper.from_array(
                        onnx.numpy_helper.to_array(_tp), name=_node.output[0])
                    onnx_model.graph.initializer.append(_init)
                    _folded += 1
                    continue
            _kept_nodes.append(_node)
        if _folded:
            # Rebuild the protobuf repeated field once. Calling remove() for
            # every Constant is quadratic on LLM graphs with tens of thousands
            # of nodes.
            del onnx_model.graph.node[:]
            onnx_model.graph.node.extend(_kept_nodes)
            print("  Folded {} Constant nodes into initializers".format(_folded))
        # QDQ strip 必须在 Constant 折叠之后 (scale/zp/qmin/qmax 需为 initializer)
        onnx_model, _n_stripped = _strip_qdq_to_float(onnx_model, model)
        _identity_stripped = _strip_identity_nodes(onnx_model)
        if _identity_stripped:
            print("  Removed {} exporter Identity nodes".format(_identity_stripped))
        _dedup_cloned = _restore_distinct_initializers(
            original_onnx, onnx_model)
        if _dedup_cloned:
            print(
                "  Restored {} distinct check6 initializer(s) merged by "
                "Torch export".format(_dedup_cloned))
    _exporter_casts = _strip_exporter_only_casts(
        onnx_model, original_onnx)
    if _exporter_casts:
        print(
            "  Removed {} exporter-only Cast nodes to match check6".format(
                _exporter_casts))
    onnx_model, fused = _fuse_pad_into_conv(onnx_model, original_onnx)
    if fused:
        print("  Fused {} Pad->Conv patterns".format(fused))
    # Run initializer identity repair only after every topology cleanup.  At
    # this point external tensors are loaded, allowing byte-identical aliases
    # to be merged without guessing from unresolved external-data references.
    _final_initializer_repairs = _restore_distinct_initializers(
        original_onnx, onnx_model)
    if _final_initializer_repairs:
        print(
            "  Finalized {} check6 initializer identity mapping(s)".format(
                _final_initializer_repairs))
    # Count remaining Casts before save (for debugging).
    _cast_before_save = sum(1 for n in onnx_model.graph.node if n.op_type == "Cast")
    # Save with external data (handles >2GB models that exceed protobuf limit).
    # Use a fixed external data filename to avoid accumulating UUID-named files.
    ext_data_name = os.path.basename(output_path) + ".data"
    # Save WITHOUT shape inference: onnx.save_model runs shape inference by
    # default, which re-inserts Cast nodes we just removed.
    onnx.save_model(onnx_model, output_path, save_as_external_data=True,
                    location=ext_data_name)
    total_elapsed = time.perf_counter() - start_time

    print("Exported regenerated ONNX (preserve, dynamo=False): {}".format(output_path))
    print("  Removed {} redundant Cast nodes in {:.4f}s".format(removed, total_elapsed - export_elapsed))
    print("  Cast before save: {}, after removal: {}".format(removed + _cast_before_save, _cast_before_save))
    return total_elapsed


def export_torch_to_onnx(model, fake_inputs, output_path, opset_version,
                         preserve_custom_ops=False):
    # Reset KV/streaming cache before tracing. A prior forward pass (e.g. the
    # PyTorch correctness run) may have populated cache_state in stateful ops
    # (exAttention KV cache, exConvStreaming tail, exLinearAttention recurrent
    # state). Tracing with stale cache appends the cached tail to the current
    # input, changing tensor sizes and breaking reshapes downstream.
    if hasattr(model, "reset_cache_state"):
        model.reset_cache_state()

    # Replace forward with trace-friendly versions for export:
    # - forward_no_cache for cache ops (exAttention): skip KV cache dict ops
    # - forward_symbolic for sub-modules (exSDPAttention): avoid dynamic shape indexing
    # Skip modules whose forward already uses a Symbolic autograd.Function (e.g.
    # Pad_sym, exSwish_sym): their symbolic() method emits the correct ONNX node
    # and should not be overridden by forward_symbolic (which uses F.pad/ops that
    # TorchScript may fuse into downstream ops like Conv).
    def _patch_for_export(m):
        for name, child in m.named_children():
            _patch_for_export(child)
            if hasattr(child, "forward_no_cache"):
                child.forward = child.forward_no_cache
                child._export_no_cache = True
                child._node_wrapped = False
            elif hasattr(child, "forward_symbolic") and type(child).__name__.endswith("_sym"):
                # _sym classes already dispatch via autograd.Function with symbolic()
                pass
            elif hasattr(child, "forward_symbolic"):
                child.forward = child.forward_symbolic
                child._node_wrapped = False
    _patch_for_export(model)
    if hasattr(model, "_wrap_nodes"):
        model._wrap_nodes()

    export_args = tuple(_as_output_sequence(fake_inputs))
    model_device = _infer_model_device(model, export_args)
    export_args = _move_export_args_to_device(export_args, model_device)

    # Keep legacy exporter robust on large models where constant folding mixes devices.
    common_kwargs = {
        "opset_version": opset_version,
        "do_constant_folding": False,
    }
    has_paged_attention = any(
        type(child).__name__ == "exPagedAttention_torch"
        for child in model.modules()
    )
    if has_paged_attention:
        common_kwargs["input_names"] = list(model.INPUT_ORIGINAL_NAMES)
        common_kwargs["output_names"] = list(model.OUTPUT_NAMES)

    # 量化模型回导: 导出前关 float16 激活模拟 (_fp16_sim), 避免 fp32->fp16->fp32
    # 双 Cast 在大图导出时被优化丢失回程 Cast 导致类型不匹配 (见 export_preserve_onnx)。
    def _do_export(*a, **k):
        old_fp16_sim = getattr(model, "_fp16_sim", None)
        if old_fp16_sim is not None:
            model._fp16_sim = False
        try:
            return _export_with_all_lora(
                model, lambda: torch.onnx.export(*a, **k))
        finally:
            if old_fp16_sim is not None:
                model._fp16_sim = old_fp16_sim

    start_time = time.perf_counter()

    # preserve_custom_ops: force dynamo=False (preserves submodule-name-based node
    # naming). ex* ops are already patched to emit gongga:: nodes via symbolic.
    # Fall back to dynamo=True if dynamo=False crashes (large models with control flow).
    if preserve_custom_ops:
        try:
            _do_export(model, export_args, output_path, dynamo=False, **common_kwargs)
            print("Exported regenerated ONNX (preserve_custom_ops, dynamo=False): {}".format(output_path))
            elapsed_sec = time.perf_counter() - start_time
            return elapsed_sec
        except Exception as exc:
            print("preserve_custom_ops dynamo=False failed ({}), fallback to dynamo=True".format(
                type(exc).__name__))
            if hasattr(model, "reset_cache_state"):
                model.reset_cache_state()
            _do_export(model, export_args, output_path, dynamo=True, **common_kwargs)
            print("Exported regenerated ONNX (preserve_custom_ops fallback, dynamo=True): {}".format(output_path))
            elapsed_sec = time.perf_counter() - start_time
            return elapsed_sec

    if has_paged_attention or _model_contains_range_op(model):
        print("Skip dynamo=True export for paged attention or data-dependent Range; use dynamo=False directly")
        _do_export(model, export_args, output_path, dynamo=False, **common_kwargs)
        print("Exported regenerated ONNX with dynamo=False: {}".format(output_path))
        elapsed_sec = time.perf_counter() - start_time
        return elapsed_sec

    try:
        _do_export(model, export_args, output_path, dynamo=True, **common_kwargs)
        print("Exported regenerated ONNX with dynamo=True: {}".format(output_path))
        elapsed_sec = time.perf_counter() - start_time
        return elapsed_sec
    except Exception as exc:
        print(
            "dynamo=True export failed ({}: {}), fallback to dynamo=False".format(
                type(exc).__name__, exc
            )
        )
        # Re-align args to model device again in case caller switched device after fallback.
        model_device = _infer_model_device(model, export_args)
        export_args = _move_export_args_to_device(export_args, model_device)
        # Reset cache again: dynamo=True tracing may have populated cache_state
        # in stateful ops before failing, which would corrupt the dynamo=False retry.
        if hasattr(model, "reset_cache_state"):
            model.reset_cache_state()
        _do_export(model, export_args, output_path, dynamo=False, **common_kwargs)
        print("Exported regenerated ONNX with dynamo=False: {}".format(output_path))
        elapsed_sec = time.perf_counter() - start_time
        return elapsed_sec


def main():
    args = parse_args()
    fast_artifact_mode = bool(args.artifact_fast_mode)
    os.makedirs(args.artifacts_dir, exist_ok=True)
    generated_py = resolve_artifact_path(args.generated_py, args.artifacts_dir)
    generated_onnx = resolve_artifact_path(args.generated_onnx, args.artifacts_dir)
    model_path = resolve_model_path(args.model)
    input_preprocess = None
    if args.input_preprocess_json:
        with open(args.input_preprocess_json, encoding="utf-8") as _f:
            input_preprocess = json.load(_f)
    lora_metadata = None
    if args.lora_metadata_json:
        with open(args.lora_metadata_json, encoding="utf-8") as _file:
            lora_metadata = json.load(_file)

    onnx_model = onnx.load(model_path)
    has_custom_domain = _has_custom_domain(onnx_model)

    # ---- 量化模型检测: 提供 --quant-json 或 onnx 首节点为 exDataConvert ----
    quant_params = None
    _quant_params_npz = None
    _quant_params_raw = None   # 未解析 npy ref 的原始 quant json (scale/zp 仍为字符串 key)
    if args.quant_json:
        if not os.path.exists(args.quant_json):
            raise RuntimeError("Quant JSON not found: {}".format(args.quant_json))
        quant_params, _quant_params_raw, _quant_params_npz = _load_quant_tab(
            args.quant_json)
        print("Loaded {} quant params from {}".format(len(quant_params), args.quant_json))
    is_quant = quant_params is not None or (
        len(onnx_model.graph.node) > 0 and onnx_model.graph.node[0].op_type == "exDataConvert"
    )
    if is_quant:
        # 量化模型走独立 manifest；跳过无 quant_tab 的浮点基线，回导后使用
        # check6 + quant_tab 的 OnnxSimulator 与 PyTorch QDQ 做同语义验证。
        fast_artifact_mode = True
        print("Quantized model: skip float baselines; run PyTorch QDQ and "
              "quant-aware check6 verification.")
    if fast_artifact_mode:
        print("Artifact fast mode enabled: skip initial Base A and Toolkit simulator runs.")

    remove_initializers_from_inputs(onnx_model)
    baseline_rknn_model = None
    baseline_rknn_const_values = None
    if not is_quant and not fast_artifact_mode:
        # Only the non-quantized path runs the RKNN graph-session baseline.
        # Fast artifact mode also skips this copy: its baseline consumers are
        # disabled, and retaining another full LLM weight set only wastes RAM.
        baseline_rknn_model = copy.deepcopy(onnx_model)
        restore_check_weights(
            baseline_rknn_model, model_path,
            _quant_params_raw, _quant_params_npz)
        baseline_rknn_const_values = get_const_map(
            baseline_rknn_model,
            required_names=collect_required_initializers(baseline_rknn_model),
        )
        # onnx.shape_inference 对携带大 raw_data 的 initializer (如 LLM 外部数据权重)
        # 会返回空图 (onnx>=1.16 的已知行为), 导致 IRGraph 建出空图。const 数据已全部
        # 移入 baseline_rknn_const_values, 这里清掉 initializer 的 embedded data,
        # 让 IRGraph 只持有小 protobuf, 权重从 const map 读取。
        for _c in baseline_rknn_model.graph.initializer:
            # Reshape/Split/Gather 等 shape inference 依赖小型 INT64 常量。
            # 保留这些常量不会明显增加内存，却可避免大模型形状推断断链；
            # 大权重仍从 protobuf 移出，由 initializer_dat 持有。
            _keep_small_int64 = _c.data_type == onnx.TensorProto.INT64 and (
                (bool(_c.raw_data) and len(_c.raw_data) <= 4096)
                or (bool(_c.int64_data) and len(_c.int64_data) * 8 <= 4096)
            )
            if not _keep_small_int64:
                _c.ClearField("raw_data")
                _c.ClearField("float_data")
                _c.ClearField("int32_data")
                _c.ClearField("int64_data")
                _c.ClearField("double_data")
                _c.ClearField("uint64_data")

    # 主流程需要 codegen (未提供 --reuse-artifacts) 时, 即使 fast + skip-regen +
    # 旧 --pytorch-artifact-dir, 也必须 materialize 权重 (codegen 依赖 onnx_model
    # 权重完整)。因此 runtime_onnx_needed 额外并入 "主流程要 codegen" 条件。
    runtime_onnx_needed = ((not fast_artifact_mode)
                           or (not args.skip_regenerated_onnx)
                           or (not args.reuse_artifacts)
                           or args.run_pytorch_accuracy_analysis)
    materialize_elapsed = 0.0
    if runtime_onnx_needed:
        materialize_start = time.perf_counter()
        # 优先从 check_external_data 回填真实权重，然后严格校验完整性。
        # 缺失权重直接失败，禁止生成结构合法但数值错误的模型。
        # 注意: 只 restore onnx_model (供 codegen), 不 restore baseline_rknn_model。
        # IRGraph 依赖 initializer_dat=const_values 读权重, 若给 baseline 的
        # initializer 填回大 raw_data, onnx.shape_inference (onnx>=1.16) 会返回
        # 空图, 导致 IRGraph 建出 0 节点 (大权重 LLM check5 实测触发)。
        restored = restore_check_weights(onnx_model, model_path, _quant_params_raw, _quant_params_npz)
        materialize_missing_initializers(onnx_model)
        materialize_elapsed = time.perf_counter() - materialize_start
        if fast_artifact_mode:
            print("Validated initializer data after restoring {} external tensor(s) in {:.4f}s.".format(
                restored, materialize_elapsed))
    else:
        print("Skip missing-initializer materialization and sanitized runtime ONNX save: reuse existing PyTorch artifacts and no runtime ONNX path is enabled.")

    if _quant_params_npz is not None:
        _quant_params_npz.close()
        _quant_params_npz = None
    _quant_params_raw = None

    config = BackendConfig.from_args(args)
    torch_device = config.torch_device
    print("PyTorch execution device: {} (backend={})".format(torch_device, config.backend))

    fake_inputs = build_fake_inputs(
        onnx_model,
        input_shape_override=args.input_shape,
        state_input_mode=args.state_input_mode,
        state_input_seed=args.state_input_seed,
        device=torch_device,
    )
    # 量化模型: 首输入适配量化范围 (0~1), 避免随机输入超出量化范围被 clip 失真。
    # 可选 --quant-input-file 提供真实图片 (uint8 0-255)。
    if is_quant and fake_inputs:
        _t0 = fake_inputs[0]
        if args.quant_input_file and not os.path.exists(args.quant_input_file):
            raise FileNotFoundError(
                "Quant input file not found: {}".format(args.quant_input_file))
        if args.quant_input_file and os.path.exists(args.quant_input_file):
            if args.quant_input_file.lower().endswith('.npy'):
                _arr = np.load(args.quant_input_file)
                _target_shape = tuple(int(_dim) for _dim in _t0.shape)
                if tuple(_arr.shape) != _target_shape:
                    if (_arr.ndim == 4 and len(_target_shape) == 4
                            and (_arr.shape[0], _arr.shape[3],
                                 _arr.shape[1], _arr.shape[2]) == _target_shape):
                        _arr = _arr.transpose(0, 3, 1, 2)
                    elif _arr.size == int(np.prod(_target_shape)):
                        _arr = _arr.reshape(_target_shape)
                    else:
                        raise ValueError(
                            "Quant input shape {} does not match model input {}".format(
                                tuple(_arr.shape), _target_shape))
                if np.issubdtype(_arr.dtype, np.integer):
                    _arr = _arr.astype(np.float32) / 255.0
                fake_inputs[0] = torch.from_numpy(np.asarray(_arr)).to(
                    device=_t0.device, dtype=_t0.dtype)
                print("Quant model input: loaded tensor {}".format(
                    args.quant_input_file))
            else:
                from PIL import Image
                import numpy as _np
                _img = Image.open(args.quant_input_file).convert("RGB")
                if _t0.ndim == 4:
                    _img = _img.resize((_t0.shape[3], _t0.shape[2]))
                    _arr = _np.array(_img).transpose(2, 0, 1)[None].astype(_np.float32) / 255.0
                else:
                    _arr = _np.array(_img)[None].astype(_np.float32) / 255.0
                fake_inputs[0] = torch.from_numpy(_arr).to(device=_t0.device, dtype=_t0.dtype)
                print("Quant model input: loaded image {}".format(args.quant_input_file))
        else:
            _min, _max = float(_t0.min()), float(_t0.max())
            if _max - _min > 1e-6:
                fake_inputs[0] = (_t0 - _min) / (_max - _min)   # 归一到 [0,1]
                print("Quant model input: normalized first input to [0,1] (was [{:.2f},{:.2f}])".format(_min, _max))

    pytorch_inputs = move_to_device(fake_inputs, torch_device)
    torch_profiler_options = {
        "enabled": args.torch_profile,
        "trace_dir": args.torch_profile_dir or os.path.join(args.artifacts_dir, "torch_profile"),
        "row_limit": args.torch_profile_row_limit,
        "record_shapes": args.torch_profile_record_shapes,
        "profile_memory": args.torch_profile_memory,
        "with_stack": args.torch_profile_with_stack,
    }
    if args.torch_profile:
        print(
            "Torch profiler enabled: trace_dir={} row_limit={} record_shapes={} profile_memory={} with_stack={}".format(
                torch_profiler_options["trace_dir"],
                torch_profiler_options["row_limit"],
                torch_profiler_options["record_shapes"],
                torch_profiler_options["profile_memory"],
                torch_profiler_options["with_stack"],
            )
        )

    original_onnx_output = None
    original_onnx_providers = None
    original_onnx_elapsed = None
    onnx_simulator_output = None
    onnx_simulator_providers = None
    onnx_simulator_elapsed = None
    onnx_simulator_profile = None
    pytorch_simulator_output = None
    pytorch_simulator_providers = None
    pytorch_simulator_elapsed = None
    pytorch_simulator_profile = None
    pytorch_accuracy_analysis_elapsed = None
    pytorch_accuracy_analysis_dir = None
    if not fast_artifact_mode:
        print("Run Original ONNX Base A (RKNN graph-session simulation) for {}".format(model_path))
        try:
            original_onnx_output, original_onnx_providers, original_onnx_elapsed = run_rknn_numpy_baseline(
                baseline_rknn_model,
                fake_inputs,
                baseline_rknn_const_values,
                model_label=model_path + " (original onnx base A rknn graph session)",
                lora_metadata=lora_metadata,
            )
        except Exception as exc:
            raise RuntimeError(
                "Original ONNX Base A (RKNN graph-session simulation) failed: {}. "
                "A path is the mandatory golden baseline. "
                "Current RKNN baseline path uses RKNN graph execution framework (IRGraph+Session).".format(exc)
            )

    if is_quant:
        print("Quantized model: defer Toolkit ONNX Simulator to the "
              "check6 + quant_tab verification stage.")
        onnx_simulator_output = None
        onnx_simulator_providers = None
        onnx_simulator_elapsed = None
        onnx_simulator_profile = None
    elif not fast_artifact_mode:
        print("Run Toolkit ONNX Simulator for {}".format(model_path))
        try:
            onnx_simulator_output, onnx_simulator_providers, onnx_simulator_elapsed, onnx_simulator_profile = run_toolkit_simulator(
                "onnx",
                baseline_rknn_model,
                fake_inputs,
                baseline_rknn_const_values,
                model_label=model_path + " (toolkit onnx simulator)",
                lora_metadata=lora_metadata,
            )
        except Exception as exc:
            print("Toolkit ONNX Simulator failed: {}".format(exc))

    if not fast_artifact_mode:
        print("Run Toolkit PyTorch Simulator for {}".format(model_path))
        try:
            pytorch_simulator_output, pytorch_simulator_providers, pytorch_simulator_elapsed, pytorch_simulator_profile = run_toolkit_simulator(
                "pytorch",
                baseline_rknn_model,
                fake_inputs,
                baseline_rknn_const_values,
                model_label=model_path + " (toolkit pytorch simulator)",
                pytorch_artifact_dir=args.pytorch_artifact_dir,
                profiler_options=torch_profiler_options,
                lora_metadata=lora_metadata,
            )
        except Exception as exc:
            print("Toolkit PyTorch Simulator failed: {}".format(exc))

    if args.run_pytorch_accuracy_analysis:
        pytorch_accuracy_analysis_dir = args.pytorch_accuracy_dir or os.path.join(
            args.artifacts_dir,
            "accuracy_analysis",
            "pytorch_simulator",
        )
        print("Run Toolkit PyTorch Simulator accuracy_analysis for {}".format(model_path))
        try:
            from onnx import numpy_helper
            analysis_model = baseline_rknn_model if baseline_rknn_model is not None else onnx_model
            analysis_consts = (
                baseline_rknn_const_values
                if baseline_rknn_const_values is not None
                else {
                    init.name: np.asarray(numpy_helper.to_array(init))
                    for init in onnx_model.graph.initializer
                }
            )
            _, pytorch_accuracy_analysis_elapsed, pytorch_accuracy_analysis_dir = run_toolkit_pytorch_accuracy_analysis(
                analysis_model,
                fake_inputs,
                analysis_consts,
                pytorch_artifact_dir=(
                    args.pytorch_artifact_dir or args.reuse_artifacts),
                output_dir=pytorch_accuracy_analysis_dir,
                model_label=model_path + " (toolkit pytorch simulator accuracy_analysis)",
                quant_json=args.quant_json,
                lora_metadata=lora_metadata,
            )
        except Exception as exc:
            print("Toolkit PyTorch Simulator accuracy_analysis failed: {}".format(exc))

    # Baseline graph/weights are not used by codegen, Torch loading, or ONNX
    # re-export. Release them before materializing the Torch model.
    del baseline_rknn_model, baseline_rknn_const_values
    gc.collect()

    codegen_elapsed = None
    load_elapsed = None
    model = None
    pytorch_output = None
    pytorch_elapsed = None
    direct_pytorch_available = bool(args.pytorch_artifact_dir)

    # 统一 codegen: 未量化/量化模型都默认由主流程自己重新 codegen
    # (save_onnx_to_torch + 可选 quant_params), 产物落到 artifacts_dir。
    # 与旧行为 (未量化依赖外部 gen_pytorch + --pytorch-artifact-dir) 不同:
    # 现在默认不再需要外部 codegen; 提供 --reuse-artifacts 时才复用已有产物。
    # codegen 实现随版本变化 (如 _qdq/_dequant 重构), 重新生成保证产物匹配当前实现。
    # 未量化/量化统一默认 preserve; --no-preserve 关闭 (展开 ex* 导出标准 onnx)。
    codegen_preserve = not args.no_preserve
    if not args.reuse_artifacts:
        start_time = time.perf_counter()
        gen_dir = args.artifacts_dir
        os.makedirs(gen_dir, exist_ok=True)
        generated_py_path = os.path.join(gen_dir, "generated.py")
        weights_base = os.path.join(gen_dir, "generated")
        required_names = collect_required_initializers(onnx_model)
        required_names.update(collect_lora_weight_names(lora_metadata))
        _consts = get_const_map(
            onnx_model,
            required_names=required_names,
        )
        print("Codegen {} model -> {}".format("quantized" if is_quant else "unquantized", gen_dir))
        save_onnx_to_torch(
            onnx_model, generated_py_path, get_shape_map(onnx_model), _consts,
            weight_format=args.weight_format, shard_bytes=args.shard_bytes,
            backend_map=None, onnx_model_path=model_path,
            default_device=str(torch_device),
            numpy_const_values_path=None,
            # 未量化/量化统一默认 preserve (保留 ex* 算子);
            # --no-preserve (未量化) / --quant-no-preserve (量化) 关闭时导出标准 onnx。
            preserve_custom_ops=codegen_preserve,
            quant_params=quant_params,        # 未量化时 None
            del_opt=args.del_opt,
            input_preprocess=input_preprocess,
            lora_metadata=lora_metadata,
        )
        # get_const_map materializes every initializer as a NumPy array. The
        # generated weight store owns the data after save_onnx_to_torch returns;
        # retaining this map alongside the loaded Torch state doubled host RAM.
        del _consts
        gc.collect()
        codegen_elapsed = time.perf_counter() - start_time
        direct_pytorch_available = True
        args.pytorch_artifact_dir = gen_dir
    else:
        args.pytorch_artifact_dir = args.reuse_artifacts
        # direct_pytorch_available 在 L5229 已按旧的 pytorch_artifact_dir 求值
        # (reuse 赋值在其后), 这里显式置 True, 否则 load/forward/回导全部跳过。
        direct_pytorch_available = True

    # No later phase consumes the materialized source model. Preserve export
    # reloads a lightweight source graph only when it needs attribute metadata.
    del onnx_model
    gc.collect()

    if direct_pytorch_available:
        generated_py_path = os.path.join(args.pytorch_artifact_dir, "generated.py")
        # WeightStore base_path = generated.py without extension ("generated");
        # the store appends "_weights.pth" / "_weights.npz" / "_weights_index.txt".
        weights_base = os.path.join(args.pytorch_artifact_dir, "generated")
        # Accept any supported weight format (pth/npz/sharded); verify generated.py exists.
        if not os.path.exists(generated_py_path):
            raise RuntimeError(
                "Invalid --pytorch-artifact-dir: generated.py not found in {}".format(
                    args.pytorch_artifact_dir
                )
            )
        # Verify at least one weight format exists before attempting load.
        _has_weights = any(
            os.path.exists(p) for p in (
                weights_base + "_weights.pth",
                weights_base + "_weights.npz",
                weights_base + "_weights_index.txt",
            )
        )
        if not _has_weights:
            raise RuntimeError(
                "Invalid --pytorch-artifact-dir: no generated_weights (.pth/.npz/sharded) found in {}".format(
                    args.pytorch_artifact_dir
                )
            )

        start_time = time.perf_counter()
        model_py_define = load_generated_module(generated_py_path)
        model, state_dict = load_model_from_weight_store(
            model_py_define.Model, weights_base, map_location="cpu")
        # codegen 版本不一致告警: 旧版 codegen 生成的 generated.py (无戳或戳不同)
        # 与当前实现不匹配, 建议重新 codegen; 用户手动编辑 (加 op/改参数) 不影响。
        _fp = getattr(model, "_codegen_fingerprint", None)
        if _fp != CODEGEN_FINGERPRINT:
            print("  WARNING: generated.py codegen fingerprint mismatch "
                  "(found {!r}, current {!r}); regenerate via convert without --reuse-artifacts "
                  "if the model was not manually edited".format(_fp, CODEGEN_FINGERPRINT))
        try:
            model = model.to(torch_device)
        except torch.OutOfMemoryError as exc:
            if torch_device.type != "cuda":
                raise
            print("PyTorch CUDA OOM during model.to(cuda), fallback to CPU: {}".format(exc))
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
            torch_device = torch.device("cpu")
            config.override_device(torch_device)
            pytorch_inputs = move_to_device(fake_inputs, torch_device)
            model = model.to(torch_device)
        model.eval()
        load_elapsed = time.perf_counter() - start_time

    all_comparisons = []
    if direct_pytorch_available:
        with torch.no_grad():
            try:
                if torch_device.type == "cuda":
                    torch.cuda.synchronize()
                start_time = time.perf_counter()
                pytorch_output = _run_with_torch_profiler(
                    "pytorch_forward",
                    lambda: model(*pytorch_inputs),
                    profiler_options=torch_profiler_options,
                )
                if torch_device.type == "cuda":
                    torch.cuda.synchronize()
                pytorch_elapsed = time.perf_counter() - start_time
            except torch.OutOfMemoryError as exc:
                if torch_device.type != "cuda":
                    raise
                print("PyTorch CUDA OOM during forward, fallback to CPU: {}".format(exc))
                if torch.cuda.is_available():
                    torch.cuda.empty_cache()
                torch_device = torch.device("cpu")
                config.override_device(torch_device)
                pytorch_inputs = move_to_device(fake_inputs, torch_device)
                model = instantiate_model_from_state_dict(
                    model_py_define.Model, state_dict, strict=True)
                model = model.to(torch_device)
                model.eval()
                if torch_device.type == "cuda":
                    torch.cuda.synchronize()
                start_time = time.perf_counter()
                pytorch_output = model(*pytorch_inputs)
                if torch_device.type == "cuda":
                    torch.cuda.synchronize()
                pytorch_elapsed = time.perf_counter() - start_time

            # Print per-node backend routing stats if a backend_map was configured.
            if hasattr(model, "print_backend_stats") and getattr(model, "_node_backend_map", None):
                model.print_backend_stats()

            if _outputs_have_non_finite(pytorch_output):
                print("Detected non-finite values (NaN/Inf) in PyTorch output; retry with float32 precision")

                def _run_non_finite_trace_once(device):
                    try:
                        trace_model = instantiate_model_from_state_dict(
                            model_py_define.Model, state_dict, strict=True)
                        trace_model = trace_model.to(device)
                        if hasattr(trace_model, "_debug_first_non_finite"):
                            trace_model._debug_first_non_finite = True
                        if hasattr(trace_model, "_reported_non_finite"):
                            trace_model._reported_non_finite = False
                        trace_model.eval()
                        trace_inputs = move_to_device(fake_inputs, device)
                        with torch.no_grad():
                            _ = trace_model(*trace_inputs)
                    except Exception as trace_exc:
                        print("Non-finite trace pass failed on {}: {}".format(device, trace_exc))

                _run_non_finite_trace_once(torch_device)

                def _run_retry_once(device, use_float32):
                    retry_model_local = instantiate_model_from_state_dict(
                        model_py_define.Model, state_dict, strict=True)
                    retry_model_local = retry_model_local.to(device)
                    if use_float32:
                        retry_model_local = retry_model_local.float()
                    retry_model_local.eval()
                    retry_inputs_local = move_to_device(fake_inputs, device)
                    if use_float32:
                        retry_inputs_local = _cast_floating_inputs(retry_inputs_local, torch.float32)
                    start_t = time.perf_counter()
                    retry_output_local = retry_model_local(*retry_inputs_local)
                    retry_elapsed_local = time.perf_counter() - start_t
                    return retry_model_local, retry_inputs_local, retry_output_local, retry_elapsed_local

                def _run_retry_with_dtype_fallback(device):
                    try:
                        model_local, inputs_local, output_local, elapsed_local = _run_retry_once(device, use_float32=True)
                        return model_local, inputs_local, output_local, elapsed_local, "float32"
                    except RuntimeError as exc:
                        if "same dtype" not in str(exc):
                            raise
                        print("float32 retry hit dtype mismatch on {}; fallback to original dtype: {}".format(device, exc))
                        model_local, inputs_local, output_local, elapsed_local = _run_retry_once(device, use_float32=False)
                        return model_local, inputs_local, output_local, elapsed_local, "original"

                retry_device = torch_device
                retry_model, retry_inputs, retry_output, retry_elapsed, retry_dtype_mode = _run_retry_with_dtype_fallback(retry_device)

                if _outputs_have_non_finite(retry_output) and retry_device.type == "cuda":
                    print("CUDA retry still has non-finite values; retry on CPU")
                    if torch.cuda.is_available():
                        torch.cuda.empty_cache()
                    retry_device = torch.device("cpu")
                    retry_model, retry_inputs, retry_output, retry_elapsed, retry_dtype_mode = _run_retry_with_dtype_fallback(retry_device)

                if _outputs_have_non_finite(retry_output):
                    print("Warning: PyTorch output still contains non-finite values after retries")
                else:
                    torch_device = retry_device
                    config.override_device(torch_device)
                    pytorch_inputs = retry_inputs
                    model = retry_model
                    pytorch_output = retry_output
                    pytorch_elapsed = retry_elapsed
                    print("Recovered finite PyTorch output using device={} dtype={}".format(torch_device, retry_dtype_mode))

        # state_dict is no longer needed; release the CPU copy to free memory.
        del state_dict
    else:
        print("Skip direct PyTorch load/forward and regenerated ONNX export because --pytorch-artifact-dir is not provided.")

    if original_onnx_output is not None and pytorch_output is not None:
        ort_tag = "{}".format(original_onnx_providers[0]) if original_onnx_providers else "unknown"
        all_comparisons.extend(
            compare_output_sequences(
                "PyTorch[{}]".format(torch_device),
                pytorch_output,
                "Original ONNX Base A[{}]".format(ort_tag),
                original_onnx_output,
            )
        )
    if onnx_simulator_output is not None and pytorch_output is not None:
        onnx_sim_tag = "{}".format(onnx_simulator_providers[0]) if onnx_simulator_providers else "unknown"
        all_comparisons.extend(
            compare_output_sequences(
                "PyTorch[{}]".format(torch_device),
                pytorch_output,
                "Toolkit ONNX Simulator[{}]".format(onnx_sim_tag),
                onnx_simulator_output,
            )
        )
    if pytorch_simulator_output is not None and pytorch_output is not None:
        pytorch_sim_tag = "{}".format(pytorch_simulator_providers[0]) if pytorch_simulator_providers else "unknown"
        all_comparisons.extend(
            compare_output_sequences(
                "PyTorch[{}]".format(torch_device),
                pytorch_output,
                "Toolkit PyTorch Simulator[{}]".format(pytorch_sim_tag),
                pytorch_simulator_output,
            )
        )
    if onnx_simulator_output is not None and pytorch_simulator_output is not None:
        onnx_sim_tag = "{}".format(onnx_simulator_providers[0]) if onnx_simulator_providers else "unknown"
        pytorch_sim_tag = "{}".format(pytorch_simulator_providers[0]) if pytorch_simulator_providers else "unknown"
        all_comparisons.extend(
            compare_output_sequences(
                "Toolkit PyTorch Simulator[{}]".format(pytorch_sim_tag),
                pytorch_simulator_output,
                "Toolkit ONNX Simulator[{}]".format(onnx_sim_tag),
                onnx_simulator_output,
            )
        )
    if original_onnx_output is not None and onnx_simulator_output is not None:
        ort_tag = "{}".format(original_onnx_providers[0]) if original_onnx_providers else "unknown"
        onnx_sim_tag = "{}".format(onnx_simulator_providers[0]) if onnx_simulator_providers else "unknown"
        all_comparisons.extend(
            compare_output_sequences(
                "Toolkit ONNX Simulator[{}]".format(onnx_sim_tag),
                onnx_simulator_output,
                "Original ONNX Base A[{}]".format(ort_tag),
                original_onnx_output,
            )
        )
    if original_onnx_output is not None and pytorch_simulator_output is not None:
        ort_tag = "{}".format(original_onnx_providers[0]) if original_onnx_providers else "unknown"
        pytorch_sim_tag = "{}".format(pytorch_simulator_providers[0]) if pytorch_simulator_providers else "unknown"
        all_comparisons.extend(
            compare_output_sequences(
                "Toolkit PyTorch Simulator[{}]".format(pytorch_sim_tag),
                pytorch_simulator_output,
                "Original ONNX Base A[{}]".format(ort_tag),
                original_onnx_output,
            )
        )
    if original_onnx_output is None:
        print("Skip Original ONNX Base comparison because Base A produced no outputs.")

    # Quantized correctness is a direct comparison between the generated
    # PyTorch forward and the authoritative check6 simulator.  It does not
    # depend on exporting the generated module back to ONNX, so keep it
    # available when callers use --skip-regenerated-onnx for a lightweight
    # regression run (especially for multi-gigabyte LLMs).
    if is_quant and pytorch_output is not None and args.quant_json and \
            os.path.exists(args.quant_json):
        try:
            _sim_cos, _sim_elapsed = _verify_quant_simulator(
                args.model, os.path.abspath(args.quant_json), pytorch_inputs,
                pytorch_output, label="check6+quant_tab",
                lora_metadata=lora_metadata)
            if _sim_cos is not None:
                print(
                    "  Quant model sim verify (pytorch QDQ vs simulator): "
                    "min_cos={:.8f}".format(_sim_cos))
        except Exception as _e:
            print("Quant simulator verification failed: {}".format(
                str(_e)[:300]))

    export_elapsed = None
    regenerated_onnx_output = None
    regenerated_onnx_providers = None
    regenerated_onnx_elapsed = None
    if not direct_pytorch_available:
        print("Skip regenerated ONNX export/runtime/model comparison because direct PyTorch artifacts are unavailable.")
    elif args.skip_regenerated_onnx:
        print("Skip regenerated ONNX export/runtime/model comparison (--skip-regenerated-onnx)")
    else:
        # 先从 PyTorch QDQ forward 导出，再移除仿真 QDQ 链，得到与 check6
        # 对齐的浮点算子图；量化参数仍由独立 quant manifest 承载。
        # Export on CPU when GPU memory is tight. TorchScript trace keeps all
        # intermediate tensors alive while building the graph, so export needs
        # roughly weights + forward peak (gemma4_llm: 18.6GB weights + ~6GB
        # trace; qwen2.5_vl_llm_check5: 11.6GB weights + ~10GB D8C8
        # intermediates). Move to CPU for export when that exceeds ~80% of GPU
        # memory; the GPU model is not needed after export.
        if torch_device.type == "cuda" and torch.cuda.is_available():
            _total_mem = torch.cuda.get_device_properties(0).total_memory
            _used_mem = torch.cuda.memory_allocated()
            _peak_mem = torch.cuda.max_memory_allocated()
            _free_mem, _ = torch.cuda.mem_get_info()
            _storage_mem = sum(
                tensor.numel() * tensor.element_size()
                for tensor in list(model.parameters()) + list(model.buffers())
            )
            # Preserve tracing materializes dequantized constants. W4/group
            # models have shown an export peak near eight times their compact
            # state size, even when the ordinary forward peak is small.
            _estimated_trace_mem = _storage_mem * 8
            if ((_used_mem + _peak_mem) / _total_mem > 0.8 or
                    _estimated_trace_mem > _free_mem * 0.8):
                print("GPU weights {:.1f}GB + forward peak {:.1f}GB / total {:.1f}GB; export regenerated ONNX on CPU to avoid OOM".format(
                    _used_mem / 1e9, _peak_mem / 1e9, _total_mem / 1e9))
                model = model.to("cpu")
                if hasattr(model, "_default_device"):
                    model._default_device = torch.device("cpu")
                pytorch_inputs = move_to_device(pytorch_inputs, torch.device("cpu"))
                torch.cuda.empty_cache()
        # 回导 preserve 语义: 未量化/量化统一默认 preserve; --no-preserve
        # 关闭时导出标准 onnx (展开 ex*)。
        export_preserve = not args.no_preserve
        _orig_onnx = None
        if export_preserve:
            # 未量化/量化统一默认 preserve 回导 (保留 ex* 算子):
            # codegen 用 _sym 类实例化 ex* (保留自定义算子), 导出回导 onnx 节点与
            # check6 一致; --no-preserve 关闭时导出标准 onnx (展开 ex*)。
            try:
                _orig_onnx = onnx.load(args.model, load_external_data=False)
            except Exception:
                _orig_onnx = None

        def _export_regenerated_model():
            if export_preserve:
                return export_preserve_onnx(
                    model, pytorch_inputs, generated_onnx,
                    args.opset_version, original_onnx=_orig_onnx)
            # 量化模型标准导出 (--no-preserve /
            # --quant-no-preserve): 直接导出 forward (QDQ 仿真展开链)。
            return export_torch_to_onnx(
                model, pytorch_inputs, generated_onnx,
                args.opset_version, preserve_custom_ops=False)

        try:
            export_elapsed = _export_regenerated_model()
        except torch.OutOfMemoryError as exc:
            if torch_device.type != "cuda":
                raise
            print(
                "CUDA OOM during regenerated ONNX export; retry on CPU: {}"
                .format(exc))
            model = model.to("cpu")
            if hasattr(model, "_default_device"):
                model._default_device = torch.device("cpu")
            pytorch_inputs = move_to_device(
                pytorch_inputs, torch.device("cpu"))
            torch_device = torch.device("cpu")
            config.override_device(torch_device)
            gc.collect()
            torch.cuda.empty_cache()
            export_elapsed = _export_regenerated_model()
        del _orig_onnx
        # exConvStreaming (linear attention) 回导布局修复: torch.onnx 省略
        # bias 后 tc (int32 KV cache) 误入 input[2], 否则 regen Base A 报
        # "Input type (float) and bias type (int)"。
        _fix_regen_exconvstreaming_layout(generated_onnx)
        _post_layout_restored = _restore_saved_regen_initializers(
            args.model, generated_onnx)
        if _post_layout_restored:
            print(
                "  Restored {} distinct check6 initializer(s) after layout "
                "fix".format(_post_layout_restored))
        # 回导 onnx 节点名/tensor 名统一为 generated.py buffer 名 (check6 名
        # sanitize 清洗): 用户对照 torch 代码调试。初次 codegen 应
        # 严格同构；用户编辑 generated.py 后则只告警，不阻断回导。
        warn_regen_structure(args.model, generated_onnx)
        _ren, _rmap = rename_regen_onnx(generated_onnx, args.model)
        if _ren:
            print("  Regen onnx renamed to buffer names ({} tensors)".format(_ren))
        # Check if exported ONNX has valid inputs (trace may collapse everything to constants
        # for models with Python control flow like NMS post-processing)
        try:
            exported_model = onnx.load(generated_onnx)
            init_names = {i.name for i in exported_model.graph.initializer}
            real_input_count = len([vi for vi in exported_model.graph.input if vi.name not in init_names])
        except Exception:
            real_input_count = -1
        if real_input_count == 0:
            print("Skip regenerated ONNX runtime: exported graph has 0 inputs (trace collapsed model to constants).")
            print("This is expected for models with Python control flow (e.g. NMS post-processing).")
        elif not export_preserve:
            # 标准导出 onnx (展开 ex*) 不保留 gongga 域 (--no-preserve / --quant-no-preserve)。
            # 标准图 ORT 应能加载, 但量化模型权重为 float32 无量化语义,
            # Base A/ORT 数值验证对量化模型不做门禁 (回归用节点一致性判定)。
            print("Standard ONNX (no preserve): skip regenerated ONNX runtime verify "
                  "(node-consistency based regression).")
            regenerated_onnx_output = None
        elif export_preserve:
            # preserve mode: use RKNN Base A (IRGraph+Session) to verify the
            # regenerated ONNX. This works for both gongga::ex* ops (needs
            # extend_infer) and standard ops (RKNN Session uses ORT internally).
            print("Verify regenerated ONNX via RKNN Base A (preserve mode).")
            try:
                # Load with external data, keep initializer raw_data intact.
                #
                # NOTE: we must NOT clear initializer raw_data here. IRGraph's
                # update_model_value_info runs shape inference on every node and
                # keys on intermediate tensor value_info; with empty raw_data it
                # raises KeyError for gongga-dense graphs (e.g. LLM quant revert
                # with 3000+ ex* nodes, failing on '.../Transpose_output_0').
                # deepcopy of a loaded model keeps raw_data in memory (no protobuf
                # serialization), so >2GB weights are safe here (verified for the
                # 5.7GB q_0.5b regen onnx).
                from onnx import numpy_helper
                regen_onnx_model = onnx.load(generated_onnx, load_external_data=True)
                # 回导 ONNX 由 torch.onnx 导出, 中间 tensor 通常不带
                # 类型信息 (value_info 稀疏: mobilenet 1/100, gemma4_llm 0/5404),
                # IRGraph 加载时逐节点 shape inference 因缺类型而失败 (如 mobilenet
                # /output_mm_tp_rs/Reshape 输出被推断为 int8 而实际为 float →
                # ONNXRuntime Type Error)。先全图 shape inference 补齐 value_info
                # 再交给 Base A, 使回导验证不再被 IRGraph 加载局限跳过。
                # infer_shapes_path 走 C++ 路径支持 >2GB 权重 (14B LLM);
                # data_prop=False 不做常量数据传播 (只补形状/类型, 省内存);
                # gongga::ex* 节点无推断规则时跳过 (strict_mode=False), 标准节点
                # 类型仍补齐 (qwen3.5_test 18 gongga 节点下补到 2327)。
                _infer_tmp = generated_onnx + ".infer_tmp.onnx"
                try:
                    onnx.shape_inference.infer_shapes_path(
                        generated_onnx, _infer_tmp, strict_mode=False, data_prop=False)
                    _inferred = onnx.load(_infer_tmp, load_external_data=True)
                    if len(_inferred.graph.value_info) > len(regen_onnx_model.graph.value_info):
                        print("  Shape-inferred regenerated ONNX: value_info {} -> {}".format(
                            len(regen_onnx_model.graph.value_info), len(_inferred.graph.value_info)))
                        regen_onnx_model = _inferred
                except Exception as _sie:
                    print("  Shape inference for regenerated ONNX skipped: {}".format(str(_sie)[:200]))
                finally:
                    if os.path.exists(_infer_tmp):
                        os.remove(_infer_tmp)
                regen_const_values = {}
                for init in regen_onnx_model.graph.initializer:
                    # Get the weight data (from raw_data or external_data).
                    arr = numpy_helper.to_array(init)
                    # 未量化模型的"伪量化"权重可能以 int8/int16/uint8 存储
                    # (如 mobilenet classifier fc [1,1280,1,1000] int8), 计算语义
                    # 是数值直转 float32 (Gemm_torch.forward 的 to(float32),
                    # scale=1/zp=0), 但 Base A (IRGraph+ORT) 加载 int8 权重 +
                    # float 激活的混合类型图时类型冲突 (Reshape 链 Type Error)。
                    # 与验证前图对齐: 整型量化权重数值转 float32 (仅未量化模型;
                    # 量化模型回导是 QDQ 图, QuantizeLinear/DequantizeLinear 的
                    # int8 权重/scale/zp 必须保持原类型); int32/int64 (索引/
                    # 常量语义, 如 Reshape shape/Gather indices) 保留原类型。
                    if not is_quant and arr.dtype in (np.int8, np.int16, np.uint8):
                        init.CopyFrom(numpy_helper.from_array(
                            arr.astype(np.float32), name=init.name))
                        arr = arr.astype(np.float32)
                    regen_const_values[init.name] = np.asarray(arr)
                regenerated_onnx_output, regen_providers, regenerated_onnx_elapsed = run_rknn_numpy_baseline(
                    regen_onnx_model, fake_inputs, regen_const_values,
                    model_label="regenerated_preserve",
                    lora_metadata=lora_metadata,
                )
                regenerated_onnx_output = _as_output_sequence(regenerated_onnx_output)
                regenerated_onnx_providers = ["RKNNGraphSessionSimulator"]
                regen_tag = "RKNNGraphSessionSimulator"
                all_comparisons.extend(
                    compare_output_sequences(
                        "Regenerated ONNX[{}]".format(regen_tag),
                        regenerated_onnx_output,
                        "PyTorch[{}]".format(torch_device),
                        pytorch_output,
                    )
                )
                if original_onnx_output is not None:
                    ort_tag = "{}".format(original_onnx_providers[0]) if original_onnx_providers else "unknown"
                    all_comparisons.extend(
                        compare_output_sequences(
                            "Regenerated ONNX[{}]".format(regen_tag),
                            regenerated_onnx_output,
                            "Original ONNX Base A[{}]".format(ort_tag),
                            original_onnx_output,
                        )
                    )
            except Exception as exc:
                print("  Regenerated ONNX Base A verification failed: {}".format(str(exc)[:300]))
                # Fallback: if no custom domain (standard ops only), try ORT.
                if not has_custom_domain:
                    print("  Fallback to ORT for regenerated ONNX (no custom domain).")
                    try:
                        regenerated_onnx_output, regenerated_onnx_providers, regenerated_onnx_elapsed = run_onnxruntime(
                            generated_onnx, fake_inputs, config=config)
                        regen_tag = "{}".format(regenerated_onnx_providers[0]) if regenerated_onnx_providers else "unknown"
                        all_comparisons.extend(
                            compare_output_sequences(
                                "Regenerated ONNX[{}]".format(regen_tag),
                                regenerated_onnx_output,
                                "PyTorch[{}]".format(torch_device),
                                pytorch_output,
                            )
                        )
                    except Exception as exc2:
                        print("  ORT fallback also failed: {}".format(str(exc2)[:200]))

    print("Execution summary:")
    if codegen_elapsed is not None:
        print("  ONNX->PyTorch codegen time={:.4f}s".format(codegen_elapsed))
    elif not direct_pytorch_available:
        print("  ONNX->PyTorch codegen time=inlined into Toolkit PyTorch Simulator (in-memory build)")
    if load_elapsed is not None:
        print("  PyTorch model load time={:.4f}s".format(load_elapsed))
    if pytorch_elapsed is not None:
        print("  PyTorch device={} time={:.4f}s".format(torch_device, pytorch_elapsed))
    if original_onnx_output is not None and original_onnx_elapsed is not None:
        original_provider = original_onnx_providers[0] if original_onnx_providers else "unknown"
        print("  Original ONNX Base A provider={} time={:.4f}s".format(original_provider, original_onnx_elapsed))
    if onnx_simulator_output is not None and onnx_simulator_elapsed is not None:
        onnx_sim_provider = onnx_simulator_providers[0] if onnx_simulator_providers else "unknown"
        print("  Toolkit ONNX Simulator provider={} time={:.4f}s".format(onnx_sim_provider, onnx_simulator_elapsed))
        print_timing_profile(onnx_simulator_profile, onnx_simulator_elapsed, indent="    ")
    if pytorch_simulator_output is not None and pytorch_simulator_elapsed is not None:
        pytorch_sim_provider = pytorch_simulator_providers[0] if pytorch_simulator_providers else "unknown"
        print("  Toolkit PyTorch Simulator provider={} time={:.4f}s".format(pytorch_sim_provider, pytorch_simulator_elapsed))
        print_timing_profile(pytorch_simulator_profile, pytorch_simulator_elapsed, indent="    ")
    if (
        onnx_simulator_elapsed is not None
        and pytorch_simulator_elapsed is not None
        and onnx_simulator_elapsed > 0
    ):
        delta_elapsed = pytorch_simulator_elapsed - onnx_simulator_elapsed
        ratio = pytorch_simulator_elapsed / onnx_simulator_elapsed
        print(
            "  Simulator E2E compare: pytorch={:.4f}s onnx={:.4f}s delta={:.4f}s ratio={:.2f}x".format(
                pytorch_simulator_elapsed,
                onnx_simulator_elapsed,
                delta_elapsed,
                ratio,
            )
        )
    if pytorch_accuracy_analysis_elapsed is not None:
        print(
            "  Toolkit PyTorch accuracy_analysis time={:.4f}s output_dir={}".format(
                pytorch_accuracy_analysis_elapsed,
                pytorch_accuracy_analysis_dir,
            )
        )
    if export_elapsed is not None:
        print("  ONNX export time={:.4f}s".format(export_elapsed))
    if regenerated_onnx_elapsed is not None:
        regenerated_provider = regenerated_onnx_providers[0] if regenerated_onnx_providers else "unknown"
        print("  Regenerated ONNX provider={} time={:.4f}s".format(regenerated_provider, regenerated_onnx_elapsed))

    print("Cosine similarity summary:")
    print_comparison_summary(all_comparisons)

    if has_custom_domain and (not fast_artifact_mode) and original_onnx_output is not None:
        ort_tag = "{}".format(original_onnx_providers[0]) if original_onnx_providers else "unknown"
        if pytorch_output is not None:
            _warn_min_cosine(
                all_comparisons,
                "PyTorch[{}]".format(torch_device),
                "Original ONNX Base A[{}]".format(ort_tag),
                args.baseline_cos_threshold,
            )
        if regenerated_onnx_output is not None:
            regen_tag = "{}".format(regenerated_onnx_providers[0]) if regenerated_onnx_providers else "unknown"
            _warn_min_cosine(
                all_comparisons,
                "Regenerated ONNX[{}]".format(regen_tag),
                "Original ONNX Base A[{}]".format(ort_tag),
                args.baseline_cos_threshold,
            )
            if pytorch_output is not None:
                print(
                    "Baseline consistency checks evaluated (threshold={}): PyTorch and Regenerated ONNX vs RKNN numpy base A (sub-threshold cosine reported as WARNING only).".format(
                        args.baseline_cos_threshold
                    )
                )
            else:
                print(
                    "Baseline consistency check (threshold={}) evaluated on Regenerated ONNX vs RKNN numpy base A only (warnings only).".format(
                        args.baseline_cos_threshold
                    )
                )
        elif pytorch_output is not None:
            print(
                "Baseline consistency check (threshold={}) evaluated on PyTorch vs RKNN numpy base A only (warnings only).".format(
                    args.baseline_cos_threshold
                )
            )


if __name__ == "__main__":
    main()
