import torch


class exMoEGather_torch(torch.nn.Module):
    """Reorder routed tokens into the compact per-expert MoE layout."""

    _INTEGER_DTYPES = (
        torch.int8,
        torch.uint8,
        torch.int16,
        torch.int32,
        torch.int64,
    )

    def __init__(
        self,
        n_routed_experts,
        n_experts_per_token,
        native_routing_input=0,
        prefill_parallel_expert_owner=0,
        parallel_core_index=0,
        parallel_core_count=1,
        expert_begin=0,
        expert_end=None,
        **kwargs,
    ):
        super(exMoEGather_torch, self).__init__()
        self.n_routed_experts = int(n_routed_experts)
        self.n_experts_per_token = int(n_experts_per_token)
        self.native_routing_input = int(native_routing_input or 0)
        self.prefill_parallel_expert_owner = int(
            prefill_parallel_expert_owner or 0
        )
        self.parallel_core_index = int(parallel_core_index or 0)
        self.parallel_core_count = int(
            1 if parallel_core_count is None else parallel_core_count
        )
        self.expert_begin = int(expert_begin or 0)
        self.expert_end = (
            self.n_routed_experts if expert_end is None else int(expert_end)
        )

    def forward(self, hidden_state, token_expert_ids, token_expert_prob):
        if hidden_state.dim() != 4 or hidden_state.shape[0] != 1 or hidden_state.shape[2] != 1:
            raise ValueError(
                "exMoEGather hidden_state must use [1, D, 1, T] layout"
            )
        token_count = hidden_state.shape[3]
        experts = self.n_routed_experts
        experts_per_token = self.n_experts_per_token

        if self.prefill_parallel_expert_owner:
            if (
                self.parallel_core_count <= 1
                or self.parallel_core_index < 0
                or self.parallel_core_index >= self.parallel_core_count
                or self.expert_begin < 0
                or self.expert_begin >= self.expert_end
                or self.expert_end > experts
            ):
                raise ValueError(
                    "exMoEGather expert-owner attributes are invalid"
                )
            expert_begin, expert_end = self.expert_begin, self.expert_end
        else:
            expert_begin, expert_end = 0, experts

        if self.native_routing_input:
            expected = (1, experts_per_token, 1, token_count)
            if tuple(token_expert_ids.shape) != expected or tuple(
                token_expert_prob.shape
            ) != expected:
                raise ValueError(
                    "exMoEGather native routing inputs must use [1,K,1,T]"
                )
            token_expert_ids = token_expert_ids[0, :, 0, :].transpose(0, 1)
            token_expert_prob = token_expert_prob[0, :, 0, :].transpose(0, 1)

        expected = (token_count, experts_per_token)
        if tuple(token_expert_ids.shape) != expected:
            raise ValueError("exMoEGather token_expert_ids shape is invalid")
        if tuple(token_expert_prob.shape) != expected:
            raise ValueError("exMoEGather token_expert_prob shape is invalid")
        if token_expert_ids.dtype not in self._INTEGER_DTYPES:
            raise ValueError(
                "exMoEGather token_expert_ids must be an integer tensor"
            )
        if torch.any(token_expert_ids < -1) or torch.any(
            token_expert_ids >= experts
        ):
            raise ValueError(
                "exMoEGather token_expert_ids contains out-of-range expert ids"
            )

        compact_tokens = token_count * experts_per_token
        permuted = torch.zeros(
            (1, hidden_state.shape[1], token_count, experts_per_token),
            dtype=hidden_state.dtype,
            device=hidden_state.device,
        )
        permuted_flat = permuted.reshape(
            1, hidden_state.shape[1], 1, compact_tokens
        )
        compact_prob = torch.zeros(
            (token_count, experts_per_token),
            dtype=token_expert_prob.dtype,
            device=token_expert_prob.device,
        )
        received = torch.zeros(
            experts, dtype=torch.int32, device=token_expert_ids.device
        )
        token_map = torch.full(
            (experts, token_count),
            -1,
            dtype=torch.int32,
            device=token_expert_ids.device,
        )

        offset = 0
        for expert_id in range(experts):
            positions = torch.nonzero(
                token_expert_ids == expert_id, as_tuple=False
            )
            count = positions.shape[0]
            if count > token_count:
                raise ValueError(
                    "exMoEGather cannot encode more than T tokens for one expert"
                )
            received[expert_id] = count
            for index in range(count):
                token_id = int(positions[index, 0].item())
                slot_id = int(positions[index, 1].item())
                if token_count != 1 and expert_begin <= expert_id < expert_end:
                    permuted_flat[:, :, :, offset + index] = hidden_state[
                        :, :, :, token_id
                    ]
                compact_prob.reshape(-1)[offset + index] = token_expert_prob[
                    token_id, slot_id
                ]
                token_map[expert_id, index] = (
                    token_id * experts_per_token + slot_id
                )
            offset += count
        return permuted, compact_prob, received, token_map

    def forward_symbolic(self, hidden_state, token_expert_ids, token_expert_prob):
        """Shape placeholders used only while preserving this custom op."""
        token_count = hidden_state.shape[3]
        permuted = hidden_state.transpose(2, 3).expand(
            -1, -1, -1, self.n_experts_per_token
        )
        if self.native_routing_input:
            compact_prob = token_expert_prob[0, :, 0, :].transpose(0, 1)
        else:
            compact_prob = token_expert_prob
        received = torch.zeros(
            self.n_routed_experts,
            dtype=torch.int32,
            device=token_expert_ids.device,
        )
        token_map = torch.zeros(
            (self.n_routed_experts, token_count),
            dtype=torch.int32,
            device=token_expert_ids.device,
        )
        return permuted, compact_prob, received, token_map


class exMoEUnGather_torch(torch.nn.Module):
    """Restore compact per-expert results to token/route-slot order."""

    _INTEGER_DTYPES = (
        torch.int8,
        torch.uint8,
        torch.int16,
        torch.int32,
        torch.int64,
    )

    def __init__(
        self,
        n_experts_per_token,
        n_shared_experts=0,
        native_routing_metadata=0,
        prefill_parallel_token_shard=0,
        parallel_core_index=0,
        parallel_core_count=1,
        token_begin=0,
        token_end=None,
        **kwargs,
    ):
        super(exMoEUnGather_torch, self).__init__()
        self.n_experts_per_token = int(n_experts_per_token)
        self.n_shared_experts = int(n_shared_experts or 0)
        self.native_routing_metadata = int(native_routing_metadata or 0)
        self.prefill_parallel_token_shard = int(
            prefill_parallel_token_shard or 0
        )
        self.parallel_core_index = int(parallel_core_index or 0)
        self.parallel_core_count = int(
            1 if parallel_core_count is None else parallel_core_count
        )
        self.token_begin = int(token_begin or 0)
        self.token_end = None if token_end is None else int(token_end)

    def forward(self, permuted_hidden, received_tokens, token_map):
        if permuted_hidden.dim() != 4 or permuted_hidden.shape[0] != 1:
            raise ValueError(
                "exMoEUnGather input must use [1, D, T, EPT + SEPT] layout"
            )
        if received_tokens.dtype not in self._INTEGER_DTYPES:
            raise ValueError(
                "exMoEUnGather received token counts must be integers"
            )
        if token_map.dtype not in self._INTEGER_DTYPES:
            raise ValueError("exMoEUnGather token map must be an integer tensor")
        received_tokens = received_tokens.reshape(-1).to(dtype=torch.int64)
        if token_map.dim() != 2 or token_map.shape[0] != received_tokens.numel():
            raise ValueError("exMoEUnGather token map shape is invalid")

        experts_per_token = self.n_experts_per_token
        shared_experts = self.n_shared_experts
        global_token_count = token_map.shape[1]
        compact_capacity = permuted_hidden.shape[2] * experts_per_token
        total_received = int(received_tokens.sum().item())
        if (
            torch.any(received_tokens < 0)
            or torch.any(received_tokens > global_token_count)
            or total_received > compact_capacity
        ):
            raise ValueError(
                "exMoEUnGather received token counts are invalid"
            )

        if self.prefill_parallel_token_shard:
            token_end = (
                global_token_count if self.token_end is None else self.token_end
            )
            if (
                self.parallel_core_count <= 1
                or self.parallel_core_index < 0
                or self.parallel_core_index >= self.parallel_core_count
                or self.token_begin < 0
                or self.token_begin >= token_end
                or token_end > global_token_count
            ):
                raise ValueError(
                    "exMoEUnGather token-shard attributes are invalid"
                )
            token_begin = self.token_begin
            token_count = token_end - token_begin
            if permuted_hidden.shape[2] != global_token_count:
                raise ValueError(
                    "token-shard exMoEUnGather input must retain the global "
                    "compact token dimension"
                )
        else:
            token_begin = 0
            token_end = global_token_count
            token_count = global_token_count
            if permuted_hidden.shape[2] != token_count:
                raise ValueError(
                    "exMoEUnGather token dimension does not match token map"
                )

        if permuted_hidden.shape[3] != experts_per_token + shared_experts:
            raise ValueError("exMoEUnGather expert dimension is invalid")

        output = torch.zeros(
            (
                1,
                permuted_hidden.shape[1],
                token_count,
                experts_per_token + shared_experts,
            ),
            dtype=permuted_hidden.dtype,
            device=permuted_hidden.device,
        )
        offset = 0
        for expert_id in range(received_tokens.numel()):
            count = int(received_tokens[expert_id].item())
            for index in range(count):
                encoded_id = int(token_map[expert_id, index].item())
                if not 0 <= encoded_id < global_token_count * experts_per_token:
                    raise ValueError(
                        "exMoEUnGather token map contains an invalid routed token"
                    )
                token_id, slot_id = divmod(encoded_id, experts_per_token)
                compact_token_id, compact_slot_id = divmod(
                    offset + index, experts_per_token
                )
                if token_begin <= token_id < token_end:
                    output[0, :, token_id - token_begin, slot_id] += (
                        permuted_hidden[
                            0, :, compact_token_id, compact_slot_id
                        ]
                    )
            offset += count

        for shared_id in range(shared_experts):
            shared_slot = experts_per_token + shared_id
            if self.prefill_parallel_token_shard:
                output[0, :, :, shared_slot] = permuted_hidden[
                    0, :, token_begin:token_end, shared_slot
                ]
            else:
                output[0, :, :, shared_slot] = permuted_hidden[
                    0, :, :, shared_slot
                ]
        return output

    def forward_symbolic(self, permuted_hidden, received_tokens, token_map):
        """Shape placeholder used only while preserving this custom op."""
        if self.prefill_parallel_token_shard:
            token_end = (
                permuted_hidden.shape[2]
                if self.token_end is None
                else self.token_end
            )
            return permuted_hidden[
                :, :, self.token_begin:token_end, :
            ]
        return permuted_hidden
