import torch
import torch.nn.functional as F


class exLRN_torch(torch.nn.Module):
    def __init__(self, alpha=1e-4, beta=0.75, bias=1.0, size=5, **kwargs):
        super(exLRN_torch, self).__init__()
        self.alpha = float(alpha)
        self.beta = float(beta)
        self.bias = float(bias)
        self.size = int(size)

    def forward(self, x):
        return F.local_response_norm(x, self.size, alpha=self.alpha, beta=self.beta, k=self.bias)
