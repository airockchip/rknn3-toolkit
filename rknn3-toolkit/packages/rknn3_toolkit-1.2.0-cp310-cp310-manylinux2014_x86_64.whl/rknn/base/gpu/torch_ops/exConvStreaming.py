import torch


class exConvStreaming_torch(torch.nn.Module):
    def __init__(self, pads=None, strides=None, dilations=None, group=1, **kwargs):
        super(exConvStreaming_torch, self).__init__()
        self.pads = tuple(pads) if pads is not None else (0, 0, 0, 0)
        self.strides = tuple(strides) if strides is not None else (1, 1)
        self.dilations = tuple(dilations) if dilations is not None else (1, 1)
        self.group = int(group)
        # kernel_shape is an ONNX attr consumed by **kwargs; store it explicitly
        # so preserve-mode Symbolic.apply can pass it as a g.op attribute.
        self.kernel_shape = tuple(kwargs["kernel_shape"]) if "kernel_shape" in kwargs else None

    def forward(self, x, weight, bias=None, tc=None):
        y, _ = self.forward_with_cache(x, weight, bias, tc, node_cache={})
        return y

    def forward_with_cache(self, x, weight, bias=None, tc=None, node_cache=None):
        node_cache = {} if node_cache is None else dict(node_cache)
        cache_w = int(self.pads[1])
        cache_x = node_cache.get("tail")
        if cache_w > 0:
            expected_shape = tuple(x.shape[:-1]) + (cache_w,)
            if cache_x is None or tuple(cache_x.shape) != expected_shape:
                cache_x = torch.zeros(expected_shape, dtype=x.dtype, device=x.device)
            conv_input = torch.cat([cache_x, x], dim=-1)
            valid_w = int(x.shape[-1])
            if tc is not None and (not isinstance(tc, torch.Tensor) or tc.numel() > 0):
                valid_w = int(tc.reshape(-1)[0].item()) \
                    if isinstance(tc, torch.Tensor) else int(tc)
                valid_w = max(0, min(valid_w, int(x.shape[-1])))
            cache_update = torch.cat([cache_x, x[..., :valid_w]], dim=-1)
            node_cache["tail"] = cache_update[..., -cache_w:].detach()
        else:
            conv_input = x
            node_cache["tail"] = x[..., :0].detach()
        # Cached values replace W-before padding; only W-after and both H
        # pads remain explicit, matching extend_op.exConvStreaming_infer.
        conv_input = torch.nn.functional.pad(
            conv_input, (0, self.pads[3], self.pads[0], self.pads[2]))
        return (
            torch.nn.functional.conv2d(
                conv_input, weight, bias, stride=self.strides,
                dilation=self.dilations, groups=self.group),
            node_cache,
        )
