import torch


class exProposal_torch(torch.nn.Module):
    def __init__(self, feat_stride=16, min_size=0, nms_thresh=0.7, image_size=None, post_nms_topn=300, pre_nms_topn=6000, **kwargs):
        super(exProposal_torch, self).__init__()
        self.feat_stride = int(feat_stride)
        self.min_size = float(min_size)
        self.nms_thresh = float(nms_thresh)
        self.image_size = tuple(image_size) if image_size is not None else None
        self.post_nms_topn = int(post_nms_topn)
        self.pre_nms_topn = int(pre_nms_topn)

    def _bbox_transform_inv(self, boxes, deltas):
        widths = boxes[:, 2] - boxes[:, 0] + 1.0
        heights = boxes[:, 3] - boxes[:, 1] + 1.0
        ctr_x = boxes[:, 0] + 0.5 * widths
        ctr_y = boxes[:, 1] + 0.5 * heights
        dx = deltas[:, 0::4]
        dy = deltas[:, 1::4]
        dw = deltas[:, 2::4]
        dh = deltas[:, 3::4]
        pred_ctr_x = dx * widths[:, None] + ctr_x[:, None]
        pred_ctr_y = dy * heights[:, None] + ctr_y[:, None]
        pred_w = torch.exp(dw) * widths[:, None]
        pred_h = torch.exp(dh) * heights[:, None]
        pred_boxes = torch.zeros_like(deltas)
        pred_boxes[:, 0::4] = pred_ctr_x - 0.5 * pred_w
        pred_boxes[:, 1::4] = pred_ctr_y - 0.5 * pred_h
        pred_boxes[:, 2::4] = pred_ctr_x + 0.5 * pred_w
        pred_boxes[:, 3::4] = pred_ctr_y + 0.5 * pred_h
        return pred_boxes

    def _clip_boxes(self, boxes, img_h, img_w):
        boxes[:, 0::4].clamp_(0, img_w - 1)
        boxes[:, 1::4].clamp_(0, img_h - 1)
        boxes[:, 2::4].clamp_(0, img_w - 1)
        boxes[:, 3::4].clamp_(0, img_h - 1)
        return boxes

    def _filter_boxes(self, boxes):
        ws = boxes[:, 2] - boxes[:, 0] + 1
        hs = boxes[:, 3] - boxes[:, 1] + 1
        return torch.where((ws >= self.min_size) & (hs >= self.min_size))[0]

    def _nms(self, boxes, scores):
        order = torch.argsort(scores, descending=True)
        keep = []
        while order.numel() > 0:
            i = order[0]
            keep.append(i)
            if order.numel() == 1:
                break
            rest = order[1:]
            xx1 = torch.maximum(boxes[i, 0], boxes[rest, 0])
            yy1 = torch.maximum(boxes[i, 1], boxes[rest, 1])
            xx2 = torch.minimum(boxes[i, 2], boxes[rest, 2])
            yy2 = torch.minimum(boxes[i, 3], boxes[rest, 3])
            w = torch.clamp(xx2 - xx1 + 1, min=0)
            h = torch.clamp(yy2 - yy1 + 1, min=0)
            inter = w * h
            area_i = (boxes[i, 2] - boxes[i, 0] + 1) * (boxes[i, 3] - boxes[i, 1] + 1)
            area_rest = (boxes[rest, 2] - boxes[rest, 0] + 1) * (boxes[rest, 3] - boxes[rest, 1] + 1)
            iou = inter / (area_i + area_rest - inter)
            order = rest[iou <= self.nms_thresh]
        return torch.stack(keep) if keep else torch.zeros((0,), dtype=torch.long, device=boxes.device)

    def forward(self, scores, bbox_deltas, anchors):
        num_anchors = anchors.shape[0]
        scores = scores[:, num_anchors:, :, :]
        height, width = scores.shape[-2:]
        shift_x = torch.arange(width, device=scores.device, dtype=anchors.dtype) * self.feat_stride
        shift_y = torch.arange(height, device=scores.device, dtype=anchors.dtype) * self.feat_stride
        shift_y, shift_x = torch.meshgrid(shift_y, shift_x, indexing='ij')
        shifts = torch.stack([shift_x.reshape(-1), shift_y.reshape(-1), shift_x.reshape(-1), shift_y.reshape(-1)], dim=1)
        anchors = anchors.reshape(1, num_anchors, 4) + shifts.reshape(-1, 1, 4)
        anchors = anchors.reshape(-1, 4)
        bbox_deltas = bbox_deltas.permute(0, 2, 3, 1).reshape(-1, 4)
        scores = scores.permute(0, 2, 3, 1).reshape(-1)
        order = torch.topk(scores, self.pre_nms_topn).indices if self.pre_nms_topn > 0 and self.pre_nms_topn < scores.numel() else torch.argsort(scores, descending=True)
        proposals = self._bbox_transform_inv(anchors[order], bbox_deltas[order])
        scores = scores[order]
        if self.image_size is not None and len(self.image_size) >= 4:
            proposals = self._clip_boxes(proposals, self.image_size[2], self.image_size[3])
        keep = self._filter_boxes(proposals)
        proposals = proposals[keep]
        scores = scores[keep]
        keep = self._nms(proposals, scores)
        keep = keep[: self.post_nms_topn] if self.post_nms_topn > 0 else keep
        proposals = proposals[keep]
        scores = scores[keep]
        if proposals.shape[0] == 0:
            return torch.zeros((self.post_nms_topn, 5), dtype=anchors.dtype, device=anchors.device), torch.zeros((self.post_nms_topn,), dtype=scores.dtype, device=scores.device)
        if self.post_nms_topn > proposals.shape[0]:
            pad = self.post_nms_topn - proposals.shape[0]
            proposals = torch.cat([proposals, proposals[-1:].repeat(pad, 1)], dim=0)
            scores = torch.cat([scores, scores[-1:].repeat(pad)], dim=0)
        batch_inds = torch.zeros((proposals.shape[0], 1), dtype=proposals.dtype, device=proposals.device)
        return torch.cat([batch_inds, proposals], dim=1), scores
