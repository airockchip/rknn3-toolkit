import torch
import torch.nn as nn

class conv_torch(torch.nn.Module):
    def __init__(self, in_channels, out_channels, stride=1, padding=0, dilation=1, groups=1, bias=True):
        super(conv_torch, self).__init__()
        # self.conv = torch.nn.Conv2d(in_channels, out_channels, kernel_size, stride, padding, dilation, groups, bias)
        self.in_channels = in_channels
        self.out_channels = out_channels
        # self.kernel_size = kernel_size
        self.stride = stride
        self.padding = padding
        self.dilation = dilation
        self.groups = groups
        self.bias = bias

    def _dispatch_conv(self, dim):
        if dim == 1:
            return torch.nn.functional.conv1d
        if dim == 2:
            return torch.nn.functional.conv2d
        if dim == 3:
            return torch.nn.functional.conv3d
        raise NotImplementedError("conv_torch only supports 1D/2D/3D convolution, got {}D".format(dim))

    def forward(self, x, weight, bias=None):
        conv_fn = self._dispatch_conv(weight.dim() - 2)
        padding = self.padding
        # Handle asymmetric padding via F.pad.
        # Avoid for-loop (causes TorchScript trace expansion); use fixed index
        # patterns for common ranks (1D/2D/3D).
        if isinstance(padding, (list, tuple)) and not isinstance(padding, int):
            n = len(padding)
            if n == 2:
                # 1D: (begin, end)
                if padding[0] != padding[1]:
                    x = torch.nn.functional.pad(x, (int(padding[0]), int(padding[1])))
                    padding = 0
                else:
                    padding = int(padding[0])
            elif n == 4:
                # 2D: (b_h, b_w, e_h, e_w) -> F.pad wants (b_w, e_w, b_h, e_h)
                if padding[0] != padding[2] or padding[1] != padding[3]:
                    x = torch.nn.functional.pad(x, (int(padding[1]), int(padding[3]), int(padding[0]), int(padding[2])))
                    padding = 0
                else:
                    padding = (int(padding[0]), int(padding[1]))
            elif n == 6:
                # 3D: (b_d, b_h, b_w, e_d, e_h, e_w) -> F.pad wants (b_w,e_w,b_h,e_h,b_d,e_d)
                if padding[0] != padding[3] or padding[1] != padding[4] or padding[2] != padding[5]:
                    x = torch.nn.functional.pad(x, (int(padding[2]), int(padding[5]), int(padding[1]), int(padding[4]), int(padding[0]), int(padding[3])))
                    padding = 0
                else:
                    padding = (int(padding[0]), int(padding[1]), int(padding[2]))
            else:
                # Fallback: general case with for-loop (rare, may expand in trace)
                half = n // 2
                begin = padding[:half]
                end = padding[half:]
                if list(begin) != list(end):
                    pad_pairs = []
                    for i in range(half - 1, -1, -1):
                        pad_pairs.extend([begin[i], end[i]])
                    x = torch.nn.functional.pad(x, tuple(pad_pairs))
                    padding = 0
                else:
                    padding = tuple(begin)
        # Align dtype: fp16 weights need fp16 input
        if weight.dtype == torch.float16 and x.dtype != torch.float16:
            x = x.to(torch.float16)
        elif weight.dtype == torch.float32 and x.dtype == torch.float16:
            x = x.to(torch.float32)
        return conv_fn(x, weight, bias, self.stride, padding, self.dilation, self.groups)

class Full_model(torch.nn.Module):
    def __init__(self):
        super(Full_model, self).__init__()
        self.encoder_conv1 = conv_torch(in_channels=3, out_channels=12, stride=2, padding=0, dilation=1, groups=1, bias=True)

        self.weight_name = "_809"
        self.bias_name = "_810"

        setattr(self, self.weight_name, nn.Parameter(torch.randn(12, 3, 2, 2)))
        setattr(self, self.bias_name, nn.Parameter(torch.randn(12)))

    def forward(self, x):
        argb_out = self.encoder_conv1(x, getattr(self, self.weight_name), getattr(self, self.bias_name))
        output2 = torch.relu(argb_out)
        output3 = torch.sigmoid(output2)
        output4 = torch.relu(output3)
        return output4
