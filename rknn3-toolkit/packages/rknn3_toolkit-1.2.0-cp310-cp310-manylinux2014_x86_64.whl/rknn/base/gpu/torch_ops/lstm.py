import torch


def _onnx_lstm_to_torch(weight):
    gate = weight.shape[0] // 4
    w_i, w_o, w_f, w_c = weight.split(gate, dim=0)
    return torch.cat([w_i, w_f, w_c, w_o], dim=0)


def _onnx_gru_to_torch(weight):
    gate = weight.shape[0] // 3
    w_z, w_r, w_h = weight.split(gate, dim=0)
    return torch.cat([w_r, w_z, w_h], dim=0)


class exLSTM_torch(torch.nn.Module):
    def __init__(self, hidden_size, direction='forward', proj_size=0, input_layout='snc', output_layout='snc', batch_size=None, sequence_size=None, **kwargs):
        super(exLSTM_torch, self).__init__()
        self.hidden_size = int(hidden_size)
        self.direction = direction
        self.proj_size = int(proj_size or 0)
        self.input_layout = input_layout
        self.output_layout = output_layout
        self.batch_size = batch_size
        self.sequence_size = sequence_size

    def _normalize_input(self, x):
        if self.input_layout == 'snc':
            return x.reshape(x.shape[0], x.shape[1], -1), x.shape[0], x.shape[1]
        seq = int(self.sequence_size or 1)
        batch = int(self.batch_size or (x.shape[0] // seq))
        return x.reshape(seq, batch, -1), seq, batch

    def _format_output(self, y, batch, num_directions):
        seq = y.shape[0]
        hidden = y.shape[-1] // num_directions
        y = y.reshape(seq, batch, num_directions, hidden).permute(0, 2, 1, 3).contiguous()
        if self.output_layout == 'snc':
            return y.permute(0, 2, 1, 3).reshape(seq, batch, -1)
        if self.output_layout == '(sn)c':
            return y.permute(0, 2, 1, 3).reshape(seq * batch, -1, 1, 1)
        return y

    def forward(self, x, w, r, b=None, seq_lens=None, initial_h=None, initial_c=None, p=None):
        x, _, batch = self._normalize_input(x)
        num_directions = 2 if self.direction == 'bidirectional' else 1
        has_bias = b is not None
        input_size = x.shape[-1]
        proj_size = self.proj_size
        hidden_out = proj_size if proj_size > 0 else self.hidden_size
        if self.direction == 'bidirectional':
            lstm = torch.nn.LSTM(
                input_size, self.hidden_size, bias=has_bias,
                bidirectional=True, proj_size=proj_size).to(
                    device=x.device, dtype=x.dtype)
            suffixes = ['', '_reverse']
            for idx, suffix in enumerate(suffixes):
                getattr(lstm, 'weight_ih_l0' + suffix).data.copy_(_onnx_lstm_to_torch(w[idx]))
                getattr(lstm, 'weight_hh_l0' + suffix).data.copy_(_onnx_lstm_to_torch(r[idx]))
                if has_bias:
                    bias_ih = _onnx_lstm_to_torch(b[idx, : 4 * self.hidden_size].reshape(4 * self.hidden_size, 1)).reshape(-1)
                    bias_hh = _onnx_lstm_to_torch(b[idx, 4 * self.hidden_size :].reshape(4 * self.hidden_size, 1)).reshape(-1)
                    getattr(lstm, 'bias_ih_l0' + suffix).data.copy_(bias_ih)
                    getattr(lstm, 'bias_hh_l0' + suffix).data.copy_(bias_hh)
                if proj_size > 0 and p is not None:
                    getattr(lstm, 'weight_hr_l0' + suffix).data.copy_(p[idx])
            state = (initial_h, initial_c) if initial_h is not None and initial_c is not None else None
            y, (y_h, y_c) = lstm(x, state) if state is not None else lstm(x)
        else:
            reverse = self.direction == 'reverse'
            lstm = torch.nn.LSTM(
                input_size, self.hidden_size, bias=has_bias,
                proj_size=proj_size).to(device=x.device, dtype=x.dtype)
            lstm.weight_ih_l0.data.copy_(_onnx_lstm_to_torch(w[0]))
            lstm.weight_hh_l0.data.copy_(_onnx_lstm_to_torch(r[0]))
            if has_bias:
                bias_ih = _onnx_lstm_to_torch(b[0, : 4 * self.hidden_size].reshape(4 * self.hidden_size, 1)).reshape(-1)
                bias_hh = _onnx_lstm_to_torch(b[0, 4 * self.hidden_size :].reshape(4 * self.hidden_size, 1)).reshape(-1)
                lstm.bias_ih_l0.data.copy_(bias_ih)
                lstm.bias_hh_l0.data.copy_(bias_hh)
            if proj_size > 0 and p is not None:
                lstm.weight_hr_l0.data.copy_(p[0])
            x_run = torch.flip(x, dims=[0]) if reverse else x
            state = (initial_h, initial_c) if initial_h is not None and initial_c is not None else None
            y, (y_h, y_c) = lstm(x_run, state) if state is not None else lstm(x_run)
            if reverse:
                y = torch.flip(y, dims=[0])
        return self._format_output(y, batch, num_directions), y_h.reshape(num_directions, batch, hidden_out), y_c.reshape(num_directions, batch, self.hidden_size)


class exGRU_torch(torch.nn.Module):
    def __init__(self, hidden_size, direction='forward', input_layout='snc', output_layout='snc', batch_size=None, sequence_size=None, **kwargs):
        super(exGRU_torch, self).__init__()
        self.hidden_size = int(hidden_size)
        self.direction = direction
        self.input_layout = input_layout
        self.output_layout = output_layout
        self.batch_size = batch_size
        self.sequence_size = sequence_size

    def _normalize_input(self, x):
        if self.input_layout == 'snc':
            return x.reshape(x.shape[0], x.shape[1], -1), x.shape[0], x.shape[1]
        seq = int(self.sequence_size or 1)
        batch = int(self.batch_size or (x.shape[0] // seq))
        return x.reshape(seq, batch, -1), seq, batch

    def _format_output(self, y, batch, num_directions):
        seq = y.shape[0]
        hidden = y.shape[-1] // num_directions
        y = y.reshape(seq, batch, num_directions, hidden).permute(0, 2, 1, 3).contiguous()
        if self.output_layout == 'snc':
            return y.permute(0, 2, 1, 3).reshape(seq, batch, -1)
        if self.output_layout == '(sn)c':
            return y.permute(0, 2, 1, 3).reshape(seq * batch, -1, 1, 1)
        return y

    def forward(self, x, w, r, b=None, seq_lens=None, initial_h=None):
        x, _, batch = self._normalize_input(x)
        num_directions = 2 if self.direction == 'bidirectional' else 1
        has_bias = b is not None
        input_size = x.shape[-1]
        if self.direction == 'bidirectional':
            gru = torch.nn.GRU(
                input_size, self.hidden_size, bias=has_bias,
                bidirectional=True).to(device=x.device, dtype=x.dtype)
            suffixes = ['', '_reverse']
            for idx, suffix in enumerate(suffixes):
                getattr(gru, 'weight_ih_l0' + suffix).data.copy_(_onnx_gru_to_torch(w[idx]))
                getattr(gru, 'weight_hh_l0' + suffix).data.copy_(_onnx_gru_to_torch(r[idx]))
                if has_bias:
                    gate = 3 * self.hidden_size
                    getattr(gru, 'bias_ih_l0' + suffix).data.copy_(_onnx_gru_to_torch(b[idx, :gate].reshape(gate, 1)).reshape(-1))
                    getattr(gru, 'bias_hh_l0' + suffix).data.copy_(_onnx_gru_to_torch(b[idx, gate:].reshape(gate, 1)).reshape(-1))
            y, y_h = gru(x, initial_h) if initial_h is not None else gru(x)
        else:
            reverse = self.direction == 'reverse'
            gru = torch.nn.GRU(
                input_size, self.hidden_size,
                bias=has_bias).to(device=x.device, dtype=x.dtype)
            gru.weight_ih_l0.data.copy_(_onnx_gru_to_torch(w[0]))
            gru.weight_hh_l0.data.copy_(_onnx_gru_to_torch(r[0]))
            if has_bias:
                gate = 3 * self.hidden_size
                gru.bias_ih_l0.data.copy_(_onnx_gru_to_torch(b[0, :gate].reshape(gate, 1)).reshape(-1))
                gru.bias_hh_l0.data.copy_(_onnx_gru_to_torch(b[0, gate:].reshape(gate, 1)).reshape(-1))
            x_run = torch.flip(x, dims=[0]) if reverse else x
            y, y_h = gru(x_run, initial_h) if initial_h is not None else gru(x_run)
            if reverse:
                y = torch.flip(y, dims=[0])
        return self._format_output(y, batch, num_directions), y_h.reshape(num_directions, batch, self.hidden_size)
