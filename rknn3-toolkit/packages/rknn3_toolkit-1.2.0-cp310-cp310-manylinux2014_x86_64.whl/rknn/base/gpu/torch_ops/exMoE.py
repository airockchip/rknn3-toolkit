import torch

from .exUnifiedMoE import _MoEFunctional_torch


class DeepseekV2MoE_torch(torch.nn.Module, _MoEFunctional_torch):
    """Direct Torch implementation of the legacy DeepseekV2MoE op."""

    def __init__(
        self,
        n_routed_experts,
        num_experts_per_tok,
        n_shared_experts=0,
        scoring_func="softmax",
        topk_method="greedy",
        norm_topk_prob=0,
        routed_scaling_factor=1.0,
        activation="silu",
        moe_structure=None,
        layer_id=0,
        moe_intermediate_size=None,
        **kwargs,
    ):
        super(DeepseekV2MoE_torch, self).__init__()
        self.n_routed_experts = int(n_routed_experts)
        self.num_experts_per_tok = int(num_experts_per_tok)
        self.n_shared_experts = int(n_shared_experts or 0)
        self.scoring_func = self._string_attr(scoring_func, "softmax")
        self.topk_method = self._string_attr(topk_method, "greedy")
        self.norm_topk_prob = bool(norm_topk_prob)
        self.routed_scaling_factor = float(
            1.0 if routed_scaling_factor is None else routed_scaling_factor
        )
        self.activation = self._string_attr(activation, "silu")
        self.moe_structure = self._string_attr(moe_structure)
        self.layer_id = int(layer_id or 0)
        self.moe_intermediate_size = (
            None
            if moe_intermediate_size is None
            else int(moe_intermediate_size)
        )

    def forward(self, *inputs):
        expected = (
            2
            + 3 * self.n_routed_experts
            + 3 * self.n_shared_experts
        )
        if len(inputs) != expected:
            raise ValueError(
                "DeepseekV2MoE expected {} inputs, got {}".format(
                    expected, len(inputs)
                )
            )
        hidden_states, gate_weight = inputs[:2]
        if hidden_states.dim() != 3:
            raise ValueError("DeepseekV2MoE hidden states must be rank 3")
        hidden_size = hidden_states.shape[-1]
        if tuple(gate_weight.shape) != (
            self.n_routed_experts,
            hidden_size,
        ):
            raise ValueError("DeepseekV2MoE gate weight shape is invalid")
        if not 1 <= self.num_experts_per_tok <= self.n_routed_experts:
            raise ValueError("DeepseekV2MoE expert count is out of range")
        if self.scoring_func != "softmax" or self.topk_method != "greedy":
            raise NotImplementedError(
                "DeepseekV2MoE only supports softmax greedy routing"
            )
        if self.activation.upper() not in ("SILU", "SWISH"):
            raise NotImplementedError(
                "DeepseekV2MoE only supports silu/swish activation"
            )

        original_dtype = hidden_states.dtype
        flat = hidden_states.reshape(-1, hidden_size).to(torch.float32)
        gate_weight = gate_weight.to(torch.float32)
        scores = torch.softmax(
            torch.matmul(flat, gate_weight.transpose(0, 1)), dim=1
        )
        topk_ids = self._topk(
            scores, self.num_experts_per_tok
        )
        topk_prob = torch.gather(scores, 1, topk_ids)
        if self.norm_topk_prob:
            topk_prob = topk_prob / (
                topk_prob.sum(dim=1, keepdim=True) + 1e-20
            )
        topk_prob = topk_prob * self.routed_scaling_factor

        cursor = 2
        output = torch.zeros_like(flat, dtype=torch.float32)
        for expert_id in range(self.n_routed_experts):
            gate = inputs[cursor].to(torch.float32)
            up = inputs[cursor + 1].to(torch.float32)
            down = inputs[cursor + 2].to(torch.float32)
            cursor += 3
            token_weight = torch.sum(
                topk_prob
                * (topk_ids == expert_id).to(dtype=topk_prob.dtype),
                dim=1,
            )
            token_indices = torch.nonzero(
                token_weight, as_tuple=False
            ).reshape(-1)
            if token_indices.numel() == 0:
                continue
            expert_output = self._legacy_silu_ffn(
                flat[token_indices], gate, up, down
            )
            output = output.index_add(
                0,
                token_indices,
                expert_output * token_weight[token_indices, None],
            )

        for _ in range(self.n_shared_experts):
            gate = inputs[cursor].to(torch.float32)
            up = inputs[cursor + 1].to(torch.float32)
            down = inputs[cursor + 2].to(torch.float32)
            cursor += 3
            output = output + self._legacy_silu_ffn(flat, gate, up, down)
        return output.to(original_dtype).reshape(hidden_states.shape)

    def forward_symbolic(self, *inputs):
        """Shape-preserving body used while exporting the custom op node."""
        if not inputs:
            raise ValueError("DeepseekV2MoE requires inputs")
        return inputs[0]


class _QwenMoe_torch(torch.nn.Module, _MoEFunctional_torch):
    """Shared implementation for the distinct Qwen3/Qwen3.5 op types."""

    def __init__(
        self,
        num_experts,
        intermediate_size,
        top_k,
        normalize_topk=0,
        activation="silu",
        shared_gate_activation="silu",
        shared_intermediate_size=None,
        **kwargs,
    ):
        super(_QwenMoe_torch, self).__init__()
        self.num_experts = int(num_experts)
        self.intermediate_size = int(intermediate_size)
        self.top_k = int(top_k)
        self.normalize_topk = bool(normalize_topk)
        self.activation = self._string_attr(activation, "silu")
        self.shared_gate_activation = self._string_attr(
            shared_gate_activation, "silu"
        )
        self.shared_intermediate_size = (
            None
            if shared_intermediate_size is None
            else int(shared_intermediate_size)
        )

    def forward(self, *inputs):
        if len(inputs) not in (4, 8):
            raise ValueError("Qwen MoE expects either 4 or 8 inputs")
        hidden_states, gate_weight, gate_up_weight, down_weight = inputs[:4]
        if hidden_states.dim() != 3:
            raise ValueError("Qwen MoE hidden states must be rank 3")
        hidden_size = hidden_states.shape[-1]
        if self.num_experts <= 0 or not 1 <= self.top_k <= self.num_experts:
            raise ValueError("Qwen MoE num_experts/top_k is out of range")
        if self.activation.upper() not in ("SILU", "SWISH"):
            raise NotImplementedError(
                "Qwen MoE only supports silu/swish routed activation"
            )
        if tuple(gate_weight.shape) != (self.num_experts, hidden_size):
            raise ValueError("Qwen MoE gate weight shape is invalid")
        if tuple(gate_up_weight.shape) != (
            self.num_experts,
            2 * self.intermediate_size,
            hidden_size,
        ):
            raise ValueError("Qwen MoE gate/up weight shape is invalid")
        if tuple(down_weight.shape) != (
            self.num_experts,
            hidden_size,
            self.intermediate_size,
        ):
            raise ValueError("Qwen MoE down weight shape is invalid")

        original_dtype = hidden_states.dtype
        flat = hidden_states.reshape(-1, hidden_size).to(torch.float32)
        scores = torch.softmax(
            torch.matmul(flat, gate_weight.to(torch.float32).transpose(0, 1)),
            dim=1,
        )
        topk_ids = self._topk(scores, self.top_k)
        topk_prob = torch.gather(scores, 1, topk_ids)
        if self.normalize_topk:
            topk_prob = topk_prob / (
                topk_prob.sum(dim=1, keepdim=True) + 1e-20
            )

        output = torch.zeros_like(flat, dtype=torch.float32)
        gate_up_weight = gate_up_weight.to(torch.float32)
        down_weight = down_weight.to(torch.float32)
        for expert_id in range(self.num_experts):
            token_weight = torch.sum(
                topk_prob
                * (topk_ids == expert_id).to(dtype=topk_prob.dtype),
                dim=1,
            )
            token_indices = torch.nonzero(
                token_weight, as_tuple=False
            ).reshape(-1)
            if token_indices.numel() == 0:
                continue
            gate = gate_up_weight[
                expert_id, : self.intermediate_size
            ]
            up = gate_up_weight[expert_id, self.intermediate_size :]
            expert_output = self._legacy_silu_ffn(
                flat[token_indices], gate, up, down_weight[expert_id]
            )
            output = output.index_add(
                0,
                token_indices,
                expert_output * token_weight[token_indices, None],
            )

        if len(inputs) == 8:
            if self.shared_gate_activation.upper() not in ("SILU", "SWISH"):
                raise NotImplementedError(
                    "Qwen MoE only supports silu/swish shared activation"
                )
            shared_gate, shared_up, shared_down, expert_gate = inputs[4:8]
            shared_intermediate = shared_gate.shape[0]
            if self.shared_intermediate_size is not None:
                if shared_intermediate != self.shared_intermediate_size:
                    raise ValueError(
                        "Qwen MoE shared intermediate size is invalid"
                    )
            if tuple(shared_gate.shape) != (
                shared_intermediate,
                hidden_size,
            ) or tuple(shared_up.shape) != (
                shared_intermediate,
                hidden_size,
            ):
                raise ValueError("Qwen MoE shared gate/up shape is invalid")
            if tuple(shared_down.shape) != (
                hidden_size,
                shared_intermediate,
            ) or tuple(expert_gate.shape) != (1, hidden_size):
                raise ValueError("Qwen MoE shared down/gate shape is invalid")
            shared_output = self._legacy_silu_ffn(
                flat,
                shared_gate.to(torch.float32),
                shared_up.to(torch.float32),
                shared_down.to(torch.float32),
            )
            shared_prob = torch.sigmoid(
                torch.matmul(
                    flat, expert_gate.to(torch.float32).transpose(0, 1)
                )
            )
            output = output + shared_output * shared_prob

        return output.to(original_dtype).reshape(hidden_states.shape)

    def forward_symbolic(self, *inputs):
        """Shape-preserving body used while exporting the custom op node."""
        if not inputs:
            raise ValueError("Qwen MoE requires inputs")
        return inputs[0]


class Qwen35Moe_torch(_QwenMoe_torch):
    """Qwen3.5 MoE custom-op identity."""

    pass


class Qwen3Moe_torch(_QwenMoe_torch):
    """Qwen3 MoE custom-op identity."""

    pass
