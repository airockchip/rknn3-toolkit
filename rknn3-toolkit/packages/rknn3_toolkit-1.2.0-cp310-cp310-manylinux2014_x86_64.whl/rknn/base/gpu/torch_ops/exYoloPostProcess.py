import torch


class exYoloPostProcess_torch(torch.nn.Module):
    def __init__(self, K, iou_type='iou', conf_threshold=0.25, iou_threshold=0.45, **kwargs):
        super(exYoloPostProcess_torch, self).__init__()
        self.K = int(K)
        self.iou_type = iou_type
        if self.iou_type != 'iou':
            raise NotImplementedError(
                "Unsupported exYoloPostProcess iou_type: {}".format(
                    self.iou_type))
        self.conf_threshold = float(conf_threshold)
        self.iou_threshold = float(iou_threshold)

    def _iou(self, box1, box2):
        x1 = torch.maximum(box1[0], box2[0])
        y1 = torch.maximum(box1[1], box2[1])
        x2 = torch.minimum(box1[2], box2[2])
        y2 = torch.minimum(box1[3], box2[3])
        inter = torch.clamp(x2 - x1, min=0) * torch.clamp(y2 - y1, min=0)
        area1 = (box1[2] - box1[0]) * (box1[3] - box1[1])
        area2 = (box2[2] - box2[0]) * (box2[3] - box2[1])
        denom = area1 + area2 - inter
        if float(denom.item()) <= 0:
            return 0.0
        return float((inter / denom).item())

    def forward(self, sum_score, class_score, position, conf_threshold=None, iou_threshold=None):
        conf = self.conf_threshold if conf_threshold is None else float(conf_threshold.reshape(-1)[0].item() if isinstance(conf_threshold, torch.Tensor) else conf_threshold)
        iou_t = self.iou_threshold if iou_threshold is None else float(iou_threshold.reshape(-1)[0].item() if isinstance(iou_threshold, torch.Tensor) else iou_threshold)
        sum_score = sum_score.squeeze()
        class_score = class_score.squeeze(0).squeeze(1)
        position = position.squeeze(0).squeeze(1)
        max_scores, class_indices = torch.max(class_score, dim=0)
        candidates = []
        for idx in range(sum_score.shape[0]):
            if float(sum_score[idx].item()) > conf and float(max_scores[idx].item()) >= conf:
                candidates.append((float(max_scores[idx].item()), int(class_indices[idx].item()), position[:, idx]))
        candidates.sort(key=lambda item: item[0], reverse=True)
        selected = []
        while candidates and len(selected) < self.K:
            picked = candidates.pop(0)
            selected.append(picked)
            remain = []
            for cand in candidates:
                if cand[1] != picked[1] or self._iou(picked[2], cand[2]) <= iou_t:
                    remain.append(cand)
            candidates = remain
        output = torch.zeros((1, self.K, 6), dtype=sum_score.dtype, device=sum_score.device)
        for idx, (score, cls, box) in enumerate(selected):
            output[0, idx, 0] = score
            output[0, idx, 1] = cls
            output[0, idx, 2:] = box
        return output
