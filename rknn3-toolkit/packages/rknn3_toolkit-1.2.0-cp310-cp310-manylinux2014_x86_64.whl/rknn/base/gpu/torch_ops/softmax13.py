import torch


class exSoftmax13_torch(torch.nn.Module):
    def __init__(self, axis=-1, **kwargs):
        super(exSoftmax13_torch, self).__init__()
        self.axis = int(axis)

    def forward(self, x):
        return torch.softmax(x, dim=self.axis)


class exLogSoftmax13_torch(torch.nn.Module):
    def __init__(self, axis=-1, **kwargs):
        super(exLogSoftmax13_torch, self).__init__()
        self.axis = int(axis)

    def forward(self, x):
        return torch.log_softmax(x, dim=self.axis)
