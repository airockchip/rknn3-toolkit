import torch


class exmpiSum_torch(torch.nn.Module):
    def __init__(self, **kwargs):
        super(exmpiSum_torch, self).__init__()

    def forward(self, *inputs):
        out = inputs[0]
        for item in inputs[1:]:
            out = out + item
        return out
