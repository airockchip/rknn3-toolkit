import numpy as np
import torch


class Add_torch(torch.nn.Module):
    def __init__(self):
        super(Add_torch, self).__init__()

    def forward(self, a, b):
        return a + b


class And_torch(torch.nn.Module):
    def __init__(self):
        super(And_torch, self).__init__()

    def forward(self, a, b):
        return torch.logical_and(a, b)


class Mul_torch(torch.nn.Module):
    def __init__(self):
        super(Mul_torch, self).__init__()

    def forward(self, a, b):
        return a * b


class Sub_torch(torch.nn.Module):
    def __init__(self):
        super(Sub_torch, self).__init__()

    def forward(self, a, b):
        return a - b


class Div_torch(torch.nn.Module):
    def __init__(self):
        super(Div_torch, self).__init__()

    def forward(self, a, b):
        if isinstance(a, torch.Tensor) and isinstance(b, torch.Tensor) \
                and not (torch.is_floating_point(a) or torch.is_floating_point(b)
                         or torch.is_complex(a) or torch.is_complex(b)):
            # ONNX integer Div truncates toward zero and preserves dtype;
            # torch `/` would incorrectly promote it to float.
            return torch.div(a, b, rounding_mode="trunc")
        return a / b


class Reciprocal_torch(torch.nn.Module):
    def __init__(self):
        super(Reciprocal_torch, self).__init__()

    def forward(self, x):
        return torch.reciprocal(x)


class IsNaN_torch(torch.nn.Module):
    def __init__(self):
        super(IsNaN_torch, self).__init__()

    def forward(self, x):
        return torch.isnan(x)


class GatherND_torch(torch.nn.Module):
    def __init__(self, batch_dims=0, **kwargs):
        super(GatherND_torch, self).__init__()
        self.batch_dims = int(batch_dims)

    def forward(self, data, indices):
        if not isinstance(indices, torch.Tensor):
            indices = torch.as_tensor(indices)
        indices = indices.to(device=data.device, dtype=torch.long)
        if indices.dim() < 1:
            raise RuntimeError("GatherND indices must have rank >= 1")
        index_depth = int(indices.shape[-1])
        if index_depth + self.batch_dims > data.dim():
            raise RuntimeError("GatherND index depth exceeds data rank")
        prefix_shape = tuple(indices.shape[:-1])
        if self.batch_dims > len(prefix_shape):
            raise RuntimeError("GatherND batch_dims exceeds indices rank - 1")

        index_tuple = []
        for axis in range(self.batch_dims):
            if int(prefix_shape[axis]) != int(data.shape[axis]):
                raise RuntimeError("GatherND batch dimension mismatch at axis {}".format(axis))
            view = [1] * len(prefix_shape)
            view[axis] = int(prefix_shape[axis])
            batch_index = torch.arange(
                prefix_shape[axis], device=data.device, dtype=torch.long)
            index_tuple.append(batch_index.reshape(view).expand(prefix_shape).reshape(-1))
        for axis in range(index_depth):
            index_tuple.append(indices[..., axis].reshape(-1))

        result = data[tuple(index_tuple)]
        suffix_shape = tuple(data.shape[self.batch_dims + index_depth:])
        return result.reshape(prefix_shape + suffix_shape)

    def forward_symbolic(self, data, indices):
        return self.forward(data, indices)


class Max_torch(torch.nn.Module):
    def __init__(self):
        super(Max_torch, self).__init__()

    def forward(self, *inputs):
        if len(inputs) == 0:
            raise RuntimeError("Max expects at least one input")
        out = inputs[0]
        for item in inputs[1:]:
            out = torch.maximum(out, item)
        return out


class Not_torch(torch.nn.Module):
    def __init__(self):
        super(Not_torch, self).__init__()

    def forward(self, x):
        return torch.logical_not(x)


class GatherElements_torch(torch.nn.Module):
    def __init__(self, axis=0, **kwargs):
        super(GatherElements_torch, self).__init__()
        self.axis = int(axis)

    def forward(self, data, indices):
        if not isinstance(indices, torch.Tensor):
            indices = torch.as_tensor(indices)
        axis = self.axis if self.axis >= 0 else self.axis + data.dim()
        indices = indices.to(device=data.device, dtype=torch.long)
        indices = torch.where(indices < 0, indices + data.shape[axis], indices)
        return torch.gather(data, axis, indices)


class Pow_torch(torch.nn.Module):
    def __init__(self):
        super(Pow_torch, self).__init__()

    def forward(self, a, b):
        return torch.pow(a, b)


class Erf_torch(torch.nn.Module):
    def __init__(self):
        super(Erf_torch, self).__init__()

    def forward(self, x):
        return torch.erf(x)


class LayerNormalization_torch(torch.nn.Module):
    def __init__(self, axis=-1, epsilon=1e-5, num_outputs=1, **kwargs):
        super(LayerNormalization_torch, self).__init__()
        self.axis = int(axis)
        self.epsilon = float(epsilon)
        self.stash_type = int(kwargs.get("stash_type", 1))
        self.num_outputs = int(num_outputs)

    def forward(self, x, scale=None, bias=None):
        if self.axis < 0:
            axis = self.axis + x.dim()
        else:
            axis = self.axis
        axes = tuple(range(axis, x.dim()))
        stash_dtype = torch.float32 if self.stash_type == 1 else x.dtype
        x_stash = x.to(dtype=stash_dtype)
        mean = torch.mean(x_stash, dim=axes, keepdim=True)
        variance = torch.mean((x_stash - mean) ** 2, dim=axes, keepdim=True)
        inv_std = torch.rsqrt(variance + self.epsilon)
        y = (x_stash - mean) * inv_std
        if scale is not None:
            y = y * scale.to(dtype=stash_dtype)
        if bias is not None:
            y = y + bias.to(dtype=stash_dtype)
        y = y.to(dtype=x.dtype)
        if self.num_outputs == 1:
            return y
        if self.num_outputs == 2:
            return y, mean
        return y, mean, inv_std


class Concat_torch(torch.nn.Module):
    def __init__(self, axis=0):
        super(Concat_torch, self).__init__()
        self.axis = axis

    def forward(self, *inputs):
        return torch.cat(inputs, dim=self.axis)


class BatchNormalization_torch(torch.nn.Module):
    def __init__(self, epsilon=1e-5, momentum=0.9, training_mode=0,
                 num_outputs=1):
        super(BatchNormalization_torch, self).__init__()
        self.epsilon = float(epsilon)
        self.momentum = float(momentum)
        self.training_mode = bool(training_mode)
        self.num_outputs = int(num_outputs)

    def forward(self, x, scale, bias, mean, var):
        if self.training_mode:
            axes = tuple(axis for axis in range(x.dim()) if axis != 1)
            compute_dtype = torch.float32 if x.dtype in (
                torch.float16, torch.bfloat16) else x.dtype
            x_compute = x.to(dtype=compute_dtype)
            batch_mean = torch.mean(x_compute, dim=axes)
            centered = x_compute - batch_mean.reshape(
                1, -1, *([1] * (x.dim() - 2)))
            batch_var = torch.mean(centered * centered, dim=axes)
            y = centered * torch.rsqrt(
                batch_var.reshape(1, -1, *([1] * (x.dim() - 2)))
                + self.epsilon)
            y = y * scale.to(dtype=compute_dtype).reshape(
                1, -1, *([1] * (x.dim() - 2)))
            y = y + bias.to(dtype=compute_dtype).reshape(
                1, -1, *([1] * (x.dim() - 2)))
            output_mean = (
                mean.to(dtype=compute_dtype) * self.momentum
                + batch_mean * (1.0 - self.momentum))
            output_var = (
                var.to(dtype=compute_dtype) * self.momentum
                + batch_var * (1.0 - self.momentum))
            outputs = (y.to(dtype=x.dtype), output_mean.to(dtype=mean.dtype),
                       output_var.to(dtype=var.dtype))
            return outputs[:self.num_outputs] if self.num_outputs > 1 else outputs[0]
        return torch.nn.functional.batch_norm(
            x,
            mean,
            var,
            weight=scale,
            bias=bias,
            training=False,
            momentum=self.momentum,
            eps=self.epsilon,
        )


class MaxPool_torch(torch.nn.Module):
    def __init__(self, kernel_shape, strides=None, pads=None, dilations=None,
                 ceil_mode=0, return_indices=False, storage_order=0):
        super(MaxPool_torch, self).__init__()
        self.kernel_shape = tuple(kernel_shape)
        self.strides = tuple(strides or [1] * len(self.kernel_shape))
        self.pads = tuple(pads or [0] * (2 * len(self.kernel_shape)))
        self.dilations = tuple(dilations or [1] * len(self.kernel_shape))
        self.ceil_mode = bool(ceil_mode)
        self.return_indices = bool(return_indices)
        self.storage_order = int(storage_order)

    def _padding_parts(self):
        spatial = len(self.kernel_shape)
        begin = tuple(int(v) for v in self.pads[:spatial])
        end = tuple(int(v) for v in self.pads[spatial:])
        return begin, end

    def _pool(self, x, padding, return_indices):
        funcs = {
            1: torch.nn.functional.max_pool1d,
            2: torch.nn.functional.max_pool2d,
            3: torch.nn.functional.max_pool3d,
        }
        if len(self.kernel_shape) not in funcs:
            raise NotImplementedError("MaxPool supports only 1D/2D/3D spatial inputs")
        return funcs[len(self.kernel_shape)](
            x, kernel_size=self.kernel_shape, stride=self.strides,
            padding=padding, dilation=self.dilations,
            ceil_mode=self.ceil_mode, return_indices=return_indices)

    def forward(self, x):
        begin, end = self._padding_parts()
        explicit_padding = begin != end
        if begin == end:
            result = self._pool(x, begin, self.return_indices)
        else:
            if torch.is_floating_point(x):
                pad_value = float("-inf")
            else:
                pad_value = torch.iinfo(x.dtype).min
            torch_pads = []
            for axis in range(len(begin) - 1, -1, -1):
                torch_pads.extend([begin[axis], end[axis]])
            result = self._pool(
                torch.nn.functional.pad(x, tuple(torch_pads), value=pad_value),
                0, self.return_indices)
        if self.return_indices:
            values, indices = result
            spatial_shape = tuple(int(v) for v in x.shape[2:])
            spatial_size = int(np.prod(spatial_shape))
            if explicit_padding:
                padded_shape = tuple(
                    spatial_shape[axis] + begin[axis] + end[axis]
                    for axis in range(len(spatial_shape)))
                remaining = indices
                coords = []
                for size in reversed(padded_shape):
                    coords.append(torch.remainder(remaining, size))
                    remaining = torch.div(
                        remaining, size, rounding_mode="floor")
                coords.reverse()
                original_index = torch.zeros_like(indices)
                stride = 1
                for axis in range(len(spatial_shape) - 1, -1, -1):
                    original_index = original_index + (
                        coords[axis] - begin[axis]) * stride
                    stride *= spatial_shape[axis]
                indices = original_index
            if self.storage_order == 1:
                # torch returns row-major spatial indices. ONNX storage_order=1
                # flattens the spatial coordinates in column-major order.
                remaining = indices
                coords = []
                for size in reversed(spatial_shape):
                    coords.append(torch.remainder(remaining, size))
                    remaining = torch.div(remaining, size, rounding_mode="floor")
                coords.reverse()
                column_major = torch.zeros_like(indices)
                stride = 1
                for coord, size in zip(coords, spatial_shape):
                    column_major = column_major + coord * stride
                    stride *= size
                indices = column_major
            elif self.storage_order != 0:
                raise RuntimeError("MaxPool storage_order must be 0 or 1")

            # ONNX indices address the flattened NCHW/NCDHW input, whereas
            # torch max_pool returns an offset inside each spatial plane.
            nc = torch.arange(
                int(x.shape[0]) * int(x.shape[1]),
                dtype=indices.dtype, device=indices.device,
            ).reshape(int(x.shape[0]), int(x.shape[1]), *([1] * len(spatial_shape)))
            indices = indices + nc * spatial_size
            result = values, indices
        return result


class AveragePool_torch(torch.nn.Module):
    def __init__(self, kernel_shape, strides=None, pads=None, ceil_mode=0, count_include_pad=0):
        super(AveragePool_torch, self).__init__()
        self.kernel_shape = tuple(kernel_shape)
        self.strides = tuple(strides or [1] * len(self.kernel_shape))
        self.pads = tuple(pads or [0] * (2 * len(self.kernel_shape)))
        self.ceil_mode = bool(ceil_mode)
        self.count_include_pad = bool(count_include_pad)

    def _padding_parts(self):
        spatial = len(self.kernel_shape)
        begin = tuple(int(v) for v in self.pads[:spatial])
        end = tuple(int(v) for v in self.pads[spatial:])
        return begin, end

    def _pool(self, x, padding, count_include_pad, ceil_mode=None):
        funcs = {
            1: torch.nn.functional.avg_pool1d,
            2: torch.nn.functional.avg_pool2d,
            3: torch.nn.functional.avg_pool3d,
        }
        if len(self.kernel_shape) not in funcs:
            raise NotImplementedError("AveragePool supports only 1D/2D/3D spatial inputs")
        return funcs[len(self.kernel_shape)](
            x, kernel_size=self.kernel_shape, stride=self.strides,
            padding=padding,
            ceil_mode=self.ceil_mode if ceil_mode is None else ceil_mode,
            count_include_pad=count_include_pad)

    def _pool_ceil_include_pad(self, x, begin, end):
        """ONNX counts the implicit ceil extension in the divisor.

        PyTorch excludes that extension even with count_include_pad=True. Pad
        it explicitly so every emitted window has the full kernel divisor.
        """
        torch_pads = []
        for axis in range(len(begin) - 1, -1, -1):
            torch_pads.extend([begin[axis], end[axis]])
        padded = torch.nn.functional.pad(x, tuple(torch_pads), value=0.0)

        extra_end = []
        for axis, (size, pad_begin, pad_end, kernel, stride) in enumerate(zip(
                x.shape[2:], begin, end, self.kernel_shape, self.strides)):
            total = int(size) + pad_begin + pad_end
            output = (total - int(kernel) + int(stride) - 1) // int(stride) + 1
            if (output - 1) * int(stride) >= int(size) + pad_begin:
                output -= 1
            required = max(
                (output - 1) * int(stride) + int(kernel) - total, 0)
            extra_end.append(required)
        if any(extra_end):
            extra_pads = []
            for axis in range(len(extra_end) - 1, -1, -1):
                extra_pads.extend([0, extra_end[axis]])
            padded = torch.nn.functional.pad(
                padded, tuple(extra_pads), value=0.0)
        return self._pool(
            padded, 0, count_include_pad=True, ceil_mode=False)

    def forward(self, x):
        begin, end = self._padding_parts()
        if self.ceil_mode and self.count_include_pad:
            return self._pool_ceil_include_pad(x, begin, end)
        if begin == end:
            return self._pool(x, begin, self.count_include_pad)

        torch_pads = []
        for axis in range(len(begin) - 1, -1, -1):
            torch_pads.extend([begin[axis], end[axis]])
        padded = torch.nn.functional.pad(x, tuple(torch_pads), value=0.0)
        pooled = self._pool(padded, 0, True)
        if self.count_include_pad:
            return pooled
        mask = torch.nn.functional.pad(
            torch.ones_like(x), tuple(torch_pads), value=0.0)
        valid_fraction = self._pool(mask, 0, True)
        return torch.where(
            valid_fraction > 0, pooled / valid_fraction,
            torch.zeros_like(pooled))


class GlobalAveragePool_torch(torch.nn.Module):
    def __init__(self):
        super(GlobalAveragePool_torch, self).__init__()

    def forward(self, x):
        if x.dim() < 3:
            raise RuntimeError("GlobalAveragePool input rank must be >= 3")
        return torch.mean(x, dim=tuple(range(2, x.dim())), keepdim=True)


class Flatten_torch(torch.nn.Module):
    def __init__(self, axis=1):
        super(Flatten_torch, self).__init__()
        self.axis = int(axis)

    def forward(self, x):
        # ONNX Flatten: output is always 2D
        #   output = (prod(shape[:axis]), prod(shape[axis:]))
        # axis can equal rank (inner dim becomes 1)
        ndim = x.dim()
        axis = self.axis if self.axis >= 0 else self.axis + ndim
        axis = max(0, min(axis, ndim))
        outer = 1
        for i in range(axis):
            outer *= x.shape[i]
        return x.reshape(outer, -1)

    def forward_symbolic(self, x):
        """Trace-friendly Flatten: use aten::flatten which maps to a single
        ONNX Flatten node, avoiding the Shape+Gather+Reshape expansion that
        the Python for-loop in forward() causes.
        """
        ndim = x.dim()
        axis = self.axis if self.axis >= 0 else self.axis + ndim
        axis = max(0, min(axis, ndim))
        if axis >= ndim:
            # ONNX Flatten with axis==rank: inner dim is 1, output is (prod(all), 1).
            # torch.flatten(x, ndim, ndim) is a no-op on a ndim-D tensor, so
            # append a singleton dim to match ONNX semantics.
            return x.reshape(-1, 1)
        return torch.flatten(x, axis, ndim)


class Softmax_torch(torch.nn.Module):
    def __init__(self, axis=-1):
        super(Softmax_torch, self).__init__()
        self.axis = int(axis)

    def forward(self, x):
        return torch.softmax(x, dim=self.axis)


class LeakyRelu_torch(torch.nn.Module):
    def __init__(self, alpha=0.01):
        super(LeakyRelu_torch, self).__init__()
        self.alpha = float(alpha)

    def forward(self, x):
        return torch.nn.functional.leaky_relu(x, negative_slope=self.alpha)


class Tanh_torch(torch.nn.Module):
    def __init__(self):
        super(Tanh_torch, self).__init__()

    def forward(self, x):
        return torch.tanh(x)


class Gemm_torch(torch.nn.Module):
    def __init__(self, alpha=1.0, beta=1.0, transA=0, transB=0):
        super(Gemm_torch, self).__init__()
        self.alpha = float(alpha)
        self.beta = float(beta)
        self.transA = bool(transA)
        self.transB = bool(transB)

    def forward(self, a, b, c=None):
        out_dtype = torch.promote_types(a.dtype, b.dtype)
        compute_dtype = out_dtype
        if out_dtype in (torch.float16, torch.bfloat16):
            compute_dtype = torch.float32

        a = a.to(dtype=compute_dtype)
        b = b.to(dtype=compute_dtype)
        if self.transA:
            a = a.transpose(-1, -2)
        if self.transB:
            b = b.transpose(-1, -2)
        y = self.alpha * torch.matmul(a, b)
        if c is not None:
            y = y + self.beta * c.to(dtype=compute_dtype)
        if y.dtype != out_dtype:
            y = y.to(dtype=out_dtype)
        return y

    def forward_symbolic(self, a, b, c=None):
        """Trace-friendly Gemm: avoid alpha*matmul+beta*c which TorchScript
        decomposes into MatMul+Mul+Add+Mul. Use plain matmul/add so the default
        ONNX symbolic can fuse them back into a single Gemm node.
        """
        if self.transA:
            a = a.transpose(-1, -2)
        if self.transB:
            b = b.transpose(-1, -2)
        y = torch.matmul(a, b)
        if c is not None:
            y = y + c
        return y


class ConvTranspose_torch(torch.nn.Module):
    def __init__(
        self,
        in_channels,
        out_channels,
        stride=1,
        padding=0,
        output_padding=0,
        dilation=1,
        groups=1,
        bias=True,
        pads=None,
        output_shape=None,
        auto_pad="NOTSET",
    ):
        super(ConvTranspose_torch, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.stride = stride
        self.padding = padding
        self.output_padding = output_padding
        self.dilation = dilation
        self.groups = groups
        self.bias = bias
        self.pads = tuple(pads) if pads is not None else None
        self.output_shape = (tuple(int(v) for v in output_shape)
                             if output_shape is not None else None)
        self.auto_pad = auto_pad.decode("utf-8") if isinstance(
            auto_pad, bytes) else str(auto_pad)

    def _dispatch_conv_transpose(self, dim):
        if dim == 1:
            return torch.nn.functional.conv_transpose1d
        if dim == 2:
            return torch.nn.functional.conv_transpose2d
        if dim == 3:
            return torch.nn.functional.conv_transpose3d
        raise NotImplementedError(
            "ConvTranspose_torch only supports 1D/2D/3D convolution, got {}D".format(dim)
        )

    def forward(self, x, weight, bias=None):
        conv_transpose_fn = self._dispatch_conv_transpose(weight.dim() - 2)
        spatial_rank = weight.dim() - 2
        padding = self.padding
        crop_begin = crop_end = None
        if self.output_shape is not None:
            # ONNX ignores explicit pads when output_shape is present and
            # derives the necessary crop from the requested shape. PyTorch's
            # output_padding cannot express all valid ONNX target shapes, so
            # run the unpadded convolution and resize its border explicitly.
            padding = 0
        elif self.pads is not None:
            crop_begin = tuple(int(v) for v in self.pads[:spatial_rank])
            crop_end = tuple(int(v) for v in self.pads[spatial_rank:])
            if crop_begin == crop_end:
                padding = crop_begin
                crop_begin = crop_end = None
            else:
                # PyTorch ConvTranspose only accepts symmetric padding. Run
                # unpadded then crop each side to implement ONNX pads_begin/end.
                padding = 0
        if weight.dtype != x.dtype and torch.is_floating_point(weight):
            x = x.to(dtype=weight.dtype)
        y = conv_transpose_fn(
            x,
            weight,
            bias,
            stride=self.stride,
            padding=padding,
            output_padding=self.output_padding,
            groups=self.groups,
            dilation=self.dilation,
        )
        if crop_begin is not None:
            slices = [slice(None), slice(None)]
            for axis in range(spatial_rank):
                stop = y.shape[axis + 2] - crop_end[axis]
                slices.append(slice(crop_begin[axis], stop))
            y = y[tuple(slices)]
        if self.output_shape is not None:
            slices = [slice(None), slice(None)]
            end_padding = []
            for axis, requested in enumerate(self.output_shape):
                actual = int(y.shape[axis + 2])
                crop_total = max(actual - requested, 0)
                if self.auto_pad == "SAME_UPPER":
                    crop_start = crop_total // 2
                else:
                    # ONNX NOTSET follows SAME_LOWER when it has to infer pads
                    # from output_shape: an odd extra crop is placed first.
                    crop_start = (crop_total + 1) // 2
                slices.append(slice(crop_start, crop_start + min(actual, requested)))
                end_padding.append(max(requested - actual, 0))
            y = y[tuple(slices)]
            if any(end_padding):
                torch_pads = []
                for amount in reversed(end_padding):
                    torch_pads.extend([0, amount])
                y = torch.nn.functional.pad(y, tuple(torch_pads))
        return y


class MatMul_torch(torch.nn.Module):
    def __init__(self):
        super(MatMul_torch, self).__init__()

    def forward(self, a, b):
        out_dtype = torch.promote_types(a.dtype, b.dtype)
        compute_dtype = out_dtype
        if out_dtype in (torch.float16, torch.bfloat16):
            compute_dtype = torch.float32

        out = torch.matmul(a.to(dtype=compute_dtype), b.to(dtype=compute_dtype))
        if out.dtype != out_dtype:
            out = out.to(dtype=out_dtype)
        return out


class Resize_torch(torch.nn.Module):
    def __init__(
        self,
        mode="nearest",
        coordinate_transformation_mode="half_pixel",
        nearest_mode="round_prefer_floor",
        axes=None,
        cubic_coeff_a=-0.75,
        exclude_outside=0,
        extrapolation_value=0.0,
        antialias=0,
        keep_aspect_ratio_policy="stretch",
    ):
        super(Resize_torch, self).__init__()
        self.mode = mode
        self.coordinate_transformation_mode = coordinate_transformation_mode
        self.nearest_mode = nearest_mode
        self.axes = tuple(int(v) for v in axes) if axes is not None else None
        self.cubic_coeff_a = float(cubic_coeff_a)
        self.exclude_outside = bool(exclude_outside)
        self.extrapolation_value = float(extrapolation_value)
        self.antialias = bool(antialias)
        self.keep_aspect_ratio_policy = keep_aspect_ratio_policy

    def _get_resize_spec(self, x, scales, sizes):
        axes = self.axes if self.axes is not None else tuple(range(x.dim()))
        axes = tuple(axis + x.dim() if axis < 0 else axis for axis in axes)
        if len(set(axes)) != len(axes):
            raise RuntimeError("Resize axes must not contain duplicates")
        if sizes is not None:
            flat = sizes.reshape(-1).to(dtype=torch.int64)
            values = tuple(int(v.item()) for v in flat)
            if self.axes is None:
                target = values
            else:
                target = tuple(values)
            if len(target) != len(axes):
                raise RuntimeError("Resize sizes length does not match axes")
            if any(value <= 0 for value in target):
                raise RuntimeError("Resize sizes values must be positive")
            requested_scales = tuple(
                float(target[index]) / float(x.shape[axis])
                for index, axis in enumerate(axes))
            if self.keep_aspect_ratio_policy == "stretch":
                scale_values = requested_scales
            elif self.keep_aspect_ratio_policy in ("not_larger", "not_smaller"):
                common_scale = (min(requested_scales)
                                if self.keep_aspect_ratio_policy == "not_larger"
                                else max(requested_scales))
                target = tuple(
                    int(np.floor(common_scale * float(x.shape[axis]) + 0.5))
                    for axis in axes)
                scale_values = (common_scale,) * len(axes)
            else:
                raise NotImplementedError(
                    "Unsupported Resize keep_aspect_ratio_policy: {}".format(
                        self.keep_aspect_ratio_policy))
            return axes, target, scale_values
        if scales is not None:
            flat = scales.reshape(-1).to(dtype=torch.float32)
            scale_values = tuple(float(v.item()) for v in flat)
            if len(scale_values) != len(axes):
                raise RuntimeError("Resize scales length does not match axes")
            if any(scale <= 0.0 for scale in scale_values):
                raise RuntimeError("Resize scales values must be positive")
            target = tuple(
                int(np.floor(float(x.shape[axis]) * scale))
                for axis, scale in zip(axes, scale_values))
            return axes, target, scale_values
        raise RuntimeError("Resize_torch expects sizes or scales input")

    def _source_positions(self, out_size, in_size, scale, roi_start, roi_end, device):
        # ONNX scales/ROI inputs are float32 in the supported graphs and ORT
        # computes source coordinates at that precision. Using float64 changes
        # floor/ceil at exact boundaries (for example scale=0.6).
        out = torch.arange(out_size, device=device, dtype=torch.float32)
        mode = self.coordinate_transformation_mode
        if mode == "align_corners":
            if out_size <= 1:
                return torch.zeros_like(out)
            return out * float(in_size - 1) / float(out_size - 1)
        if mode == "asymmetric":
            return out / scale
        if mode == "pytorch_half_pixel":
            if out_size <= 1:
                return torch.full_like(out, -0.5)
            return (out + 0.5) / scale - 0.5
        if mode == "half_pixel":
            return (out + 0.5) / scale - 0.5
        if mode == "half_pixel_symmetric":
            output_width = float(in_size) * scale
            adjustment = float(out_size) / output_width if output_width else 0.0
            offset = float(in_size) * 0.5 * (1.0 - adjustment)
            return offset + (out + 0.5) / scale - 0.5
        if mode == "tf_crop_and_resize":
            if out_size > 1:
                return (roi_start * (in_size - 1)
                        + out * (roi_end - roi_start) * (in_size - 1) / (out_size - 1))
            return torch.full_like(out, 0.5 * (roi_start + roi_end) * (in_size - 1))
        raise NotImplementedError(
            "Unsupported Resize coordinate_transformation_mode: {}".format(mode))

    def _nearest_indices(self, positions, in_size):
        mode = self.nearest_mode
        if mode == "round_prefer_floor":
            indices = torch.ceil(positions - 0.5)
        elif mode == "round_prefer_ceil":
            indices = torch.floor(positions + 0.5)
        elif mode == "floor":
            indices = torch.floor(positions)
        elif mode == "ceil":
            indices = torch.ceil(positions)
        else:
            raise NotImplementedError("Unsupported Resize nearest_mode: {}".format(mode))
        return indices.to(dtype=torch.long).clamp(0, in_size - 1)

    def _resize_nearest(self, x, specs):
        if self.antialias:
            raise NotImplementedError(
                "Resize antialias is only defined for linear and cubic modes")
        result = x
        for axis, out_size, positions in specs:
            in_size = int(result.shape[axis])
            indices = self._nearest_indices(positions, in_size)
            result = torch.index_select(result, axis, indices)
            if self.coordinate_transformation_mode == "tf_crop_and_resize":
                outside = (positions < 0) | (positions > in_size - 1)
                mask_shape = [1] * result.dim()
                mask_shape[axis] = out_size
                result = torch.where(
                    outside.reshape(mask_shape),
                    torch.full_like(result, self.extrapolation_value), result)
        return result

    def _weighted_axis(self, result, axis, indices, weights):
        in_size = int(result.shape[axis])
        valid = (indices >= 0) & (indices < in_size)
        if self.exclude_outside:
            weights = weights * valid.to(dtype=weights.dtype)
            denom = torch.sum(weights, dim=1, keepdim=True)
            weights = torch.where(
                denom != 0, weights / denom, torch.zeros_like(weights))
        indices = indices.clamp(0, in_size - 1)
        gathered = torch.index_select(result, axis, indices.reshape(-1))
        gathered_shape = list(result.shape)
        gathered_shape[axis] = int(indices.shape[0])
        gathered_shape.insert(axis + 1, int(indices.shape[1]))
        gathered = gathered.reshape(gathered_shape)
        weight_shape = [1] * gathered.dim()
        weight_shape[axis] = int(weights.shape[0])
        weight_shape[axis + 1] = int(weights.shape[1])
        return torch.sum(
            gathered * weights.to(dtype=result.dtype).reshape(weight_shape),
            dim=axis + 1)

    @staticmethod
    def _filter_base_and_ratio(positions):
        lower = torch.floor(positions)
        fraction = positions - lower
        is_integer = fraction == 0
        ratio = torch.where(is_integer, torch.ones_like(fraction), fraction)
        base = torch.where(is_integer, lower - 1.0, lower)
        return base.to(dtype=torch.long), ratio

    def _resize_linear(self, x, specs, scale_values):
        if not torch.is_floating_point(x):
            raise RuntimeError("Resize linear mode requires floating-point input")
        output_dtype = x.dtype
        result = x.float() if x.dtype in (torch.float16, torch.bfloat16) else x
        for (axis, _, positions), axis_scale in zip(specs, scale_values):
            in_size = int(result.shape[axis])
            filter_scale = min(float(axis_scale), 1.0) if self.antialias else 1.0
            start = int(np.floor(-1.0 / filter_scale) + 1)
            footprint = 2 - 2 * start
            offsets = torch.arange(
                start, start + footprint, device=result.device,
                dtype=positions.dtype)
            base, ratio = self._filter_base_and_ratio(positions)
            indices = base[:, None] + offsets.to(dtype=torch.long)[None, :]
            distances = (offsets[None, :] - ratio[:, None]) * filter_scale
            weights = torch.clamp(1.0 - torch.abs(distances), min=0.0, max=1.0)
            if self.antialias:
                weights = weights / torch.sum(weights, dim=1, keepdim=True)
            result = self._weighted_axis(result, axis, indices, weights)
            if self.coordinate_transformation_mode == "tf_crop_and_resize":
                outside = (positions < 0) | (positions > in_size - 1)
                weight_shape = [1] * result.dim()
                weight_shape[axis] = positions.numel()
                result = torch.where(
                    outside.reshape(weight_shape),
                    torch.full_like(result, self.extrapolation_value), result)
        return result.to(dtype=output_dtype)

    def _resize_cubic(self, x, specs, scale_values):
        if not torch.is_floating_point(x):
            raise RuntimeError("Resize cubic mode requires floating-point input")
        output_dtype = x.dtype
        result = x.float() if x.dtype in (torch.float16, torch.bfloat16) else x
        for (axis, _, positions), axis_scale in zip(specs, scale_values):
            in_size = int(result.shape[axis])
            filter_scale = min(float(axis_scale), 1.0) if self.antialias else 1.0
            start = int(np.floor(-2.0 / filter_scale) + 1)
            footprint = 4 - 2 * start
            offsets = torch.arange(
                start, start + footprint, device=result.device,
                dtype=positions.dtype)
            base, ratio = self._filter_base_and_ratio(positions)
            indices = base[:, None] + offsets.to(dtype=torch.long)[None, :]
            distances = torch.abs(
                (offsets[None, :] - ratio[:, None]) * filter_scale)
            a = self.cubic_coeff_a
            d2 = distances * distances
            d3 = d2 * distances
            weights = torch.where(
                distances <= 1.0,
                (a + 2.0) * d3 - (a + 3.0) * d2 + 1.0,
                torch.where(
                    distances < 2.0,
                    a * d3 - 5.0 * a * d2 + 8.0 * a * distances - 4.0 * a,
                    torch.zeros_like(distances)))
            if self.antialias:
                weights = weights / torch.sum(weights, dim=1, keepdim=True)
            result = self._weighted_axis(result, axis, indices, weights)
            if self.coordinate_transformation_mode == "tf_crop_and_resize":
                outside = (positions < 0) | (positions > in_size - 1)
                mask_shape = [1] * result.dim()
                mask_shape[axis] = positions.numel()
                result = torch.where(
                    outside.reshape(mask_shape),
                    torch.full_like(result, self.extrapolation_value), result)
        return result.to(dtype=output_dtype)

    def forward(self, _x, _roi=None, scales=None, sizes=None):
        axes, target, scale_values = self._get_resize_spec(_x, scales, sizes)
        roi = None
        if _roi is not None and _roi.numel() > 0:
            roi = _roi.reshape(-1).to(dtype=torch.float64)
        specs = []
        for index, (axis, out_size, scale) in enumerate(zip(axes, target, scale_values)):
            roi_start, roi_end = 0.0, 1.0
            if roi is not None:
                roi_axis = axis if self.axes is None else index
                roi_start = float(roi[roi_axis].item())
                roi_end = float(roi[roi_axis + len(axes)].item())
            positions = self._source_positions(
                out_size, int(_x.shape[axis]), scale,
                roi_start, roi_end, _x.device)
            specs.append((axis, out_size, positions))

        if self.mode == "nearest":
            return self._resize_nearest(_x, specs)
        if self.mode == "linear":
            return self._resize_linear(_x, specs, scale_values)
        if self.mode == "cubic":
            return self._resize_cubic(_x, specs, scale_values)
        raise NotImplementedError("Unsupported Resize mode: {}".format(self.mode))

    def forward_symbolic(self, _x, _roi=None, scales=None, sizes=None):
        """Keep the numerical implementation while the export wrapper emits
        one standard ONNX Resize node.

        Constructing a plain helper module here intentionally avoids inlining
        the nested Resize helper calls into the generated autograd.Function;
        textual inlining cannot safely rewrite calls containing nested Python
        expressions such as ``int(x.shape[axis])``.
        """
        return Resize_torch(
            mode=self.mode,
            coordinate_transformation_mode=self.coordinate_transformation_mode,
            nearest_mode=self.nearest_mode,
            axes=self.axes,
            cubic_coeff_a=self.cubic_coeff_a,
            exclude_outside=self.exclude_outside,
            extrapolation_value=self.extrapolation_value,
            antialias=self.antialias,
            keep_aspect_ratio_policy=self.keep_aspect_ratio_policy,
        ).forward(_x, _roi, scales, sizes)


class Transpose_torch(torch.nn.Module):
    def __init__(self, perm=None):
        super(Transpose_torch, self).__init__()
        self.perm = tuple(perm) if perm is not None else None

    def forward(self, x):
        if self.perm is None:
            perm = tuple(range(x.dim() - 1, -1, -1))
            return x.permute(*perm)
        return x.permute(*self.perm)


class Unsqueeze_torch(torch.nn.Module):
    def __init__(self, axes=None):
        super(Unsqueeze_torch, self).__init__()
        self.axes = tuple(axes) if axes is not None else None

    def _get_axes(self, axes):
        if axes is not None:
            # axes 可能是动态输入 (tensor) 或构造属性 (tuple), 双形态兼容
            if isinstance(axes, torch.Tensor):
                axes = axes.reshape(-1).to(dtype=torch.int64).tolist()
            return tuple(int(v) for v in axes)
        if self.axes is None:
            raise RuntimeError("Unsqueeze_torch requires axes input or attribute")
        return self.axes

    def forward(self, x, axes=None):
        resolved_axes = self._get_axes(axes)
        output_rank = x.dim() + len(resolved_axes)
        normalized_axes = sorted(
            axis + output_rank if axis < 0 else axis for axis in resolved_axes)
        if len(set(normalized_axes)) != len(normalized_axes):
            raise RuntimeError("Unsqueeze axes must not contain duplicates")
        for axis in normalized_axes:
            x = torch.unsqueeze(x, axis)
        return x

    def forward_symbolic(self, x, axes=None):
        """Trace-friendly Unsqueeze: single-axis uses torch.unsqueeze directly
        (maps to one ONNX Unsqueeze node). Multi-axis still uses loop in
        Symbolic.forward (pure Python, not traced); symbolic() emits one node.
        """
        resolved_axes = self._get_axes(axes)
        output_rank = x.dim() + len(resolved_axes)
        normalized_axes = sorted(
            axis + output_rank if axis < 0 else axis for axis in resolved_axes)
        for axis in normalized_axes:
            x = torch.unsqueeze(x, axis)
        return x


class Squeeze_torch(torch.nn.Module):
    def __init__(self, axes=None):
        super(Squeeze_torch, self).__init__()
        self.axes = tuple(axes) if axes is not None else None

    def _get_axes(self, axes):
        if axes is not None:
            # axes 可能是动态输入 (tensor) 或构造属性 (tuple), 双形态兼容
            if isinstance(axes, torch.Tensor):
                axes = axes.reshape(-1).to(dtype=torch.int64).tolist()
            return tuple(int(v) for v in axes)
        if self.axes is None:
            return None
        return self.axes

    def forward(self, x, axes=None):
        axes_to_use = self._get_axes(axes)
        if axes_to_use is None:
            return torch.squeeze(x)
        normalized_axes = sorted(
            (axis + x.dim() if axis < 0 else axis for axis in axes_to_use),
            reverse=True)
        if len(set(normalized_axes)) != len(normalized_axes):
            raise RuntimeError("Squeeze axes must not contain duplicates")
        for axis in normalized_axes:
            if x.shape[axis] != 1:
                raise RuntimeError(
                    "Cannot squeeze axis {} with dimension {}".format(
                        axis, x.shape[axis]))
            x = torch.squeeze(x, axis)
        return x


class Reshape_torch(torch.nn.Module):
    def __init__(self, allowzero=0):
        super(Reshape_torch, self).__init__()
        self.allowzero = int(allowzero)

    def _normalize_shape(self, x, shape):
        dims = shape.reshape(-1).to(dtype=torch.int64)
        if self.allowzero:
            return dims
        x_shape = torch._shape_as_tensor(x).to(device=dims.device, dtype=torch.int64)
        # Build a same-length replacement tensor for zero-dims. For indices beyond
        # input rank, use 1 as a safe placeholder (it is ignored unless dims==0).
        x_shape_ext = torch.cat(
            [x_shape, torch.ones((1,), device=dims.device, dtype=torch.int64)], dim=0
        )
        idx = torch.arange(dims.shape[0], device=dims.device, dtype=torch.int64)
        max_idx = torch.full_like(idx, x_shape.shape[0])
        safe_idx = torch.minimum(idx, max_idx)
        x_shape_for_where = x_shape_ext[safe_idx]
        return torch.where(dims == 0, x_shape_for_where, dims)

    def forward(self, x, shape):
        return torch.ops.aten.reshape.default(x, self._normalize_shape(x, shape))


class ReduceMean_torch(torch.nn.Module):
    def __init__(self, axes=None, keepdims=1, noop_with_empty_axes=0):
        super(ReduceMean_torch, self).__init__()
        self.axes = tuple(axes) if axes is not None else None
        self.keepdims = bool(keepdims)
        self.noop_with_empty_axes = bool(noop_with_empty_axes)

    def _get_axes(self, x, axes):
        if axes is not None:
            # axes 可能是动态输入 (tensor) 或构造属性 (tuple), 双形态兼容
            if isinstance(axes, torch.Tensor):
                axes = axes.reshape(-1).to(dtype=torch.int64).tolist()
            axes = tuple(int(v) for v in axes)
            if len(axes) == 0:
                return None if self.noop_with_empty_axes else tuple(range(x.dim()))
            return axes
        if self.axes is not None:
            return self.axes
        if self.noop_with_empty_axes:
            return None
        return tuple(range(x.dim()))

    def forward(self, x, axes=None):
        axes_to_use = self._get_axes(x, axes)
        if axes_to_use is None:
            return x
        return torch.mean(x, dim=axes_to_use, keepdim=self.keepdims)


class ReduceSum_torch(torch.nn.Module):
    def __init__(self, axes=None, keepdims=1, noop_with_empty_axes=0):
        super(ReduceSum_torch, self).__init__()
        self.axes = tuple(axes) if axes is not None else None
        self.keepdims = bool(keepdims)
        self.noop_with_empty_axes = bool(noop_with_empty_axes)

    def _get_axes(self, x, axes):
        if axes is not None:
            # axes 可能是动态输入 (tensor) 或构造属性 (tuple), 双形态兼容
            if isinstance(axes, torch.Tensor):
                axes = axes.reshape(-1).to(dtype=torch.int64).tolist()
            axes = tuple(int(v) for v in axes)
            if len(axes) == 0:
                return None if self.noop_with_empty_axes else tuple(range(x.dim()))
            return axes
        if self.axes is not None:
            return self.axes
        if self.noop_with_empty_axes:
            return None
        return tuple(range(x.dim()))

    def forward(self, x, axes=None):
        axes_to_use = self._get_axes(x, axes)
        if axes_to_use is None:
            return x
        return torch.sum(x, dim=axes_to_use, keepdim=self.keepdims)


class Gather_torch(torch.nn.Module):
    def __init__(self, axis=0):
        super(Gather_torch, self).__init__()
        self.axis = int(axis)

    def forward(self, data, indices):
        axis = self.axis if self.axis >= 0 else self.axis + data.dim()
        normalized = indices.to(dtype=torch.long, device=data.device)
        normalized = torch.where(
            normalized < 0, normalized + data.shape[axis], normalized)
        gathered = torch.index_select(data, axis, normalized.reshape(-1))
        target_shape = list(data.shape[:axis]) + list(indices.shape) + list(data.shape[axis + 1 :])
        return gathered.reshape(target_shape)

    def forward_symbolic(self, data, indices):
        """Trace-friendly Gather: avoid Python list(data.shape[...]) which
        TorchScript expands into Shape+Gather+Concat noise nodes.

        Uses torch.cat on shape tensors to build the reshape target, keeping
        the trace graph minimal (index_select + reshape only).
        """
        axis = self.axis if self.axis >= 0 else self.axis + data.dim()
        idx = indices.to(dtype=torch.long, device=data.device)
        idx = torch.where(idx < 0, idx + data.shape[axis], idx).reshape(-1)
        gathered = torch.index_select(data, axis, idx)
        # Build target shape via tensor ops: [data.shape[:axis], indices.shape, data.shape[axis+1:]]
        data_shape = torch._shape_as_tensor(data).to(dtype=torch.int64)
        idx_shape = torch._shape_as_tensor(indices).to(dtype=torch.int64)
        if axis == 0:
            target = idx_shape
        else:
            target = torch.cat([data_shape[:axis], idx_shape])
        if axis < data.dim() - 1:
            target = torch.cat([target, data_shape[axis + 1:]])
        return torch.ops.aten.reshape.default(gathered, target)


class Split_torch(torch.nn.Module):
    def __init__(self, axis=0, num_outputs=None, sections=None):
        super(Split_torch, self).__init__()
        self.axis = int(axis)
        self.num_outputs = int(num_outputs) if num_outputs is not None else None
        self.sections = [int(s) for s in sections] if sections is not None else None

    def _build_sections(self, x, split):
        if split is not None:
            split = split.reshape(-1).to(dtype=torch.int64).tolist()
            return [int(v) for v in split]
        if self.sections is not None:
            return self.sections
        if self.num_outputs is None:
            raise RuntimeError("Split_torch requires split input or num_outputs attribute")
        if int(x.shape[self.axis]) < self.num_outputs:
            raise RuntimeError(
                "Split num_outputs {} exceeds axis {} size {}".format(
                    self.num_outputs, self.axis, x.shape[self.axis]))
        # ONNX Split-18 permits an uneven split: all chunks except the last
        # use ceil(axis_size / num_outputs), and the last receives the rest.
        part = (int(x.shape[self.axis]) + self.num_outputs - 1) // self.num_outputs
        return [part] * (self.num_outputs - 1) + [
            int(x.shape[self.axis]) - part * (self.num_outputs - 1)]

    def forward(self, x, split=None):
        sections = self._build_sections(x, split)
        results = torch.split(x, sections, dim=self.axis)
        # If num_outputs is 1, return single tensor (ONNX declared 1 output)
        if self.num_outputs is not None and self.num_outputs == 1:
            return results[0]
        # If only 1 section, return tensor directly
        if len(sections) == 1:
            return results[0]
        return tuple(results)


class Slice_torch(torch.nn.Module):
    def __init__(self):
        super(Slice_torch, self).__init__()

    def forward(self, data, starts, ends, axes=None, steps=None):
        starts = starts.reshape(-1).to(dtype=torch.int64).tolist()
        ends = ends.reshape(-1).to(dtype=torch.int64).tolist()
        if axes is None:
            axes = list(range(len(starts)))
        else:
            axes = axes.reshape(-1).to(dtype=torch.int64).tolist()
        if steps is None:
            steps = [1] * len(starts)
        else:
            steps = steps.reshape(-1).to(dtype=torch.int64).tolist()

        slices = [slice(None)] * data.dim()
        negative_steps = []
        for axis, start, end, step in zip(axes, starts, ends, steps):
            axis = int(axis)
            axis = axis + data.dim() if axis < 0 else axis
            step = int(step)
            if step == 0:
                raise RuntimeError("Slice step cannot be zero")
            if step < 0:
                negative_steps.append((axis, int(start), int(end), step))
            else:
                slices[axis] = slice(int(start), int(end), step)
        result = data[tuple(slices)]
        for axis, start, end, step in negative_steps:
            # Python's slice.indices implements ONNX's clamping rules,
            # including INT_MAX/INT_MIN sentinels and negative axes/steps.
            start, end, step = slice(start, end, step).indices(result.shape[axis])
            indices = torch.arange(
                start, end, step, dtype=torch.long, device=result.device)
            result = torch.index_select(result, axis, indices)
        return result


class Pad_torch(torch.nn.Module):
    MODE_MAP = {
        "constant": "constant",
        "reflect": "reflect",
        "edge": "replicate",
        "wrap": "circular",
    }

    def __init__(self, mode="constant", pads=None, value=0.0):
        super(Pad_torch, self).__init__()
        self.mode = mode
        self.pads = tuple(pads) if pads is not None else None
        self.value = float(value)

    def _resolve_full_pads(self, x, pads, axes=None):
        raw = pads if pads is not None else self.pads
        if raw is None:
            raise RuntimeError("Pad_torch requires pads input or attribute")
        if isinstance(raw, torch.Tensor):
            raw = raw.reshape(-1).to(dtype=torch.int64).tolist()
        raw = [int(v) for v in raw]
        rank = x.dim()
        if axes is None:
            if len(raw) != 2 * rank:
                raise RuntimeError(
                    "Pad_torch expects {} pad values, got {}".format(
                        2 * rank, len(raw)))
            return raw
        if isinstance(axes, torch.Tensor):
            axes = axes.reshape(-1).to(dtype=torch.int64).tolist()
        axes = [int(axis) + rank if int(axis) < 0 else int(axis)
                for axis in axes]
        if len(set(axes)) != len(axes):
            raise RuntimeError("Pad axes must not contain duplicates")
        if any(axis < 0 or axis >= rank for axis in axes):
            raise RuntimeError("Pad axis is outside input rank")
        if len(raw) != 2 * len(axes):
            raise RuntimeError(
                "Pad_torch expects {} pad values for axes {}, got {}".format(
                    2 * len(axes), axes, len(raw)))
        full = [0] * (2 * rank)
        count = len(axes)
        for index, axis in enumerate(axes):
            full[axis] = raw[index]
            full[axis + rank] = raw[index + count]
        return full

    def _get_pads(self, x, pads, axes=None):
        raw = self._resolve_full_pads(x, pads, axes)
        rank = x.dim()
        # F.pad expects (last_dim_end, last_dim_begin, ..., first_dim_end, first_dim_begin)
        torch_pads = []
        for axis in range(rank - 1, -1, -1):
            torch_pads.extend([raw[axis], raw[axis + rank]])
        return tuple(torch_pads)

    def _get_value(self, value):
        if value is None:
            return self.value
        if isinstance(value, torch.Tensor):
            return float(value.reshape(-1)[0].item())
        return float(value)

    def _nonconstant_pad(self, x, pads, axes=None):
        raw = self._resolve_full_pads(x, pads, axes)
        rank = x.dim()
        result = x
        for axis in range(rank):
            begin, end = raw[axis], raw[axis + rank]
            crop_begin = max(-begin, 0)
            crop_end = int(result.shape[axis]) - max(-end, 0)
            if crop_begin or crop_end != int(result.shape[axis]):
                result = result.narrow(axis, crop_begin, max(crop_end - crop_begin, 0))
            pad_begin, pad_end = max(begin, 0), max(end, 0)
            if pad_begin == 0 and pad_end == 0:
                continue
            size = int(result.shape[axis])
            positions = torch.arange(
                -pad_begin, size + pad_end,
                dtype=torch.long, device=result.device)
            if self.mode == "edge":
                indices = positions.clamp(0, size - 1)
            elif self.mode == "wrap":
                indices = torch.remainder(positions, size)
            elif self.mode == "reflect":
                if size <= 1:
                    raise RuntimeError("reflect padding requires dimension > 1")
                period = 2 * (size - 1)
                reflected = torch.remainder(positions, period)
                indices = torch.where(
                    reflected < size, reflected, period - reflected)
            else:
                raise NotImplementedError("Unsupported Pad mode: {}".format(self.mode))
            result = torch.index_select(result, axis, indices)
        return result

    def forward(self, x, pads=None, value=None, axes=None):
        if self.mode != "constant":
            return self._nonconstant_pad(x, pads, axes)
        mode = self.MODE_MAP.get(self.mode, self.mode)
        kwargs = {"mode": mode}
        if mode == "constant":
            kwargs["value"] = self._get_value(value)
        return torch.nn.functional.pad(
            x, self._get_pads(x, pads, axes), **kwargs)

    def forward_symbolic(self, x, pads=None, value=None, axes=None):
        """Trace-friendly Pad: the symbolic method emits a single ONNX Pad node,
        replacing the F.pad + _get_pads expansion. forward is still used for
        compute; symbolic overrides the ONNX graph node.
        """
        # Inline MODE_MAP lookup to avoid class-constant reference (not inlineable).
        mode_map = {"constant": "constant", "reflect": "reflect", "edge": "replicate"}
        resolved_mode = mode_map.get(self.mode, self.mode)
        raw_list = self._resolve_full_pads(x, pads, axes)
        rank = x.dim()
        torch_pads = []
        for axis in range(rank - 1, -1, -1):
            torch_pads.extend([raw_list[axis], raw_list[axis + rank]])
        resolved_val = value
        if resolved_val is None:
            resolved_val = 0.0
        if isinstance(resolved_val, torch.Tensor):
            resolved_val = resolved_val.reshape(-1)[0].item()
        resolved_val = float(resolved_val)
        return torch.nn.functional.pad(x, torch_pads, mode=resolved_mode, value=resolved_val)


class Shape_torch(torch.nn.Module):
    def __init__(self, start=0, end=None):
        super(Shape_torch, self).__init__()
        self.start = int(start)
        self.end = None if end is None else int(end)

    def forward(self, x):
        shape = list(x.shape)
        end = self.end if self.end is not None else len(shape)
        return torch.tensor(shape[self.start:end], dtype=torch.int64, device=x.device)


class Cast_torch(torch.nn.Module):
    ONNX_TO_TORCH = {
        1: torch.float32,
        2: torch.uint8,
        3: torch.int8,
        5: torch.int16,
        6: torch.int32,
        7: torch.int64,
        9: torch.bool,
        10: torch.float16,
        11: torch.float64,
        12: torch.uint32,
        13: torch.uint64,
        16: torch.bfloat16,
    }

    def __init__(self, to):
        super(Cast_torch, self).__init__()
        self.to = int(to)

    def forward(self, x):
        if self.to not in self.ONNX_TO_TORCH:
            raise NotImplementedError("Unsupported ONNX Cast target: {}".format(self.to))
        target_dtype = self.ONNX_TO_TORCH[self.to]

        # Follow ONNX Cast exactly. In particular, float32->float16 overflow
        # produces +/-inf; saturating to finite values changes graph semantics.
        return x.to(dtype=target_dtype)


class Clip_torch(torch.nn.Module):
    def __init__(self, min_value=None, max_value=None):
        super(Clip_torch, self).__init__()
        self.min_value = min_value
        self.max_value = max_value

    def _normalize_bound(self, value):
        if value is None:
            return None
        if isinstance(value, torch.Tensor):
            return value.reshape(-1)[0]
        return torch.as_tensor(value)

    def forward(self, x, min_value=None, max_value=None):
        min_value = self._normalize_bound(min_value if min_value is not None else self.min_value)
        max_value = self._normalize_bound(max_value if max_value is not None else self.max_value)
        return torch.clamp(x, min=min_value, max=max_value)


class Expand_torch(torch.nn.Module):
    def __init__(self):
        super(Expand_torch, self).__init__()

    def forward(self, x, shape):
        # ONNX Expand: broadcast x to target shape.
        target = shape.reshape(-1).to(dtype=torch.int64).tolist()
        if any(dim < 0 for dim in target):
            raise RuntimeError("ONNX Expand shape values must be non-negative")
        input_shape = list(x.shape)
        # Align ranks by left-padding with 1s.
        if len(target) < len(input_shape):
            target = [1] * (len(input_shape) - len(target)) + target
        elif len(target) > len(input_shape):
            input_shape = [1] * (len(target) - len(input_shape)) + input_shape
            x = x.reshape(input_shape)
        # Multidirectional broadcasting: target=1 retains a non-singleton input
        # dimension; all other unequal dimensions require the input to be 1.
        resolved = []
        for t, i in zip(target, input_shape):
            if t == 1 and i != 1:
                resolved.append(i)
            elif i not in (1, t):
                raise RuntimeError(
                    "Expand cannot broadcast input dimension {} to {}".format(i, t))
            else:
                resolved.append(t)
        return x.expand(resolved)

    def forward_symbolic(self, x, shape):
        # Simplified forward for preserve mode symbolic export.
        # Pass the already valid non-negative shape tensor directly. No
        # .tolist()/for/if that would cause
        # TorchScript to expand into ConstantOfShape/Where/Mul or crash.
        shape = shape.reshape(-1).to(dtype=torch.int64)
        return torch.ops.aten.expand.default(x, shape)


class Where_torch(torch.nn.Module):
    def __init__(self):
        super(Where_torch, self).__init__()

    def forward(self, condition, x, y):
        # ONNX Where expects bool condition; torch.where also accepts it directly.
        # Avoid .to(dtype=torch.bool) which inserts Cast(BOOL) nodes in trace.
        return torch.where(condition, x, y)


class Exp_torch(torch.nn.Module):
    def __init__(self):
        super(Exp_torch, self).__init__()

    def forward(self, x):
        return torch.exp(x)


class LessOrEqual_torch(torch.nn.Module):
    def __init__(self):
        super(LessOrEqual_torch, self).__init__()

    def forward(self, x, y):
        return torch.le(x, y)


class Identity_torch(torch.nn.Module):
    def __init__(self):
        super(Identity_torch, self).__init__()

    def forward(self, x):
        return x




class Abs_torch(torch.nn.Module):
    def forward(self, x):
        return torch.abs(x)


class BitwiseAnd_torch(torch.nn.Module):
    def forward(self, x, y):
        return torch.bitwise_and(x, y)


class ConstantOfShape_torch(torch.nn.Module):
    def __init__(self, value=0.0):
        super(ConstantOfShape_torch, self).__init__()
        if isinstance(value, np.ndarray):
            value_arr = value
        else:
            value_arr = np.asarray(value)
        if value_arr.size == 0:
            value_arr = np.asarray(0.0, dtype=np.float32)
        self.value = torch.as_tensor(value_arr.reshape(-1)[0])

    def forward(self, shape):
        if isinstance(shape, torch.Tensor):
            shape_list = [int(dim) for dim in shape.detach().cpu().flatten().tolist()]
        else:
            shape_list = [int(dim) for dim in np.asarray(shape).flatten().tolist()]
        out = torch.full(shape_list, self.value.item(), dtype=self.value.dtype)
        if isinstance(shape, torch.Tensor):
            out = out.to(shape.device)
        return out


class Cos_torch(torch.nn.Module):
    def forward(self, x):
        return torch.cos(x)


class Equal_torch(torch.nn.Module):
    def forward(self, x, y):
        return torch.eq(x, y)


class Greater_torch(torch.nn.Module):
    def forward(self, x, y):
        return torch.gt(x, y)


class Min_torch(torch.nn.Module):
    def forward(self, *inputs):
        if len(inputs) == 0:
            raise RuntimeError("Min expects at least one input")
        out = inputs[0]
        for item in inputs[1:]:
            out = torch.minimum(out, item)
        return out


class Mod_torch(torch.nn.Module):
    def __init__(self, fmod=0):
        super(Mod_torch, self).__init__()
        self.fmod = int(fmod)

    def forward(self, x, y):
        if self.fmod:
            return torch.fmod(x, y)
        return torch.remainder(x, y)


class Neg_torch(torch.nn.Module):
    def forward(self, x):
        return torch.neg(x)


class Range_torch(torch.nn.Module):
    def forward(self, start, limit, delta):
        if isinstance(start, torch.Tensor):
            start_value = start.reshape(-1)[0]
        else:
            start_value = torch.as_tensor(start)
        if isinstance(limit, torch.Tensor):
            limit_value = limit.reshape(-1)[0]
        else:
            limit_value = torch.as_tensor(limit)
        if isinstance(delta, torch.Tensor):
            delta_value = delta.reshape(-1)[0]
        else:
            delta_value = torch.as_tensor(delta)

        device = start_value.device
        return torch.arange(
            start_value,
            limit_value,
            delta_value,
            dtype=start_value.dtype,
            device=device,
        )


class ScatterND_torch(torch.nn.Module):
    def __init__(self, reduction="none"):
        super(ScatterND_torch, self).__init__()
        self.reduction = reduction

    def forward(self, data, indices, updates):
        if isinstance(indices, torch.Tensor):
            idx = indices.to(device=data.device, dtype=torch.long).clone()
        else:
            idx = torch.as_tensor(indices, dtype=torch.long, device=data.device)

        output = data.clone()
        if idx.numel() == 0:
            return output

        if idx.shape[-1] > data.dim():
            raise RuntimeError(
                "ScatterND index rank {} exceeds data rank {}".format(idx.shape[-1], data.dim())
            )

        for axis in range(idx.shape[-1]):
            dim = int(data.shape[axis])
            if dim <= 0:
                continue
            axis_indices = idx[..., axis]
            if torch.any(axis_indices < -dim) or torch.any(axis_indices >= dim):
                raise IndexError(
                    "ScatterND index is out of bounds for axis {} with size {}".format(
                        axis, dim))
            idx[..., axis] = torch.where(
                axis_indices < 0, axis_indices + dim, axis_indices)

        flat_idx = idx.reshape(-1, idx.shape[-1])
        prefix_shape = idx.shape[:-1]
        suffix_shape = data.shape[idx.shape[-1]:]
        reshaped_updates = updates.reshape(*prefix_shape, *suffix_shape)
        flat_updates = reshaped_updates.reshape(flat_idx.shape[0], *suffix_shape)

        if self.reduction not in ("none", "replace", "add", "sum", "mul", "max", "min"):
            raise NotImplementedError("ScatterND reduction '{}' is not supported".format(self.reduction))

        # Vectorized index_put avoids Python loops that make ONNX export very slow
        # on large models while keeping ScatterND replace/add behavior.
        index_tuple = tuple(flat_idx[:, axis] for axis in range(flat_idx.shape[1]))
        if self.reduction in ("none", "replace"):
            output.index_put_(index_tuple, flat_updates, accumulate=False)
        elif self.reduction in ("add", "sum"):
            output.index_put_(index_tuple, flat_updates, accumulate=True)
        else:
            # index_put_ has no multiply/min/max reduction. Keep the suffix
            # tensor update intact and apply entries in ONNX index order.
            for row, update in zip(flat_idx, flat_updates):
                item_index = tuple(row[axis] for axis in range(row.numel()))
                if self.reduction == "mul":
                    output[item_index] = output[item_index] * update
                elif self.reduction == "max":
                    output[item_index] = torch.maximum(output[item_index], update)
                else:
                    output[item_index] = torch.minimum(output[item_index], update)
        return output


class Sign_torch(torch.nn.Module):
    def forward(self, x):
        return torch.sign(x)


class Sin_torch(torch.nn.Module):
    def forward(self, x):
        return torch.sin(x)


class Sqrt_torch(torch.nn.Module):
    def forward(self, x):
        return torch.sqrt(x)


class Softplus_torch(torch.nn.Module):
    def __init__(self):
        super(Softplus_torch, self).__init__()

    def forward(self, x):
        return torch.nn.functional.softplus(x)


class Floor_torch(torch.nn.Module):
    def __init__(self):
        super(Floor_torch, self).__init__()

    def forward(self, x):
        return torch.floor(x)
