import torch

from rknn.base.gpu.torch_ops.exRoPE import exRoPE_torch
from rknn.base.gpu.torch_ops.exSDPAttention import exSDPAttention_torch


class exAttention_torch(torch.nn.Module):
    def __init__(self, rope=0, scale=1.0, kvcache_buffer_len=0, sliding_window_size=0, **kwargs):
        super(exAttention_torch, self).__init__()
        self.rope = int(rope)
        self.kvcache_buffer_len = int(kvcache_buffer_len)
        self.sliding_window_size = int(sliding_window_size)
        self.scale = float(scale)
        # Store remaining ONNX attrs (attention_type, kvcache_dtype, etc.) so
        # preserve-mode Symbolic.apply can pass them as g.op attributes.
        self.attention_type = kwargs.get("attention_type", 0)
        self.kvcache_dtype = kwargs.get("kvcache_dtype", 0)
        self.kvcache_group_size = kwargs.get("kvcache_group_size", 0)
        self.kvcache_residual_depth = kwargs.get("kvcache_residual_depth", 0)
        self.kvcache_store_method = kwargs.get("kvcache_store_method", 0)
        self.max_pos_embedding = kwargs.get("max_pos_embedding", 0)
        self.rope_impl = exRoPE_torch()
        self.attn = exSDPAttention_torch(scale=scale)

    def _apply_rope(self, q, k, cos, sin, th, tc, ts, tsr):
        q = self.rope_impl(q, cos, sin, th, tc, ts, tsr)
        k = self.rope_impl(k, cos, sin, th, tc, ts, tsr)
        return q, k

    def _zero_invalid_queries(
        self, output: torch.Tensor, tc: torch.Tensor | None
    ) -> torch.Tensor:
        if tc is None or self.kvcache_buffer_len <= 0:
            return output
        valid = (
            torch.arange(output.shape[-1], device=output.device)
            < tc.reshape(-1)[0]
        )
        return torch.where(valid, output, torch.zeros_like(output))

    def _merge_cache(self, node_cache, k, v):
        if self.kvcache_buffer_len <= 0:
            return k, v, node_cache
        cached_k = node_cache.get("k")
        cached_v = node_cache.get("v")
        if cached_k is not None:
            k = torch.cat([cached_k, k], dim=-1)
        if cached_v is not None:
            v = torch.cat([cached_v, v], dim=-1)
        limit = self.sliding_window_size or self.kvcache_buffer_len
        if limit > 0 and k.shape[-1] > limit:
            k = k[..., -limit:]
            v = v[..., -limit:]
        node_cache["k"] = k.detach()
        node_cache["v"] = v.detach()
        return k, v, node_cache

    def forward(self, q, k, v, mask, cos=None, sin=None, th=None, tc=None, ts=None, tsr=None):
        outputs, _ = self.forward_with_cache(q, k, v, mask, cos, sin, th, tc, ts, tsr, node_cache={})
        return outputs

    def forward_no_cache(self, q, k, v, mask, cos=None, sin=None, th=None, tc=None, ts=None, tsr=None):
        """Cache-free forward for ONNX export. Skips KV cache merge logic
        that causes TorchScript trace issues (dynamic shape indexing, dict ops).
        """
        if self.rope != 0 and cos is not None and sin is not None and th is not None:
            q, k = self._apply_rope(q, k, cos, sin, th, tc, ts, tsr)
        return self._zero_invalid_queries(self.attn(q, k, v, mask), tc)

    def forward_symbolic(self, q, k, v, mask, cos=None, sin=None, th=None, tc=None, ts=None, tsr=None):
        """Shape placeholder used only while preserving this custom op."""
        # The result keeps q's query length but uses v's value channel.  Use
        # broadcasting instead of Python shape values so tracing also works
        # when the query and value channel counts differ.
        return q[:, :1, ...] + v[..., :1] * 0

    def forward_with_cache(self, q, k, v, mask, cos=None, sin=None, th=None, tc=None, ts=None, tsr=None, node_cache=None):
        node_cache = {} if node_cache is None else dict(node_cache)

        # Apply RoPE if enabled (rope != 0 and cos/sin provided)
        if self.rope != 0 and cos is not None and sin is not None and th is not None:
            q, k = self._apply_rope(q, k, cos, sin, th, tc, ts, tsr)

        # Merge KV cache
        k, v, node_cache = self._merge_cache(node_cache, k, v)

        # SDP attention
        return self._zero_invalid_queries(self.attn(q, k, v, mask), tc), node_cache
