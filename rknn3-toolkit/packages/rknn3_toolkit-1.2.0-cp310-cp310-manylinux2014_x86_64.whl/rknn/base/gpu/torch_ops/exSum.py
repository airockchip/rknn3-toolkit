import torch


class exSum_torch(torch.nn.Module):
    def __init__(self, scale=None, **kwargs):
        super(exSum_torch, self).__init__()
        self.scale = list(scale) if scale is not None else None

    def forward(self, *inputs):
        out = inputs[0]
        for idx, item in enumerate(inputs[1:], start=1):
            if self.scale is not None and idx < len(self.scale):
                out = out + item * self.scale[idx]
            else:
                out = out + item
        return out
