import torch


class exRoPE_torch(torch.nn.Module):
    def __init__(self, **kwargs):
        super(exRoPE_torch, self).__init__()

    def _apply_rope(self, x, cos, sin):
        half = x.shape[1] // 2
        rotated = torch.cat([-x[:, half:, :, :], x[:, :half, :, :]], dim=1)
        return rotated * sin + x * cos

    def forward(self, x, cos, sin, th=None, tc=None, ts=None, tsr=None):
        y, _ = self.forward_with_cache(x, cos, sin, th, tc, ts, tsr, node_cache={})
        return y

    def forward_with_cache(self, x, cos, sin, th=None, tc=None, ts=None, tsr=None, node_cache=None):
        node_cache = {} if node_cache is None else dict(node_cache)

        # --- 无状态分支：th/tc/ts/tsr 未提供，直接对整个 x 做 rope ---
        if th is None or tc is None or ts is None or tsr is None:
            y = self._apply_rope(x, cos, sin)
            node_cache["last_pos"] = None
            return y, node_cache

        # --- 有状态分支：KV cache 场景 ---
        # convert 生态的验证路径 (accuracy_analysis golden / sim verify /
        # regen Base A) 全部用 disable_kv_cache=True (IRGraph 默认), 此时 numpy
        # exRoPE_infer 走全量分支: pos = arange(seq), 忽略 th/tc/ts/tsr 增量。
        # 旧实现这里做增量 (只 rope 前 tc 个), 与 numpy 全量不一致 -> q_0.5b/
        # q_1.7b (rope=1 标准 attention) 每层 exAttention 0.5% 差异累积到
        # logits cos 0.99 (q_0.8b rope=0 无此问题 =1.0)。改为与 numpy 一致的全量。
        # 真实硬件增量推理 (disable_kv_cache=False, pos=Th..Th+Tc) 走 load_llm,
        # 不经过 convert 生成的 generated.py。
        pos = torch.arange(x.shape[-1], device=x.device, dtype=torch.int64)
        max_pos = cos.shape[-1]
        pos = pos.clamp(0, max_pos - 1)

        cos_part = cos.index_select(-1, pos)
        sin_part = sin.index_select(-1, pos)
        y = self._apply_rope(x, cos_part, sin_part)

        node_cache["last_pos"] = None
        return y, node_cache
