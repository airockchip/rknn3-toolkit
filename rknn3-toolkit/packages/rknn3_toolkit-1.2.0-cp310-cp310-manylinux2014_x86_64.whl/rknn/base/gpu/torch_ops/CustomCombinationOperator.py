import torch


class CustomCombinationOperator_torch(torch.nn.Module):
    def __init__(self, op_code=None, **kwargs):
        super(CustomCombinationOperator_torch, self).__init__()
        self.op_code = op_code
        self.attrs = dict(kwargs)

    def forward(self, *inputs):
        if self.op_code == 'floor':
            return torch.floor(inputs[0])
        if self.op_code == 'ceil':
            return torch.ceil(inputs[0])
        if self.op_code == 'reciprocal':
            return torch.reciprocal(inputs[0])
        if self.op_code == 'where':
            if all(name in self.attrs for name in ('cmp_val', 'select_a', 'select_b')):
                return torch.where(
                    inputs[0] == self.attrs['cmp_val'],
                    torch.as_tensor(self.attrs['select_a'], dtype=torch.float32,
                                    device=inputs[0].device),
                    torch.as_tensor(self.attrs['select_b'], dtype=torch.float32,
                                    device=inputs[0].device))
            return torch.where(inputs[0].to(dtype=torch.bool), inputs[1], inputs[2])
        if self.op_code in ('sc_add', 'bs_add'):
            return inputs[0] + inputs[1]
        if self.op_code in ('mul_trt_pc', 'bs_mul'):
            return inputs[0] * inputs[1]
        if self.op_code == 'bs_clip':
            return torch.clamp(inputs[0], -6, 6)
        if self.op_code == 'NonflyCopy':
            return inputs[0]
        if self.op_code == 'c1hwc2_hwc':
            n, c, h, w = inputs[0].shape
            return inputs[0].permute(0, 2, 3, 1).reshape(n, 1, h, w, c)
        if self.op_code == 'c1hwc2_chw':
            n, c, h, w = inputs[0].shape
            return inputs[0].reshape(n, 1, c, h, w)
        if self.op_code == 'bulb_squeeze':
            return inputs[0].reshape(inputs[0].shape[0], -1)[:, :int(self.attrs['bulb_co'])]
        if self.op_code == 'config_fdwt':
            accu_ch = inputs[0].shape[1] if int(self.attrs['config_conv']) == 1 else 1
            value = float(self.attrs['config_fd']) * float(self.attrs['config_wt']) * accu_ch
            return torch.full_like(inputs[0], value, dtype=torch.float32)
        if self.op_code == 'pool_flymode':
            return torch.amax(inputs[0], dim=3, keepdim=True)
        if self.op_code is None:
            return inputs[0]
        raise NotImplementedError(
            'Unsupported CustomCombinationOperator op_code: {}'.format(self.op_code))
