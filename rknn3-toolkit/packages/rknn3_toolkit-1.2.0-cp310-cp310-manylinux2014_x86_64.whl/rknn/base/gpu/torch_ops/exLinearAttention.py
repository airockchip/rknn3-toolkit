import torch


class exLinearAttention_torch(torch.nn.Module):
    """PyTorch implementation of exLinearAttention (Gated DeltaNet).

    Implements the recurrent gated delta rule:
      For each timestep t:
        1. state = state * exp(g_t)           # decay
        2. kv_mem = state @ k_t               # read current memory
        3. delta = (v_t - kv_mem) * beta_t    # compute residual
        4. state = state + k_t ⊗ delta         # write residual
        5. out_t = state @ q_t                 # read output

    With optional qk L2-norm (qk_norm attribute) and scale = 1/sqrt(head_dim).
    """

    def __init__(self, qk_norm=0, **kwargs):
        super(exLinearAttention_torch, self).__init__()
        self.qk_norm = int(qk_norm)

    def forward(self, query, key, value, g, beta, tc):
        y, _ = self.forward_with_cache(query, key, value, g, beta, tc, node_cache={})
        return y

    def forward_with_cache(self, query, key, value, g, beta, tc, node_cache=None):
        node_cache = {} if node_cache is None else dict(node_cache)

        # Input shapes:
        #   query/key: [head_num, head_dim, 1, seq_len]
        #   value:     [head_num, value_dim, 1, seq_len]
        #   g/beta:    [1, head_num, 1, seq_len]
        #   tc:        [1] (optional)
        # Output shape: [head_num, value_dim, 1, seq_len] (same as value)

        # Force float32 for numerical stability (RKNN does the same)
        orig_dtype = query.dtype
        q = query.to(torch.float32)
        k = key.to(torch.float32)
        v = value.to(torch.float32)
        g_in = g.to(torch.float32)
        beta_in = beta.to(torch.float32)

        head_num, head_dim, _, seq_len = q.shape
        _, value_dim, _, _ = v.shape

        # Optional L2 normalization (on head_dim, dim=1 in [head, dim, 1, seq])
        if self.qk_norm:
            eps = 1e-6
            inv_norm_q = torch.rsqrt((q * q).sum(dim=1, keepdim=True) + eps)
            q = q * inv_norm_q
            inv_norm_k = torch.rsqrt((k * k).sum(dim=1, keepdim=True) + eps)
            k = k * inv_norm_k
            scale = 1.0 / (head_dim ** 0.5)
            q = q * scale

        # Handle Tc (non-full-bucket): zero out positions beyond Tc
        # Use tensor mask instead of if-branch so torch.onnx.export (trace mode)
        # does not固化 tc into a constant.
        tc_i = tc.reshape(-1)[0].to(torch.int64) if isinstance(tc, torch.Tensor) else torch.tensor(int(tc), dtype=torch.int64, device=q.device)
        # 与 check6 (numpy exLinearAttention_infer) 一致: 仅当 tc>1 时按 tc 截断
        # (非满桶右清零), tc<=1 表示全序列参与 (不清零)。旧实现无条件
        # positions<tc, tc=0 时整个输出清零 -> fake 全零 vs numpy 正常
        # (q_0.8b linear attention 实测, fake abs_sum=0 / golden 5000+)。
        # tc <= 1 means a full bucket. Keep this entirely in tensor form so
        # ONNX export does not freeze the branch according to the sample tc.
        full_length = torch.full_like(tc_i, seq_len)
        effective_tc = torch.where(tc_i > 1, tc_i, full_length)
        positions = torch.arange(
            seq_len, device=q.device, dtype=tc_i.dtype)
        tc_mask = (positions < effective_tc).to(q.dtype)
        input_mask = tc_mask.view(1, 1, 1, seq_len)
        q = q * input_mask
        k = k * input_mask
        v = v * input_mask
        g_in = g_in * input_mask
        beta_in = beta_in * input_mask

        # Get or init recurrent state: [head_num, head_dim, 1, value_dim]
        # In RKNN: state shape is [batch, head, k_dim, v_dim]
        # Here: [head_num, head_dim, 1, value_dim] (batch=1 squeezed into dim 2)
        state = node_cache.get("recurrent_state")
        if state is None:
            state = torch.zeros(head_num, head_dim, 1, value_dim,
                                dtype=q.dtype, device=q.device)

        # Squeeze to [head_num, head_dim, value_dim] for easier computation
        state_flat = state.squeeze(-2)  # [head_num, head_dim, value_dim]

        # Output buffer: [head_num, value_dim, 1, seq_len]
        core_out = torch.zeros(head_num, value_dim, 1, seq_len,
                               dtype=q.dtype, device=q.device)

        # Gated delta rule recurrent computation
        for t in range(seq_len):
            # Extract timestep: [head_num, dim, 1] after squeeze
            q_t = q[:, :, 0, t]       # [head_num, head_dim]
            k_t = k[:, :, 0, t]       # [head_num, head_dim]
            v_t = v[:, :, 0, t]       # [head_num, value_dim]
            g_t = g_in[0, :, 0, t]    # [head_num]
            beta_t = beta_in[0, :, 0, t]  # [head_num]

            # 1. Decay: state = state * exp(g)
            g_exp = g_t.exp()         # [head_num]
            state_flat = state_flat * g_exp.unsqueeze(-1).unsqueeze(-1)  # broadcast

            # 2. Read memory: kv_mem = state @ k_t
            #    state: [head_num, head_dim, value_dim]
            #    k_t:   [head_num, head_dim]
            #    kv_mem = sum over head_dim of (state * k_t) -> [head_num, value_dim]
            kv_mem = (state_flat * k_t.unsqueeze(-1)).sum(dim=1)  # [head_num, value_dim]

            # 3. Compute residual: delta = (v_t - kv_mem) * beta
            delta = (v_t - kv_mem) * beta_t.unsqueeze(-1)  # [head_num, value_dim]

            # 4. Write residual: state += k_t ⊗ delta
            #    k_t:   [head_num, head_dim]
            #    delta: [head_num, value_dim]
            #    outer: [head_num, head_dim, value_dim]
            state_flat = state_flat + k_t.unsqueeze(-1) * delta.unsqueeze(1)

            # 5. Read output: out_t = state @ q_t
            #    state: [head_num, head_dim, value_dim]
            #    q_t:   [head_num, head_dim]
            #    out = sum over head_dim of (state * q_t) -> [head_num, value_dim]
            out_t = (state_flat * q_t.unsqueeze(-1)).sum(dim=1)  # [head_num, value_dim]
            core_out[:, :, 0, t] = out_t

        # Store recurrent state
        state = state_flat.unsqueeze(-2)  # [head_num, head_dim, 1, value_dim]
        # RKNN simulator stores the recurrent state after bfloat16 rounding,
        # then expands it back to float32 for the next invocation.
        node_cache["recurrent_state"] = state.detach().to(
            torch.bfloat16).to(torch.float32)

        # Handle non-full-bucket: zero out beyond Tc using tensor mask
        core_out = core_out * tc_mask.view(1, 1, 1, seq_len)

        # Convert back to original dtype
        core_out = core_out.to(orig_dtype)

        return core_out, node_cache
