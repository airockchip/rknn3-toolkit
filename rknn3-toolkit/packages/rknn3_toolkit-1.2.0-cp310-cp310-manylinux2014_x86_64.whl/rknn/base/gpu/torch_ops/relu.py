import torch

class ReLU_torch(torch.nn.Module):
    def __init__(self):
        super(ReLU_torch, self).__init__()

    def forward(self, x):
        return torch.relu(x)