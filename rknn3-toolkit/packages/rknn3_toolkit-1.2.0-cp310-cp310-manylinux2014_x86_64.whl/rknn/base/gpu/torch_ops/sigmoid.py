import torch

class Sigmoid_torch(torch.nn.Module):
    def __init__(self):
        super(Sigmoid_torch, self).__init__()

    def forward(self, x):
        return torch.sigmoid(x)