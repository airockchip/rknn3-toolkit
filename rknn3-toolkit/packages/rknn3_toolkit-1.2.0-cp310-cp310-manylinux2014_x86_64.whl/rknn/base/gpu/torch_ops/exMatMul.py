import torch


class exMatMul_torch(torch.nn.Module):
    def __init__(self, c_type=None, **kwargs):
        super(exMatMul_torch, self).__init__()
        self.c_type = c_type

    def forward(self, a, b, c=None):
        _, k, _, n = a.shape
        _, _, _, m = b.shape
        compute_dtype = torch.promote_types(a.dtype, b.dtype)
        out = torch.matmul(
            a.to(compute_dtype).reshape(-1, k, n).transpose(1, 2),
            b.to(compute_dtype).reshape(-1, k, m),
        ).reshape(-1, n, 1, m)
        if c is not None:
            c_cast = c.to(out.dtype)
            if self.c_type == 'add':
                out = out + c_cast
            elif self.c_type == 'mul':
                out = out * c_cast
        return out
