import torch


def _tensor_list(value, dtype=torch.int64):
    if isinstance(value, torch.Tensor):
        return [int(v.item()) for v in value.reshape(-1).to(dtype=dtype)]
    if isinstance(value, (list, tuple)):
        return [int(v) for v in value]
    return [int(value)]


class exIRfftn_torch(torch.nn.Module):
    def __init__(self, dim=None, norm='backward', **kwargs):
        super(exIRfftn_torch, self).__init__()
        self.dim = tuple(dim) if dim is not None else None
        self.norm = norm

    def forward(self, x, s):
        y = torch.complex(x[0], x[1])
        return torch.fft.irfftn(y, s=tuple(_tensor_list(s)), dim=self.dim, norm=self.norm)
