import torch


class exmpiBCast_torch(torch.nn.Module):
    def __init__(self, num_outputs, **kwargs):
        super(exmpiBCast_torch, self).__init__()
        self.num_outputs = int(num_outputs)

    def forward(self, x):
        return tuple(x for _ in range(self.num_outputs))
