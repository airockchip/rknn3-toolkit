import torch


class exNorm_torch(torch.nn.Module):
    def __init__(self, mode='layer', eps=1e-5, axes=(-1,), std_multipler=1.0, **kwargs):
        super(exNorm_torch, self).__init__()
        self.mode = mode
        self.eps = float(eps)
        self.axes = tuple(axes)
        self.std_multipler = float(std_multipler)

    def forward(self, x, weight=None, bias=None):
        if self.mode == 'layer':
            xu = x - torch.mean(x, dim=self.axes, keepdim=True)
            y = xu / torch.sqrt(torch.mean(xu * xu, dim=self.axes, keepdim=True) + self.eps)
        elif self.mode == 'rms':
            y = x / torch.sqrt(torch.mean(x * x, dim=self.axes, keepdim=True) + self.eps)
        elif self.mode == 'mean_var':
            mean = torch.mean(x, dim=self.axes, keepdim=True)
            y = (x - mean) / torch.sqrt(torch.mean(x * x, dim=self.axes, keepdim=True) - mean * mean + self.eps)
        elif self.mode == 'pixel':
            y = x / torch.sqrt(torch.sum(x * x, dim=self.axes, keepdim=True) + self.eps)
        elif self.mode == 'l1':
            y = x / torch.clamp(torch.sum(torch.abs(x), dim=self.axes, keepdim=True), min=self.eps)
        elif self.mode == 'l2':
            y = x / torch.clamp(torch.sqrt(torch.sum(x * x, dim=self.axes, keepdim=True)), min=self.eps)
        elif self.mode == 'gaussian_topk':
            mean = torch.mean(x, dim=self.axes, keepdim=True)
            std = torch.sqrt(torch.mean(x * x, dim=self.axes, keepdim=True) - mean * mean)
            y = torch.clamp(x - (mean + std * self.std_multipler), min=0.0)
        else:
            raise NotImplementedError('Unsupported exNorm mode: {}'.format(self.mode))
        if weight is not None:
            y = y * weight
        if bias is not None:
            y = y + bias
        return y
