import torch


class exActivation_torch(torch.nn.Module):
    def __init__(self, type=None, **kwargs):
        super(exActivation_torch, self).__init__()
        self.type = type

    def forward(self, x):
        if self.type == 'HardSwishHK':
            return x * torch.clamp(x + 3.0, min=0.0, max=6.0) * 0.16667
        return x
