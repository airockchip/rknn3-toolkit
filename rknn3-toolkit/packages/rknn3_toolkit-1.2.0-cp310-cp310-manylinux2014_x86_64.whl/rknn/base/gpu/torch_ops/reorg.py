import torch


class exReorg_torch(torch.nn.Module):
    def __init__(self, stride=2, **kwargs):
        super(exReorg_torch, self).__init__()
        self.stride = int(stride)

    def forward(self, x):
        b, c, h, w = x.shape
        s = self.stride
        if c % (s * s) != 0 or h % s != 0 or w % s != 0:
            raise RuntimeError(
                "exReorg requires C divisible by stride^2 and H/W divisible by stride")
        # Match rknn.base.extend_op.reorg exactly. This is not the usual
        # space-to-depth ordering: the source channel is folded into the
        # inferred leading dimension before stride offsets are permuted.
        x = x.reshape(-1, c // (s * s), h, s, w, s)
        x = x.permute(0, 3, 5, 1, 2, 4).contiguous()
        return x.reshape(b, c * s * s, h // s, w // s)
