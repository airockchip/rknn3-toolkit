import torch


class exmpiConcat_torch(torch.nn.Module):
    def __init__(self, axis, start=None, end=None, **kwargs):
        super(exmpiConcat_torch, self).__init__()
        self.axis = int(axis)
        self.start = tuple(start) if start is not None else None
        self.end = tuple(end) if end is not None else None

    def forward(self, *inputs):
        if self.start is not None and self.end is not None:
            wanted = [e - s for s, e in zip(self.start, self.end)]
            got = [item.shape[self.axis] for item in inputs]
            if wanted != got:
                raise RuntimeError('exmpiConcat start/end mismatch: {} vs {}'.format(wanted, got))
        return torch.cat(inputs, dim=self.axis)

    def forward_symbolic(self, *inputs):
        """Trace-safe implementation used only by preserve ONNX export.

        TorchScript represents dimensions observed inside a variadic
        ``autograd.Function`` as scalar tensors.  Validating those traced
        dimensions against the static ``start``/``end`` attributes can produce
        a false mismatch even though the ordinary PyTorch forward has already
        validated the real tensors.  Keep the check in ``forward`` and make the
        symbolic path perform only the concatenation whose attributes are
        emitted by the generated symbolic wrapper.
        """
        return torch.cat(inputs, dim=self.axis)
