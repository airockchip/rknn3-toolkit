import torch


class exmpiSplit_torch(torch.nn.Module):
    def __init__(self, axis, start, end, **kwargs):
        super(exmpiSplit_torch, self).__init__()
        self.axis = int(axis)
        self.start = tuple(start)
        self.end = tuple(end)

    def forward(self, x):
        outputs = []
        for start, end in zip(self.start, self.end):
            slc = [slice(None)] * x.dim()
            slc[self.axis] = slice(start, end)
            outputs.append(x[tuple(slc)])
        return tuple(outputs)
