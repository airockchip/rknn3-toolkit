import torch


class exRfftn_torch(torch.nn.Module):
    def __init__(self, s=None, dim=None, norm='backward', **kwargs):
        super(exRfftn_torch, self).__init__()
        self.s = tuple(s) if s is not None else None
        self.dim = tuple(dim) if dim is not None else None
        self.norm = norm

    def forward(self, x):
        y = torch.fft.rfftn(x, s=self.s, dim=self.dim, norm=self.norm)
        return torch.stack([y.real, y.imag], dim=0)
