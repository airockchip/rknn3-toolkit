import torch


class exWindow_torch(torch.nn.Module):
    def __init__(self, mode, window_sizes, num_windows, **kwargs):
        super(exWindow_torch, self).__init__()
        self.mode = mode
        self.window_sizes = tuple(window_sizes)
        self.num_windows = tuple(num_windows)

    def forward(self, x):
        b, c, _, _ = x.shape
        wh, ww = self.window_sizes
        nh, nw = self.num_windows
        if self.mode == 'partition':
            return x.reshape(b, c, nh, wh, nw, ww).permute(0, 1, 2, 4, 3, 5).contiguous().reshape(b, c, nh * nw, wh * ww)
        if self.mode == 'reverse':
            return x.reshape(b, c, nh, nw, wh, ww).permute(0, 1, 2, 4, 3, 5).contiguous().reshape(b, c, nh * wh, nw * ww)
        if self.mode == 'partition_num_first':
            return x.reshape(b, c, wh, nh, ww, nw).permute(0, 1, 3, 5, 2, 4).contiguous().reshape(b, c, nh * nw, wh * ww)
        raise NotImplementedError('Unsupported exWindow mode: {}'.format(self.mode))
