import torch


class exSwish_torch(torch.nn.Module):
    def __init__(self, beta=1.0, gamma=0.0, **kwargs):
        super(exSwish_torch, self).__init__()
        self.beta = float(beta)
        self.gamma = float(gamma)

    def forward(self, x):
        return x * torch.sigmoid(self.beta * x + self.gamma)
