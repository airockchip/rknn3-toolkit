import torch


class exDataConvert_torch(torch.nn.Module):
    def __init__(self, **kwargs):
        super(exDataConvert_torch, self).__init__()

    def forward(self, x):
        return x
