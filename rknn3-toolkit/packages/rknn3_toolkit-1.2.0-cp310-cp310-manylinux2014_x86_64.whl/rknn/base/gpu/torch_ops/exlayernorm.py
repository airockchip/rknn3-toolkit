import torch
import torch.nn.functional as F


class exLayerNorm_torch(torch.nn.Module):
    def __init__(self, normalized_shape, elementwise_affine=True, eps=1e-5, **kwargs):
        super(exLayerNorm_torch, self).__init__()
        self.normalized_shape = tuple(normalized_shape) if isinstance(normalized_shape, (list, tuple)) else normalized_shape
        self.elementwise_affine = bool(elementwise_affine)
        self.eps = float(eps)

    def forward(self, x, weight=None, bias=None):
        y = F.layer_norm(x, self.normalized_shape, None, None, self.eps)
        if self.elementwise_affine and weight is not None and bias is not None:
            y = y * weight + bias
        return y
