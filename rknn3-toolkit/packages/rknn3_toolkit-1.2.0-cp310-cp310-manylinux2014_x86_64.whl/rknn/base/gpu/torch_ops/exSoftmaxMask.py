import torch


class exSoftmaxMask_torch(torch.nn.Module):
    def __init__(self, mask_value, axis=-1, **kwargs):
        super(exSoftmaxMask_torch, self).__init__()
        self.mask_value = float(mask_value)
        self.axis = int(axis)

    def forward(self, x, mask_tensor):
        minus = torch.full_like(x, -65536.0)
        masked = torch.where(mask_tensor == self.mask_value, minus, x)
        tmp = torch.exp(masked - torch.amax(masked, dim=self.axis, keepdim=True))
        tmp = torch.where(mask_tensor == self.mask_value, torch.zeros_like(tmp), tmp)
        denom = torch.sum(tmp, dim=self.axis, keepdim=True)
        denom = torch.where(torch.isclose(denom, torch.zeros_like(denom)), denom + 1e-6, denom)
        return tmp / denom
