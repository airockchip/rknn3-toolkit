import torch


class exPagedAttention_torch(torch.nn.Module):
    """Logical paged attention for generated PyTorch models.

    Pages are a compiler/runtime storage detail. The PyTorch model keeps
    per-request logical token history in ordinary tensors. Cache-free execution
    follows the Toolkit simulator; stateful execution does not model physical
    page allocation or the target's quantized cache storage.
    """

    def __init__(self, rope=0, scale=1.0, kvcache_buffer_len=0,
                 sliding_window_size=-1, tokens_per_page=0,
                 kvcache_write_policy="WRITE_THROUGH", infer_mask=None,
                 store_mask=None, **kwargs):
        super().__init__()
        self.rope = int(rope)
        self.scale = float(scale)
        self.kvcache_buffer_len = int(kvcache_buffer_len)
        self.sliding_window_size = int(sliding_window_size)
        self.tokens_per_page = int(tokens_per_page)
        self.kvcache_write_policy = kvcache_write_policy
        self.infer_mask = infer_mask
        self.store_mask = store_mask
        # Preserve every operator attribute when exporting gongga::exPagedAttention.
        for name, value in kwargs.items():
            setattr(self, name, value)

    def _check_inputs(self, q, k, v, control):
        if control.ndim != 2 or control.shape[1] != 9 or control.dtype not in (
                torch.int8, torch.int16, torch.int32, torch.int64, torch.uint8):
            raise ValueError("control_variables must be an integer [request_num, 9] tensor")
        request_num = control.shape[0]
        if request_num > 1:
            for name, value in (("query", q), ("key", k), ("value", v)):
                if value.ndim != 4 or value.shape[-1] != request_num:
                    raise ValueError("{} must carry request_num on its width axis".format(name))
            if not torch.jit.is_tracing() and torch.any(
                    (control[:, 1] < 0) | (control[:, 1] > 1)):
                raise ValueError("multi-request exPagedAttention requires Tc <= 1")
        if q.shape[0] % k.shape[0] or k.shape[0] != v.shape[0]:
            raise ValueError("query heads must be divisible by matching key/value heads")
        return request_num

    def _request_mask(self, mask, request_id, request_num):
        if mask is None or request_num == 1:
            return mask
        if mask.shape[0] == request_num:
            mask = mask[request_id:request_id + 1]
        if mask.shape[-1] == request_num:
            mask = mask[..., request_id:request_id + 1]
        return mask

    def _apply_rope(self, value, cos, sin, th):
        positions = torch.arange(value.shape[-1], device=value.device) + th
        cos = cos.index_select(-1, positions)
        sin = sin.index_select(-1, positions)
        half = value.shape[1] // 2
        rotated = torch.cat((-value[:, half:], value[:, :half]), dim=1)
        return value * cos + rotated * sin

    def _attention(self, q, k, v, mask):
        if q.shape[0] != k.shape[0]:
            group_size = q.shape[0] // k.shape[0]
            # Legacy torch.onnx.export traces repeat_interleave with a CPU
            # index even when the key/value tensors are on CUDA.
            head_indices = torch.arange(
                q.shape[0], dtype=torch.long, device=k.device
            ) // group_size
            k = k.index_select(0, head_indices)
            v = v.index_select(0, head_indices.to(v.device))
        scores = torch.matmul(k.flatten(2).transpose(1, 2), q.flatten(2)) * self.scale
        if mask is not None:
            if mask.ndim == 4:
                mask = mask.flatten(2)
            elif mask.ndim == 2:
                mask = mask.unsqueeze(-1)
            scores = scores + mask
        probs = torch.softmax(scores, dim=1)
        return torch.matmul(v.flatten(2), probs).reshape(
            q.shape[0], v.shape[1], *q.shape[2:])

    def forward_symbolic(self, q, k, v, mask, cos_or_control, sin=None, control_variables=None):
        """Cache-free execution with tensor-valued controls for ONNX export."""
        if self.rope:
            cos, control = cos_or_control, control_variables
        else:
            cos, control = None, cos_or_control
        request_num = self._check_inputs(q, k, v, control)
        outputs = []
        for request_id in range(request_num):
            active = (control[request_id, 8] != 0) & (control[request_id, 1] > 0)
            if not torch.jit.is_tracing() and bool(control[request_id, 8]):
                tc = int(control[request_id, 1])
                if tc < 0 or tc > min(q.shape[-1], k.shape[-1], v.shape[-1]):
                    raise ValueError("Tc must be within the query/key/value width")
            qi = q[..., request_id:request_id + 1] if request_num > 1 else q
            ki = k[..., request_id:request_id + 1] if request_num > 1 else k
            vi = v[..., request_id:request_id + 1] if request_num > 1 else v
            if cos is not None:
                th = torch.where(active, control[request_id, 0],
                                 torch.zeros_like(control[request_id, 0]))
                qi = self._apply_rope(qi, cos, sin, th)
                ki = self._apply_rope(ki, cos, sin, th)
            mi = self._request_mask(mask, request_id, request_num)
            result = self._attention(qi, ki, vi, mi).float()
            outputs.append(torch.where(active, result, torch.zeros_like(result)))
        return torch.cat(outputs, dim=-1)

    def forward(self, q, k, v, mask, cos_or_control, sin=None, control_variables=None):
        return self.forward_symbolic(
            q, k, v, mask, cos_or_control, sin, control_variables)

    def forward_with_cache(self, q, k, v, mask, cos_or_control, sin=None, control_variables=None, node_cache=None):
        if self.kvcache_buffer_len <= 0:
            return self.forward_symbolic(
                q, k, v, mask, cos_or_control, sin, control_variables
            ), ({} if node_cache is None else node_cache)
        if self.rope:
            cos, control = cos_or_control, control_variables
        else:
            cos, control = None, cos_or_control
        request_num = self._check_inputs(q, k, v, control)
        if self.kvcache_write_policy not in (
                "SKIP_WRITE", "WRITE_THROUGH", "DEFERRED_WRITE"):
            raise ValueError("unsupported kvcache_write_policy: {}".format(
                self.kvcache_write_policy))
        node_cache = {} if node_cache is None else dict(node_cache)
        requests = dict(node_cache.get("requests", {}))
        pending = dict(node_cache.get("pending", {}))
        active_mask = int(node_cache.get("infer_mask", 0))
        if self.kvcache_write_policy == "DEFERRED_WRITE" and active_mask:
            compute_enabled = bool(active_mask & int(self.infer_mask or 1))
            store_enabled = bool(active_mask & int(self.store_mask or 1))
        else:
            compute_enabled = True
            store_enabled = self.kvcache_write_policy != "SKIP_WRITE"

        outputs = []
        for request_id in range(request_num):
            qi = q[..., request_id:request_id + 1] if request_num > 1 else q
            ki = k[..., request_id:request_id + 1] if request_num > 1 else k
            vi = v[..., request_id:request_id + 1] if request_num > 1 else v
            result = torch.zeros((qi.shape[0], vi.shape[1], *qi.shape[2:]),
                                 dtype=torch.float32, device=q.device)
            if not bool(control[request_id, 8]):
                outputs.append(result)
                continue
            tc = int(control[request_id, 1])
            if tc < 0 or tc > qi.shape[-1] or tc > ki.shape[-1] or tc > vi.shape[-1]:
                raise ValueError("Tc must be within the query/key/value width")
            if tc == 0 or (not compute_enabled and not store_enabled):
                outputs.append(result)
                continue
            th = int(control[request_id, 0])
            q_valid, k_valid, v_valid = qi[..., :tc], ki[..., :tc], vi[..., :tc]
            if cos is not None:
                ts = int(control[request_id, 2])
                tsr = int(control[request_id, 3])
                rope_position = th - (ts - tsr if th >= ts else 0)
                q_valid = self._apply_rope(q_valid, cos, sin, rope_position)
                k_valid = self._apply_rope(k_valid, cos, sin, rope_position)
            if store_enabled and not compute_enabled:
                if request_id not in pending:
                    raise ValueError("DEFERRED_WRITE requires a preceding compute phase")
                k_valid, v_valid, th = pending[request_id]
            history = requests.get(request_id)
            if history is not None:
                old_k, old_v, start = history
                if th < start:
                    old_k, old_v, start = None, None, th
                else:
                    kept = min(old_k.shape[-1], max(0, th - start))
                    old_k, old_v = old_k[..., :kept], old_v[..., :kept]
            else:
                old_k = old_v = None
                start = th
            merged_k = torch.cat((old_k, k_valid), dim=-1) if old_k is not None else k_valid
            merged_v = torch.cat((old_v, v_valid), dim=-1) if old_v is not None else v_valid
            limit = self.sliding_window_size if self.sliding_window_size > 0 else self.kvcache_buffer_len
            if limit > 0 and merged_k.shape[-1] > limit:
                removed = merged_k.shape[-1] - limit
                merged_k, merged_v = merged_k[..., removed:], merged_v[..., removed:]
                start += removed
            if compute_enabled:
                mi = self._request_mask(mask, request_id, request_num)
                if mi is not None and mi.ndim in (2, 4):
                    mask_query_len = mi.shape[-1] if mi.ndim == 4 else tc
                    if mi.ndim == 4:
                        mi = mi[..., :tc]
                    history_len = merged_k.shape[-1] - tc
                    full_history_mask = (
                        mi.ndim == 4
                        and mi.shape[1] >= merged_k.shape[-1]
                        and mi.shape[1] > qi.shape[-1]
                        and mask_query_len == tc
                    )
                    if history_len < 0:
                        # A window shorter than this chunk keeps its tail.
                        # Slice the same current-token positions from the mask.
                        if mi.shape[1] != 1:
                            mi = mi[:, -merged_k.shape[-1]:]
                    elif history_len > 0 and not full_history_mask:
                        # The model input mask covers this call's padded token
                        # slots, not the K/V tokens retained from earlier calls.
                        # Cached tokens are already valid; mask only the current
                        # chunk and prepend an unmasked history portion.
                        current_mask = mi[:, :tc]
                        if current_mask.shape[1] == 1 and tc > 1:
                            current_mask = current_mask.expand(
                                (-1, tc) + (-1,) * (mi.ndim - 2))
                        if current_mask.shape[1] != tc:
                            raise ValueError("attention mask key width must cover Tc")
                        history_mask = current_mask.new_zeros(
                            (current_mask.shape[0], history_len,
                             *current_mask.shape[2:]))
                        mi = torch.cat((history_mask, current_mask), dim=1)
                    else:
                        mi = mi[:, :merged_k.shape[-1]]
                result[..., :tc] = self._attention(q_valid, merged_k, merged_v, mi).float()
            if store_enabled:
                requests[request_id] = (merged_k.detach(), merged_v.detach(), start)
                pending.pop(request_id, None)
            elif self.kvcache_write_policy == "DEFERRED_WRITE":
                pending[request_id] = (k_valid.detach(), v_valid.detach(), th)
            outputs.append(result)
        node_cache["requests"] = requests
        node_cache["pending"] = pending
        return torch.cat(outputs, dim=-1), node_cache
