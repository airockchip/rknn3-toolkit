import torch
import torch.nn.functional as F


class exMish_torch(torch.nn.Module):
    def __init__(self, **kwargs):
        super(exMish_torch, self).__init__()

    def forward(self, x):
        return x * torch.tanh(F.softplus(x))
