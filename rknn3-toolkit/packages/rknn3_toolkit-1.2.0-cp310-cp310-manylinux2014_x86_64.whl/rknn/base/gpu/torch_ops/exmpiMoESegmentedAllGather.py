import torch


class exmpiMoESegmentedAllGather_torch(torch.nn.Module):
    """Reference implementation of the segmented MoE all-gather."""

    def __init__(self, core_num, **kwargs):
        super(exmpiMoESegmentedAllGather_torch, self).__init__()
        self.core_num = int(core_num)

    def forward(self, *inputs):
        if self.core_num <= 0 or len(inputs) != 2 * self.core_num:
            raise ValueError(
                "exmpiMoESegmentedAllGather expects 2*core_num inputs"
            )
        payloads = inputs[:self.core_num]
        first = payloads[0]
        if not isinstance(first, torch.Tensor):
            raise TypeError(
                "exmpiMoESegmentedAllGather payloads must be tensors"
            )
        for payload in payloads[1:]:
            if (
                not isinstance(payload, torch.Tensor)
                or payload.shape != first.shape
                or payload.dtype != first.dtype
                or payload.device != first.device
            ):
                raise ValueError(
                    "exmpiMoESegmentedAllGather payloads must have matching "
                    "shape, dtype, and device"
                )
        full = first.clone()
        for payload in payloads[1:]:
            full = full + payload
        return tuple(full.clone() for _ in range(self.core_num))

    def forward_symbolic(self, *inputs):
        if self.core_num <= 0 or len(inputs) != 2 * self.core_num:
            raise ValueError(
                "exmpiMoESegmentedAllGather expects 2*core_num inputs"
            )
        return tuple(inputs[0] for _ in range(self.core_num))
