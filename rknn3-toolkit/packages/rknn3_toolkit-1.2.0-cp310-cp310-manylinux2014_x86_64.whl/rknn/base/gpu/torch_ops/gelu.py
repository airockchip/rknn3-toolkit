import torch
import torch.nn.functional as F


class exGelu_torch(torch.nn.Module):
    def __init__(self, **kwargs):
        super(exGelu_torch, self).__init__()

    def forward(self, x):
        return F.gelu(x, approximate='none')
