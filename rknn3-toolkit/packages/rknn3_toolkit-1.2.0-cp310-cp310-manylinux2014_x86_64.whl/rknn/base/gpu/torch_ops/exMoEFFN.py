import torch


class exMoEFFN_torch(torch.nn.Module):
    """Pure-Torch implementation of Toolkit's fused MoE FFN operator."""

    def __init__(
        self,
        n_routed_experts,
        n_experts_per_token,
        n_shared_experts=0,
        gate_activation="SWISH",
        activation_alpha=1.0,
        gate_clip_mode="NONE",
        gate_clip_min=0.0,
        gate_clip_max=0.0,
        up_clip_mode="NONE",
        up_clip_min=0.0,
        up_clip_max=0.0,
        up_offset=0.0,
        has_gate_bias=0,
        has_up_bias=0,
        has_down_bias=0,
        routing_weight_mode="POST_DOWN_OUTPUT",
        **kwargs,
    ):
        super(exMoEFFN_torch, self).__init__()
        self.n_routed_experts = int(n_routed_experts)
        self.n_experts_per_token = int(n_experts_per_token)
        self.n_shared_experts = int(n_shared_experts or 0)
        self.gate_activation = self._string_attr(
            gate_activation, "SWISH"
        )
        self.activation_alpha = float(activation_alpha)
        self.gate_clip_mode = self._string_attr(gate_clip_mode, "NONE")
        self.gate_clip_min = float(gate_clip_min)
        self.gate_clip_max = float(gate_clip_max)
        self.up_clip_mode = self._string_attr(up_clip_mode, "NONE")
        self.up_clip_min = float(up_clip_min)
        self.up_clip_max = float(up_clip_max)
        self.up_offset = float(up_offset)
        self.has_gate_bias = bool(has_gate_bias)
        self.has_up_bias = bool(has_up_bias)
        self.has_down_bias = bool(has_down_bias)
        self.routing_weight_mode = self._string_attr(
            routing_weight_mode, "POST_DOWN_OUTPUT"
        )

    @staticmethod
    def _string_attr(value, default):
        if value is None:
            return default
        if isinstance(value, bytes):
            return value.decode("utf-8")
        return str(value)

    @staticmethod
    def _clip(value, mode, minimum, maximum):
        if mode == "NONE":
            return value
        if mode == "MAX":
            return torch.clamp_max(value, maximum)
        if mode == "MIN_MAX":
            return torch.clamp(value, minimum, maximum)
        raise ValueError(
            "Unsupported exMoEFFN clip mode: {}".format(mode)
        )

    def _activate(self, value):
        if self.gate_activation == "SWISH":
            return value * torch.sigmoid(self.activation_alpha * value)
        if self.gate_activation == "GELU_TANH":
            return 0.5 * value * (
                1.0
                + torch.tanh(
                    0.7978845608028654
                    * (value + 0.044715 * torch.pow(value, 3))
                )
            )
        if self.gate_activation == "GELU_ERF":
            return 0.5 * value * (
                1.0 + torch.erf(value / 1.4142135623730951)
            )
        raise ValueError(
            "Unsupported gate activation: {}".format(
                self.gate_activation
            )
        )

    @staticmethod
    def _project(hidden, weight, bias=None):
        if hidden.dim() != 4 or weight.dim() != 4:
            raise ValueError("exMoEFFN projection inputs must be 4-D")
        _, hidden_channels, _, hidden_tokens = hidden.shape
        _, weight_channels, _, output_channels = weight.shape
        if hidden_channels != weight_channels:
            raise ValueError(
                "exMoEFFN projection channel dimensions do not match"
            )
        output = torch.matmul(
            hidden.reshape(-1, hidden_channels, hidden_tokens).transpose(1, 2),
            weight.reshape(-1, weight_channels, output_channels),
        ).reshape(-1, hidden_tokens, 1, output_channels)
        if bias is not None:
            output = output + bias.reshape(1, 1, 1, -1)
        return output

    def _ffn(self, hidden, probabilities, parameters):
        (
            gate_weight,
            up_weight,
            down_weight,
            gate_bias,
            up_bias,
            down_bias,
        ) = parameters
        if self.routing_weight_mode == "PRE_EXPERT_INPUT":
            hidden = hidden * probabilities.reshape(1, 1, 1, -1)
        gate = self._project(hidden, gate_weight, gate_bias)
        up = self._project(hidden, up_weight, up_bias)
        gate = self._clip(
            gate,
            self.gate_clip_mode,
            self.gate_clip_min,
            self.gate_clip_max,
        )
        up = self._clip(
            up,
            self.up_clip_mode,
            self.up_clip_min,
            self.up_clip_max,
        )
        intermediate = (
            self._activate(gate) * (up + self.up_offset)
        ).permute(0, 3, 2, 1)
        output = self._project(
            intermediate, down_weight, down_bias
        ).permute(0, 3, 2, 1)
        if self.routing_weight_mode == "POST_DOWN_OUTPUT":
            output = output * probabilities.reshape(1, 1, 1, -1)
        return output

    def forward(self, *inputs):
        if len(inputs) < 5:
            raise ValueError(
                "exMoEFFN requires five routing/shared metadata inputs"
            )
        if self.n_routed_experts <= 0 or self.n_shared_experts < 0:
            raise ValueError("exMoEFFN expert counts are invalid")
        if self.routing_weight_mode not in (
            "PRE_EXPERT_INPUT",
            "POST_DOWN_OUTPUT",
        ):
            raise ValueError(
                "Unsupported routing weight mode: {}".format(
                    self.routing_weight_mode
                )
            )

        routed_hidden, routed_prob, received_tokens = inputs[:3]
        shared_hidden, shared_prob = inputs[3:5]
        if routed_hidden.dim() != 4 or routed_hidden.shape[0] != 1:
            raise ValueError(
                "routed_expert_permuted_hidden_state must use "
                "[1, D, T, EPT] layout"
            )
        hidden_size = routed_hidden.shape[1]
        token_count = routed_hidden.shape[2]
        experts_per_token = routed_hidden.shape[3]
        compact_tokens = token_count * experts_per_token
        if experts_per_token != self.n_experts_per_token:
            raise ValueError(
                "routed_expert_permuted_hidden_state expert dimension "
                "is invalid"
            )
        if routed_prob.numel() != compact_tokens:
            raise ValueError(
                "routed_expert_prob shape does not match routed input"
            )

        has_shared_inputs = (
            self.n_shared_experts > 0
            and shared_hidden is not None
            and shared_prob is not None
        )
        if has_shared_inputs:
            if tuple(shared_hidden.shape) != (
                1,
                hidden_size,
                1,
                token_count,
            ):
                raise ValueError(
                    "shared_expert_hidden_state shape does not match "
                    "routed input"
                )
            if tuple(shared_prob.shape) != (
                token_count,
                self.n_shared_experts,
            ):
                raise ValueError(
                    "shared_expert_prob shape does not match shared "
                    "expert count"
                )

        integer_types = (
            torch.int8,
            torch.uint8,
            torch.int16,
            torch.int32,
            torch.int64,
        )
        if received_tokens.dtype not in integer_types:
            raise ValueError(
                "routed_expert_received_tokens must be an integer tensor"
            )
        received_tokens = received_tokens.reshape(-1).to(dtype=torch.int64)
        if (
            received_tokens.numel() != self.n_routed_experts
            or torch.any(received_tokens < 0)
            or torch.any(received_tokens > token_count)
            or int(received_tokens.sum().item()) > compact_tokens
        ):
            raise ValueError(
                "routed_expert_received_tokens is invalid"
            )

        cursor = 5

        def next_expert_parameters():
            nonlocal cursor
            weights = []
            biases = []
            for has_bias in (
                self.has_gate_bias,
                self.has_up_bias,
                self.has_down_bias,
            ):
                if cursor >= len(inputs):
                    raise ValueError("Missing exMoEFFN expert parameters")
                weights.append(inputs[cursor])
                cursor += 1
                if has_bias:
                    if cursor >= len(inputs):
                        raise ValueError("Missing exMoEFFN expert bias")
                    biases.append(inputs[cursor])
                    cursor += 1
                else:
                    biases.append(None)
            return (*weights, *biases)

        routed_output = torch.zeros_like(routed_hidden)
        routed_hidden_flat = routed_hidden.reshape(
            1, hidden_size, 1, compact_tokens
        )
        routed_output_flat = routed_output.reshape(
            1, hidden_size, 1, compact_tokens
        )
        routed_prob_flat = routed_prob.reshape(-1)
        offset = 0
        for received_count_tensor in received_tokens:
            parameters = next_expert_parameters()
            received_count = int(received_count_tensor.item())
            end = offset + received_count
            if token_count == 1:
                if shared_hidden is None:
                    raise ValueError(
                        "decode exMoEFFN requires shared_expert_hidden_state"
                    )
                routed_input = shared_hidden
            else:
                routed_input = routed_hidden_flat[:, :, :, offset:end]
            if received_count:
                routed_output_flat[:, :, :, offset:end] = self._ffn(
                    routed_input,
                    routed_prob_flat[offset:end],
                    parameters,
                )
            offset = end

        routed_output = routed_output_flat.reshape(routed_hidden.shape)
        shared_outputs = []
        if has_shared_inputs:
            for expert_id in range(self.n_shared_experts):
                parameters = next_expert_parameters()
                shared_outputs.append(
                    self._ffn(
                        shared_hidden,
                        shared_prob[:, expert_id],
                        parameters,
                    ).permute(0, 1, 3, 2)
                )

        if cursor != len(inputs):
            raise ValueError(
                "Unexpected {} trailing exMoEFFN inputs".format(
                    len(inputs) - cursor
                )
            )
        if not has_shared_inputs:
            return routed_output
        return routed_output, torch.cat(shared_outputs, dim=3)

    def forward_symbolic(self, *inputs):
        """Shape placeholders used only while preserving this custom op."""
        if not inputs:
            raise ValueError("exMoEFFN requires inputs")
        has_shared_inputs = (
            self.n_shared_experts > 0
            and len(inputs) >= 5
            and inputs[3] is not None
            and inputs[4] is not None
        )
        if has_shared_inputs:
            shared_output = inputs[0][..., :1].expand(
                -1, -1, -1, self.n_shared_experts
            )
            return inputs[0], shared_output
        return inputs[0]
