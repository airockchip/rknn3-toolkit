import torch


class exConvTransposePad_torch(torch.nn.Module):
    def __init__(self, kernel_shape, strides, pads, **kwargs):
        super(exConvTransposePad_torch, self).__init__()
        self.kernel_shape = tuple(kernel_shape)
        self.strides = tuple(strides)
        self.pads = tuple(pads)

    def forward(self, x):
        n, c, h, w = x.shape
        new_w = (w - 1) * self.strides[1] + 1 + (self.kernel_shape[1] - self.pads[1] - 1) + (self.kernel_shape[1] - self.pads[3] - 1)
        new_h = (h - 1) * self.strides[0] + 1 + (self.kernel_shape[0] - self.pads[0] - 1) + (self.kernel_shape[0] - self.pads[2] - 1)
        out = torch.zeros((n, c, new_h, new_w), dtype=x.dtype, device=x.device)
        start_h = self.kernel_shape[0] - self.pads[0] - 1
        start_w = self.kernel_shape[1] - self.pads[1] - 1
        stop_h = start_h + (h - 1) * self.strides[0] + 1
        stop_w = start_w + (w - 1) * self.strides[1] + 1
        out[:, :, start_h:stop_h:self.strides[0],
            start_w:stop_w:self.strides[1]] = x
        return out
