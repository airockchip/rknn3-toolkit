import torch


class exRMSNorm_torch(torch.nn.Module):
    def __init__(self, eps=1e-5, **kwargs):
        super(exRMSNorm_torch, self).__init__()
        self.eps = float(eps)

    def forward(self, x, weight):
        return x * torch.rsqrt(torch.mean(x * x, dim=-1, keepdim=True) + self.eps) * weight
