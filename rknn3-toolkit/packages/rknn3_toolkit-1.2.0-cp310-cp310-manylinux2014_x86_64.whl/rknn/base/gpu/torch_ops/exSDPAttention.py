import torch


class exSDPAttention_torch(torch.nn.Module):
    def __init__(self, scale=1.0, **kwargs):
        super(exSDPAttention_torch, self).__init__()
        self.scale = float(scale)

    def forward(self, q, k, v, mask=None):
        # q: [batch, dim_k, 1, seq_q]
        # k: [batch, dim_k, 1, seq_k]
        # v: [batch, dim_c, 1, seq_k]
        # output: [batch, dim_c, 1, seq_q]

        batch = q.shape[0]
        dim_k = q.shape[1]
        dim_c = v.shape[1]

        q2 = q.flatten(2)
        k2 = k.flatten(2)
        v2 = v.flatten(2)

        attn = torch.matmul(k2.transpose(1, 2), q2) * self.scale

        if mask is not None:
            if mask.dim() == 4:
                mask = mask.reshape(mask.shape[0], mask.shape[1], mask.shape[3])
            elif mask.dim() == 2:
                mask = mask.unsqueeze(-1)
            attn = attn + mask

        attn = torch.softmax(attn, dim=1)
        out = torch.matmul(v2, attn)

        seq_q = q2.shape[-1]
        out = out.view(batch, dim_c, 1, seq_q)
        return out

    def forward_symbolic(self, q, k, v, mask=None):
        """Trace-friendly SDP attention: avoid q.shape[0]/v.shape[1] indexing
        which causes TorchScript to emit Shape+Gather nodes that break ORT
        graph initialization. Use flatten/unsqueeze instead.
        """
        q2 = q.flatten(2)
        k2 = k.flatten(2)
        v2 = v.flatten(2)

        attn = torch.matmul(k2.transpose(1, 2), q2) * self.scale

        if mask is not None:
            if mask.dim() == 4:
                # [batch, seq_k, 1, seq_q] -> [batch, seq_k, seq_q] via flatten
                mask = mask.flatten(2)
            elif mask.dim() == 2:
                mask = mask.unsqueeze(-1)
            attn = attn + mask

        attn = torch.softmax(attn, dim=1)
        out = torch.matmul(v2, attn)
        # [batch, dim_c, seq_q] -> [batch, dim_c, 1, seq_q]
        out = out.unsqueeze(2)
        return out
