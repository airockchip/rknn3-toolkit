import torch


class exMeanVarianceNormalization_torch(torch.nn.Module):
    def __init__(self, axes, eps=1e-5, elementwise_affine=False, **kwargs):
        super(exMeanVarianceNormalization_torch, self).__init__()
        self.axes = tuple(axes)
        self.eps = float(eps)
        self.elementwise_affine = bool(elementwise_affine)

    def forward(self, x, weight=None, bias=None):
        mean = torch.mean(x, dim=self.axes, keepdim=True)
        squared_mean = torch.mean(x * x, dim=self.axes, keepdim=True)
        std = torch.sqrt(squared_mean - mean * mean + self.eps)
        y = (x - mean) / std
        if self.elementwise_affine and weight is not None and bias is not None:
            y = y * weight + bias
        return y
