import torch


class exLogit_torch(torch.nn.Module):
    def __init__(self, eps=1e-6, **kwargs):
        super(exLogit_torch, self).__init__()
        self.eps = float(eps)

    def forward(self, x):
        x1 = torch.clamp(x, min=self.eps, max=torch.finfo(x.dtype).max)
        x2 = torch.clamp(1 - x, min=self.eps, max=torch.finfo(x.dtype).max)
        return torch.log(x1 / x2)
