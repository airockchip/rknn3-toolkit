import torch


class exFcclipNonzero_torch(torch.nn.Module):
    def __init__(self, repeat, **kwargs):
        super(exFcclipNonzero_torch, self).__init__()
        self.repeat = int(repeat)

    def forward(self, x, threshold):
        expanded = torch.repeat_interleave(x, self.repeat, dim=1)
        attn_mask = expanded.permute(1, 2, 0, 3) < threshold
        sum_mask = attn_mask.sum(dim=-1)
        attn_mask[sum_mask == attn_mask.shape[-1]] = False
        return attn_mask
