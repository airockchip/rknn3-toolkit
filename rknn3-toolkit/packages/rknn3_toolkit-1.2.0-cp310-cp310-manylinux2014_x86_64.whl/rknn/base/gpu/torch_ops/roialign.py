import torch


class exRoiAlign_torch(torch.nn.Module):
    def __init__(self, output_height, output_width, spatial_scale=1.0,
                 sampling_ratio=0, aligned=None,
                 coordinate_transformation_mode='half_pixel', **kwargs):
        super(exRoiAlign_torch, self).__init__()
        self.output_height = int(output_height)
        self.output_width = int(output_width)
        self.spatial_scale = float(spatial_scale)
        self.sampling_ratio = int(sampling_ratio)
        # RKNN's exRoiAlign reference lowers to ONNX RoiAlign, whose default
        # coordinate mode is half_pixel. torchvision calls this aligned=True.
        self.aligned = (coordinate_transformation_mode == 'half_pixel'
                        if aligned is None else bool(aligned))
        self.coordinate_transformation_mode = coordinate_transformation_mode

    def forward(self, x, rois):
        try:
            from torchvision.ops import roi_align
        except Exception as exc:
            raise NotImplementedError('exRoiAlign_torch requires torchvision') from exc
        if rois.dim() != 2 or rois.shape[1] != 5:
            raise RuntimeError(
                'exRoiAlign expects rois with shape [num_rois, 5]')
        # Passing [boxes] assigns every ROI to batch zero. The [K,5] form keeps
        # the batch index in column zero and matches RKNN/ONNX RoiAlign.
        return roi_align(
            x, rois, output_size=(self.output_height, self.output_width),
            spatial_scale=self.spatial_scale,
            sampling_ratio=self.sampling_ratio, aligned=self.aligned)
