import torch


class exHardSwish_torch(torch.nn.Module):
    def __init__(self, **kwargs):
        super(exHardSwish_torch, self).__init__()

    def forward(self, x):
        return x * torch.clamp(x / 6.0 + 0.5, min=0.0, max=1.0)
