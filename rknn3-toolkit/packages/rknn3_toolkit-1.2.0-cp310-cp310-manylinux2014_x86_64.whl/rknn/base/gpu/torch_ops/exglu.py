import torch

class exGlu_torch(torch.nn.Module):
    def __init__(self, axis=-1):
        super(exGlu_torch, self).__init__()
        self.axis = axis

    def forward(self, x):
        a, b = torch.chunk(x, 2, dim=self.axis)
        return a * torch.sigmoid(b)
