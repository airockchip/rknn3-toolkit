import numpy as np


class exmpiBCast_numpy:
    def __init__(self, num_outputs, **kwargs):
        self.num_outputs = int(num_outputs)

    def forward(self, x):
        x = np.asarray(x)
        return tuple(x.copy() for _ in range(self.num_outputs))
