import numpy as np


class exRfftn_numpy:
    def __init__(self, s=None, dim=None, norm='backward', **kwargs):
        self.s = tuple(s) if s is not None else None
        self.dim = tuple(dim) if dim is not None else None
        self.norm = norm

    def forward(self, x):
        x = np.asarray(x)
        y = np.fft.rfftn(x, s=self.s, axes=self.dim, norm=self.norm)
        return np.stack([y.real, y.imag], axis=0)
