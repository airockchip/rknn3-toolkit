import numpy as np


class exReorg_numpy:
    def __init__(self, stride=2, **kwargs):
        self.stride = int(stride)

    def forward(self, x):
        x = np.asarray(x)
        b, c, h, w = x.shape
        s = self.stride
        x = x.reshape(b, c, h // s, s, w // s, s)
        x = x.transpose(0, 1, 3, 5, 2, 4)
        return x.reshape(b, c * s * s, h // s, w // s)
