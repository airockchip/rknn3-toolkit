"""Pure-numpy implementations of standard ONNX ops.

Each class mirrors the constructor signature of the corresponding torch_ops class,
but uses numpy for computation. No torch dependency.
"""
import numpy as np
from scipy.special import erf as _erf


# --- Simple elementwise ops (no constructor params) ---

class Abs_numpy:
    def __init__(self, **kwargs):
        pass
    def forward(self, x):
        return np.abs(np.asarray(x))

class Add_numpy:
    def __init__(self, **kwargs):
        pass
    def forward(self, a, b):
        return np.asarray(a) + np.asarray(b)

class And_numpy:
    def __init__(self, **kwargs):
        pass
    def forward(self, a, b):
        return np.logical_and(np.asarray(a), np.asarray(b))

class BitwiseAnd_numpy:
    def __init__(self, **kwargs):
        pass
    def forward(self, x, y):
        return np.bitwise_and(np.asarray(x), np.asarray(y))

class Cos_numpy:
    def __init__(self, **kwargs):
        pass
    def forward(self, x):
        return np.cos(np.asarray(x))

class Div_numpy:
    def __init__(self, **kwargs):
        pass
    def forward(self, a, b):
        return np.asarray(a) / np.asarray(b)

class Equal_numpy:
    def __init__(self, **kwargs):
        pass
    def forward(self, x, y):
        return np.equal(np.asarray(x), np.asarray(y))

class Erf_numpy:
    def __init__(self, **kwargs):
        pass
    def forward(self, x):
        return _erf(np.asarray(x))

class Exp_numpy:
    def __init__(self, **kwargs):
        pass
    def forward(self, x):
        return np.exp(np.asarray(x))

class Floor_numpy:
    def __init__(self, **kwargs):
        pass
    def forward(self, x):
        return np.floor(np.asarray(x))

class Greater_numpy:
    def __init__(self, **kwargs):
        pass
    def forward(self, x, y):
        return np.greater(np.asarray(x), np.asarray(y))

class LessOrEqual_numpy:
    def __init__(self, **kwargs):
        pass
    def forward(self, x, y):
        return np.less_equal(np.asarray(x), np.asarray(y))

class Identity_numpy:
    def __init__(self, **kwargs):
        pass
    def forward(self, x):
        return np.asarray(x)

class IsNaN_numpy:
    def __init__(self, **kwargs):
        pass
    def forward(self, x):
        return np.isnan(np.asarray(x))

class Max_numpy:
    def __init__(self, **kwargs):
        pass
    def forward(self, *inputs):
        out = np.asarray(inputs[0])
        for item in inputs[1:]:
            out = np.maximum(out, np.asarray(item))
        return out

class Min_numpy:
    def __init__(self, **kwargs):
        pass
    def forward(self, *inputs):
        out = np.asarray(inputs[0])
        for item in inputs[1:]:
            out = np.minimum(out, np.asarray(item))
        return out

class Mul_numpy:
    def __init__(self, **kwargs):
        pass
    def forward(self, a, b):
        return np.asarray(a) * np.asarray(b)

class Neg_numpy:
    def __init__(self, **kwargs):
        pass
    def forward(self, x):
        return np.negative(np.asarray(x))

class Not_numpy:
    def __init__(self, **kwargs):
        pass
    def forward(self, x):
        return np.logical_not(np.asarray(x))

class Pow_numpy:
    def __init__(self, **kwargs):
        pass
    def forward(self, a, b):
        return np.power(np.asarray(a), np.asarray(b))

class Reciprocal_numpy:
    def __init__(self, **kwargs):
        pass
    def forward(self, x):
        return np.reciprocal(np.asarray(x))

class Sign_numpy:
    def __init__(self, **kwargs):
        pass
    def forward(self, x):
        return np.sign(np.asarray(x))

class Sin_numpy:
    def __init__(self, **kwargs):
        pass
    def forward(self, x):
        return np.sin(np.asarray(x))

class Sqrt_numpy:
    def __init__(self, **kwargs):
        pass
    def forward(self, x):
        return np.sqrt(np.asarray(x))

class Sub_numpy:
    def __init__(self, **kwargs):
        pass
    def forward(self, a, b):
        return np.asarray(a) - np.asarray(b)

class Tanh_numpy:
    def __init__(self, **kwargs):
        pass
    def forward(self, x):
        return np.tanh(np.asarray(x))

class Where_numpy:
    def __init__(self, **kwargs):
        pass
    def forward(self, condition, x, y):
        return np.where(np.asarray(condition), np.asarray(x), np.asarray(y))

class Softplus_numpy:
    def __init__(self, **kwargs):
        pass
    def forward(self, x):
        x = np.asarray(x)
        return np.log1p(np.exp(x))

# --- Ops with constructor params ---

class Cast_numpy:
    ONNX_TO_NUMPY = {
        1: np.float32, 2: np.uint8, 3: np.int8, 5: np.int16,
        6: np.int32, 7: np.int64, 9: np.bool_, 10: np.float16,
        11: np.float64, 12: np.uint32, 13: np.uint64,
    }
    def __init__(self, to, **kwargs):
        self.to = int(to)
    def forward(self, x):
        x = np.asarray(x)
        target = self.ONNX_TO_NUMPY.get(self.to, np.float32)
        if target == np.float16 and np.issubdtype(x.dtype, np.floating):
            finfo = np.finfo(np.float16)
            x = np.clip(x, finfo.min, finfo.max)
        return x.astype(target)

class Clip_numpy:
    def __init__(self, min_value=None, max_value=None, **kwargs):
        self.min_value = min_value
        self.max_value = max_value
    def forward(self, x, min_value=None, max_value=None):
        x = np.asarray(x)
        lo = min_value if min_value is not None else self.min_value
        hi = max_value if max_value is not None else self.max_value
        return np.clip(x, lo, hi)

class Concat_numpy:
    def __init__(self, axis=0, **kwargs):
        self.axis = int(axis)
    def forward(self, *inputs):
        return np.concatenate([np.asarray(x) for x in inputs], axis=self.axis)

class ConstantOfShape_numpy:
    def __init__(self, value=0.0, **kwargs):
        if isinstance(value, np.ndarray):
            self.value = value.reshape(-1)[0]
        else:
            self.value = np.asarray(value).reshape(-1)[0]
    def forward(self, shape):
        shape = np.asarray(shape).flatten().tolist()
        return np.full(shape, self.value)

class Flatten_numpy:
    def __init__(self, axis=1, **kwargs):
        self.axis = int(axis)
    def forward(self, x):
        x = np.asarray(x)
        axis = self.axis if self.axis >= 0 else self.axis + x.ndim
        return x.reshape(int(np.prod(x.shape[:axis])), -1)

class Gather_numpy:
    def __init__(self, axis=0, **kwargs):
        self.axis = int(axis)
    def forward(self, data, indices):
        data = np.asarray(data)
        indices = np.asarray(indices).astype(np.int64).reshape(-1)
        axis = self.axis if self.axis >= 0 else self.axis + data.ndim
        gathered = np.take(data, indices, axis=axis)
        target_shape = list(data.shape[:axis]) + list(indices.shape) + list(data.shape[axis + 1:])
        return gathered.reshape(target_shape)

class GatherElements_numpy:
    def __init__(self, axis=0, **kwargs):
        self.axis = int(axis)
    def forward(self, data, indices):
        data = np.asarray(data)
        indices = np.asarray(indices).astype(np.int64)
        return np.take_along_axis(data, indices, axis=self.axis)

class GatherND_numpy:
    def __init__(self, batch_dims=0, **kwargs):
        self.batch_dims = int(batch_dims)
    def forward(self, data, indices):
        data = np.asarray(data)
        indices = np.asarray(indices).astype(np.int64)
        if indices.ndim < 2:
            return data[indices]
        m = indices.shape[-1]
        batch_shape = indices.shape[:-1]
        flat = indices.reshape(-1, m)
        out = np.array([data[tuple(row)] for row in flat])
        return out.reshape(batch_shape + list(out.shape[1:]))

class Gemm_numpy:
    def __init__(self, alpha=1.0, beta=1.0, transA=0, transB=0, **kwargs):
        self.alpha = float(alpha)
        self.beta = float(beta)
        self.transA = bool(transA)
        self.transB = bool(transB)
    def forward(self, a, b, c=None):
        a = np.asarray(a)
        b = np.asarray(b)
        if self.transA:
            a = a.swapaxes(-1, -2)
        if self.transB:
            b = b.swapaxes(-1, -2)
        y = self.alpha * np.matmul(a, b)
        if c is not None:
            y = y + self.beta * np.asarray(c)
        return y

class GlobalAveragePool_numpy:
    def __init__(self, **kwargs):
        pass
    def forward(self, x):
        x = np.asarray(x)
        axes = tuple(range(2, x.ndim))
        return np.mean(x, axis=axes, keepdims=True)

class LayerNormalization_numpy:
    def __init__(self, axis=-1, epsilon=1e-5, **kwargs):
        self.axis = int(axis)
        self.epsilon = float(epsilon)
    def forward(self, x, scale=None, bias=None):
        x = np.asarray(x)
        axis = self.axis if self.axis >= 0 else self.axis + x.ndim
        axes = tuple(range(axis, x.ndim))
        mean = np.mean(x, axis=axes, keepdims=True)
        var = np.mean((x - mean) ** 2, axis=axes, keepdims=True)
        y = (x - mean) / np.sqrt(var + self.epsilon)
        if scale is not None:
            y = y * np.asarray(scale)
        if bias is not None:
            y = y + np.asarray(bias)
        return y

class LeakyRelu_numpy:
    def __init__(self, alpha=0.01, **kwargs):
        self.alpha = float(alpha)
    def forward(self, x):
        x = np.asarray(x)
        return np.where(x >= 0, x, self.alpha * x)

class MatMul_numpy:
    def __init__(self, **kwargs):
        pass
    def forward(self, a, b):
        return np.matmul(np.asarray(a), np.asarray(b))

class Mod_numpy:
    def __init__(self, fmod=0, **kwargs):
        self.fmod = int(fmod)
    def forward(self, x, y):
        x = np.asarray(x)
        y = np.asarray(y)
        if self.fmod:
            return np.fmod(x, y)
        return np.remainder(x, y)

class Pad_numpy:
    MODE_MAP = {"constant": "constant", "reflect": "reflect", "edge": "edge"}
    def __init__(self, mode="constant", pads=None, value=0.0, **kwargs):
        self.mode = mode
        self.pads = tuple(pads) if pads is not None else None
        self.value = float(value)
    def forward(self, x, pads=None, value=None):
        x = np.asarray(x)
        raw = pads if pads is not None else self.pads
        if raw is None:
            raise RuntimeError("Pad_numpy requires pads")
        raw = [int(v) for v in np.asarray(raw).flatten()]
        rank = x.ndim
        np_pads = [(0, 0)] * rank
        for axis in range(rank):
            np_pads[axis] = (raw[axis], raw[axis + rank])
        mode = self.MODE_MAP.get(self.mode, self.mode)
        val = float(value) if value is not None else self.value
        return np.pad(x, np_pads, mode=mode, constant_values=val)

class Range_numpy:
    def __init__(self, **kwargs):
        pass
    def forward(self, start, limit, delta):
        start = float(np.asarray(start).reshape(-1)[0])
        limit = float(np.asarray(limit).reshape(-1)[0])
        delta = float(np.asarray(delta).reshape(-1)[0])
        return np.arange(start, limit, delta)

class ReduceMean_numpy:
    def __init__(self, axes=None, keepdims=1, noop_with_empty_axes=0, **kwargs):
        self.axes = tuple(axes) if axes is not None else None
        self.keepdims = bool(keepdims)
        self.noop = bool(noop_with_empty_axes)
    def forward(self, x, axes=None):
        x = np.asarray(x)
        if axes is not None:
            ax = tuple(int(v) for v in np.asarray(axes).flatten())
        elif self.axes is not None:
            ax = self.axes
        elif self.noop:
            return x
        else:
            ax = None
        return np.mean(x, axis=ax, keepdims=self.keepdims)

class ReduceSum_numpy:
    def __init__(self, axes=None, keepdims=1, noop_with_empty_axes=0, **kwargs):
        self.axes = tuple(axes) if axes is not None else None
        self.keepdims = bool(keepdims)
        self.noop = bool(noop_with_empty_axes)
    def forward(self, x, axes=None):
        x = np.asarray(x)
        if axes is not None:
            ax = tuple(int(v) for v in np.asarray(axes).flatten())
        elif self.axes is not None:
            ax = self.axes
        elif self.noop:
            return x
        else:
            ax = None
        return np.sum(x, axis=ax, keepdims=self.keepdims)

class Reshape_numpy:
    def __init__(self, allowzero=0, **kwargs):
        self.allowzero = int(allowzero)
    def forward(self, x, shape):
        x = np.asarray(x)
        dims = [int(v) for v in np.asarray(shape).flatten()]
        if not self.allowzero:
            for i, d in enumerate(dims):
                if d == 0:
                    dims[i] = x.shape[i] if i < x.ndim else 1
        return x.reshape(dims)

class Resize_numpy:
    def __init__(self, mode="nearest", coordinate_transformation_mode="half_pixel",
                 nearest_mode="round_prefer_floor", **kwargs):
        self.mode = mode
    def forward(self, x, roi=None, scales=None, sizes=None):
        x = np.asarray(x)
        if sizes is not None:
            size = tuple(int(v) for v in np.asarray(sizes).flatten()[-2:])
            return np.resize(x, (x.shape[0], x.shape[1]) + size)  # simplified
        if scales is not None:
            scale = np.asarray(scales).flatten()
            new_shape = list(x.shape)
            for i in range(2, x.ndim):
                new_shape[i] = int(round(x.shape[i] * float(scale[i])))
            return np.resize(x, new_shape)
        raise RuntimeError("Resize_numpy expects sizes or scales")

class ScatterND_numpy:
    def __init__(self, reduction="none", **kwargs):
        self.reduction = reduction
    def forward(self, data, indices, updates):
        data = np.asarray(data).copy()
        indices = np.asarray(indices).astype(np.int64)
        updates = np.asarray(updates)
        if indices.size == 0:
            return data
        flat_idx = indices.reshape(-1, indices.shape[-1])
        suffix_shape = data.shape[indices.shape[-1]:]
        flat_updates = updates.reshape(flat_idx.shape[0], *suffix_shape)
        for i in range(flat_idx.shape[0]):
            idx = tuple(flat_idx[i])
            if self.reduction in ("none", "replace"):
                data[idx] = flat_updates[i]
            elif self.reduction in ("add", "sum"):
                data[idx] += flat_updates[i]
        return data

class Shape_numpy:
    def __init__(self, start=0, end=None, **kwargs):
        self.start = int(start)
        self.end = None if end is None else int(end)
    def forward(self, x):
        x = np.asarray(x)
        shape = list(x.shape)
        end = self.end if self.end is not None else len(shape)
        return np.array(shape[self.start:end], dtype=np.int64)

class Slice_numpy:
    def __init__(self, **kwargs):
        pass
    def forward(self, data, starts, ends, axes=None, steps=None):
        data = np.asarray(data)
        starts = [int(v) for v in np.asarray(starts).flatten()]
        ends = [int(v) for v in np.asarray(ends).flatten()]
        if axes is not None:
            axes = [int(v) for v in np.asarray(axes).flatten()]
        else:
            axes = list(range(len(starts)))
        if steps is not None:
            steps = [int(v) for v in np.asarray(steps).flatten()]
        else:
            steps = [1] * len(starts)
        slc = [slice(None)] * data.ndim
        for axis, start, end, step in zip(axes, starts, ends, steps):
            slc[axis] = slice(start, end, step)
        return data[tuple(slc)]

class Softmax_numpy:
    def __init__(self, axis=-1, **kwargs):
        self.axis = int(axis)
    def forward(self, x):
        x = np.asarray(x)
        x_max = np.max(x, axis=self.axis, keepdims=True)
        e = np.exp(x - x_max)
        return e / np.sum(e, axis=self.axis, keepdims=True)

class Split_numpy:
    def __init__(self, axis=0, num_outputs=None, sections=None, **kwargs):
        self.axis = int(axis)
        self.num_outputs = int(num_outputs) if num_outputs is not None else None
        self.sections = [int(s) for s in sections] if sections is not None else None
    def forward(self, x, split=None):
        x = np.asarray(x)
        if split is not None:
            sections = [int(v) for v in np.asarray(split).flatten()]
        elif self.sections is not None:
            sections = self.sections
        else:
            part = x.shape[self.axis] // self.num_outputs
            sections = [part] * self.num_outputs
        results = np.split(x, np.cumsum(sections)[:-1], axis=self.axis)
        if self.num_outputs is not None and self.num_outputs == 1:
            return results[0]
        if len(sections) == 1:
            return results[0]
        return tuple(results)

class Squeeze_numpy:
    def __init__(self, axes=None, **kwargs):
        self.axes = tuple(axes) if axes is not None else None
    def forward(self, x, axes=None):
        x = np.asarray(x)
        if axes is not None:
            ax = tuple(int(v) for v in np.asarray(axes).flatten())
        elif self.axes is not None:
            ax = self.axes
        else:
            return x.squeeze()
        return np.squeeze(x, axis=ax)

class Transpose_numpy:
    def __init__(self, perm=None, **kwargs):
        self.perm = tuple(perm) if perm is not None else None
    def forward(self, x):
        x = np.asarray(x)
        if self.perm is None:
            return x.T
        return x.transpose(self.perm)

class Unsqueeze_numpy:
    def __init__(self, axes=None, **kwargs):
        self.axes = tuple(axes) if axes is not None else None
    def forward(self, x, axes=None):
        x = np.asarray(x)
        if axes is not None:
            ax = [int(v) for v in np.asarray(axes).flatten()]
        elif self.axes is not None:
            ax = list(self.axes)
        else:
            raise RuntimeError("Unsqueeze_numpy requires axes")
        for axis in sorted(ax):
            x = np.expand_dims(x, axis)
        return x

class Expand_numpy:
    def __init__(self, **kwargs):
        pass
    def forward(self, x, shape):
        x = np.asarray(x)
        target = [int(v) for v in np.asarray(shape).flatten()]
        input_shape = list(x.shape)
        # Align ranks by left-padding with 1s
        if len(target) < len(input_shape):
            target = [1] * (len(input_shape) - len(target)) + target
        elif len(target) > len(input_shape):
            x = x.reshape([1] * (len(target) - len(input_shape)) + input_shape)
        # Resolve each dim: -1 -> keep input; else use target (broadcast handles 1->N)
        resolved = []
        for t, i in zip(target, list(x.shape)):
            if t < 0:
                resolved.append(i)
            elif t == 1 and i != 1:
                resolved.append(i)
            else:
                resolved.append(t)
        return np.broadcast_to(x, resolved).copy()
