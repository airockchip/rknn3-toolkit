import numpy as np


class exIRfftn_numpy:
    def __init__(self, dim=None, norm='backward', **kwargs):
        self.dim = tuple(dim) if dim is not None else None
        self.norm = norm

    def forward(self, x, s):
        x0 = np.asarray(x[0])
        x1 = np.asarray(x[1])
        y = x0 + 1j * x1
        s_list = [int(v) for v in (s.tolist() if hasattr(s, 'tolist') else s)]
        return np.fft.irfftn(y, s=s_list, axes=self.dim, norm=self.norm)
