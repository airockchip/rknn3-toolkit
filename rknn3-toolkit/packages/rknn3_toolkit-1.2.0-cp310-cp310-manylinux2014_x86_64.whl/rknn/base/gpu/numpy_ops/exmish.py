import numpy as np


class exMish_numpy:
    def __init__(self, **kwargs):
        pass

    def forward(self, x):
        x = np.asarray(x)
        return x * np.tanh(np.log1p(np.exp(x)))
