import numpy as np

from rknn.base.gpu.numpy_ops.exRoPE import exRoPE_numpy
from rknn.base.gpu.numpy_ops.exSDPAttention import exSDPAttention_numpy


class exAttention_numpy:
    """NumPy implementation of exAttention for the simulator backend.

    ``NumpyNodeRunner`` creates an ``IRGraph`` with ``disable_kv_cache=True``.
    Keep the pure NumPy path identical: it evaluates the current sequence only
    and must not retain a KV cache between node calls.
    """

    def __init__(self, rope=0, scale=1.0, kvcache_buffer_len=0, sliding_window_size=0,
                 **kwargs):
        self.rope = int(rope)
        self.scale = float(scale)
        self.kvcache_buffer_len = int(kvcache_buffer_len)
        self.sliding_window_size = int(sliding_window_size)
        self.attention_type = kwargs.get("attention_type", 0)
        self.kvcache_dtype = kwargs.get("kvcache_dtype", 0)
        self.kvcache_group_size = kwargs.get("kvcache_group_size", 0)
        self.kvcache_residual_depth = kwargs.get("kvcache_residual_depth", 0)
        self.kvcache_store_method = kwargs.get("kvcache_store_method", 0)
        self.max_pos_embedding = kwargs.get("max_pos_embedding", 0)
        self.rope_impl = exRoPE_numpy()
        self.attn = exSDPAttention_numpy(scale=scale)

    def forward(self, q, k, v, mask, cos=None, sin=None, th=None, tc=None, ts=None,
                tsr=None):
        y, _ = self.forward_with_cache(q, k, v, mask, cos, sin, th, tc, ts, tsr,
                                       node_cache={})
        return y

    def forward_with_cache(self, q, k, v, mask, cos=None, sin=None, th=None, tc=None,
                           ts=None, tsr=None, node_cache=None):
        node_cache = {} if node_cache is None else dict(node_cache)
        q, k, v = np.asarray(q), np.asarray(k), np.asarray(v)
        if self.rope != 0 and cos is not None and sin is not None and th is not None:
            q, _ = self.rope_impl.forward_with_cache(q, cos, sin, th, tc, ts, tsr)
            k, _ = self.rope_impl.forward_with_cache(k, cos, sin, th, tc, ts, tsr)
        return self.attn.forward(q, k, v, mask), node_cache
