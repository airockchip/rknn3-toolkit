import numpy as np


class conv_numpy:
    """numpy Conv1d/2d/3d via scipy.signal.correlate."""

    def __init__(self, in_channels, out_channels, stride=1, padding=0, dilation=1, groups=1, bias=True, **kwargs):
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.stride = stride
        self.padding = padding
        self.dilation = dilation
        self.groups = int(groups)
        self.bias = bias

    @staticmethod
    def _dilate_kernel(kernel, dilation):
        """Insert zeros between kernel elements to apply dilation."""
        spatial = kernel.ndim
        result = kernel
        for s in range(spatial):
            if dilation[s] <= 1:
                continue
            new_shape = list(result.shape)
            new_shape[s] = (new_shape[s] - 1) * dilation[s] + 1
            new_kernel = np.zeros(new_shape, dtype=kernel.dtype)
            slc = [slice(None)] * spatial
            slc[s] = slice(None, None, dilation[s])
            new_kernel[tuple(slc)] = result
            result = new_kernel
        return result

    def forward(self, x, weight, bias=None):
        x = np.asarray(x)
        weight = np.asarray(weight)
        spatial = weight.ndim - 2

        # Normalize stride/dilation to tuples
        if isinstance(self.stride, int):
            stride = (self.stride,) * spatial
        elif len(self.stride) == spatial:
            stride = tuple(self.stride)
        else:
            stride = (self.stride[0],) * spatial

        if isinstance(self.dilation, int):
            dilation = (self.dilation,) * spatial
        elif len(self.dilation) == spatial:
            dilation = tuple(self.dilation)
        else:
            dilation = (self.dilation[0],) * spatial

        # Handle padding: apply F.pad equivalent before convolution
        if isinstance(self.padding, int):
            if self.padding > 0:
                pad_width = [(0, 0), (0, 0)] + [(self.padding, self.padding)] * spatial
                x = np.pad(x, pad_width)
        elif isinstance(self.padding, (list, tuple)):
            p = list(self.padding)
            n = len(p)
            if n == spatial:
                # symmetric: (p_h, p_w) -> pad each spatial dim with (p, p)
                pad_width = [(0, 0), (0, 0)] + [(p[i], p[i]) for i in range(spatial)]
                x = np.pad(x, pad_width)
            elif n == 2 * spatial:
                half = n // 2
                begin = p[:half]
                end = p[half:]
                if begin == end:
                    pad_width = [(0, 0), (0, 0)] + [(begin[i], end[i]) for i in range(spatial)]
                    x = np.pad(x, pad_width)
                else:
                    # asymmetric
                    pad_width = [(0, 0), (0, 0)] + [(begin[i], end[i]) for i in range(spatial)]
                    x = np.pad(x, pad_width)
            elif n == 1:
                # 1D padding (begin, end) for 1D conv
                pad_width = [(0, 0), (0, 0), (p[0], p[0])]
                x = np.pad(x, pad_width)
            else:
                # General fallback
                half = n // 2
                begin = p[:half]
                end = p[half:]
                pad_width = [(0, 0), (0, 0)] + [(begin[i], end[i]) for i in range(half)]
                x = np.pad(x, pad_width)

        # Use scipy.signal for correlation (mathematically equivalent to convolution with flipped kernel)
        from scipy.signal import correlate

        N, C_in = x.shape[0], x.shape[1]
        C_out = weight.shape[0]
        in_per_group = C_in // self.groups
        out_per_group = C_out // self.groups

        # Compute output spatial dims
        out_spatial = []
        for s in range(spatial):
            ks = weight.shape[2 + s]
            ds = dilation[s]
            effective_ks = (ks - 1) * ds + 1
            out_dim = (x.shape[2 + s] - effective_ks) // stride[s] + 1
            out_spatial.append(max(out_dim, 1))

        out = np.zeros((N, C_out) + tuple(out_spatial), dtype=x.dtype)

        for g in range(self.groups):
            x_g = x[:, g * in_per_group:(g + 1) * in_per_group]
            w_g = weight[g * out_per_group:(g + 1) * out_per_group]
            for oc in range(out_per_group):
                w_oc = w_g[oc]  # (in_per_group, k1, k2, ...)
                # Process each sample in batch
                for n in range(N):
                    result = None
                    for ic in range(in_per_group):
                        x_slice = x_g[n, ic]  # (H, W) or (L,)
                        w_slice = w_oc[ic]    # (k1, k2) or (k,)
                        # Apply dilation by spreading the kernel with zeros
                        if any(d > 1 for d in dilation):
                            w_slice = self._dilate_kernel(w_slice, dilation)
                        corr = correlate(x_slice, w_slice, mode='valid')
                        # Apply stride by subsampling
                        slc = tuple(slice(None, None, stride[s]) for s in range(spatial))
                        corr = corr[slc]
                        if result is None:
                            result = corr
                        else:
                            result = result + corr
                    out[n, g * out_per_group + oc] = result

        if bias is not None:
            bias = np.asarray(bias)
            out = out + bias.reshape(1, -1, *([1] * spatial))

        return out
