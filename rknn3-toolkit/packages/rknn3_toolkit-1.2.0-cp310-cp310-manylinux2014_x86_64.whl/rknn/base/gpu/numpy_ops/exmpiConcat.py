import numpy as np


class exmpiConcat_numpy:
    def __init__(self, axis, start=None, end=None, **kwargs):
        self.axis = int(axis)
        self.start = tuple(start) if start is not None else None
        self.end = tuple(end) if end is not None else None

    def forward(self, *inputs):
        inputs = [np.asarray(x) for x in inputs]
        if self.start is not None and self.end is not None:
            wanted = [e - s for s, e in zip(self.start, self.end)]
            got = [item.shape[self.axis] for item in inputs]
            if wanted != got:
                raise RuntimeError('exmpiConcat start/end mismatch: {} vs {}'.format(wanted, got))
        return np.concatenate(inputs, axis=self.axis)
