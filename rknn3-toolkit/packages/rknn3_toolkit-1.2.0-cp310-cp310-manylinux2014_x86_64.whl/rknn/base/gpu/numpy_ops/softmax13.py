import numpy as np


class exSoftmax13_numpy:
    def __init__(self, axis=-1, **kwargs):
        self.axis = int(axis)

    def forward(self, x):
        x = np.asarray(x)
        x_max = np.max(x, axis=self.axis, keepdims=True)
        e = np.exp(x - x_max)
        return e / np.sum(e, axis=self.axis, keepdims=True)


class exLogSoftmax13_numpy:
    def __init__(self, axis=-1, **kwargs):
        self.axis = int(axis)

    def forward(self, x):
        x = np.asarray(x)
        x_max = np.max(x, axis=self.axis, keepdims=True)
        shifted = x - x_max
        log_sum = np.log(np.sum(np.exp(shifted), axis=self.axis, keepdims=True))
        return shifted - log_sum
