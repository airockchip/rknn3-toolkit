import numpy as np


class exLogit_numpy:
    def __init__(self, eps=1e-6, **kwargs):
        self.eps = float(eps)

    def forward(self, x):
        x = np.asarray(x)
        x1 = np.clip(x, self.eps, None)
        x2 = np.clip(1.0 - x, self.eps, None)
        return np.log(x1 / x2)
