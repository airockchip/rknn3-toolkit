import numpy as np


class CustomCombinationOperator_numpy:
    def __init__(self, op_code=None, **kwargs):
        self.op_code = op_code

    def forward(self, *inputs):
        x = np.asarray(inputs[0])
        if self.op_code == 'floor':
            return np.floor(x)
        if self.op_code == 'ceil':
            return np.ceil(x)
        if self.op_code == 'reciprocal':
            return np.reciprocal(x)
        if self.op_code == 'where':
            return np.where(inputs[0].astype(bool), np.asarray(inputs[1]), np.asarray(inputs[2]))
        return x
