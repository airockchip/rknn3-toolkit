import numpy as np


class exLinearAttention_numpy:
    """NumPy implementation of the generated-model Gated DeltaNet operator."""

    def __init__(self, qk_norm=0, **kwargs):
        self.qk_norm = int(qk_norm)

    @staticmethod
    def _bfloat16_round(x):
        """Round float32 data to bfloat16 then expand it back to float32."""
        x = np.asarray(x, dtype=np.float32)
        bits = x.view(np.uint32)
        rounded = bits + np.uint32(0x7FFF) + ((bits >> 16) & np.uint32(1))
        return (rounded & np.uint32(0xFFFF0000)).view(np.float32)

    def forward(self, query, key, value, g, beta, tc):
        y, _ = self.forward_with_cache(query, key, value, g, beta, tc, node_cache={})
        return y

    def forward_with_cache(self, query, key, value, g, beta, tc, node_cache=None):
        original_dtype = np.asarray(query).dtype
        q = np.asarray(query, dtype=np.float32)
        k = np.asarray(key, dtype=np.float32)
        v = np.asarray(value, dtype=np.float32)
        g = np.asarray(g, dtype=np.float32)
        beta = np.asarray(beta, dtype=np.float32)
        node_cache = {} if node_cache is None else dict(node_cache)
        head_num, head_dim, _, seq_len = q.shape
        value_dim = v.shape[1]

        if self.qk_norm:
            q *= 1.0 / np.sqrt(np.sum(q * q, axis=1, keepdims=True) + 1e-6)
            k *= 1.0 / np.sqrt(np.sum(k * k, axis=1, keepdims=True) + 1e-6)
            q *= 1.0 / np.sqrt(head_dim)

        tc_value = int(np.asarray(tc).reshape(-1)[0])
        tc_mask = None
        if tc_value > 1:
            tc_mask = (np.arange(seq_len) < tc_value).astype(np.float32)
            mask = tc_mask.reshape(1, 1, 1, seq_len)
            q, k, v, g, beta = q * mask, k * mask, v * mask, g * mask, beta * mask

        state = node_cache.get("recurrent_state")
        if state is None:
            state = np.zeros((head_num, head_dim, 1, value_dim), dtype=np.float32)
        state = np.asarray(state, dtype=np.float32).squeeze(-2)
        output = np.zeros((head_num, value_dim, 1, seq_len), dtype=np.float32)
        for index in range(seq_len):
            q_t = q[:, :, 0, index]
            k_t = k[:, :, 0, index]
            v_t = v[:, :, 0, index]
            g_t = g[0, :, 0, index]
            beta_t = beta[0, :, 0, index]
            state *= np.exp(g_t)[:, None, None]
            kv_mem = np.sum(state * k_t[:, :, None], axis=1)
            delta = (v_t - kv_mem) * beta_t[:, None]
            state += k_t[:, :, None] * delta[:, None, :]
            output[:, :, 0, index] = np.sum(state * q_t[:, :, None], axis=1)

        node_cache["recurrent_state"] = self._bfloat16_round(state[:, :, None, :])
        if tc_mask is not None:
            output *= tc_mask.reshape(1, 1, 1, seq_len)
        return output.astype(original_dtype, copy=False), node_cache
