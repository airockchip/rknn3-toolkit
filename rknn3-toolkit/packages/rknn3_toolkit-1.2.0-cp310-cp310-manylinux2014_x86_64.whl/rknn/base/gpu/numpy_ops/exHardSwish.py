import numpy as np


class exHardSwish_numpy:
    def __init__(self, **kwargs):
        pass

    def forward(self, x):
        x = np.asarray(x)
        return x * np.clip(x / 6.0 + 0.5, 0.0, 1.0)
