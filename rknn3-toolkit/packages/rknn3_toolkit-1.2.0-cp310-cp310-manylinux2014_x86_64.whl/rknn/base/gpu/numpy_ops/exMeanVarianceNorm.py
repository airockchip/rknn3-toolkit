import numpy as np


class exMeanVarianceNormalization_numpy:
    def __init__(self, axes, eps=1e-5, elementwise_affine=False, **kwargs):
        self.axes = tuple(axes)
        self.eps = float(eps)
        self.elementwise_affine = bool(elementwise_affine)

    def forward(self, x, weight=None, bias=None):
        x = np.asarray(x)
        mean = np.mean(x, axis=self.axes, keepdims=True)
        squared_mean = np.mean(x * x, axis=self.axes, keepdims=True)
        std = np.sqrt(squared_mean - mean * mean + self.eps)
        y = (x - mean) / std
        if self.elementwise_affine and weight is not None and bias is not None:
            y = y * np.asarray(weight) + np.asarray(bias)
        return y
