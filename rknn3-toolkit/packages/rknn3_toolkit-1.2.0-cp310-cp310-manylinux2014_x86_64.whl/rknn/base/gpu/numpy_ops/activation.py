import numpy as np


class exActivation_numpy:
    def __init__(self, type=None, **kwargs):
        self.type = type

    def forward(self, x):
        x = np.asarray(x)
        if self.type == 'HardSwishHK':
            return x * np.clip(x + 3.0, 0.0, 6.0) * 0.16667
        return x
