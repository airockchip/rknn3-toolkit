import numpy as np


class exMoETopK_numpy:
    """NumPy implementation of Toolkit's routed-MoE TopK operator."""

    def __init__(
        self,
        n_experts_per_token,
        n_routed_experts=None,
        n_shared_experts=0,
        norm_before_select="NONE",
        norm_after_select="NONE",
        topk_method="greedy",
        n_group=1,
        topk_group=1,
        group_score_mode="max",
        routed_scaling_factor=1.0,
        selection_bias_input=0,
        has_tc=0,
        token_id_fix_experts=0,
        native_routing_output=0,
        expert_capacity=None,
        expert_policy=None,
        **kwargs,
    ):
        self.n_experts_per_token = int(n_experts_per_token)
        self.n_routed_experts = (
            None if n_routed_experts is None else int(n_routed_experts)
        )
        self.n_shared_experts = int(n_shared_experts or 0)
        self.norm_before_select = self._string_attr(
            norm_before_select, "NONE"
        )
        self.norm_after_select = self._string_attr(norm_after_select, "NONE")
        self.topk_method = self._string_attr(topk_method, "greedy")
        self.n_group = int(1 if n_group is None else n_group)
        self.topk_group = int(1 if topk_group is None else topk_group)
        self.group_score_mode = self._string_attr(group_score_mode, "max")
        self.routed_scaling_factor = float(
            1.0 if routed_scaling_factor is None else routed_scaling_factor
        )
        self.selection_bias_input = int(selection_bias_input or 0)
        self.has_tc = int(has_tc or 0)
        self.token_id_fix_experts = int(token_id_fix_experts or 0)
        self.native_routing_output = int(native_routing_output or 0)
        self.expert_capacity = expert_capacity
        self.expert_policy = expert_policy

    @staticmethod
    def _string_attr(value, default):
        if value is None:
            return default
        if isinstance(value, bytes):
            return value.decode("utf-8")
        return str(value)

    @staticmethod
    def _normalize(scores, mode):
        if mode in (None, "NONE", ""):
            return scores
        if mode == "softmax":
            shifted = scores - np.max(scores, axis=1, keepdims=True)
            exponent = np.exp(shifted)
            return exponent / np.sum(exponent, axis=1, keepdims=True)
        if mode == "sigmoid":
            return 1.0 / (1.0 + np.exp(-scores))
        raise ValueError(
            "Unsupported exMoETopK normalization: {}".format(mode)
        )

    @staticmethod
    def _topk(scores, count):
        """Use the same unordered top-k operation as the reference backend."""
        return np.argpartition(scores, -count, axis=1)[:, -count:]

    def _format_outputs(self, topk_ids, topk_prob, token_count):
        result = [
            topk_ids.astype(np.int32, copy=False),
            topk_prob,
        ]
        if self.native_routing_output:
            result[0] = result[0].T[None, :, None, :]
            result[1] = result[1].T[None, :, None, :]
        if self.n_shared_experts > 0:
            result.append(
                np.ones(
                    (token_count, self.n_shared_experts),
                    dtype=topk_prob.dtype,
                )
            )
        return tuple(result)

    def _pad_routes(
        self, topk_ids, topk_prob, token_count, valid_token_count
    ):
        if valid_token_count >= token_count:
            return topk_ids, topk_prob
        pad_count = token_count - valid_token_count
        return (
            np.concatenate(
                (
                    topk_ids,
                    np.full(
                        (pad_count, self.n_experts_per_token),
                        -1,
                        dtype=np.int32,
                    ),
                ),
                axis=0,
            ),
            np.concatenate(
                (
                    topk_prob,
                    np.zeros(
                        (pad_count, self.n_experts_per_token),
                        dtype=topk_prob.dtype,
                    ),
                ),
                axis=0,
            ),
        )

    def forward(self, weight_scores, selection_scores, *optional_inputs):
        if self.expert_capacity is not None or self.expert_policy is not None:
            raise NotImplementedError(
                "exMoETopK expert_capacity/expert_policy is not implemented"
            )
        weight_scores = np.asarray(weight_scores)
        selection_scores = np.asarray(selection_scores)
        if weight_scores.ndim != 4 or selection_scores.ndim != 4:
            raise ValueError(
                "exMoETopK score inputs must be four-dimensional"
            )
        if weight_scores.shape[0] != 1 or weight_scores.shape[2] != 1:
            raise ValueError(
                "exMoETopK score inputs must use [1, experts, 1, tokens] layout"
            )
        selection_shape_ok = selection_scores.shape == weight_scores.shape
        if self.selection_bias_input:
            selection_shape_ok = selection_shape_ok or (
                selection_scores.shape[:3] == weight_scores.shape[:3]
                and selection_scores.shape[3] == 1
            )
        if not selection_shape_ok:
            raise ValueError(
                "exMoETopK selection input must match scores, or use "
                "[1, experts, 1, 1] for a broadcast selection bias"
            )

        experts = weight_scores.shape[1]
        token_count = weight_scores.shape[3]
        if self.n_routed_experts is not None and self.n_routed_experts != experts:
            raise ValueError(
                "exMoETopK n_routed_experts does not match score shape"
            )
        if not 1 <= self.n_experts_per_token <= experts:
            raise ValueError("exMoETopK n_experts_per_token is invalid")

        cursor = 0
        valid_token_count = token_count
        if self.has_tc:
            if cursor >= len(optional_inputs):
                raise ValueError("exMoETopK has_tc=1 requires a Tc input")
            tc = np.asarray(optional_inputs[cursor]).reshape(-1)
            if tc.size != 1:
                raise ValueError(
                    "exMoETopK Tc input must be a single-element [1] int32 tensor"
                )
            if not np.issubdtype(tc.dtype, np.integer):
                raise ValueError("exMoETopK Tc input must be an integer tensor")
            valid_token_count = int(tc[0])
            if valid_token_count < 0 or valid_token_count > token_count:
                raise ValueError(
                    "exMoETopK Tc {} out of range (0, {})".format(
                        valid_token_count, token_count
                    )
                )
            cursor += 1

        token_id_table = None
        if self.token_id_fix_experts:
            if cursor >= len(optional_inputs):
                raise ValueError(
                    "exMoETopK token_id_fix_experts=1 requires a "
                    "token_id_fix_experts input"
                )
            token_id_table = np.asarray(optional_inputs[cursor])
            if not np.issubdtype(token_id_table.dtype, np.integer):
                raise ValueError(
                    "exMoETopK token_id_fix_experts must be an integer tensor"
                )
            expected_shape = (
                1,
                token_count,
                self.n_experts_per_token,
            )
            if token_id_table.shape != expected_shape:
                raise ValueError(
                    "exMoETopK token_id_fix_experts must be "
                    "[1, Tchunk, n_experts_per_token]"
                )
            valid_ids = token_id_table[0, :valid_token_count]
            if np.any(valid_ids < 0) or np.any(valid_ids >= experts):
                raise ValueError(
                    "exMoETopK token_id_fix_experts contains out-of-range "
                    "expert ids"
                )
            token_id_table = valid_ids.astype(np.int64, copy=False)
            cursor += 1

        if cursor != len(optional_inputs):
            raise ValueError(
                "Unexpected {} trailing exMoETopK inputs".format(
                    len(optional_inputs) - cursor
                )
            )

        weights = self._normalize(
            weight_scores[0, :, 0, :].T, self.norm_before_select
        )
        selection = selection_scores[0, :, 0, :].T
        if self.selection_bias_input:
            if selection.shape[0] == 1 and token_count != 1:
                selection = np.broadcast_to(selection, weights.shape)
            selection = weights.astype(np.float32) + selection.astype(np.float32)
        else:
            selection = self._normalize(selection, self.norm_before_select)

        if self.token_id_fix_experts:
            topk_ids = token_id_table[:valid_token_count]
            if np.any(topk_ids < 0) or np.any(topk_ids >= experts):
                raise ValueError(
                    "exMoETopK token_id_fix_experts contains out-of-range expert ids"
                )
            topk_prob = np.take_along_axis(
                weights[:valid_token_count], topk_ids, axis=1
            )
        elif valid_token_count == 0:
            topk_ids = np.empty(
                (0, self.n_experts_per_token), dtype=np.int64
            )
            topk_prob = np.empty(
                (0, self.n_experts_per_token), dtype=weight_scores.dtype
            )
        else:
            selection_valid = selection[:valid_token_count]
            weights_valid = weights[:valid_token_count]
            if self.topk_method in (
                "groupk",
                "group_limited_greedy",
                "noaux_tc",
            ) and self.n_group > 1:
                if (
                    self.topk_group <= 0
                    or self.topk_group > self.n_group
                    or experts % self.n_group != 0
                ):
                    raise ValueError(
                        "exMoETopK grouped routing attributes are invalid"
                    )
                experts_per_group = experts // self.n_group
                if self.n_experts_per_token > self.topk_group * experts_per_group:
                    raise ValueError(
                        "exMoETopK grouped routing cannot select {} experts "
                        "from {} selected groups".format(
                            self.n_experts_per_token,
                            self.topk_group * experts_per_group,
                        )
                    )
                grouped = selection_valid.reshape(
                    valid_token_count, self.n_group, experts_per_group
                )
                if self.topk_method == "noaux_tc" or self.group_score_mode == "top2sum":
                    if experts_per_group < 2:
                        raise ValueError(
                            "exMoETopK top2sum grouping needs two experts per group"
                        )
                    part = np.partition(grouped, -2, axis=2)
                    group_scores = part[..., -1] + part[..., -2]
                else:
                    group_scores = grouped.max(axis=-1)
                group_ids = self._topk(
                    group_scores, self.topk_group
                )
                group_mask = np.zeros(
                    (valid_token_count, self.n_group), dtype=bool
                )
                np.put_along_axis(group_mask, group_ids, True, axis=1)
                selection_valid = np.where(
                    np.repeat(group_mask, experts_per_group, axis=1),
                    selection_valid,
                    -np.inf,
                )
            elif self.topk_method not in ("greedy", ""):
                raise ValueError(
                    "Unsupported exMoETopK topk_method: {}".format(
                        self.topk_method
                    )
                )
            topk_ids = self._topk(
                selection_valid, self.n_experts_per_token
            )
            topk_prob = np.take_along_axis(weights_valid, topk_ids, axis=1)

        if self.norm_after_select == "softmax":
            topk_prob = self._normalize(topk_prob, "softmax")
        elif self.norm_after_select == "sum":
            topk_prob = topk_prob / (
                np.sum(topk_prob, axis=1, keepdims=True) + 1e-20
            )
        elif self.norm_after_select not in (None, "NONE", ""):
            raise ValueError(
                "Unsupported exMoETopK post-selection normalization: {}".format(
                    self.norm_after_select
                )
            )
        topk_prob = topk_prob * self.routed_scaling_factor
        topk_ids, topk_prob = self._pad_routes(
            topk_ids, topk_prob, token_count, valid_token_count
        )
        result = list(self._format_outputs(topk_ids, topk_prob, token_count))
        if self.n_shared_experts > 0 and valid_token_count < token_count:
            result[-1][valid_token_count:] = 0
        return tuple(result)
