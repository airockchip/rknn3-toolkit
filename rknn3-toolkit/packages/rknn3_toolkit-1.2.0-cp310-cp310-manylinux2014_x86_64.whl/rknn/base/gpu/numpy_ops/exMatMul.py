import numpy as np


class exMatMul_numpy:
    """numpy implementation matching exMatMul_torch.

    Layout: [ab, k, 1, n] @ [ab, k, 1, m] -> [ab, n, 1, m]
    """

    def __init__(self, c_type=None, **kwargs):
        self.c_type = c_type

    def forward(self, a, b, c=None):
        a = np.asarray(a)
        b = np.asarray(b)
        _, k, _, n = a.shape
        _, _, _, m = b.shape
        out = np.matmul(
            a.reshape(-1, k, n).transpose(0, 2, 1),
            b.reshape(-1, k, m),
        ).reshape(-1, n, 1, m)
        if c is not None:
            c = np.asarray(c)
            if self.c_type == 'add':
                out = out + c
            elif self.c_type == 'mul':
                out = out * c
        return out
