import numpy as np


class exRoPE_numpy:
    """NumPy implementation of the generated-model exRoPE semantics."""

    def __init__(self, **kwargs):
        pass

    @staticmethod
    def _apply_rope(x, cos, sin):
        half = x.shape[1] // 2
        rotated = np.concatenate((-x[:, half:, :, :], x[:, :half, :, :]), axis=1)
        return rotated * sin + x * cos

    def forward(self, x, cos, sin, th=None, tc=None, ts=None, tsr=None):
        y, _ = self.forward_with_cache(x, cos, sin, th, tc, ts, tsr, node_cache={})
        return y

    def forward_with_cache(self, x, cos, sin, th=None, tc=None, ts=None, tsr=None,
                           node_cache=None):
        x = np.asarray(x)
        cos = np.asarray(cos)
        sin = np.asarray(sin)
        node_cache = {} if node_cache is None else dict(node_cache)

        if th is None or tc is None or ts is None or tsr is None:
            node_cache["last_pos"] = None
            return self._apply_rope(x, cos, sin), node_cache

        # Generated torch models model the check6 validation path, where KV cache
        # is disabled and the whole current sequence is rotated from position zero.
        positions = np.arange(x.shape[-1], dtype=np.int64)
        positions = np.clip(positions, 0, cos.shape[-1] - 1)
        node_cache["last_pos"] = None
        return self._apply_rope(x, cos[..., positions], sin[..., positions]), node_cache
