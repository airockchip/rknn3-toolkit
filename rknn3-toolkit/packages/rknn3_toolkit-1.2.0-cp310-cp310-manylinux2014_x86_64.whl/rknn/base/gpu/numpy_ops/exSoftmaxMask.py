import numpy as np


class exSoftmaxMask_numpy:
    def __init__(self, mask_value, axis=-1, **kwargs):
        self.mask_value = float(mask_value)
        self.axis = int(axis)

    def forward(self, x, mask_tensor):
        x = np.asarray(x)
        mask_tensor = np.asarray(mask_tensor)
        neg = np.full_like(x, -65504.0)
        masked = np.where(mask_tensor == self.mask_value, neg, x)
        tmp = np.exp(masked - np.max(masked, axis=self.axis, keepdims=True))
        tmp = np.where(mask_tensor == self.mask_value, 0.0, tmp)
        denom = np.sum(tmp, axis=self.axis, keepdims=True)
        denom = np.where(np.isclose(denom, 0.0), denom + 1e-6, denom)
        return tmp / denom
