import numpy as np


class exFcclipNonzero_numpy:
    def __init__(self, repeat, **kwargs):
        self.repeat = int(repeat)

    def forward(self, x, threshold):
        x = np.asarray(x)
        threshold = np.asarray(threshold)
        expanded = np.repeat(x, self.repeat, axis=1)
        attn_mask = expanded.transpose(1, 2, 0, 3) < threshold
        sum_mask = attn_mask.sum(axis=-1)
        attn_mask[sum_mask == attn_mask.shape[-1]] = False
        return attn_mask
