import numpy as np


class exLayerNorm_numpy:
    def __init__(self, axis=-1, epsilon=1e-5, **kwargs):
        self.axis = int(axis)
        self.epsilon = float(epsilon)

    def forward(self, x, scale=None, bias=None):
        x = np.asarray(x)
        axis = self.axis if self.axis >= 0 else self.axis + x.ndim
        normalized_axes = tuple(range(axis, x.ndim))
        mean = np.mean(x, axis=normalized_axes, keepdims=True)
        var = np.mean((x - mean) ** 2, axis=normalized_axes, keepdims=True)
        y = (x - mean) / np.sqrt(var + self.epsilon)
        if scale is not None:
            y = y * np.asarray(scale)
        if bias is not None:
            y = y + np.asarray(bias)
        return y
