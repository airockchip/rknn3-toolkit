"""Pure-numpy operator implementations for per-node numpy backend.

Each class mirrors the signature of the corresponding torch_ops class
(constructor params = scalar attrs, forward params = tensor inputs),
but uses numpy for computation. This avoids loading IRGraph/Session
and eliminates the extra weight copies.
"""
