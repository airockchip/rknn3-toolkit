import numpy as np
from scipy.special import erf as _scipy_erf


class exGelu_numpy:
    """numpy implementation matching exGelu_torch (exact gelu, not tanh approx)."""

    def __init__(self, **kwargs):
        pass

    def forward(self, x):
        x = np.asarray(x)
        return 0.5 * x * (1.0 + _scipy_erf(x / 1.4142135381698608))
