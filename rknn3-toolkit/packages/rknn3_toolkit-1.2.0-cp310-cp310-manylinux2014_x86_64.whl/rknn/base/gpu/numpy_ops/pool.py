import numpy as np


class BatchNormalization_numpy:
    def __init__(self, epsilon=1e-5, momentum=0.9, **kwargs):
        self.epsilon = float(epsilon)
        self.momentum = float(momentum)

    def forward(self, x, scale, bias, mean, var):
        x = np.asarray(x)
        scale = np.asarray(scale)
        bias = np.asarray(bias)
        mean = np.asarray(mean)
        var = np.asarray(var)
        return (x - mean) / np.sqrt(var + self.epsilon) * scale + bias


class AveragePool_numpy:
    def __init__(self, kernel_shape, strides=None, pads=None, ceil_mode=0, count_include_pad=0, **kwargs):
        self.kernel_shape = tuple(kernel_shape)
        self.strides = tuple(strides or kernel_shape)
        self.pads = tuple(pads or [0] * (2 * len(self.kernel_shape)))
        self.ceil_mode = bool(ceil_mode)
        self.count_include_pad = bool(count_include_pad)

    def forward(self, x):
        x = np.asarray(x)
        spatial = len(self.kernel_shape)
        kh, kw = self.kernel_shape[:2] if spatial >= 2 else (self.kernel_shape[0], 1)
        sh, sw = self.strides[:2] if spatial >= 2 else (self.strides[0], 1)
        ph_begin = self.pads[:spatial] if len(self.pads) >= spatial else (0,) * spatial
        ph_end = self.pads[spatial:] if len(self.pads) >= spatial else (0,) * spatial
        if any(ph_begin) or any(ph_end):
            pad_width = [(0, 0), (0, 0)] + list(zip(ph_begin, ph_end))
            x = np.pad(x, pad_width, mode='constant')
        N, C = x.shape[0], x.shape[1]
        H, W = x.shape[2], x.shape[3] if spatial >= 2 else 1
        out_h = (H - kh) // sh + 1
        out_w = (W - kw) // sw + 1 if spatial >= 2 else 1
        out = np.zeros((N, C, out_h, out_w), dtype=x.dtype) if spatial >= 2 else np.zeros((N, C, out_h), dtype=x.dtype)
        for i in range(out_h):
            for j in range(out_w):
                region = x[:, :, i * sh:i * sh + kh, j * sw:j * sw + kw] if spatial >= 2 else x[:, :, i * sh:i * sh + kh]
                out[:, :, i, j] = region.mean(axis=(2, 3)) if spatial >= 2 else region.mean(axis=2)
        return out


class MaxPool_numpy:
    def __init__(self, kernel_shape, strides=None, pads=None, dilations=None, ceil_mode=0, **kwargs):
        self.kernel_shape = tuple(kernel_shape)
        self.strides = tuple(strides or kernel_shape)
        self.pads = tuple(pads or [0] * (2 * len(self.kernel_shape)))
        self.dilations = tuple(dilations or [1] * len(self.kernel_shape))
        self.ceil_mode = bool(ceil_mode)

    def forward(self, x):
        x = np.asarray(x)
        spatial = len(self.kernel_shape)
        kh, kw = self.kernel_shape[:2] if spatial >= 2 else (self.kernel_shape[0], 1)
        sh, sw = self.strides[:2] if spatial >= 2 else (self.strides[0], 1)
        ph_begin = self.pads[:spatial] if len(self.pads) >= spatial else (0,) * spatial
        ph_end = self.pads[spatial:] if len(self.pads) >= spatial else (0,) * spatial
        if any(ph_begin) or any(ph_end):
            pad_width = [(0, 0), (0, 0)] + list(zip(ph_begin, ph_end))
            x = np.pad(x, pad_width, mode='constant', constant_values=-np.inf)
        N, C = x.shape[0], x.shape[1]
        H, W = x.shape[2], x.shape[3] if spatial >= 2 else 1
        out_h = (H - kh) // sh + 1
        out_w = (W - kw) // sw + 1 if spatial >= 2 else 1
        out = np.zeros((N, C, out_h, out_w), dtype=x.dtype) if spatial >= 2 else np.zeros((N, C, out_h), dtype=x.dtype)
        for i in range(out_h):
            for j in range(out_w):
                region = x[:, :, i * sh:i * sh + kh, j * sw:j * sw + kw] if spatial >= 2 else x[:, :, i * sh:i * sh + kh]
                out[:, :, i, j] = region.max(axis=(2, 3)) if spatial >= 2 else region.max(axis=2)
        return out


class ConvTranspose_numpy:
    def __init__(self, in_channels, out_channels, stride=1, padding=0,
                 output_padding=0, dilation=1, groups=1, bias=True, **kwargs):
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.stride = stride
        self.padding = padding
        self.output_padding = output_padding
        self.dilation = dilation
        self.groups = int(groups)
        self.bias = bias

    def forward(self, x, weight, bias=None):
        x = np.asarray(x)
        weight = np.asarray(weight)
        spatial = weight.ndim - 2

        if isinstance(self.stride, int):
            stride = (self.stride,) * spatial
        elif len(self.stride) == spatial:
            stride = tuple(self.stride)
        else:
            stride = (self.stride[0],) * spatial

        if isinstance(self.dilation, int):
            dilation = (self.dilation,) * spatial
        elif len(self.dilation) == spatial:
            dilation = tuple(self.dilation)
        else:
            dilation = (self.dilation[0],) * spatial

        if isinstance(self.padding, int):
            padding = (self.padding,) * spatial
        elif len(self.padding) == spatial:
            padding = tuple(self.padding)
        else:
            padding = (self.padding[0],) * spatial

        from scipy.signal import correlate

        N, C_in = x.shape[0], x.shape[1]
        C_out = weight.shape[1] * self.groups  # weight: (C_in, C_out/groups, k...)
        in_per_group = C_in // self.groups
        out_per_group = C_out // self.groups

        # Step 1: Insert (stride-1) zeros between input elements along each spatial dim
        for s in range(spatial):
            if stride[s] > 1:
                new_shape = list(x.shape)
                new_shape[2 + s] = (x.shape[2 + s] - 1) * stride[s] + 1
                new_x = np.zeros(new_shape, dtype=x.dtype)
                slc = [slice(None)] * x.ndim
                slc[2 + s] = slice(None, None, stride[s])
                new_x[tuple(slc)] = x
                x = new_x

        # Step 2: Dilate kernel if needed
        w_dilated = weight
        if any(d > 1 for d in dilation):
            for s in range(spatial):
                if dilation[s] <= 1:
                    continue
                new_shape = list(w_dilated.shape)
                new_shape[2 + s] = (new_shape[2 + s] - 1) * dilation[s] + 1
                new_w = np.zeros(new_shape, dtype=w_dilated.dtype)
                slc = [slice(None)] * w_dilated.ndim
                slc[2 + s] = slice(None, None, dilation[s])
                new_w[tuple(slc)] = w_dilated
                w_dilated = new_w

        # Step 3: Pad input with (kernel_size - 1) zeros on each side per spatial dim
        for s in range(spatial):
            ks = w_dilated.shape[2 + s]
            pad_amt = ks - 1
            pad_width = [(0, 0), (0, 0)] + [(0, 0)] * spatial
            pad_width[2 + s] = (pad_amt, pad_amt)
            x = np.pad(x, pad_width)

        # Step 4: Flip kernel along spatial dims
        flip_axes = tuple(range(w_dilated.ndim - spatial, w_dilated.ndim))
        w_flipped = np.flip(w_dilated, axis=flip_axes)

        # Step 5: Compute output spatial dims (before cropping padding)
        out_spatial = []
        for s in range(spatial):
            ks = w_flipped.shape[2 + s]
            out_dim = x.shape[2 + s] - ks + 1
            out_spatial.append(out_dim)

        # Step 5: Correlate (valid mode), then crop padding, then add output_padding
        out = np.zeros((N, C_out) + tuple(out_spatial), dtype=x.dtype)

        for g in range(self.groups):
            x_g = x[:, g * in_per_group:(g + 1) * in_per_group]
            w_g = w_flipped[g * in_per_group:(g + 1) * in_per_group]
            for oc in range(out_per_group):
                for n in range(N):
                    result = None
                    for ic in range(in_per_group):
                        corr = correlate(x_g[n, ic], w_g[ic, oc], mode='valid')
                        if result is None:
                            result = corr
                        else:
                            result = result + corr
                    # Crop padding from start and end
                    for s in range(spatial):
                        if padding[s] > 0:
                            slc = [slice(None)] * result.ndim
                            slc[s] = slice(padding[s], result.shape[s] - padding[s])
                            result = result[tuple(slc)]
                    # Add output_padding at the end of each spatial dim
                    op = self.output_padding
                    if isinstance(op, int):
                        op = (op,) * spatial
                    elif len(op) < spatial:
                        op = (op[0],) * spatial
                    if any(p > 0 for p in op):
                        pad_width = [(0, 0)] * result.ndim
                        for s in range(spatial):
                            pad_width[s] = (0, op[s])
                        result = np.pad(result, pad_width)
                    out[n, g * out_per_group + oc] = result

        if bias is not None:
            bias = np.asarray(bias)
            out = out + bias.reshape(1, -1, *([1] * spatial))

        return out


class ReLU_numpy:
    def __init__(self, **kwargs):
        pass
    def forward(self, x):
        return np.maximum(np.asarray(x), 0)


class Sigmoid_numpy:
    def __init__(self, **kwargs):
        pass
    def forward(self, x):
        x = np.asarray(x)
        return 1.0 / (1.0 + np.exp(-x))
