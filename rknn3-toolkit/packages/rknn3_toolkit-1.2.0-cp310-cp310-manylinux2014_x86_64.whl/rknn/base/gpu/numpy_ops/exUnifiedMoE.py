import numpy as np


class _MoEFunctional_numpy:
    """Shared NumPy-only helpers for generated MoE operators."""

    @staticmethod
    def _topk(scores, count):
        """Use the same unordered top-k operation as the reference backend."""
        return np.argpartition(scores, -count, axis=1)[:, -count:]

    @staticmethod
    def _string_attr(value, default=None):
        if value is None:
            return default
        if isinstance(value, bytes):
            return value.decode("utf-8")
        return str(value)

    @staticmethod
    def _is_none_mode(value):
        return value is None or str(value).upper() in ("NONE", "")

    @staticmethod
    def _sigmoid(value):
        value = np.asarray(value)
        result = np.empty_like(
            value, dtype=np.result_type(value, np.float32)
        )
        positive = value >= 0
        result[positive] = 1.0 / (1.0 + np.exp(-value[positive]))
        negative_exp = np.exp(value[~positive])
        result[~positive] = negative_exp / (1.0 + negative_exp)
        return result

    @staticmethod
    def _softplus(value):
        value = np.asarray(value)
        return np.maximum(value, 0) + np.log1p(np.exp(-np.abs(value)))

    @staticmethod
    def _score_normalize(score, mode):
        if _MoEFunctional_numpy._is_none_mode(mode):
            return score
        mode = str(mode).lower()
        if mode == "softmax":
            shifted = score - np.max(score, axis=-1, keepdims=True)
            exponent = np.exp(shifted)
            return exponent / np.sum(exponent, axis=-1, keepdims=True)
        if mode == "sigmoid":
            return _MoEFunctional_numpy._sigmoid(score)
        if mode == "reducesum":
            return score / (np.sum(score, axis=-1, keepdims=True) + 1e-20)
        raise ValueError(
            "Unsupported MoE score normalization: {}".format(mode)
        )

    @staticmethod
    def _selected_normalize(score, mode):
        if _MoEFunctional_numpy._is_none_mode(mode):
            return score
        mode = str(mode).lower()
        if mode == "softmax":
            shifted = score - np.max(score, axis=-1, keepdims=True)
            exponent = np.exp(shifted)
            return exponent / np.sum(exponent, axis=-1, keepdims=True)
        if mode == "sigmoid":
            return _MoEFunctional_numpy._sigmoid(score)
        if mode == "reducesum":
            return score / (np.sum(score, axis=-1, keepdims=True) + 1e-20)
        if mode == "sigmoid_reducesum":
            score = _MoEFunctional_numpy._sigmoid(score)
            return score / (np.sum(score, axis=-1, keepdims=True) + 1e-20)
        if mode == "sqrtsoftplus":
            return np.sqrt(_MoEFunctional_numpy._softplus(score))
        raise ValueError(
            "Unsupported MoE selected-score normalization: {}".format(mode)
        )

    @staticmethod
    def _clip(value, mode, minimum, maximum):
        if mode == "NONE":
            return value
        if mode == "MAX":
            return np.minimum(value, maximum)
        if mode == "MIN_MAX":
            return np.clip(value, minimum, maximum)
        raise ValueError("Unsupported MoE clip mode: {}".format(mode))

    @staticmethod
    def _activate(value, activation, alpha=1.0):
        activation = str(activation).upper()
        if activation in ("SILU", "SWISH"):
            return value * _MoEFunctional_numpy._sigmoid(alpha * value)
        if activation == "GELU_TANH":
            return 0.5 * value * (
                1.0
                + np.tanh(
                    0.7978845608028654
                    * (value + 0.044715 * np.power(value, 3))
                )
            )
        if activation in ("GELU", "GELU_ERF"):
            from scipy.special import erf as scipy_erf

            return 0.5 * value * (
                1.0 + scipy_erf(value / 1.4142135623730951)
            )
        raise ValueError(
            "Unsupported MoE activation: {}".format(activation)
        )

    @staticmethod
    def _select_topk(selection_scores, expert_count, top_k, method, n_group, topk_group):
        if method in (None, "greedy", ""):
            return _MoEFunctional_numpy._topk(
                selection_scores, top_k
            )
        if method != "group_limited_greedy":
            raise ValueError("Unsupported MoE topk_method: {}".format(method))
        if (
            n_group <= 0
            or topk_group <= 0
            or topk_group > n_group
            or expert_count % n_group != 0
        ):
            raise ValueError(
                "Invalid MoE n_group/topk_group: {} {}".format(
                    n_group, topk_group
                )
            )
        experts_per_group = expert_count // n_group
        if top_k > topk_group * experts_per_group:
            raise ValueError(
                "Grouped MoE routing cannot select {} experts from {} "
                "selected groups".format(
                    top_k, topk_group * experts_per_group
                )
            )
        grouped = selection_scores.reshape(
            selection_scores.shape[0], n_group, experts_per_group
        )
        group_scores = grouped.max(axis=2)
        group_ids = _MoEFunctional_numpy._topk(
            group_scores, topk_group
        )
        group_mask = np.zeros_like(group_scores, dtype=bool)
        np.put_along_axis(group_mask, group_ids, True, axis=1)
        choice = np.where(
            np.repeat(group_mask, experts_per_group, axis=1),
            selection_scores,
            -np.inf,
        )
        return _MoEFunctional_numpy._topk(choice, top_k)

    @staticmethod
    def _rms_norm(value, scales=None):
        normalized = value / np.sqrt(
            np.mean(value.astype(np.float32) ** 2, axis=-1, keepdims=True)
            + 1e-6
        )
        if scales is not None:
            normalized = normalized * scales
        return normalized

    @staticmethod
    def _legacy_silu_ffn(hidden, gate_weight, up_weight, down_weight):
        gate = np.matmul(hidden, gate_weight.T)
        up = np.matmul(hidden, up_weight.T)
        return np.matmul(
            gate * _MoEFunctional_numpy._sigmoid(gate) * up,
            down_weight.T,
        )


class exUnifiedMoE_numpy(_MoEFunctional_numpy):
    """Direct NumPy implementation of the unified routed-MoE operator."""

    def __init__(
        self,
        n_routed_experts,
        num_experts_per_token,
        layer_id=0,
        n_group=0,
        topk_group=0,
        topk_method="greedy",
        expert_capacity=None,
        expert_policy=None,
        token_id_fix_experts=0,
        norm_before_router=None,
        norm_before_router_with_scales=0,
        router_bias=0,
        norm_before_ffn=None,
        norm_before_ffn_with_scales=0,
        scoring_func=None,
        score_select_bias=0,
        norm_selected_score=None,
        per_expert_scale=0,
        routed_scaling_factor=1.0,
        routed_scores_before_ffn=0,
        expert_weight_packed=None,
        gate_up_packed=0,
        gate_up_cross_packed=0,
        gate_bias=0,
        up_bias=0,
        down_bias=0,
        activation="silu",
        activation_alpha=1.0,
        gate_clip_mode="NONE",
        gate_clip_min=0.0,
        gate_clip_max=0.0,
        up_clip_mode="NONE",
        up_clip_min=0.0,
        up_clip_max=0.0,
        up_offset=0.0,
        **kwargs,
    ):
        self.n_routed_experts = int(n_routed_experts)
        self.num_experts_per_token = int(num_experts_per_token)
        self.layer_id = int(layer_id or 0)
        self.n_group = int(n_group or 0)
        self.topk_group = int(topk_group or 0)
        self.topk_method = self._string_attr(topk_method, "greedy")
        self.expert_capacity = expert_capacity
        self.expert_policy = expert_policy
        self.token_id_fix_experts = bool(token_id_fix_experts)
        self.norm_before_router = self._string_attr(norm_before_router)
        self.norm_before_router_with_scales = bool(
            norm_before_router_with_scales
        )
        self.router_bias = bool(router_bias)
        self.norm_before_ffn = self._string_attr(norm_before_ffn)
        self.norm_before_ffn_with_scales = bool(
            norm_before_ffn_with_scales
        )
        self.scoring_func = self._string_attr(scoring_func)
        self.score_select_bias = bool(score_select_bias)
        self.norm_selected_score = self._string_attr(norm_selected_score)
        self.per_expert_scale = bool(per_expert_scale)
        self.routed_scaling_factor = float(
            1.0 if routed_scaling_factor is None else routed_scaling_factor
        )
        self.routed_scores_before_ffn = bool(routed_scores_before_ffn)
        self.expert_weight_packed = self._string_attr(expert_weight_packed)
        self.gate_up_packed = bool(gate_up_packed)
        self.gate_up_cross_packed = bool(gate_up_cross_packed)
        self.gate_bias = bool(gate_bias)
        self.up_bias = bool(up_bias)
        self.down_bias = bool(down_bias)
        self.activation = self._string_attr(activation, "silu")
        self.activation_alpha = float(activation_alpha)
        self.gate_clip_mode = self._string_attr(gate_clip_mode, "NONE")
        self.gate_clip_min = float(gate_clip_min)
        self.gate_clip_max = float(gate_clip_max)
        self.up_clip_mode = self._string_attr(up_clip_mode, "NONE")
        self.up_clip_min = float(up_clip_min)
        self.up_clip_max = float(up_clip_max)
        self.up_offset = float(up_offset)

    def _validate_attributes(self):
        if not 1 <= self.num_experts_per_token <= self.n_routed_experts:
            raise ValueError(
                "exUnifiedMoE num_experts_per_token is out of range"
            )
        if self.expert_capacity is not None or self.expert_policy is not None:
            raise NotImplementedError(
                "exUnifiedMoE expert_capacity/expert_policy is not implemented"
            )
        if (
            self.norm_before_router_with_scales
            and self.norm_before_router != "rms"
        ):
            raise ValueError(
                "norm_before_router_with_scales requires rms normalization"
            )
        if (
            self.norm_before_ffn_with_scales
            and self.norm_before_ffn != "rms"
        ):
            raise ValueError(
                "norm_before_ffn_with_scales requires rms normalization"
            )
        if self.gate_clip_mode not in ("NONE", "MAX", "MIN_MAX"):
            raise ValueError("Unsupported exUnifiedMoE gate clip mode")
        if self.up_clip_mode not in ("NONE", "MAX", "MIN_MAX"):
            raise ValueError("Unsupported exUnifiedMoE up clip mode")
        if self.gate_up_cross_packed and not self.gate_up_packed:
            raise ValueError(
                "gate_up_cross_packed requires gate_up_packed"
            )
        if self.gate_up_cross_packed and self.gate_bias != self.up_bias:
            raise ValueError(
                "cross-packed gate/up weights require matching bias flags"
            )

    def _compute_expert(
        self,
        output,
        expert_hidden,
        topk_ids,
        topk_prob,
        expert_id,
        gate_weight,
        up_weight,
        gate_bias,
        up_bias,
        down_weight,
        down_bias,
        expert_scale,
    ):
        hidden_size = expert_hidden.shape[1]
        if gate_weight.ndim != 2 or gate_weight.shape[0] != hidden_size:
            raise ValueError("exUnifiedMoE gate weight shape is invalid")
        intermediate_size = gate_weight.shape[1]
        if up_weight.shape != (hidden_size, intermediate_size):
            raise ValueError("exUnifiedMoE up weight shape is invalid")
        if down_weight.shape != (intermediate_size, hidden_size):
            raise ValueError("exUnifiedMoE down weight shape is invalid")
        if gate_bias is not None and gate_bias.size != intermediate_size:
            raise ValueError("exUnifiedMoE gate bias shape is invalid")
        if up_bias is not None and up_bias.size != intermediate_size:
            raise ValueError("exUnifiedMoE up bias shape is invalid")
        if down_bias is not None and down_bias.size != hidden_size:
            raise ValueError("exUnifiedMoE down bias shape is invalid")
        token_weight = np.sum(
            topk_prob * (topk_ids == expert_id), axis=1
        )
        token_indices = np.flatnonzero(token_weight)
        if not token_indices.size:
            return
        expert_input = expert_hidden[token_indices]
        if self.routed_scores_before_ffn:
            expert_input = expert_input * token_weight[token_indices, None]
        gate = np.matmul(expert_input, gate_weight)
        up = np.matmul(expert_input, up_weight)
        if gate_bias is not None:
            gate = gate + gate_bias
        if up_bias is not None:
            up = up + up_bias
        gate = self._clip(
            gate,
            self.gate_clip_mode,
            self.gate_clip_min,
            self.gate_clip_max,
        )
        up = self._clip(
            up,
            self.up_clip_mode,
            self.up_clip_min,
            self.up_clip_max,
        )
        expert_output = np.matmul(
            self._activate(gate, self.activation, self.activation_alpha)
            * (up + self.up_offset),
            down_weight,
        )
        if down_bias is not None:
            expert_output = expert_output + down_bias
        if expert_scale is not None:
            expert_output = expert_output * expert_scale
        if not self.routed_scores_before_ffn:
            expert_output = expert_output * token_weight[token_indices, None]
        output[token_indices] += expert_output

    def forward(self, *inputs):
        self._validate_attributes()
        if not inputs:
            raise ValueError("exUnifiedMoE requires inputs")
        hidden_states = np.asarray(inputs[0])
        if hidden_states.ndim != 3:
            raise ValueError(
                "exUnifiedMoE hidden_states must be [B, N, hidden_size]"
            )
        original_dtype = hidden_states.dtype
        hidden_size = hidden_states.shape[-1]
        flat = hidden_states.reshape(-1, hidden_size).astype(np.float32)
        cursor = 1

        fixed_expert_ids = None
        if self.token_id_fix_experts:
            fixed_expert_ids = np.asarray(inputs[cursor])
            cursor += 1
            if (
                fixed_expert_ids.ndim != 2
                or fixed_expert_ids.shape[0] != flat.shape[0]
                or fixed_expert_ids.shape[1] != self.num_experts_per_token
            ):
                raise ValueError(
                    "token_id_fix_experts must be "
                    "[B*N, num_experts_per_token]"
                )
            if not np.issubdtype(fixed_expert_ids.dtype, np.integer):
                raise ValueError(
                    "token_id_fix_experts must contain integer expert ids"
                )
            if np.any(fixed_expert_ids < 0) or np.any(
                fixed_expert_ids >= self.n_routed_experts
            ):
                raise ValueError(
                    "token_id_fix_experts contains out-of-range expert ids"
                )
            fixed_expert_ids = fixed_expert_ids.astype(np.int64, copy=False)

        norm_before_scales = None
        if self.norm_before_router_with_scales:
            norm_before_scales = np.asarray(
                inputs[cursor], dtype=np.float32
            ).reshape(1, -1)
            cursor += 1
            if norm_before_scales.shape[1] != hidden_size:
                raise ValueError("norm_before_router scale shape is invalid")

        router_weights = np.asarray(inputs[cursor], dtype=np.float32)
        cursor += 1
        if router_weights.shape != (
            hidden_size,
            self.n_routed_experts,
        ):
            raise ValueError("exUnifiedMoE router weight shape is invalid")

        router_bias_value = None
        if self.router_bias:
            router_bias_value = np.asarray(
                inputs[cursor], dtype=np.float32
            ).reshape(-1)
            cursor += 1
            if router_bias_value.size != self.n_routed_experts:
                raise ValueError("exUnifiedMoE router bias shape is invalid")

        norm_before_ffn_scales = None
        if self.norm_before_ffn_with_scales:
            norm_before_ffn_scales = np.asarray(
                inputs[cursor], dtype=np.float32
            ).reshape(1, -1)
            cursor += 1
            if norm_before_ffn_scales.shape[1] != hidden_size:
                raise ValueError("norm_before_ffn scale shape is invalid")

        select_bias = None
        if self.score_select_bias:
            select_bias = np.asarray(
                inputs[cursor], dtype=np.float32
            ).reshape(-1)
            cursor += 1
            if select_bias.size != self.n_routed_experts:
                raise ValueError("score_select_bias shape is invalid")

        expert_scales = None
        if self.per_expert_scale:
            expert_scales = np.asarray(
                inputs[cursor], dtype=np.float32
            ).reshape(-1)
            cursor += 1
            if expert_scales.size != self.n_routed_experts:
                raise ValueError("per_expert_scale shape is invalid")

        if self.norm_before_router == "rms":
            routing_hidden = self._rms_norm(flat, norm_before_scales)
        elif self._is_none_mode(self.norm_before_router):
            routing_hidden = flat
        else:
            raise ValueError("Unsupported norm_before_router")
        logits = np.matmul(routing_hidden, router_weights)
        if router_bias_value is not None:
            logits = logits + router_bias_value
        scores = self._score_normalize(logits, self.scoring_func)

        if self.norm_before_ffn == "rms":
            expert_hidden = self._rms_norm(flat, norm_before_ffn_scales)
        elif self._is_none_mode(self.norm_before_ffn):
            expert_hidden = flat
        else:
            raise ValueError("Unsupported norm_before_ffn")

        token_count = flat.shape[0]
        if self.token_id_fix_experts:
            topk_ids = fixed_expert_ids
        else:
            selection_scores = scores
            if select_bias is not None:
                selection_scores = selection_scores + select_bias
            topk_ids = self._select_topk(
                selection_scores,
                self.n_routed_experts,
                self.num_experts_per_token,
                self.topk_method,
                self.n_group,
                self.topk_group,
            )
        topk_prob = np.take_along_axis(scores, topk_ids, axis=1)
        topk_prob = self._selected_normalize(
            topk_prob, self.norm_selected_score
        )
        topk_prob = topk_prob * self.routed_scaling_factor

        output = np.zeros_like(flat, dtype=np.float32)

        def split_gate_up(weight, bias):
            intermediate_size = weight.shape[-1] // 2
            if weight.shape[-1] != 2 * intermediate_size:
                raise ValueError("gate_up weight shape is invalid")
            if self.gate_up_cross_packed:
                gate_weight = weight[..., 0::2]
                up_weight = weight[..., 1::2]
            else:
                gate_weight = weight[..., :intermediate_size]
                up_weight = weight[..., intermediate_size:]
            gate_bias = up_bias = None
            if bias is not None:
                if self.gate_bias and self.up_bias:
                    if self.gate_up_cross_packed:
                        gate_bias = bias[..., 0::2]
                        up_bias = bias[..., 1::2]
                    else:
                        gate_bias = bias[..., :intermediate_size]
                        up_bias = bias[..., intermediate_size:]
                elif self.gate_bias:
                    gate_bias = bias
                else:
                    up_bias = bias
            return gate_weight, up_weight, gate_bias, up_bias

        def read_weight_group(group_cursor):
            if self.gate_up_packed:
                gate_up = np.asarray(inputs[group_cursor], dtype=np.float32)
                group_cursor += 1
                gate_up_bias = None
                if self.gate_bias or self.up_bias:
                    gate_up_bias = np.asarray(
                        inputs[group_cursor], dtype=np.float32
                    )
                    group_cursor += 1
                down_weight = np.asarray(
                    inputs[group_cursor], dtype=np.float32
                )
                group_cursor += 1
                down_bias = None
                if self.down_bias:
                    down_bias = np.asarray(
                        inputs[group_cursor], dtype=np.float32
                    )
                    group_cursor += 1
                return (
                    gate_up,
                    gate_up_bias,
                    down_weight,
                    down_bias,
                    group_cursor,
                )
            gate_weight = np.asarray(inputs[group_cursor], dtype=np.float32)
            group_cursor += 1
            gate_bias = None
            if self.gate_bias:
                gate_bias = np.asarray(
                    inputs[group_cursor], dtype=np.float32
                )
                group_cursor += 1
            up_weight = np.asarray(inputs[group_cursor], dtype=np.float32)
            group_cursor += 1
            up_bias = None
            if self.up_bias:
                up_bias = np.asarray(
                    inputs[group_cursor], dtype=np.float32
                )
                group_cursor += 1
            down_weight = np.asarray(inputs[group_cursor], dtype=np.float32)
            group_cursor += 1
            down_bias = None
            if self.down_bias:
                down_bias = np.asarray(
                    inputs[group_cursor], dtype=np.float32
                )
                group_cursor += 1
            return (
                gate_weight,
                gate_bias,
                up_weight,
                up_bias,
                down_weight,
                down_bias,
                group_cursor,
            )

        if self.expert_weight_packed == "batch":
            group = read_weight_group(cursor)
            cursor = group[-1]
            for value in group[:-1]:
                if value is not None and (
                    value.ndim < 1
                    or value.shape[0] != self.n_routed_experts
                ):
                    raise ValueError(
                        "exUnifiedMoE batch weight expert count is invalid"
                    )
            for expert_id in range(self.n_routed_experts):
                if self.gate_up_packed:
                    gate_weight, up_weight, gate_bias, up_bias = split_gate_up(
                        group[0][expert_id],
                        None if group[1] is None else group[1][expert_id],
                    )
                    down_weight = group[2][expert_id]
                    down_bias = (
                        None if group[3] is None else group[3][expert_id]
                    )
                else:
                    gate_weight = group[0][expert_id]
                    gate_bias = (
                        None if group[1] is None else group[1][expert_id]
                    )
                    up_weight = group[2][expert_id]
                    up_bias = (
                        None if group[3] is None else group[3][expert_id]
                    )
                    down_weight = group[4][expert_id]
                    down_bias = (
                        None if group[5] is None else group[5][expert_id]
                    )
                self._compute_expert(
                    output,
                    expert_hidden,
                    topk_ids,
                    topk_prob,
                    expert_id,
                    gate_weight,
                    up_weight,
                    gate_bias,
                    up_bias,
                    down_weight,
                    down_bias,
                    None if expert_scales is None else expert_scales[expert_id],
                )
        else:
            for expert_id in range(self.n_routed_experts):
                group = read_weight_group(cursor)
                cursor = group[-1]
                if self.gate_up_packed:
                    gate_weight, up_weight, gate_bias, up_bias = split_gate_up(
                        group[0], group[1]
                    )
                    down_weight, down_bias = group[2:4]
                else:
                    (
                        gate_weight,
                        gate_bias,
                        up_weight,
                        up_bias,
                        down_weight,
                        down_bias,
                    ) = group[:6]
                self._compute_expert(
                    output,
                    expert_hidden,
                    topk_ids,
                    topk_prob,
                    expert_id,
                    gate_weight,
                    up_weight,
                    gate_bias,
                    up_bias,
                    down_weight,
                    down_bias,
                    None if expert_scales is None else expert_scales[expert_id],
                )

        if cursor != len(inputs):
            raise ValueError(
                "Unexpected {} trailing exUnifiedMoE inputs".format(
                    len(inputs) - cursor
                )
            )
        return output.astype(original_dtype, copy=False).reshape(
            hidden_states.shape
        )
