import numpy as np


class exmpiMoESegmentedAllGather_numpy:
    """NumPy reference implementation of the segmented MoE all-gather."""

    def __init__(self, core_num, **kwargs):
        self.core_num = int(core_num)

    def forward(self, *inputs):
        if self.core_num <= 0 or len(inputs) != 2 * self.core_num:
            raise ValueError(
                "exmpiMoESegmentedAllGather expects 2*core_num inputs"
            )
        payloads = [np.asarray(value) for value in inputs[:self.core_num]]
        first = payloads[0]
        for payload in payloads[1:]:
            if payload.shape != first.shape or payload.dtype != first.dtype:
                raise ValueError(
                    "exmpiMoESegmentedAllGather payloads must have matching "
                    "shape and dtype"
                )
        full = np.array(first, copy=True)
        for payload in payloads[1:]:
            full = np.add(full, payload, dtype=full.dtype)
        return tuple(full.copy() for _ in range(self.core_num))
