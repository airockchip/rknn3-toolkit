import numpy as np


class exmpiSum_numpy:
    def __init__(self, **kwargs):
        pass

    def forward(self, *inputs):
        out = np.asarray(inputs[0])
        for item in inputs[1:]:
            out = out + np.asarray(item)
        return out
