import numpy as np


class exRMSNorm_numpy:
    def __init__(self, eps=1e-5, **kwargs):
        self.eps = float(eps)

    def forward(self, x, weight):
        x = np.asarray(x)
        weight = np.asarray(weight)
        return x * np.reciprocal(np.sqrt(np.mean(np.square(x), axis=-1, keepdims=True) + self.eps)) * weight
