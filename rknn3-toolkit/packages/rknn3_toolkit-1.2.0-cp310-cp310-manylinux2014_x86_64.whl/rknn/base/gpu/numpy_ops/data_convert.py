import numpy as np


class exDataConvert_numpy:
    def __init__(self, **kwargs):
        pass

    def forward(self, x):
        return np.asarray(x)
