import numpy as np


class exYoloPostProcess_numpy:
    def __init__(self, K, iou_type='iou', conf_threshold=0.25, iou_threshold=0.45, **kwargs):
        self.K = int(K)
        self.iou_type = iou_type
        self.conf_threshold = float(conf_threshold)
        self.iou_threshold = float(iou_threshold)

    def _iou(self, box1, box2):
        x1 = max(box1[0], box2[0])
        y1 = max(box1[1], box2[1])
        x2 = min(box1[2], box2[2])
        y2 = min(box1[3], box2[3])
        inter = max(0, x2 - x1) * max(0, y2 - y1)
        area1 = (box1[2] - box1[0]) * (box1[3] - box1[1])
        area2 = (box2[2] - box2[0]) * (box2[3] - box2[1])
        denom = area1 + area2 - inter
        if denom <= 0:
            return 0.0
        return float(inter / denom)

    def forward(self, sum_score, class_score, position, conf_threshold=None, iou_threshold=None):
        sum_score = np.asarray(sum_score).squeeze()
        class_score = np.asarray(class_score).squeeze()
        position = np.asarray(position).squeeze()
        if class_score.ndim == 2:
            class_score = class_score.squeeze(0) if class_score.shape[0] == 1 else class_score
        if position.ndim == 3:
            position = position.squeeze(0)
            if position.ndim == 2 and position.shape[0] == 1:
                position = position.squeeze(0)

        conf = self.conf_threshold if conf_threshold is None else float(conf_threshold)
        iou_t = self.iou_threshold if iou_threshold is None else float(iou_threshold)

        max_scores = np.max(class_score, axis=0)
        class_indices = np.argmax(class_score, axis=0)

        candidates = []
        for idx in range(sum_score.shape[0]):
            if float(sum_score[idx]) > conf and float(max_scores[idx]) >= conf:
                candidates.append((float(max_scores[idx]), int(class_indices[idx]), position[:, idx]))

        candidates.sort(key=lambda item: item[0], reverse=True)
        selected = []
        while candidates and len(selected) < self.K:
            picked = candidates.pop(0)
            selected.append(picked)
            remain = []
            for cand in candidates:
                if cand[1] != picked[1] or self._iou(picked[2], cand[2]) <= iou_t:
                    remain.append(cand)
            candidates = remain

        output = np.zeros((1, self.K, 6), dtype=sum_score.dtype)
        for idx, (score, cls, box) in enumerate(selected):
            output[0, idx, 0] = score
            output[0, idx, 1] = cls
            output[0, idx, 2:] = box
        return output
