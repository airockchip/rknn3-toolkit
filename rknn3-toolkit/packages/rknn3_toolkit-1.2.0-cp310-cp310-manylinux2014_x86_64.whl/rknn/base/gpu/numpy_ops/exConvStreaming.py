import numpy as np


class exConvStreaming_numpy:
    """NumPy implementation of streaming Conv2D with a per-node tail cache."""

    def __init__(self, pads=None, strides=None, dilations=None, group=1, **kwargs):
        self.pads = tuple(pads) if pads is not None else (0, 0, 0, 0)
        self.strides = tuple(strides) if strides is not None else (1, 1)
        self.dilations = tuple(dilations) if dilations is not None else (1, 1)
        self.group = int(group)
        self.kernel_shape = tuple(kwargs["kernel_shape"]) if "kernel_shape" in kwargs else None

    def forward(self, x, weight, bias=None, tc=None):
        y, _ = self.forward_with_cache(x, weight, bias, tc, node_cache={})
        return y

    @staticmethod
    def _conv2d(x, weight, bias, strides, dilations, group):
        n, channels, height, width = x.shape
        out_channels, channels_per_group, kernel_h, kernel_w = weight.shape
        stride_h, stride_w = strides
        dilation_h, dilation_w = dilations
        out_h = (height - dilation_h * (kernel_h - 1) - 1) // stride_h + 1
        out_w = (width - dilation_w * (kernel_w - 1) - 1) // stride_w + 1
        output = np.empty((n, out_channels, out_h, out_w), dtype=x.dtype)
        out_per_group = out_channels // group
        for batch in range(n):
            for group_index in range(group):
                c0 = group_index * channels_per_group
                c1 = c0 + channels_per_group
                o0 = group_index * out_per_group
                o1 = o0 + out_per_group
                for oy in range(out_h):
                    y0 = oy * stride_h
                    ys = slice(y0, y0 + dilation_h * kernel_h, dilation_h)
                    for ox in range(out_w):
                        x0 = ox * stride_w
                        xs = slice(x0, x0 + dilation_w * kernel_w, dilation_w)
                        patch = x[batch, c0:c1, ys, xs]
                        output[batch, o0:o1, oy, ox] = np.tensordot(
                            weight[o0:o1], patch, axes=((1, 2, 3), (0, 1, 2)))
        if bias is not None:
            output += np.asarray(bias).reshape(1, -1, 1, 1)
        return output

    def forward_with_cache(self, x, weight, bias=None, tc=None, node_cache=None):
        x = np.asarray(x)
        weight = np.asarray(weight)
        node_cache = {} if node_cache is None else dict(node_cache)
        cache_w = int(self.pads[1])
        if cache_w > 0:
            expected_shape = x.shape[:-1] + (cache_w,)
            cache_x = node_cache.get("tail")
            if cache_x is None or cache_x.shape != expected_shape:
                cache_x = np.zeros(expected_shape, dtype=x.dtype)
            conv_input = np.concatenate((cache_x, x), axis=-1)
            valid_w = x.shape[-1]
            if tc is not None and np.asarray(tc).size > 0:
                valid_w = int(np.asarray(tc).reshape(-1)[0])
                valid_w = max(0, min(valid_w, x.shape[-1]))
            node_cache["tail"] = np.concatenate((cache_x, x[..., :valid_w]), axis=-1)[..., -cache_w:].copy()
        else:
            conv_input = x
            node_cache["tail"] = x[..., :0].copy()
        conv_input = np.pad(
            conv_input,
            ((0, 0), (0, 0), (self.pads[0], self.pads[2]), (0, self.pads[3])),
        )
        return self._conv2d(
            conv_input, weight, bias, self.strides, self.dilations, self.group,
        ), node_cache
