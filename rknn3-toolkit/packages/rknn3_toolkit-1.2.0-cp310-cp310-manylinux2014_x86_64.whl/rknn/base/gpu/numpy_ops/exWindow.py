import numpy as np


class exWindow_numpy:
    def __init__(self, mode, window_sizes, num_windows, **kwargs):
        self.mode = mode
        self.window_sizes = tuple(window_sizes)
        self.num_windows = tuple(num_windows)

    def forward(self, x):
        x = np.asarray(x)
        b, c, _, _ = x.shape
        wh, ww = self.window_sizes
        nh, nw = self.num_windows
        if self.mode == 'partition':
            return x.reshape(b, c, nh, wh, nw, ww).transpose(0, 1, 2, 4, 3, 5).reshape(b, c, nh * nw, wh * ww)
        if self.mode == 'reverse':
            return x.reshape(b, c, nh, nw, wh, ww).transpose(0, 1, 2, 4, 3, 5).reshape(b, c, nh * wh, nw * ww)
        if self.mode == 'partition_num_first':
            return x.reshape(b, c, wh, nh, ww, nw).transpose(0, 1, 3, 5, 2, 4).reshape(b, c, nh * nw, wh * ww)
        raise NotImplementedError('Unsupported exWindow mode: {}'.format(self.mode))
