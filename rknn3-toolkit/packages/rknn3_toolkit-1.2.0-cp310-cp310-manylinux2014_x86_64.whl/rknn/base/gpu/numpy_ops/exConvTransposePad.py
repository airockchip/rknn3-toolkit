import numpy as np


class exConvTransposePad_numpy:
    def __init__(self, kernel_shape, strides, pads, **kwargs):
        self.kernel_shape = tuple(kernel_shape)
        self.strides = tuple(strides)
        self.pads = tuple(pads)

    def forward(self, x):
        x = np.asarray(x)
        n, c, h, w = x.shape
        new_w = (w - 1) * self.strides[1] + 1 + (self.kernel_shape[1] - self.pads[1] - 1) + (self.kernel_shape[1] - self.pads[3] - 1)
        new_h = (h - 1) * self.strides[0] + 1 + (self.kernel_shape[0] - self.pads[0] - 1) + (self.kernel_shape[0] - self.pads[2] - 1)
        out = np.zeros((n, c, new_h, new_w), dtype=x.dtype)
        out[:, :, self.kernel_shape[0] - self.pads[0] - 1 :: self.strides[0], self.kernel_shape[1] - self.pads[1] - 1 :: self.strides[1]] = x
        return out
