import numpy as np


class exGlu_numpy:
    def __init__(self, axis=-1, **kwargs):
        self.axis = int(axis)

    def forward(self, x):
        x = np.asarray(x)
        a, b = np.split(x, 2, axis=self.axis)
        return a * (1.0 / (1.0 + np.exp(-b)))
