import numpy as np


class exRoiAlign_numpy:
    """numpy RoIAlign via bilinear interpolation (no torchvision dependency)."""

    def __init__(self, output_height, output_width, spatial_scale=1.0, sampling_ratio=0, aligned=0, **kwargs):
        self.output_height = int(output_height)
        self.output_width = int(output_width)
        self.spatial_scale = float(spatial_scale)
        self.sampling_ratio = int(sampling_ratio)
        self.aligned = bool(aligned)

    def forward(self, x, rois):
        x = np.asarray(x)
        rois = np.asarray(rois)
        # rois: [N, 5] (batch_idx, x1, y1, x2, y2)
        N = rois.shape[0]
        C = x.shape[1]
        out = np.zeros((N, C, self.output_height, self.output_width), dtype=x.dtype)
        offset = 0.5 if self.aligned else 0.0
        for i in range(N):
            x1 = rois[i, 1] * self.spatial_scale
            y1 = rois[i, 2] * self.spatial_scale
            x2 = rois[i, 3] * self.spatial_scale
            y2 = rois[i, 4] * self.spatial_scale
            roi_w = x2 - x1
            roi_h = y2 - y1
            if roi_w <= 0 or roi_h <= 0:
                continue
            bin_h = roi_h / self.output_height
            bin_w = roi_w / self.output_width
            sy = int(self.sampling_ratio) if self.sampling_ratio > 0 else int(np.ceil(roi_h / self.output_height))
            sx = int(self.sampling_ratio) if self.sampling_ratio > 0 else int(np.ceil(roi_w / self.output_width))
            sy = max(sy, 1)
            sx = max(sx, 1)
            for ph in range(self.output_height):
                for pw in range(self.output_width):
                    sample_y = y1 + offset + (ph + 0.5) * bin_h
                    sample_x = x1 + offset + (pw + 0.5) * bin_w
                    # Bilinear sample
                    sample_y = np.clip(sample_y, 0, x.shape[2] - 1)
                    sample_x = np.clip(sample_x, 0, x.shape[3] - 1)
                    y0 = int(np.floor(sample_y))
                    x0 = int(np.floor(sample_x))
                    y1p = min(y0 + 1, x.shape[2] - 1)
                    x1p = min(x0 + 1, x.shape[3] - 1)
                    dy = sample_y - y0
                    dx = sample_x - x0
                    val = (x[:, :, y0, x0] * (1 - dy) * (1 - dx) +
                           x[:, :, y0, x1p] * (1 - dy) * dx +
                           x[:, :, y1p, x0] * dy * (1 - dx) +
                           x[:, :, y1p, x1p] * dy * dx)
                    out[i, :, ph, pw] = val
        return out
