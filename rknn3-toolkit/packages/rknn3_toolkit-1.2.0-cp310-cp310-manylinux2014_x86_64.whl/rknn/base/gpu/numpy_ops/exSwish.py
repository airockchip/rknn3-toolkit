import numpy as np


class exSwish_numpy:
    def __init__(self, beta=1.0, gamma=0.0, **kwargs):
        self.beta = float(beta)
        self.gamma = float(gamma)

    def forward(self, x):
        x = np.asarray(x)
        return x * (1.0 / (1.0 + np.exp(-(self.beta * x + self.gamma))))
