import numpy as np


class exSDPAttention_numpy:
    def __init__(self, scale=1.0, **kwargs):
        self.scale = float(scale)

    def forward(self, q, k, v, mask=None):
        q = np.asarray(q)
        k = np.asarray(k)
        v = np.asarray(v)
        batch = q.shape[0]
        dim_k = q.shape[1]
        dim_c = v.shape[1]
        q2 = q.reshape(batch, dim_k, -1)
        k2 = k.reshape(batch, dim_k, -1)
        v2 = v.reshape(batch, dim_c, -1)
        attn = np.matmul(k2.transpose(0, 2, 1), q2) * self.scale
        if mask is not None:
            mask = np.asarray(mask)
            if mask.ndim == 4:
                mask = mask.reshape(mask.shape[0], mask.shape[1], mask.shape[3])
            elif mask.ndim == 2:
                mask = mask[:, :, None]
            attn = attn + mask
        # softmax along dim=1
        attn_max = np.max(attn, axis=1, keepdims=True)
        attn = np.exp(attn - attn_max)
        attn = attn / np.sum(attn, axis=1, keepdims=True)
        out = np.matmul(v2, attn)
        seq_q = q2.shape[-1]
        out = out.reshape(batch, dim_c, 1, seq_q)
        return out
