import numpy as np


class exSum_numpy:
    def __init__(self, scale=None, **kwargs):
        self.scale = list(scale) if scale is not None else None

    def forward(self, *inputs):
        out = np.asarray(inputs[0])
        for idx, item in enumerate(inputs[1:], start=1):
            item = np.asarray(item)
            if self.scale is not None and idx < len(self.scale):
                out = out + item * self.scale[idx]
            else:
                out = out + item
        return out
