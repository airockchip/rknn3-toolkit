import numpy as np


class exLRN_numpy:
    """Local Response Normalization.

    numpy implementation of F.local_response_norm.
    """
    def __init__(self, alpha=1e-4, beta=0.75, bias=1.0, size=5, **kwargs):
        self.alpha = float(alpha)
        self.beta = float(beta)
        self.bias = float(bias)
        self.size = int(size)

    def forward(self, x):
        x = np.asarray(x)
        # x shape: (N, C, H, W) or (N, C, L)
        div = x * x
        # Sum over a window of 'size' channels centered on each channel
        half = self.size // 2
        # Use 1D running sum along channel axis
        sum_sq = np.zeros_like(x)
        for i in range(self.size):
            shift = i - half
            if shift < 0:
                # Pad beginning with zeros
                sliced = np.zeros_like(x)
                sliced[:, -shift:] = x[:, :x.shape[1] + shift]
                sum_sq += sliced * sliced
            elif shift > 0:
                sliced = np.zeros_like(x)
                sliced[:, :x.shape[1] - shift] = x[:, shift:]
                sum_sq += sliced * sliced
            else:
                sum_sq += x * x
        scale = 1.0 + self.alpha / self.size * sum_sq
        return x / np.power(scale, self.beta)
