import numpy as np


class exLSTM_numpy:
    """numpy LSTM via explicit gate computation (no torch.nn.LSTM dependency)."""

    def __init__(self, hidden_size, direction='forward', proj_size=0,
                 input_layout='snc', output_layout='snc',
                 batch_size=None, sequence_size=None, **kwargs):
        self.hidden_size = int(hidden_size)
        self.direction = direction
        self.proj_size = int(proj_size or 0)
        self.input_layout = input_layout
        self.output_layout = output_layout
        self.batch_size = batch_size
        self.sequence_size = sequence_size

    def _normalize_input(self, x):
        if self.input_layout == 'snc':
            return x.reshape(x.shape[0], x.shape[1], -1), x.shape[0], x.shape[1]
        seq = int(self.sequence_size or 1)
        batch = int(self.batch_size or (x.shape[0] // seq))
        return x.reshape(seq, batch, -1), seq, batch

    def _format_output(self, y, batch, num_directions):
        seq = y.shape[0]
        hidden = y.shape[-1] // num_directions
        y = y.reshape(seq, batch, num_directions, hidden).transpose(0, 2, 1, 3)
        if self.output_layout == 'snc':
            return y.transpose(0, 2, 1, 3).reshape(seq, batch, -1)
        if self.output_layout == '(sn)c':
            return y.transpose(0, 2, 1, 3).reshape(seq * batch, -1, 1, 1)
        return y

    @staticmethod
    def _onnx_to_torch_weight(w):
        gate = w.shape[0] // 4
        w_i, w_o, w_f, w_c = np.split(w, [gate, 2*gate, 3*gate], axis=0)
        return np.concatenate([w_i, w_f, w_c, w_o], axis=0)

    def _lstm_cell(self, x_t, w_ih, w_hh, h, c, bias_ih=None, bias_hh=None):
        gates = np.matmul(x_t, w_ih.T)
        if bias_ih is not None:
            gates = gates + bias_ih
        h_proj = np.matmul(h, w_hh.T) if bias_hh is None else np.matmul(h, w_hh.T) + bias_hh
        gates = gates + h_proj
        gate = self.hidden_size
        i = 1.0 / (1.0 + np.exp(-gates[:, :gate]))
        f = 1.0 / (1.0 + np.exp(-gates[:, gate:2*gate]))
        g = np.tanh(gates[:, 2*gate:3*gate])
        o = 1.0 / (1.0 + np.exp(-gates[:, 3*gate:]))
        c = f * c + i * g
        h = o * np.tanh(c)
        return h, c

    def forward(self, x, w, r, b=None, seq_lens=None, initial_h=None, initial_c=None, p=None):
        x = np.asarray(x)
        w = [np.asarray(wi) for wi in w] if isinstance(w, (list, tuple)) or w.ndim > 2 else [np.asarray(w)]
        r = [np.asarray(ri) for ri in r] if isinstance(r, (list, tuple)) or r.ndim > 2 else [np.asarray(r)]
        x, _, batch = self._normalize_input(x)
        seq_len = x.shape[0]
        input_size = x.shape[-1]
        num_directions = 2 if self.direction == 'bidirectional' else 1
        has_bias = b is not None
        hidden_out = self.proj_size if self.proj_size > 0 else self.hidden_size

        all_outputs = []
        all_h = []
        all_c = []

        for d in range(num_directions):
            suffix = d
            if self.direction == 'bidirectional':
                w_d = self._onnx_to_torch_weight(w[suffix])
                r_d = self._onnx_to_torch_weight(r[suffix])
            else:
                reverse = self.direction == 'reverse'
                w_d = self._onnx_to_torch_weight(w[0])
                r_d = self._onnx_to_torch_weight(r[0])

            if has_bias:
                b = np.asarray(b)
                gate = 4 * self.hidden_size
                bias_ih = self._onnx_to_torch_weight(b[d, :gate].reshape(gate, 1)).reshape(-1)
                bias_hh = self._onnx_to_torch_weight(b[d, gate:].reshape(gate, 1)).reshape(-1)
            else:
                bias_ih = bias_hh = None

            h = np.zeros((batch, self.hidden_size), dtype=x.dtype) if initial_h is None else np.asarray(initial_h[d])
            c = np.zeros((batch, self.hidden_size), dtype=x.dtype) if initial_c is None else np.asarray(initial_c[d])

            outputs = []
            indices = range(seq_len - 1, -1, -1) if reverse else range(seq_len)
            for t in indices:
                h, c = self._lstm_cell(x[t], w_d, r_d, h, c, bias_ih, bias_hh)
                if self.proj_size > 0 and p is not None:
                    p_arr = np.asarray(p[d])
                    h = np.matmul(h, p_arr.T)
                outputs.append(h)
            if reverse:
                outputs = outputs[::-1]
            all_outputs.extend(outputs)
            all_h.append(h)
            all_c.append(c)

        y = np.stack(all_outputs, axis=0)
        y = self._format_output(y, batch, num_directions)
        h_out = np.stack(all_h, axis=0)
        c_out = np.stack(all_c, axis=0)
        return y, h_out, c_out


class exGRU_numpy:
    """numpy GRU via explicit gate computation."""

    def __init__(self, hidden_size, direction='forward',
                 input_layout='snc', output_layout='snc',
                 batch_size=None, sequence_size=None, **kwargs):
        self.hidden_size = int(hidden_size)
        self.direction = direction
        self.input_layout = input_layout
        self.output_layout = output_layout
        self.batch_size = batch_size
        self.sequence_size = sequence_size

    def _normalize_input(self, x):
        if self.input_layout == 'snc':
            return x.reshape(x.shape[0], x.shape[1], -1), x.shape[0], x.shape[1]
        seq = int(self.sequence_size or 1)
        batch = int(self.batch_size or (x.shape[0] // seq))
        return x.reshape(seq, batch, -1), seq, batch

    def _format_output(self, y, batch, num_directions):
        seq = y.shape[0]
        hidden = y.shape[-1] // num_directions
        y = y.reshape(seq, batch, num_directions, hidden).transpose(0, 2, 1, 3)
        if self.output_layout == 'snc':
            return y.transpose(0, 2, 1, 3).reshape(seq, batch, -1)
        if self.output_layout == '(sn)c':
            return y.transpose(0, 2, 1, 3).reshape(seq * batch, -1, 1, 1)
        return y

    @staticmethod
    def _onnx_to_torch_weight(w):
        gate = w.shape[0] // 3
        w_z, w_r, w_h = np.split(w, [gate, 2*gate], axis=0)
        return np.concatenate([w_r, w_z, w_h], axis=0)

    def _gru_cell(self, x_t, w_ih, w_hh, h, bias_ih=None, bias_hh=None):
        gates_x = np.matmul(x_t, w_ih.T)
        gates_h = np.matmul(h, w_hh.T)
        if bias_ih is not None:
            gates_x = gates_x + bias_ih
        if bias_hh is not None:
            gates_h = gates_h + bias_hh
        gate = self.hidden_size
        r = 1.0 / (1.0 + np.exp(-(gates_x[:, :gate] + gates_h[:, :gate])))
        z = 1.0 / (1.0 + np.exp(-(gates_x[:, gate:2*gate] + gates_h[:, gate:2*gate])))
        n = np.tanh(gates_x[:, 2*gate:] + r * gates_h[:, 2*gate:])
        h = (1 - z) * n + z * h
        return h

    def forward(self, x, w, r, b=None, seq_lens=None, initial_h=None):
        x = np.asarray(x)
        w = [np.asarray(wi) for wi in w] if isinstance(w, (list, tuple)) or w.ndim > 2 else [np.asarray(w)]
        r = [np.asarray(ri) for ri in r] if isinstance(r, (list, tuple)) or r.ndim > 2 else [np.asarray(r)]
        x, _, batch = self._normalize_input(x)
        seq_len = x.shape[0]
        num_directions = 2 if self.direction == 'bidirectional' else 1
        has_bias = b is not None

        all_outputs = []
        all_h = []

        for d in range(num_directions):
            if self.direction == 'bidirectional':
                w_d = self._onnx_to_torch_weight(w[d])
                r_d = self._onnx_to_torch_weight(r[d])
            else:
                reverse = self.direction == 'reverse'
                w_d = self._onnx_to_torch_weight(w[0])
                r_d = self._onnx_to_torch_weight(r[0])

            if has_bias:
                b = np.asarray(b)
                gate = 3 * self.hidden_size
                bias_ih = self._onnx_to_torch_weight(b[d, :gate].reshape(gate, 1)).reshape(-1)
                bias_hh = self._onnx_to_torch_weight(b[d, gate:].reshape(gate, 1)).reshape(-1)
            else:
                bias_ih = bias_hh = None

            h = np.zeros((batch, self.hidden_size), dtype=x.dtype) if initial_h is None else np.asarray(initial_h[d])

            outputs = []
            indices = range(seq_len - 1, -1, -1) if reverse else range(seq_len)
            for t in indices:
                h = self._gru_cell(x[t], w_d, r_d, h, bias_ih, bias_hh)
                outputs.append(h)
            if reverse:
                outputs = outputs[::-1]
            all_outputs.extend(outputs)
            all_h.append(h)

        y = np.stack(all_outputs, axis=0)
        y = self._format_output(y, batch, num_directions)
        h_out = np.stack(all_h, axis=0)
        return y, h_out
