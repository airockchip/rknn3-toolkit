import numpy as np


class exNorm_numpy:
    def __init__(self, mode='layer', eps=1e-5, axes=(-1,), std_multipler=1.0, **kwargs):
        self.mode = mode
        self.eps = float(eps)
        self.axes = tuple(axes)
        self.std_multipler = float(std_multipler)

    def forward(self, x, weight=None, bias=None):
        x = np.asarray(x)
        axes = self.axes

        if self.mode == 'layer':
            xu = x - np.mean(x, axis=axes, keepdims=True)
            y = xu * (1.0 / np.sqrt(np.mean(xu * xu, axis=axes, keepdims=True) + self.eps))
        elif self.mode == 'rms':
            y = x * (1.0 / np.sqrt(np.mean(x * x, axis=axes, keepdims=True) + self.eps))
        elif self.mode == 'mean_var':
            mean = np.mean(x, axis=axes, keepdims=True)
            y = (x - mean) * (1.0 / np.sqrt(np.mean(x * x, axis=axes, keepdims=True) - mean * mean + self.eps))
        elif self.mode == 'pixel':
            y = x * (1.0 / np.sqrt(np.sum(x * x, axis=axes, keepdims=True) + self.eps))
        elif self.mode == 'l1':
            y = x / np.maximum(np.sum(np.abs(x), axis=axes, keepdims=True), self.eps)
        elif self.mode == 'l2':
            y = x / np.maximum(np.sqrt(np.sum(x * x, axis=axes, keepdims=True)), self.eps)
        elif self.mode == 'gaussian_topk':
            mean = np.mean(x, axis=axes, keepdims=True)
            std = np.sqrt(np.mean(x * x, axis=axes, keepdims=True) - mean * mean)
            cutoff = mean + std * self.std_multipler
            y = np.clip(x - cutoff, a_min=0, a_max=None)
            y = y.astype(x.dtype)
        else:
            raise NotImplementedError('Unsupported exNorm mode: {}'.format(self.mode))

        if weight is not None:
            y = y * np.asarray(weight)
        if bias is not None:
            y = y + np.asarray(bias)
        return y
