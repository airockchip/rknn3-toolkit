import numpy as np


class exmpiSplit_numpy:
    def __init__(self, axis, start, end, **kwargs):
        self.axis = int(axis)
        self.start = tuple(start)
        self.end = tuple(end)

    def forward(self, x):
        x = np.asarray(x)
        outputs = []
        for start, end in zip(self.start, self.end):
            slc = [slice(None)] * x.ndim
            slc[self.axis] = slice(start, end)
            outputs.append(x[tuple(slc)])
        return tuple(outputs)
