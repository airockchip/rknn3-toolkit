import glob
import math
import os
import pathlib
import shutil
import time
from pathlib import Path
from enum import IntEnum
import onnx
from onnx import helper
import pandas as pd
from tabulate import tabulate

import torch
import numpy as np
from .rknn_kvcache_tester import kv_store_infer, kv_store_GroupQuantCache_infer, DeviceConfig, getGroupQuantCacheVNC1HWC2Params, getGroupQuantCacheVNCHWParams, MatMulType
from .data_convert import *

kvcache_matmul_type = {
    "Float16": MatMulType.MATMUL_TYPE_WF16_AF16_OF16,
    "Int4_to_F8": MatMulType.MATMUL_TYPE_WI4_AF16_OF16_ZF8_SF16_GRP_PCH_ASYNC,
    "Int4_to_F16": MatMulType.MATMUL_TYPE_WI4_AF16_OF16_ZF16_SF16_GRP_PCH_ASYNC,
    "Int8_to_F16": MatMulType.MATMUL_TYPE_WI8_AF16_OF16_ZF16_SF16_GRP_PCH_ASYNC,
    "Float4_to_F16": MatMulType.MATMUL_TYPE_WF4_AF16_OF16_SF16_WPF16_GRP_PCH_SYNC,
    "Float4_to_F8": MatMulType.MATMUL_TYPE_WF4_AF16_OF16_SF16_WPF8_GRP_PCH_SYNC,
    "Float8_to_F16": MatMulType.MATMUL_TYPE_WF8_AF16_OF16_SF16_WPF16_GRP_PCH_SYNC,
    "Float8_to_F8": MatMulType.MATMUL_TYPE_WF8_AF16_OF16_SF16_WPF8_GRP_PCH_SYNC,
}

def get_default_rope(position_ids, dim=128):
    inv_freq = 1.0 / (10000 ** (torch.arange(0, dim, 2, dtype=torch.int64).float() / dim))
    inv_freq_expanded = inv_freq[None, :, None].float().expand(position_ids.shape[0], -1, 1)
    position_ids_expanded = position_ids[:, None, :].float()
    freqs = (inv_freq_expanded.float() @ position_ids_expanded.float()).transpose(1, 2)
    emb = torch.cat((freqs, freqs), dim=-1)
    cos = emb.cos()
    sin = emb.sin()
    return cos, sin


def rotate_half(x):
    """Rotates half the hidden dims of the input."""
    x1 = x[..., : x.shape[-1] // 2]
    x2 = x[..., x.shape[-1] // 2:]
    return torch.cat((-x2, x1), dim=-1)


def apply_rotary_pos_emb(q, cos, sin, position_ids=None, unsqueeze_dim=1):
    cos = cos.unsqueeze(unsqueeze_dim)
    sin = sin.unsqueeze(unsqueeze_dim)
    q_embed = ((q.astype * cos).astype(np.float32) + (rotate_half(q) * sin).astype(np.float32)).astype(np.float16)
    return q_embed


def get_default_rope_np(position_ids, dim=128):
    if (len(position_ids.shape) == 1):
        position_ids = position_ids[:, None]
    inv_freq = 1.0 / (10000 ** (np.arange(0, dim, 2, dtype=np.int64).astype(np.float32) / dim))[None, :]
    freqs = position_ids.astype(np.float32) * inv_freq.astype(np.float32)
    emb = np.concatenate([freqs, freqs], axis=-1)
    cos = np.cos(emb)
    sin = np.sin(emb)
    return cos, sin


def rotate_half_np(x):
    """Rotates half the hidden dims of the input."""
    x1 = x[:, :x.shape[1] // 2, :, :]
    x2 = x[:, x.shape[1] // 2:, :, :]
    return np.concatenate((-x2, x1), axis=1)


def apply_rotary_pos_emb_np(q, cos, sin):
    q_embed = (q * cos) + (rotate_half_np(q) * sin)
    # return cos * cos
    # return (rotate_half_np(q) * sin)
    return q_embed


def align(x, alignment):
    return (x + alignment - 1) // alignment * alignment


def surf_align(x, alignment):
    return x if x == 1 else (x + alignment - 1) // alignment * alignment


def softmax(x):
    # 在 C 维度上进行 softmax
    max_x = np.max(x, axis=1, keepdims=True).astype(np.float16)  # 避免数值溢出
    # fast exp
    # sub = (x - max_x).astype(np.float16)
    # index = np.where(sub < -10)
    # s = np.array([1.4426950409], dtype=np.float32)
    # tmp = ((1 << 10) * (s * sub.astype(np.float32) + 14.94201519))
    # exp_x = (tmp.astype(np.int16)).view(np.float16)
    # exp_x[index] = 0
    exp_x = np.exp(x.astype(np.float16) - max_x.astype(np.float16)).astype(np.float16)
    sum_exp_x = np.sum(exp_x.astype(np.float16), axis=1, keepdims=True).astype(np.float16)
    return exp_x / sum_exp_x


def group_quant_cache_key_group_quant_matmul(device_config, feature, weight, params, group_size):
    # TODO: 目前先和 Value 写法一致
    '''
    feature: [K, M]
    weight: [K, N]
    params: [K, 2, group_nums]
    '''
    group_nums = params.shape[2]

    scale = params[:, 0, :]
    zp = params[:, 1, :]

    output_list = []
    for i in range(group_nums):
        scale_feature = (feature * scale[:, i:i+1]).astype(np.float16).astype(np.float32)
        if device_config.mac_k == 32:
            weight_ow = fp8_to_fp32(fp32_to_fp8(weight[:, i*group_size:(i+1)*group_size].astype(np.float32) + zp[:, i:i+1].astype(np.float32))).astype(np.float16)
        else:
            weight_ow = fp32_to_fp16(weight[:, i*group_size:(i+1)*group_size].astype(np.float32) + zp[:, i:i+1].astype(np.float32)).astype(np.float32)
        gold_temp = np.matmul(scale_feature.transpose((1, 0)), weight_ow).astype(np.float16)
        output_list.append(gold_temp)
    output = np.concatenate(output_list, axis=1).transpose((1, 0)).astype(np.float16)
    return output

def group_quant_cache_value_group_quant_matmul(device_config, feature, weight, params, group_size):
    '''
    feature: [K, M]
    weight: [N, K]
    params: [group_nums, 2, K] [scale, zp]
    '''
    group_nums = params.shape[0]

    scale = params[:, 0, :]
    zp = params[:, 1, :]

    output_list = []
    for i in range(group_nums):
        scale_feature = (feature.transpose((1, 0)) * scale[i:i+1, :]).astype(np.float32)
        if device_config.mac_k == 32:
            weight_ow = fp8_to_fp32(fp32_to_fp8(weight[i*group_size:(i+1)*group_size, :].astype(np.float32)+zp[i:i+1, :].astype(np.float32))).transpose((1, 0))
        else:
            weight_ow = fp32_to_fp16(weight[i*group_size:(i+1)*group_size, :].astype(np.float32)+zp[i:i+1, :].astype(np.float32)).transpose((1, 0)).astype(np.float32)
        # np.save("exAttention/scale_fd_{}".format(i), scale_feature)
        # np.save("exAttention/weight_ow_{}".format(i), weight_ow)
        gold_temp = np.matmul(scale_feature, weight_ow).astype(np.float16)
        output_list.append(gold_temp)
    output = np.concatenate(output_list, axis=1).transpose((1, 0))
    return output

def exAttention_gen_inputs_golden_p1(dst_dir: Path, *args, **wargs):
    np.random.seed(67)
    query   = wargs['query'].astype(np.float16)
    key     = wargs['key'].astype(np.float16)
    value   = wargs['value'].astype(np.float16)
    mask    = wargs['mask'].astype(np.float16)
    sink_tensor = wargs.get('has_sink')
    if sink_tensor is not None:
        assert sink_tensor.shape == (query.shape[0],), "sink_tensor must have one scalar per query head"
        sink_tensor = sink_tensor.astype(np.float16)
    # compiler_exe_path = args[1]
    # compiler_lib_path = args[2]
    k_channel = key.shape[1]
    v_channel = value.shape[1]
    num_head_size = wargs["num_head_size"]
    num_kv_head_size = wargs["num_kv_head_size"]
    kv_cache_dtype = wargs["kv_cache_dtype"]
    store_method = wargs["store_method"]
    group_size = wargs["group_size"]
    residual_depth = wargs["residual_depth"]
    max_token_len = wargs["max_token_len"]
    max_pos_embedding = wargs["max_pos_embedding"]
    use_kv_cache = wargs["use_kv_cache"]
    bucket_size = wargs["bucket_size"]
    Th = wargs["Th"]
    Tc = wargs["Tc"]
    Ts = wargs["Ts"]
    Tsr = wargs["Tsr"]
    Ti = wargs["Ti"]
    Tr = wargs["Tr"]
    scale = wargs["scale"]
    infer_times = wargs["infer_times"]
    store_begin_id = wargs["store_begin_id"]
    longest_surviving_id = wargs["longest_surviving_id"]
    tokens_per_page = wargs["tokens_per_page"]
    rope = wargs["rope"]
    storage_separation = wargs["storage_separation"]
    eagle = wargs['eagle']
    max_sample_num = wargs["max_sample_num"]
    sample_num_list = wargs["sample_num_list"]
    select_id_list = wargs["select_id_list"]

    is_group_quant = store_method == "GroupQuant"

    decode_b2w = wargs["decode_b2w"]
    # 硬件仿真用，toolkit屏蔽
    # page_nums = align(max_token_len, tokens_per_page) // tokens_per_page

    key_matmul_type = kvcache_matmul_type[kv_cache_dtype]
    value_matmul_type = kvcache_matmul_type[kv_cache_dtype]

    wargs["k_matmul_type"] = key_matmul_type
    wargs["v_matmul_type"] = value_matmul_type

    device_config = DeviceConfig("p1", MatMulType.MATMUL_TYPE_WF16_AF16_OF16)
    key_device_config = DeviceConfig("p1", key_matmul_type)
    value_device_config = DeviceConfig("p1", value_matmul_type)

    subc_out = device_config.subc_out

    # 替换为外部传入cache
    # past_key_cache = np.zeros((num_kv_head_size, channel, 1, max_token_len)).astype(np.float16)
    # past_key_residual_cache = np.zeros((num_kv_head_size, channel, 1, residual_depth)).astype(np.float16)
    # past_value_cache = np.zeros((num_kv_head_size, channel, 1, max_token_len)).astype(np.float16)
    # past_value_residual_cache = np.zeros((num_kv_head_size, channel, 1, residual_depth)).astype(np.float16)
    past_key_cache            = wargs['past_key_cache'].astype(np.float16)
    past_key_residual_cache   = wargs['past_key_residual_cache'].astype(np.float16)
    past_value_cache          = wargs['past_value_cache'].astype(np.float16)
    past_value_residual_cache = wargs['past_value_residual_cache'].astype(np.float16)

    if is_group_quant:
        channel_align_macc = align(k_channel, key_device_config.mac_c)
        value_group_nums = align(v_channel, group_size) // group_size
        key_max_group_nums = align(max_token_len, group_size) // group_size

        # 计算 key cache 的相关参数
        key_zp_width = key_device_config.zp_bits * key_device_config.mac_c // key_device_config.bus_bits
        key_scale_width = key_device_config.scale_bits * key_device_config.mac_c // key_device_config.bus_bits

        # 计算 value cache 的相关参数
        value_zp_width = value_device_config.zp_bits * value_device_config.mac_c // value_device_config.bus_bits
        value_scale_width = value_device_config.scale_bits * value_device_config.mac_c // value_device_config.bus_bits
        past_key_cache = past_key_cache.astype(np.int8)
        past_value_cache = past_value_cache.astype(np.int8)
        # 替换为外部传入cache的量化参数
        # past_key_params_cache = np.zeros((num_kv_head_size, channel_align_macc, 2, 1, key_max_group_nums)).astype(np.float16)
        # past_value_params_cache = np.zeros((num_kv_head_size, value_group_nums, 2, 1, max_token_len)).astype(np.float16)
        past_key_params_cache   = wargs['past_key_params_cache'].astype(np.float16)
        past_value_params_cache = wargs['past_value_params_cache'].astype(np.float16)
    else:
        past_key_params_cache = None
        past_value_params_cache = None

    ori_Tc = Tc
    if "infer_list" in wargs:
        for Tc in wargs["infer_list"]:
            key = np.random.randn(num_kv_head_size, k_channel, 1, Tc).astype(np.float16)
            value = np.random.randn(num_kv_head_size, v_channel, 1, Tc).astype(np.float16)
            # key = np.load("/home/gls/project/rknn_compiler_unittest/shape0/task_sub_6_segment_0_5005__model_layers.0_self_attn_k_proj_MatMul_output_0_mm_tp_sw_SP_D8C6_shape_1_128_1_128_float32.npy")[..., :Tc]
            # cos = np.load("/home/gls/project/rknn_compiler_unittest/shape1/task_sub_0_segment_0_004_rope_cos_cache_BC_D8C0_shape_1_128_1_8192_float32.npy")
            # sin = np.load("/home/gls/project/rknn_compiler_unittest/shape1/task_sub_0_segment_0_005_rope_sin_cache_BC_D8C0_shape_1_128_1_8192_float32.npy")
            # key = apply_rotary_pos_emb_np(key, cos[..., :Tc], sin[..., :Tc])
            # value = np.load("/home/gls/project/rknn_compiler_unittest/shape0/task_sub_6_segment_0_5004__model_layers.0_self_attn_v_proj_MatMul_output_0_mm_tp_sw_SP_D8C6_shape_1_128_1_128_float32.npy")[..., :Tc]
            if Ts != 0:
                ts_align_in_tc = (Th < Ts) * (Th+Tc >= Ts) * (Ts-Tsr > 0)
                ts_align_in_tc_w_q = ts_align_in_tc * (Th + Tc > Ts)
                tsr_begin_id = Tsr - Th
                if ts_align_in_tc:
                    key[:, :, :, tsr_begin_id:] = 0
                    value[:, :, :, tsr_begin_id:] = 0
            # k store
            if is_group_quant:
                k_store_info, past_key_cache, past_key_residual_cache, past_key_params_cache = kv_store_GroupQuantCache_infer("key", key_device_config,
                    key, past_key_cache, past_key_residual_cache, past_key_params_cache, Th, Tc, Ts, Ti, Tr, store_begin_id,
                    longest_surviving_id, max_token_len, group_size, residual_depth, key_zp_width, key_scale_width)
            else:
                k_store_info, past_key_cache, past_key_residual_cache = kv_store_infer(
                    key, past_key_cache, past_key_residual_cache, Th, Tc, Ts, Ti, Tr, store_begin_id, longest_surviving_id, max_token_len, group_size, residual_depth)

            # v store
            if is_group_quant:
                v_store_info, past_value_cache, past_value_residual_cache, past_value_params_cache = kv_store_GroupQuantCache_infer("value", value_device_config,
                    value, past_value_cache, past_value_residual_cache, past_value_params_cache, Th, Tc, Ts, Ti, Tr, store_begin_id,
                    longest_surviving_id, max_token_len, group_size, residual_depth, value_zp_width, value_scale_width)
            else:
                v_store_info, past_value_cache, past_value_residual_cache = kv_store_infer(
                value, past_value_cache, past_value_residual_cache, Th, Tc, Ts, Ti, Tr, store_begin_id, longest_surviving_id, max_token_len, group_size, residual_depth)

            Th = k_store_info["Th"]
            Tr = k_store_info["Tr"]
            Ti = k_store_info["Ti"]
            store_begin_id = k_store_info["store_begin_id"]
            longest_surviving_id = k_store_info["longest_surviving_id"]
            Th = Ti
        if "back_num" in wargs:
            if wargs["back_num"] != 0:
                Th = (Th - wargs["back_num"]) // group_size * group_size

    Tc = ori_Tc

    ori_Tr = Tr
    ori_Ti = Ti
    ori_store_begin_id = store_begin_id
    ori_longest_surviving_id = longest_surviving_id

    # 生成输入
    # query = np.random.randn(num_head_size, channel, 1, bucket_size).astype(np.float16)
    # key = np.random.randn(num_kv_head_size, channel, 1, bucket_size).astype(np.float16)
    # value = np.random.randn(num_kv_head_size, channel, 1, bucket_size).astype(np.float16)
    # 替换为外部传入输入
    # if "query_path" in wargs:
    #     query = np.load(wargs["query_path"]).astype(np.float16)
    #     print(query.shape)
    # else:
    #     query = np.random.normal(loc=np.random.randn() * 2, scale=np.random.uniform(1, 5),
    #                             size=(num_head_size, channel, 1, bucket_size)).astype(np.float16)
    # if "key_path" in wargs:
    #     key = np.load(wargs["key_path"]).astype(np.float16)
    #     print(key.shape)
    # else:
    #     key = np.random.normal(loc=np.random.randn() * 2, scale=np.random.uniform(1, 5),
    #                         size=(num_kv_head_size, channel, 1, bucket_size)).astype(np.float16)
    # if "value_path" in wargs:
    #     value = np.load(wargs["value_path"]).astype(np.float16)
    #     print(value.shape)
    # else:
    #     value = np.random.normal(loc=np.random.randn(), scale=np.random.uniform(
    #         1, 5), size=(num_kv_head_size, channel, 1, bucket_size)).astype(np.float16)
    # if "mask_path" in wargs:
    #     mask = np.load(wargs["mask_path"]).astype(np.float16)
    #     print(mask.shape)
    # else:
    #     # mask = np.ones((1, bucket_size, 1, bucket_size)).astype(np.float16) * -np.inf
    #     mask = np.tril(np.ones((bucket_size, bucket_size))).astype(np.float16)
    #     mask = np.where(mask == 0, -np.inf, mask)
    #     mask = np.where(mask == 1, 0, mask)
    #     mask = mask.transpose((1, 0))
    #     mask = mask[None, :, None, :]
    #     mask[..., Tc:] = -np.inf
    #     if Th < Ts and Th + Tc >= Ts:
    #         tsr_begin_id = Tsr - Th
    #         tsr_w = Ts - Tsr
    #         mask[:, tsr_begin_id:tsr_begin_id + tsr_w, :, :] = -np.inf
    #         mask[:, :, :, tsr_begin_id:tsr_begin_id + tsr_w] = -np.inf
    #     mask = mask.astype(np.float16)

    # if "cos_path" in wargs and "sin_path" in wargs:
    #     pos_cos = np.load(wargs["cos_path"]).astype(np.float16)
    #     pos_sin = np.load(wargs["sin_path"]).astype(np.float16)
    #     print(pos_cos.shape)
    #     print(pos_sin.shape)
    # else:
    #     pos_ids = np.arange(max_pos_embedding).reshape((-1, 1))
    #     pos_cos, pos_sin = get_default_rope_np(pos_ids, dim=channel)
    #     pos_cos = pos_cos[None, :, None, :].transpose((0, 3, 2, 1)).astype(np.float16)
    #     pos_sin = pos_sin[None, :, None, :].transpose((0, 3, 2, 1)).astype(np.float16)
    # history_token = np.array([Th]).astype(np.int32)
    # cur_token = np.array([Tc]).astype(np.int32)
    # sys_token_len = np.array([Ts]).astype(np.int32)
    # sys_real_token_len = np.array([Tsr]).astype(np.int32)
    # infer_token_len = np.array([Ti]).astype(np.int32)
    # residual_token_len = np.array([Tr]).astype(np.int32)
    # store_begin_id_t = np.array([store_begin_id]).astype(np.int32)
    # longest_surviving_id_t = np.array([longest_surviving_id]).astype(np.int32)
    if rope:
        pos_cos = wargs['pos_cos'].astype(np.float16)
        pos_sin = wargs['pos_sin'].astype(np.float16)

    # ============== 计算 golden ===========
    # 计算是否回退
    is_reset = 1 if Th == 0 else 0

    store_begin_id = (is_reset == 0) * store_begin_id  # 每次填充时的index
    longest_surviving_id = (is_reset == 1) * (-1) + (is_reset == 0) * \
        longest_surviving_id  # cache现存的最早填充的token的index
    Ti = (is_reset == 0) * Ti
    Tr = (is_reset == 0) * Tr

    back_num = (Ti != Th) * (Ti - (Th // group_size * group_size))
    residual_back_num = back_num if (Tr - back_num) >= 0 else Tr
    Tr = Tr - residual_back_num
    cache_back_num = back_num - residual_back_num

    null_num = (longest_surviving_id - store_begin_id) + (longest_surviving_id < store_begin_id) * \
        (max_token_len - Ts + (longest_surviving_id == (Ts - 1)))
    filled_num = max_token_len - Ts - null_num
    full_back = ((cache_back_num >= (max_token_len - Ts)) + (cache_back_num >= filled_num) * (filled_num > 0)) > 0
    longest_surviving_id = (1 - full_back) * longest_surviving_id
    store_begin_id = full_back * Ts + (1 - full_back) * ((store_begin_id - cache_back_num) +
                                                         ((store_begin_id - Ts) >= 0) * (cache_back_num > (store_begin_id - Ts)) * (max_token_len - Ts))

    ts_w = (Ts > 0) * ((longest_surviving_id == 0) * store_begin_id + (longest_surviving_id >= Ts) * Ts)
    # cache0_w = (longest_surviving_id >= Ts) * ((store_begin_id == longest_surviving_id) * (max_token_len - Ts) + (store_begin_id > longest_surviving_id)
    #                                            * ((longest_surviving_id == Ts) * (store_begin_id - Ts)) + (store_begin_id < longest_surviving_id) * (store_begin_id - Ts))
    # cache1_begin_id = (store_begin_id != longest_surviving_id) * ((longest_surviving_id > Ts)) * longest_surviving_id
    # cache1_w = (longest_surviving_id >= Ts) * ((store_begin_id > longest_surviving_id) * (longest_surviving_id > Ts) *
    #                                            (store_begin_id - longest_surviving_id) + (store_begin_id < longest_surviving_id) * (max_token_len - cache1_begin_id))
    cache0_w = (longest_surviving_id >= Ts) * (
        (store_begin_id <= longest_surviving_id) * (store_begin_id - Ts)
    )

    cache1_begin_id = ((longest_surviving_id >= Ts)) * longest_surviving_id
    cache1_w = (longest_surviving_id >= Ts) * (
        (store_begin_id <= longest_surviving_id)
        * (max_token_len - longest_surviving_id)
        + (store_begin_id > longest_surviving_id)
        * (store_begin_id - longest_surviving_id)
    )

    ts_w = min(ts_w, Tsr)
    ts_w_align_subc = align(ts_w, subc_out)
    cur_pos_id = (Th >= Ts) * (Th - (Ts - Tsr)) + (Th < Ts) * Th
    cache_size = ts_w + cache0_w + cache1_w + Tr
    sliding_cache_size = cache0_w + cache1_w + Tr
    kv_group_size = num_head_size // num_kv_head_size
    attn_r_channel = ts_w_align_subc + cache0_w + cache1_w + align(Tr, subc_out) + Tc

    surf_alignment = 4
    if wargs["decode_b2w"]:
        surf_alignment = 1
        new_Tc = kv_group_size
    else:
        new_Tc = Tc

    attn_channel = max_token_len + residual_depth + align(bucket_size, subc_out)
    Tc_surf_align = surf_align(new_Tc, 4)
    attn = np.zeros((1, attn_channel, 1, Tc_surf_align)).astype(np.float16)

    ts_align_in_tc = (Th < Ts) * (Th+Tc >= Ts) * (Ts-Tsr > 0)
    ts_align_in_tc_w_q = ts_align_in_tc * (Th + Tc > Ts)

    ts_align_w = Tsr - Th

    question_shift = Ts - Th
    question_w = Tc - question_shift
    question_pos_d = cur_pos_id + (Tsr - Th)

    sliding_window_mask = None
    if wargs["attention_type"] == "SlidingAttention":
        sliding_window = wargs["sliding_window"]
        if Tc - ts_align_in_tc * (Ts - Tsr) > sliding_window:
            sw_start = sliding_window + ts_align_in_tc * (sliding_window > (Tsr - Th)) * (Ts - Tsr)
            for i in range(sw_start, Tc):
                channel_len = i + 1 - sliding_window - ts_align_in_tc * (i >= (Ts - Th)) * (i < (Ts - Th + sliding_window - 1)) * (Ts - Tsr)
                mask[:, :channel_len, :, i] = -65504
        cache_channel = max_token_len + residual_depth
        sliding_window_mask = np.zeros((Tc_surf_align, cache_channel), dtype=np.float16)
        if sliding_cache_size + Tc - ts_align_in_tc * (Ts - Tsr) > sliding_window:
            cache_start_id = ((sliding_window - sliding_cache_size) > 0) * (
                sliding_window - sliding_cache_size
            )
            for i in range(cache_start_id, Tc):
                channel_len = min(sliding_cache_size + i + 1 - sliding_window - ts_align_in_tc * (i >= (Ts - Th)) * (Ts - Tsr), sliding_cache_size)
                sliding_window_mask[i, :channel_len] = -65504
        sliding_window_mask = sliding_window_mask.transpose((1, 0))[None, :, None, :]
        # np.save(
        #     dst_dir.joinpath("sliding_window_mask_golden.npy"),
        #     np.ascontiguousarray(sliding_window_mask),
        # )

    if ts_align_in_tc and (not ts_align_in_tc_w_q):
        tsr_begin_id = Tsr - Th
        tsr_w = Ts - Tsr
        query[:, :, :, tsr_begin_id:] = 0
        key[:, :, :, tsr_begin_id:] = 0
        value[:, :, :, tsr_begin_id:] = 0

    # 生成输入
    # np.save(dst_dir.joinpath("query.npy"), np.ascontiguousarray(query.transpose((0, 2, 3, 1))))
    # np.save(dst_dir.joinpath("key.npy"), np.ascontiguousarray(key.transpose((0, 2, 3, 1))))
    # np.save(dst_dir.joinpath("value.npy"), np.ascontiguousarray(value.transpose((0, 2, 3, 1))))
    # np.save(dst_dir.joinpath("mask.npy"), np.ascontiguousarray(mask.transpose((0, 2, 3, 1))))
    # np.save(dst_dir.joinpath("cos.npy"), np.ascontiguousarray(pos_cos.transpose((0, 2, 3, 1))))
    # np.save(dst_dir.joinpath("sin.npy"), np.ascontiguousarray(pos_sin.transpose((0, 2, 3, 1))))
    # np.save(dst_dir.joinpath("Th.npy"), np.ascontiguousarray(history_token))
    # np.save(dst_dir.joinpath("Tc.npy"), np.ascontiguousarray(cur_token))
    # np.save(dst_dir.joinpath("Ts.npy"), np.ascontiguousarray(sys_token_len))
    # np.save(dst_dir.joinpath("Tsr.npy"), np.ascontiguousarray(sys_real_token_len))
    # np.save(dst_dir.joinpath("Ti.npy"), np.ascontiguousarray(infer_token_len))
    # np.save(dst_dir.joinpath("Tr.npy"), np.ascontiguousarray(residual_token_len))
    # np.save(dst_dir.joinpath("store_begin_id.npy"), np.ascontiguousarray(store_begin_id_t))
    # np.save(dst_dir.joinpath("longest_surviving_id.npy"), np.ascontiguousarray(longest_surviving_id_t))
    # np.save(dst_dir.joinpath("max_token_len.npy"), np.ascontiguousarray(np.array([wargs["max_token_len"]]).astype(np.int32)))

    if storage_separation:
        store_mask = wargs['store_mask']
        infer_mask = wargs['infer_mask']
        infer_mask_v = store_mask | infer_mask
        # infer_mask_v = infer_mask
        if eagle:
            if rope:
                sample_num_list_t = sample_num_list + [0] * (max_sample_num - sample_num_list[0])
                # np.save(dst_dir.joinpath("sample_num_list.npy"), np.ascontiguousarray(sample_num_list_t))
            select_id_list_t = select_id_list + [0] * (max_sample_num - select_id_list[0])
            # np.save(dst_dir.joinpath("select_id_list.npy"), np.ascontiguousarray(select_id_list_t))
    else:
        infer_mask_v = 0
    # np.save(dst_dir.joinpath("infer_mask.npy"), np.ascontiguousarray(np.array([infer_mask_v]).astype(np.int32)))


    # np.save(dst_dir.joinpath("query_gongga.npy"), np.ascontiguousarray(query.astype(np.float32)))
    # np.save(dst_dir.joinpath("key_gongga.npy"), np.ascontiguousarray(key.astype(np.float32)))
    # np.save(dst_dir.joinpath("value_gongga.npy"), np.ascontiguousarray(value.astype(np.float32)))
    # np.save(dst_dir.joinpath("mask_gongga.npy"), np.ascontiguousarray(mask.astype(np.float32)))
    # np.save(dst_dir.joinpath("cos_gongga.npy"), np.ascontiguousarray(pos_cos.astype(np.float32)))
    # np.save(dst_dir.joinpath("sin_gongga.npy"), np.ascontiguousarray(pos_sin.astype(np.float32)))
    # np.save(dst_dir.joinpath("Th_gongga.npy"), np.ascontiguousarray(history_token.astype(np.float32)))
    # np.save(dst_dir.joinpath("Tc_gongga.npy"), np.ascontiguousarray(cur_token.astype(np.float32)))
    # np.save(dst_dir.joinpath("Ts_gongga.npy"), np.ascontiguousarray(sys_token_len.astype(np.float32)))
    # np.save(dst_dir.joinpath("Tsr_gongga.npy"), np.ascontiguousarray(sys_real_token_len.astype(np.float32)))

    if wargs["decode_b2w"]:
        query = query.reshape((num_head_size // kv_group_size, kv_group_size, k_channel, 1)).transpose((0, 2, 3, 1))
    output_shape = query.shape[0:1] + value.shape[1:2] + query.shape[2:]
    output = np.zeros(output_shape)

    # dev_past_key_residual_cache = past_key_residual_cache.reshape(
    #     (num_kv_head_size, channel//key_device_config.subc_in, key_device_config.subc_in, 1, residual_depth)).transpose((0, 1, 3, 4, 2))
    # dev_past_value_residual_cache = past_value_residual_cache.reshape(
    #     (num_kv_head_size, channel//key_device_config.subc_in, key_device_config.subc_in, 1, residual_depth)).transpose((0, 1, 3, 4, 2))

    # TODO:
    # channel_align_macc = align(channel, key_device_config.mac_c)
    # dev_past_key_cahce = past_key_cache.reshape(num_kv_head_size, channel // key_device_config.mac_c,
    #                                         key_device_config.mac_c, max_token_len // key_device_config.mac_k,
    #                                         key_device_config.mac_k).transpose((0, 3, 1, 4, 2))
    # if is_group_quant:
    #     if key_device_config.kvcache_bits == 4:
    #         dev_past_key_cahce = (np.where(dev_past_key_cahce < 0, dev_past_key_cahce + 16, dev_past_key_cahce)).astype(np.uint8)
    #         input_past_key_cache = ((dev_past_key_cahce[..., 1::2] << 4) | (dev_past_key_cahce[..., ::2])).astype(np.uint8)
    #     else:
    #         input_past_key_cache = dev_past_key_cahce
    # else:
    #     input_past_key_cache = dev_past_key_cahce
    # # np.save(dst_dir.joinpath("past_key_cache.npy"), np.ascontiguousarray(input_past_key_cache))
    # np.save(dst_dir.joinpath("past_key_residual_cache.npy"), np.ascontiguousarray(dev_past_key_residual_cache))

    # input_past_value_cache = past_value_cache.reshape(num_kv_head_size, channel, 1, page_nums, tokens_per_page).transpose((0, 3, 1, 2, 4))
    # input_past_value_cache = input_past_value_cache.reshape((num_kv_head_size * page_nums, channel, 1, tokens_per_page))
    # input_past_value_cache = input_past_value_cache.reshape(
    #     (num_kv_head_size * page_nums, channel // value_device_config.mac_k, value_device_config.mac_k, 1, tokens_per_page)).transpose((0, 1, 3, 4, 2))

    # if is_group_quant:
    #     if value_device_config.kvcache_bits == 4:
    #         input_past_value_cache = (np.where(input_past_value_cache < 0, input_past_value_cache + 16, input_past_value_cache)).astype(np.uint8)
    #         input_past_value_cache = ((input_past_value_cache[..., 1::2] << 4) | (input_past_value_cache[..., ::2])).astype(np.uint8)

    # np.save(dst_dir.joinpath("past_value_cache.npy"), np.ascontiguousarray(input_past_value_cache))
    # np.save(dst_dir.joinpath("past_value_residual_cache.npy"), np.ascontiguousarray(dev_past_value_residual_cache))

    # if is_group_quant:
    #     wargs["store_type"] = "key"
    #     dev_key_params_cache_nchw = getGroupQuantCacheVNCHWParams(past_key_params_cache, **wargs)
    #     kpn, kpc, kph, kpw = dev_key_params_cache_nchw.shape
    #     subc_16 = key_device_config.bus_bits // 16
    #     dev_key_params_cache_nc1hwc2 = dev_key_params_cache_nchw.reshape([kpn, kpc//subc_16, subc_16, kph, kpw]).transpose([0,1,3,4,2])
    #     np.save(dst_dir.joinpath("past_key_params_cache.npy"), np.ascontiguousarray(dev_key_params_cache_nc1hwc2))

    #     wargs["store_type"] = "value"
    #     dev_value_params_cache_nchw = getGroupQuantCacheVNC1HWC2Params(past_value_params_cache, **wargs)
    #     np.save(dst_dir.joinpath("past_value_params_cache.npy"), np.ascontiguousarray(dev_value_params_cache_nchw))

    if (storage_separation and (infer_mask_v & infer_mask > 0)) or (not storage_separation):
        if rope:
            # q rope
            query_emb = np.zeros_like(query).astype(np.float16)
            if ts_align_in_tc:
                query_emb[..., :ts_align_w] = apply_rotary_pos_emb_np(
                    query[..., :ts_align_w], pos_cos[:, :, :, cur_pos_id:cur_pos_id+ts_align_w], pos_sin[:, :, :, cur_pos_id:cur_pos_id+ts_align_w])

                if ts_align_in_tc_w_q:
                    query_emb[..., question_shift:Tc] = apply_rotary_pos_emb_np(
                        query[..., question_shift:Tc], pos_cos[:, :, :, question_pos_d:question_pos_d+question_w], pos_sin[:, :, :, question_pos_d:question_pos_d+question_w])
            else:
                if eagle and sample_num_list[0] > 0:
                    group_num = sample_num_list[0]
                    value_start_id = 0
                    pos_id = cur_pos_id
                    if group_num > 0:
                        for i in range(group_num):
                            token_len = sample_num_list[i+1]
                            query_emb[..., value_start_id:value_start_id+token_len] = apply_rotary_pos_emb_np(
                                query[..., value_start_id:value_start_id+token_len],
                                pos_cos[..., pos_id : pos_id + 1],
                                pos_sin[..., pos_id : pos_id + 1],
                            )
                            pos_id += 1
                            value_start_id += token_len
                else:
                    query_emb[..., :new_Tc] = apply_rotary_pos_emb_np(
                        query[..., :new_Tc], pos_cos[:, :, :, cur_pos_id:cur_pos_id+Tc], pos_sin[:, :, :, cur_pos_id:cur_pos_id+Tc])
            # k rope
            key_emb = np.zeros_like(key).astype(np.float16)
            if ts_align_in_tc:
                key_emb[..., :ts_align_w] = apply_rotary_pos_emb_np(
                    key[..., :ts_align_w], pos_cos[:, :, :, cur_pos_id:cur_pos_id+ts_align_w], pos_sin[:, :, :, cur_pos_id:cur_pos_id+ts_align_w])

                if ts_align_in_tc_w_q:
                    key_emb[..., question_shift:Tc] = apply_rotary_pos_emb_np(
                        key[..., question_shift:Tc], pos_cos[:, :, :, question_pos_d:question_pos_d+question_w], pos_sin[:, :, :, question_pos_d:question_pos_d+question_w])
            else:
                if eagle and sample_num_list[0] > 0:
                    group_num = sample_num_list[0]
                    value_start_id = 0
                    pos_id = cur_pos_id
                    if group_num > 0:
                        for i in range(group_num):
                            token_len = sample_num_list[i+1]
                            key_emb[..., value_start_id:value_start_id+token_len] = apply_rotary_pos_emb_np(
                                key[..., value_start_id:value_start_id+token_len],
                                pos_cos[..., pos_id : pos_id + 1],
                                pos_sin[..., pos_id : pos_id + 1],
                            )
                            pos_id += 1
                            value_start_id += token_len
                else:
                    key_emb[..., :new_Tc] = apply_rotary_pos_emb_np(
                        key[..., :new_Tc], pos_cos[:, :, :, cur_pos_id:cur_pos_id+Tc], pos_sin[:, :, :, cur_pos_id:cur_pos_id+Tc])
        else:
            query_emb = query
            key_emb = key

        head_size = num_kv_head_size if decode_b2w else num_head_size
        for i in range(head_size):
        # for i in range(1):
            attn = np.zeros_like(attn).astype(np.float16)
            kv_head_id = i // kv_group_size if not decode_b2w else i
            if ts_w > 0:
                start_id = 0
                end_id = start_id + ts_w
                cache_size = ts_w + cache0_w + cache1_w + Tr
                if Th <= max_token_len or (not rope):
                    # group_quant_cache k matmul
                    group_start = start_id // group_size
                    group_width = align(ts_w, group_size) // group_size
                    group_end = group_start + group_width
                    if is_group_quant:
                        qk_ts_w_output = group_quant_cache_key_group_quant_matmul(key_device_config, query_emb[i, :, 0, :new_Tc],
                                                                    past_key_cache[kv_head_id, :, 0, start_id:end_id],
                                                                    past_key_params_cache[kv_head_id, :, :, 0, group_start:group_end], group_size)
                        qk_ts_w_output = qk_ts_w_output.reshape((1, ts_w, 1, new_Tc))
                        attn[:, start_id:end_id, :, :new_Tc] = qk_ts_w_output
                    else:
                        attn[:, start_id:end_id, 0, :new_Tc] = np.matmul(query_emb[i:i+1, :, 0, :new_Tc].transpose(
                            (0, 2, 1)), past_key_cache[kv_head_id:kv_head_id + 1, :, 0, start_id:end_id]).transpose((0, 2, 1))
                if rope:
                    if Th > max_token_len:
                        if eagle and sample_num_list[0] > 0:
                            group_num = sample_num_list[0]
                            value_start_id = 0
                            pos_id = cache_size
                            if group_num > 0:
                                for i in range(group_num):
                                    token_len = sample_num_list[i+1]
                                    query_emb_b[..., value_start_id:value_start_id+token_len] = apply_rotary_pos_emb_np(
                                        query[i:i+1, :, :, value_start_id:value_start_id+token_len],
                                        pos_cos[..., pos_id : pos_id + 1],
                                        pos_sin[..., pos_id : pos_id + 1],
                                    )
                                    pos_id += 1
                                    value_start_id += token_len
                        else:
                            query_emb_b = apply_rotary_pos_emb_np(
                                query[i:i+1, :, :, :new_Tc], pos_cos[:, :, :, cache_size:cache_size+Tc], pos_sin[:, :, :, cache_size:cache_size+Tc])
                        if is_group_quant:
                            # group_quant_cache k matmul
                            group_start = start_id // group_size
                            group_width = align(ts_w, group_size) // group_size
                            group_end = group_start + group_width
                            qk_ts_w_output = group_quant_cache_key_group_quant_matmul(key_device_config, query_emb_b[0, :, 0, :new_Tc],
                                                                        past_key_cache[kv_head_id, :, 0, start_id:end_id],
                                                                        past_key_params_cache[kv_head_id, :, :, 0, group_start:group_end], group_size)
                            qk_ts_w_output = qk_ts_w_output.reshape((1, ts_w, 1, new_Tc))
                            attn[:, start_id:end_id, :, :new_Tc] = qk_ts_w_output
                        else:
                            attn[:, start_id:end_id, 0, :new_Tc] = np.matmul(query_emb_b[:, :, 0, :new_Tc].transpose(
                                (0, 2, 1)), past_key_cache[kv_head_id:kv_head_id + 1, :, 0, start_id:end_id]).transpose((0, 2, 1))
                        if ts_w_align_subc > ts_w:
                            attn[:, end_id:ts_w_align_subc, 0, :new_Tc] = -65504
                        # np.save(dst_dir.joinpath("query_emb_b.npy"), np.ascontiguousarray(query_emb_b))
                supply_id = start_id + align(ts_w, subc_out)
                attn[:, start_id:end_id, 0, :new_Tc] *= scale
                attn[:, end_id:supply_id, 0, :new_Tc] = -65504

            # qk_cache1
            if cache1_w > 0:
                start_id = ts_w_align_subc
                end_id = start_id + cache1_w
                if is_group_quant:
                    # group_quant_cache k matmul
                    group_start = cache1_begin_id // group_size
                    group_width = align(cache1_w, group_size) // group_size
                    group_end = group_start + group_width
                    qk_ts_w_output = group_quant_cache_key_group_quant_matmul(key_device_config, query_emb[i, :, 0, :new_Tc],
                                                                    past_key_cache[kv_head_id, :, 0, cache1_begin_id:cache1_begin_id+cache1_w],
                                                                    past_key_params_cache[kv_head_id, :, :, 0, group_start:group_end], group_size)
                    qk_ts_w_output = qk_ts_w_output.reshape((1, cache1_w, 1, new_Tc))
                    attn[:, start_id:end_id, :, :new_Tc] = qk_ts_w_output
                else:
                    attn[:, start_id:end_id, 0, :new_Tc] = np.matmul(query_emb[i:i+1, :, 0, :new_Tc].transpose(
                        (0, 2, 1)), past_key_cache[kv_head_id:kv_head_id + 1, :, 0, cache1_begin_id:cache1_begin_id+cache1_w]).transpose((0, 2, 1))
                attn[:, start_id:end_id, 0, :new_Tc] *= scale
                if sliding_window_mask is not None:
                    mask_start_id = 0
                    mask_end_id = cache1_w
                    attn[:, start_id:end_id, 0, :new_Tc] += sliding_window_mask[:, mask_start_id:mask_end_id, 0, :Tc]

            # qk_cahce0
            if cache0_w > 0:
                start_id = ts_w_align_subc + cache1_w
                end_id = start_id + cache0_w
                if is_group_quant:
                    weight_start_id = Ts
                    weight_end_id = weight_start_id + cache0_w
                    # group_quant_cache k matmul
                    group_start = weight_start_id // group_size
                    group_width = align(cache0_w, group_size) // group_size
                    group_end = group_start + group_width
                    qk_ts_w_output = group_quant_cache_key_group_quant_matmul(key_device_config, query_emb[i, :, 0, :new_Tc],
                                                                    past_key_cache[kv_head_id, :, 0, weight_start_id:weight_end_id],
                                                                    past_key_params_cache[kv_head_id, :, :, 0, group_start:group_end], group_size)
                    qk_ts_w_output = qk_ts_w_output.reshape((1, cache0_w, 1, new_Tc))
                    attn[:, start_id:end_id, :, :new_Tc] = qk_ts_w_output
                else:
                    attn[:, start_id:end_id, 0, :new_Tc] = np.matmul(query_emb[i:i+1, :, 0, :new_Tc].transpose(
                        (0, 2, 1)), past_key_cache[kv_head_id:kv_head_id + 1, :, 0, Ts:Ts+cache0_w]).transpose((0, 2, 1))
                attn[:, start_id:end_id, 0, :new_Tc] *= scale
                if sliding_window_mask is not None:
                    mask_start_id = cache1_w
                    mask_end_id = mask_start_id + cache0_w
                    attn[:, start_id:end_id, 0, :new_Tc] += sliding_window_mask[:, mask_start_id:mask_end_id, 0, :Tc]

            # qk_tr
            if Tr > 0:
                start_id = ts_w_align_subc + cache0_w + cache1_w
                end_id = start_id + Tr
                supply_id = start_id + align(Tr, subc_out)
                attn[:, start_id:end_id, 0, :new_Tc] = np.matmul(query_emb[i:i+1, :, 0, :new_Tc].transpose(
                    (0, 2, 1)), past_key_residual_cache[kv_head_id:kv_head_id + 1, :, 0, :Tr]).transpose((0, 2, 1))
                attn[:, start_id:end_id, 0, :new_Tc] *= scale
                attn[:, end_id:supply_id, 0, :new_Tc] = -65504
                if sliding_window_mask is not None:
                    mask_start_id = cache0_w + cache1_w
                    mask_end_id = mask_start_id + Tr
                    attn[:, start_id:end_id, 0, :new_Tc] += sliding_window_mask[:, mask_start_id:mask_end_id, 0, :Tc]

            # qk_tc
            if Tc > 0:
                start_id = ts_w_align_subc + cache0_w + cache1_w + align(Tr, subc_out)
                end_id = start_id + Tc
                attn[:, start_id:end_id, 0, :new_Tc] = np.matmul(query_emb[i:i+1, :, 0, :new_Tc].transpose(
                    (0, 2, 1)), key_emb[kv_head_id:kv_head_id + 1, :, 0, :Tc]).transpose((0, 2, 1))
                attn[:, start_id:end_id, 0, :new_Tc] *= scale
                attn[:, start_id:end_id, 0, :new_Tc] += mask[:, :Tc, 0, :Tc]
                supply_id = start_id + align(Tc, subc_out)
                attn[:, end_id:supply_id, 0, :new_Tc] = -65504
                # np.save(dst_dir.joinpath("attn_matmul_golden.npy"), np.ascontiguousarray(attn))

            # softmax
            sink_value = None
            if sink_tensor is not None:
                sink_value = np.full((1, 1, 1, attn.shape[-1]), -65504, dtype=np.float16)
                sink_value[..., :new_Tc] = sink_tensor[i]
            reduce_max = np.max(attn[:, :attn_r_channel, :, :], axis=1, keepdims=True)
            if sink_value is not None:
                reduce_max = np.maximum(reduce_max, sink_value)
            # np.save(dst_dir.joinpath("softmax_reduce_max_golden.npy"), np.ascontiguousarray(reduce_max))
            # sub
            sub = np.zeros_like(attn).astype(np.float16)
            sub[:, :attn_r_channel, :, :] = attn[:, :attn_r_channel, :, :] - reduce_max
            # np.save(dst_dir.joinpath("softmax_sub_golden.npy"), np.ascontiguousarray(sub))
            # exp
            # exp = np.exp(sub)
            sub_temp = sub[:, :attn_r_channel, :, :]
            index = np.where(sub_temp < -10)
            s = np.array([1.4426950409], dtype=np.float32)
            tmp = ((1 << 10) * (s * sub_temp.astype(np.float32) + 14.94201519))
            exp_tmp = (tmp.astype(np.int16)).view(np.float16)
            exp_tmp[index] = 0
            exp = np.zeros_like(attn).astype(np.float16)
            exp[:, :attn_r_channel, :, :] = exp_tmp
            # np.save(dst_dir.joinpath("softmax_exp_golden.npy"), np.ascontiguousarray(exp))
            # sum
            reduce_sum = np.sum(exp[:, :attn_r_channel, :, :], axis=1, keepdims=True)
            if sink_value is not None:
                sink_sub = sink_value - reduce_max
                sink_tmp = ((1 << 10) * (s * sink_sub.astype(np.float32) + 14.94201519))
                sink_exp = sink_tmp.astype(np.int16).view(np.float16)
                sink_exp[sink_sub < -10] = 0
                reduce_sum += sink_exp
            # np.save(dst_dir.joinpath("softmax_reduce_sum_golden.npy"), np.ascontiguousarray(reduce_sum))
            # 1 / sum
            reciprocal = np.zeros_like(reduce_sum, dtype=np.float16)
            reciprocal[:, :, :, :] = 1.0 / reduce_sum[:, :, :, :]
            # np.save(dst_dir.joinpath("softmax_reciprocal_golden.npy"), np.ascontiguousarray(reciprocal))
            # mul
            attn[:, :attn_r_channel, :, :] = exp[:, :attn_r_channel, :, :] * reciprocal[:, :, :, :]

            # attn[:, :attn_r_channel, :, :] = softmax(attn[:, :attn_r_channel, :, :])
            attn[:, attn_r_channel:, :, :] = 0

            if ts_align_in_tc:
                tsr_begin_id = Tsr - Th
                tsr_w = Ts - Tsr
                attn[:, :, :attn_r_channel, tsr_begin_id:tsr_begin_id + tsr_w] = 0

            # attnv_tc
            if Tc > 0:
                start_id = ts_w_align_subc + cache0_w + cache1_w + align(Tr, subc_out)
                end_id = start_id + Tc
                output[i:i+1, :, 0, :new_Tc] = np.matmul(attn[:, start_id:end_id, 0, :new_Tc].transpose((0, 2, 1)),
                                                    value[kv_head_id:kv_head_id + 1, :, 0, :Tc].transpose((0, 2, 1))).transpose((0, 2, 1))

            # attnv_ts
            if ts_w > 0:
                start_id = 0
                end_id = start_id + ts_w
                if is_group_quant:
                    attnv_ts_w_output = group_quant_cache_value_group_quant_matmul(value_device_config, attn[0, start_id:end_id, 0, :new_Tc],
                                                                    past_value_cache[kv_head_id, :, 0, start_id:end_id],
                                                                    past_value_params_cache[kv_head_id, :, :, 0, start_id:end_id], group_size)
                    attnv_ts_w_output = attnv_ts_w_output.reshape((1, v_channel, 1, new_Tc))
                    output[i:i+1, :, :, :new_Tc] += attnv_ts_w_output
                    # np.save(dst_dir.joinpath("attnv_ts_w_output_golden.npy"), np.ascontiguousarray(attnv_ts_w_output))
                else:
                    ts_w_output = np.matmul(attn[:, start_id:end_id, 0, :new_Tc].transpose((0, 2, 1)),
                                        past_value_cache[kv_head_id:kv_head_id + 1, :, 0, start_id:end_id].transpose((0, 2, 1))).transpose((0, 2, 1))
                    output[i:i+1, :, 0, :new_Tc] += ts_w_output
                    # ts_w_output = ts_w_output.reshape((1, channel, 1, new_Tc))
                    # np.save(dst_dir.joinpath("tw_s_output_golden.npy"), np.ascontiguousarray(ts_w_output))
            # attnv_cache0
            if cache0_w > 0:
                feature_start_id = ts_w_align_subc + cache1_w
                feature_end_id = feature_start_id + cache0_w
                weight_start_id = Ts
                weight_end_id = weight_start_id + cache0_w
                if is_group_quant:
                    attnv_cache0_output = group_quant_cache_value_group_quant_matmul(value_device_config, attn[0, feature_start_id:feature_end_id, 0, :new_Tc],
                                                                        past_value_cache[kv_head_id, :, 0, weight_start_id:weight_end_id],
                                                                        past_value_params_cache[kv_head_id, :, :, 0, weight_start_id:weight_end_id], group_size)
                    attnv_cache0_output = attnv_cache0_output.reshape((1, v_channel, 1, new_Tc))
                    output[i:i+1, :, :, :new_Tc] += attnv_cache0_output
                else:
                    output[i:i+1, :, 0, :new_Tc] += np.matmul(attn[:, feature_start_id:feature_end_id, 0, :new_Tc].transpose((0, 2, 1)),
                                                    past_value_cache[kv_head_id:kv_head_id + 1, :, 0, weight_start_id:weight_end_id].transpose((0, 2, 1))).transpose((0, 2, 1))
            # attnv_cache1
            if cache1_w > 0:
                start_id = ts_w_align_subc
                end_id = start_id + cache1_w
                if is_group_quant:
                    attnv_cache1_output = group_quant_cache_value_group_quant_matmul(value_device_config, attn[0, start_id:end_id, 0, :new_Tc],
                                                                        past_value_cache[kv_head_id, :, 0, cache1_begin_id:cache1_begin_id+cache1_w],
                                                                        past_value_params_cache[kv_head_id, :, :, 0, cache1_begin_id:cache1_begin_id+cache1_w], group_size)
                    attnv_cache1_output = attnv_cache1_output.reshape((1, v_channel, 1, new_Tc))
                    output[i:i+1, :, :, :new_Tc] += attnv_cache1_output
                else:
                    output[i:i+1, :, 0, :new_Tc] += np.matmul(attn[:, start_id:end_id, 0, :new_Tc].transpose((0, 2, 1)),
                                                    past_value_cache[kv_head_id:kv_head_id + 1, :, 0, cache1_begin_id:cache1_begin_id+cache1_w].transpose((0, 2, 1))).transpose((0, 2, 1))
            # attnv_tr
            if Tr > 0:
                start_id = ts_w_align_subc + cache0_w + cache1_w
                align_Tr = align(Tr, subc_out)
                end_id = start_id + align_Tr
                output[i:i+1, :, 0, :new_Tc] += np.matmul(attn[:, start_id:end_id, 0, :new_Tc].transpose((0, 2, 1)),
                                                    past_value_residual_cache[kv_head_id:kv_head_id + 1, :, 0, :align_Tr].transpose((0, 2, 1))).transpose((0, 2, 1))

        if decode_b2w:
            output = output.transpose((0, 3, 1, 2)).reshape((num_head_size, v_channel, 1, Tc))

        attn_channel = align(ts_w, subc_out) + cache0_w + cache1_w + align(Tr, subc_out) + Tc
        # np.save(dst_dir.joinpath("attn_channel.npy"), np.array([attn_channel]).astype(np.int32))
        # np.save(dst_dir.joinpath("query_emb.npy"), np.ascontiguousarray(query_emb))
        # np.save(dst_dir.joinpath("key_emb.npy"), np.ascontiguousarray(key_emb))

        if ts_align_in_tc:
            if is_group_quant:
                tsr_begin_id = Tsr - Th
                tsr_w = Ts - Tsr
                tsr_align_group_size = align(Tsr, group_size)
                tsr_align_group_size_w = tsr_align_group_size - Tsr
                ts_w_clear_start = tsr_align_group_size - Th
                ts_clear_w = Ts - tsr_align_group_size
                key_emb[:, :, :, tsr_begin_id:tsr_begin_id+tsr_align_group_size_w] = key_emb[:, :, :, tsr_begin_id-1:tsr_begin_id]
                key_emb[:, :, :, ts_w_clear_start:ts_w_clear_start+ts_clear_w] = 0
                value[:, :, :, tsr_begin_id:tsr_begin_id+tsr_w] = 0
            else:
                tsr_begin_id = Tsr - Th
                tsr_w = Ts - Tsr
                key_emb[:, :, :, tsr_begin_id:tsr_begin_id+tsr_w] = 0
                value[:, :, :, tsr_begin_id:tsr_begin_id+tsr_w] = 0
            # np.save(dst_dir.joinpath("value_clear.npy"), np.ascontiguousarray(value))
            # np.save(dst_dir.joinpath("key_emb_clear.npy"), np.ascontiguousarray(key_emb))

    if (storage_separation and (infer_mask_v & store_mask > 0)) or (not storage_separation):
        # 重新获取控制变量
        # Th = wargs["Th"]
        # Tc = wargs["Tc"]
        # Ts = wargs["Ts"]
        Ti = ori_Ti
        Tr = ori_Tr
        store_begin_id = ori_store_begin_id
        longest_surviving_id = ori_longest_surviving_id

        if eagle and select_id_list[0] > 0:
            key_emb[..., :select_id_list[0]] = key_emb[..., select_id_list[1:]]
            value[..., :select_id_list[0]] = value[..., select_id_list[1:]]
            Tc = select_id_list[0]

        # k store
        if is_group_quant:
            k_store_info, new_past_key_cache, new_past_key_residual_cache, new_past_key_params_cache = kv_store_GroupQuantCache_infer("key", key_device_config,
                key_emb, past_key_cache, past_key_residual_cache, past_key_params_cache, Th, Tc, Ts, Ti, Tr, store_begin_id,
                longest_surviving_id, max_token_len, group_size, residual_depth, key_zp_width, key_scale_width)
        else:
            k_store_info, new_past_key_cache, new_past_key_residual_cache = kv_store_infer(
                key_emb, past_key_cache, past_key_residual_cache, Th, Tc, Ts, Ti, Tr, store_begin_id, longest_surviving_id, max_token_len, group_size, residual_depth)

        # v store
        if is_group_quant:
            v_store_info, new_past_value_cache, new_past_value_residual_cache, new_past_value_params_cache = kv_store_GroupQuantCache_infer("value",
                value_device_config, value, past_value_cache, past_value_residual_cache, past_value_params_cache, Th, Tc, Ts, Ti, Tr, store_begin_id,
                longest_surviving_id, max_token_len, group_size, residual_depth, value_zp_width, value_scale_width)
        else:
            v_store_info, new_past_value_cache, new_past_value_residual_cache = kv_store_infer(
                value, past_value_cache, past_value_residual_cache, Th, Tc, Ts, Ti, Tr, store_begin_id, longest_surviving_id, max_token_len, group_size, residual_depth)
    else:
        new_past_key_cache = past_key_cache
        new_past_key_residual_cache = past_key_residual_cache
        new_past_value_cache = past_value_cache
        new_past_value_residual_cache = past_value_residual_cache
        if is_group_quant:
            new_past_key_params_cache = past_key_params_cache
            new_past_value_params_cache = past_value_params_cache

    # if v_store_info["trans1_min_max"] is not None:
    #     np.save(dst_dir.joinpath("trans1_min_max.npy"), np.ascontiguousarray(v_store_info["trans1_min_max"]))
    # if v_store_info["trans1_scale"] is not None:
    #     np.save(dst_dir.joinpath("trans1_scale.npy"), np.ascontiguousarray(v_store_info["trans1_scale"]))
    # if v_store_info["trans1_reciprocal_scale"] is not None:
    #     np.save(dst_dir.joinpath("trans1_reciprocal_scale.npy"),
    #             np.ascontiguousarray(v_store_info["trans1_reciprocal_scale"]))
    # if v_store_info["trans1_quant_cache"] is not None:
    #     # v_quant_cache = v_store_info["trans1_quant_cache"].astype(np.int16)
    #     # v_quant_cache = (np.where(v_quant_cache < 0, v_quant_cache + 16, v_quant_cache)).astype(np.uint8)
    #     # v_quant_cache = ((v_quant_cache[..., 1::2] << 4) | (v_quant_cache[..., ::2])).astype(np.uint8)
    #     # np.save(dst_dir.joinpath("trans1_quant_cache.npy"), np.ascontiguousarray(v_quant_cache))
    #     np.save(dst_dir.joinpath("trans1_quant_cache.npy"), np.ascontiguousarray(v_store_info["trans1_quant_cache"]))
    # if v_store_info["trans1_zp"] is not None:
    #     zp = v_store_info["trans1_zp"]
    #     if value_device_config.zp_bits == 8:
    #         np.save(dst_dir.joinpath("trans1_zp_fp16.npy"), np.ascontiguousarray(zp))
    #         zp = fp32_to_fp8(zp.astype(np.float32))
    #     np.save(dst_dir.joinpath("trans1_zp.npy"), np.ascontiguousarray(zp))
    # if v_store_info["trans1_value_quant_scale"] is not None:
    #     np.save(dst_dir.joinpath("trans1_value_quant_scale.npy"),
    #             np.ascontiguousarray(v_store_info["trans1_value_quant_scale"]))

    # if k_store_info["trans1_min_max"] is not None:
    #     np.save(dst_dir.joinpath("trans1_min_max.npy"), np.ascontiguousarray(k_store_info["trans1_min_max"]))
    # if k_store_info["trans1_scale"] is not None:
    #     np.save(dst_dir.joinpath("trans1_scale.npy"), np.ascontiguousarray(k_store_info["trans1_scale"]))
    # if k_store_info["trans1_reciprocal_scale"] is not None:
    #     np.save(dst_dir.joinpath("trans1_reciprocal_scale.npy"),
    #             np.ascontiguousarray(k_store_info["trans1_reciprocal_scale"]))
    # if k_store_info["trans1_quant_cache"] is not None:
    #     # v_quant_cache = k_store_info["trans1_quant_cache"].astype(np.int16)
    #     # v_quant_cache = (np.where(v_quant_cache < 0, v_quant_cache + 16, v_quant_cache)).astype(np.uint8)
    #     # v_quant_cache = ((v_quant_cache[..., 1::2] << 4) | (v_quant_cache[..., ::2])).astype(np.uint8)
    #     # np.save(dst_dir.joinpath("trans1_quant_cache.npy"), np.ascontiguousarray(v_quant_cache))
    #     np.save(dst_dir.joinpath("trans1_quant_cache.npy"), np.ascontiguousarray(k_store_info["trans1_quant_cache"]))
    # if k_store_info["trans1_zp"] is not None:
    #     zp = k_store_info["trans1_zp"]
    #     if value_device_config.zp_bits == 8:
    #         np.save(dst_dir.joinpath("trans1_zp_fp16.npy"), np.ascontiguousarray(zp))
    #         zp = fp32_to_fp8(zp.astype(np.float32))
    #     np.save(dst_dir.joinpath("trans1_zp.npy"), np.ascontiguousarray(zp))
    # if k_store_info["trans1_value_quant_scale"] is not None:
    #     np.save(dst_dir.joinpath("trans1_value_quant_scale.npy"),
    #             np.ascontiguousarray(k_store_info["trans1_value_quant_scale"]))

    # if v_store_info["pre_trans1_min_max"] is not None:
    #     np.save(dst_dir.joinpath("pre_trans1_min_max.npy"), np.ascontiguousarray(v_store_info["pre_trans1_min_max"]))
    # if v_store_info["pre_trans1_scale"] is not None:
    #     np.save(dst_dir.joinpath("pre_trans1_scale.npy"), np.ascontiguousarray(v_store_info["pre_trans1_scale"]))
    # if v_store_info["pre_trans1_reciprocal_scale"] is not None:
    #     np.save(dst_dir.joinpath("pre_trans1_reciprocal_scale.npy"),
    #             np.ascontiguousarray(v_store_info["pre_trans1_reciprocal_scale"]))
    # if v_store_info["pre_trans1_quant_cache"] is not None:
    #     # v_quant_cache = v_store_info["pre_trans1_quant_cache"].astype(np.int16)
    #     # v_quant_cache = (np.where(v_quant_cache < 0, v_quant_cache + 16, v_quant_cache)).astype(np.uint8)
    #     # v_quant_cache = ((v_quant_cache[..., 1::2] << 4) | (v_quant_cache[..., ::2])).astype(np.uint8)
    #     # np.save(dst_dir.joinpath("pre_trans1_quant_cache.npy"), np.ascontiguousarray(v_quant_cache))
    #     np.save(dst_dir.joinpath("pre_trans1_quant_cache.npy"), np.ascontiguousarray(v_store_info["pre_trans1_quant_cache"]))
    # if v_store_info["pre_trans1_zp"] is not None:
    #     zp = v_store_info["pre_trans1_zp"]
    #     if value_device_config.zp_bits == 8:
    #         np.save(dst_dir.joinpath("pre_trans1_zp_fp16.npy"), np.ascontiguousarray(zp))
    #         zp = fp32_to_fp8(zp.astype(np.float32))
    #     np.save(dst_dir.joinpath("pre_trans1_zp.npy"), np.ascontiguousarray(zp))
    # if v_store_info["pre_trans1_value_quant_scale"] is not None:
    #     np.save(dst_dir.joinpath("pre_trans1_value_quant_scale.npy"),
    #             np.ascontiguousarray(v_store_info["pre_trans1_value_quant_scale"]))

    # np.save(dst_dir.joinpath("output_golden.npy"), np.ascontiguousarray(output))
    # np.save(dst_dir.joinpath("attn_golden.npy"), np.ascontiguousarray(attn))
    # output_golden_dev = np.ascontiguousarray(output.reshape(
    #     num_head_size, channel//device_config.subc_in, device_config.subc_in, 1, bucket_size).transpose((0, 1, 3, 4, 2)))
    # output_golden_dev.tofile(dst_dir.joinpath("output_golden_dev.bin"))
    # np.save(dst_dir.joinpath("output_golden_dev.npy"), output_golden_dev)

    new_Ti = k_store_info["Ti"]
    new_Tr = k_store_info["Tr"]
    new_store_begin_id = k_store_info["store_begin_id"]
    new_longest_surviving_id = k_store_info["longest_surviving_id"]

    if is_group_quant:
        return output, new_Ti, new_Tr, new_store_begin_id, new_longest_surviving_id, \
               new_past_key_cache, new_past_key_residual_cache, new_past_value_cache, new_past_value_residual_cache, \
               new_past_key_params_cache, new_past_value_params_cache
    else:
        return output, new_Ti, new_Tr, new_store_begin_id, new_longest_surviving_id, \
               new_past_key_cache, new_past_key_residual_cache, new_past_value_cache, new_past_value_residual_cache \

    # np.save(dst_dir.joinpath("Ti_golden.npy"), np.array([new_Ti]).astype(np.int32))
    # np.save(dst_dir.joinpath("Tr_golden.npy"), np.array([new_Tr]).astype(np.int32))
    # np.save(dst_dir.joinpath("store_begin_id_golden.npy"), np.array([new_store_begin_id]).astype(np.int32))
    # np.save(dst_dir.joinpath("longest_surviving_id_golden.npy"), np.array([new_longest_surviving_id]).astype(np.int32))

    # new_past_key_cache = new_past_key_cache.reshape(num_kv_head_size, channel // key_device_config.mac_c,
    #                                             key_device_config.mac_c, max_token_len // key_device_config.mac_k,
    #                                             key_device_config.mac_k).transpose((0, 3, 1, 4, 2))
    # if is_group_quant:
    #     if key_device_config.kvcache_bits == 4:
    #         new_past_key_cache = (np.where(new_past_key_cache < 0, new_past_key_cache + 16, new_past_key_cache)).astype(np.uint8)
    #         new_past_key_cache = ((new_past_key_cache[..., 1::2] << 4) | (new_past_key_cache[..., ::2])).astype(np.uint8)
    # np.save(dst_dir.joinpath("past_key_cache_golden.npy"), np.ascontiguousarray(new_past_key_cache))
    # np.save(dst_dir.joinpath("past_key_residual_cache_golden.npy"), np.ascontiguousarray(new_past_key_residual_cache))

    # new_past_value_cache = new_past_value_cache.reshape(num_kv_head_size, channel, 1, page_nums, tokens_per_page).transpose((0, 3, 1, 2, 4))
    # new_past_value_cache = new_past_value_cache.reshape((num_kv_head_size * page_nums, channel, 1, tokens_per_page))
    # if is_group_quant:
    #     new_past_value_cache = new_past_value_cache.reshape(
    #         (num_kv_head_size * page_nums, channel // value_device_config.mac_k, value_device_config.mac_k, 1, tokens_per_page))
    #     new_past_value_cache = new_past_value_cache.transpose((0, 1, 3, 4, 2))
    #     if value_device_config.kvcache_bits == 4:
    #         new_past_value_cache = (np.where(new_past_value_cache < 0, new_past_value_cache + 16, new_past_value_cache)).astype(np.uint8)
    #         new_past_value_cache = ((new_past_value_cache[..., 1::2] << 4) | (new_past_value_cache[..., ::2])).astype(np.uint8)
    # np.save(dst_dir.joinpath("past_value_cache_golden.npy"), np.ascontiguousarray(new_past_value_cache))
    # np.save(dst_dir.joinpath("past_value_residual_cache_golden.npy"), np.ascontiguousarray(new_past_value_residual_cache))
    # if is_group_quant:
    #     wargs["store_type"] = "key"
    #     past_key_params_cache_nchw = getGroupQuantCacheVNCHWParams(new_past_key_params_cache, **wargs)
    #     np.save(dst_dir.joinpath("past_key_params_cache_golden.npy"), np.ascontiguousarray(past_key_params_cache_nchw))
    #     wargs["store_type"] = "value"
    #     past_value_params_cache_nchw = getGroupQuantCacheVNCHWParams(new_past_value_params_cache, **wargs)
    #     np.save(dst_dir.joinpath("past_value_params_cache_golden.npy"), np.ascontiguousarray(past_value_params_cache_nchw))
        # value_zp, value_scale = params_split_to_zp_scale(past_value_params_cache_nchw, 1, 2)
        # np.save(dst_dir.joinpath("past_value_zp.npy"), np.ascontiguousarray(value_zp))
        # np.save(dst_dir.joinpath("past_value_scale.npy"), np.ascontiguousarray(value_scale))

    # root = str(dst_dir)
    # files = [file for file in os.listdir(root) if "npy" in file and not file.startswith("._")]
    # files.sort()
    # for i, file in enumerate(files):
    #     src_path = os.path.join(root, file)
    #     dst_path = os.path.join(root, file.replace("npy", "tensor"))
    #     nchw_npy_to_nc1hwc2_tensor(src_path, dst_path)
    #     undefine_npy_to_tensor(src_path, dst_path)

    # model = createExAttentionOnnx(**wargs)
    # if model is not None:
    #     onnx.save(model, dst_dir.joinpath("exAttention.onnx"))
    # else:
    #     print("Generate failed")
    #     exit()
    # if rope:
    #     inputs = ["query", "key", "value", "mask", "cos", "sin", "Th", "Tc", "Ts", "Tsr"]
    # else:
    #     inputs = ["query", "key", "value", "mask", "Th", "Tc", "Ts", "Tsr"]
    # for i, input in enumerate(inputs):
    #     inputs[i] = str(dst_dir.absolute().joinpath("{}.npy".format(input)))
    # inputs = "#".join(inputs)

    # with open(dst_dir.joinpath('rknn_compiler_out.txt'), 'w') as f:
    #     with open(dst_dir.joinpath('rknn_compiler_err.txt'), 'w') as fe:
    #         # nrv_tool_chain_path = '/data0/toolchain/gcc/linux-x86/riscv/riscv32-rknrv-elf-gcc-linux-x64'
    #         # nrv_out_dir = "/data1/home/zjn/wsp/rknn_compiler_unittest/tmp"

    #         json_config = {
    #             "target_name": "RKNPU",
    #             "target_version": wargs["target"],
    #             "request_type": "float16",
    #             "onnx_model_path": str(dst_dir.joinpath("exAttention.onnx")) if "onnx" not in wargs else wargs["onnx"],
    #             "external_weights_dir": "" if "external_weights_dir" not in wargs else wargs["external_weights_dir"],
    #             "rknn_model_path": str(dst_dir.joinpath("exAttention.rknn")) if "onnx" not in wargs else str(dst_dir.joinpath(os.path.basename(wargs["onnx"].replace(".onnx", ".rknn")))),
    #             "model_inputs_path": "",
    #             "dump_dir": str(dst_dir),
    #             "channel_mean": "0",
    #             "channel_std": "1",
    #             "channel_order": "0",
    #             "model_type": wargs["model_type"],
    #             "nrv_gen_code_dir": "./tmp",
    #             "verbose_level": 6,
    #             "work_core_id": 0,
    #             "simulator_params": {
    #                 "dyn_shape_id": 0,
    #                 "onnx_id": 0,
    #                 "simulate_en": 0,
    #             },
    #             "optimize_options": {
    #                 "compress": 0,
    #                 "global_fuse": 1,
    #                 "conv_eltwise_activation_fuse": 1,
    #                 "enable_argb_group": 0,
    #                 "enable-layout-match": 1,
    #                 "pipeline_fuse": 0,
    #                 "enable_flash_attention": 0,
    #                 "debug_nrv_code": wargs["debug"],
    #                 "enable_rknrv_only": 0,
    #                 "opTargetMaps": {}
    #             },
    #             "kv_cache_config":{
    #                 "store_method": wargs["store_method"],
    #                 "kv_cache_dtype": wargs["kv_cache_dtype"],
    #                 "group_size": wargs["group_size"],
    #                 "residual_depth": wargs["residual_depth"],
    #                 "max_token_len": wargs["max_token_len"],
    #                 "enable_dyn_context": wargs["enable_dyn_context"]
    #             },
    #         }
    #         import json
    #         compiler_config_path = os.path.join(
    #             dst_dir.absolute(), 'rknn_compiler_config.json')
    #         with open(compiler_config_path, 'w') as fc:
    #             json.dump(json_config, fc, indent=4)

    #         env = os.environ.copy()
    #         env.update({
    #             "LD_LIBRARY_PATH": compiler_lib_path,
    #             "RKNN_DUMP_TXT_TENSOR": "1",
    #             "RKNN_LOG_LEVEL": "5",
    #             "RKNN_MODEL_TYPE": "full",
    #             "RKNN_DUMP_QUANT": "0",
    #         })
    #         command = "{} {}".format(compiler_exe_path, compiler_config_path)
    #         print(command)
    #         res = subprocess.run(
    #             command,
    #             env=env,
    #             shell=True, check=False, stdout=f, stderr=fe)
